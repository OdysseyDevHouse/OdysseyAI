-- MariaDB dump 10.19  Distrib 10.5.13-MariaDB, for Win64 (AMD64)
--
-- Host: 105.30.57.88    Database: ody10006_master
-- ------------------------------------------------------
-- Server version	10.6.22-MariaDB-0ubuntu0.22.04.1-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `activity_log`
--

DROP TABLE IF EXISTS `activity_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `activity_log` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `entity` varchar(40) NOT NULL,
  `entity_id` int(10) unsigned DEFAULT NULL,
  `action` varchar(40) NOT NULL,
  `detail` varchar(400) DEFAULT NULL,
  `changes` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`changes`)),
  `user_id` int(10) unsigned DEFAULT NULL,
  `user_name` varchar(120) NOT NULL DEFAULT '',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `ix_activity_entity` (`entity`,`entity_id`,`created_at`),
  KEY `ix_activity_user` (`user_id`,`created_at`),
  KEY `ix_activity_created` (`created_at`),
  KEY `ix_activity_entity_created` (`entity`,`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=83 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `activity_log`
--

LOCK TABLES `activity_log` WRITE;
/*!40000 ALTER TABLE `activity_log` DISABLE KEYS */;
INSERT INTO `activity_log` VALUES (1,'online_store',NULL,'update','Online store settings changed',NULL,1,'Tiaan Smith','2026-08-07 09:36:58'),(2,'online_store',NULL,'image','Front-page picture uploaded: ChatGPT Image Aug 9, 2026, 09_53_25 AM.png',NULL,1,'Tiaan Smith','2026-08-09 10:02:23'),(3,'online_store',NULL,'theme','Storefront appearance changed',NULL,1,'Tiaan Smith','2026-08-09 10:02:29'),(4,'customer',1,'create','CUST-1 — Tiaan Smith',NULL,1,'Tiaan Smith','2026-08-09 10:08:58'),(5,'customer',1,'update','CUST-1 — Tiaan Smith',NULL,1,'Tiaan Smith','2026-08-09 10:13:36'),(6,'customer',1,'ledger','Invoice INV000002 317.40',NULL,1,'Tiaan Smith','2026-08-09 10:14:30'),(7,'customer',1,'update','CUST-1 — Tiaan Smith',NULL,1,'Tiaan Smith','2026-08-09 10:15:11'),(8,'online_store',NULL,'publish','Front page published',NULL,1,'Tiaan Smith','2026-08-09 10:50:03'),(9,'online_store',NULL,'publish','Front page published',NULL,1,'Tiaan Smith','2026-08-09 10:50:26'),(10,'online_store',NULL,'image','Front-page picture uploaded: ChatGPT Image Aug 9, 2026, 11_02_31 AM.png',NULL,1,'Tiaan Smith','2026-08-09 11:28:53'),(11,'online_store',NULL,'image','Front-page picture uploaded: ChatGPT Image Aug 9, 2026, 11_02_35 AM.png',NULL,1,'Tiaan Smith','2026-08-09 11:29:07'),(12,'online_store',NULL,'image','Front-page picture uploaded: ChatGPT Image Aug 9, 2026, 11_02_37 AM.png',NULL,1,'Tiaan Smith','2026-08-09 11:29:17'),(13,'online_store',NULL,'theme','Storefront appearance changed',NULL,1,'Tiaan Smith','2026-08-09 11:29:27'),(14,'online_store',NULL,'publish','Front page published',NULL,1,'Tiaan Smith','2026-08-09 11:29:31'),(15,'product',9,'icon_set','Till icon set',NULL,1,'Tiaan Smith','2026-08-09 11:46:00'),(16,'online_store',NULL,'create','Delivery area “George”',NULL,1,'Tiaan Smith','2026-08-09 12:29:02'),(17,'online_store',NULL,'update','Online store settings changed',NULL,1,'Tiaan Smith','2026-08-09 12:29:06'),(18,'customer',1,'ledger','Payment -55.00',NULL,1,'Tiaan Smith','2026-08-09 12:48:00'),(19,'online_store',NULL,'image','Picture uploaded: ChatGPT Image Aug 9, 2026, 12_47_26 PM (3).png',NULL,1,'Tiaan Smith','2026-08-09 12:49:40'),(20,'online_store',NULL,'image','Picture uploaded: ChatGPT Image Aug 9, 2026, 12_47_26 PM (4).png',NULL,1,'Tiaan Smith','2026-08-09 12:49:47'),(21,'online_store',NULL,'image','Picture uploaded: ChatGPT Image Aug 9, 2026, 12_47_25 PM (1).png',NULL,1,'Tiaan Smith','2026-08-09 12:50:01'),(22,'online_store',NULL,'image','Picture uploaded: ChatGPT Image Aug 9, 2026, 12_47_26 PM (2).png',NULL,1,'Tiaan Smith','2026-08-09 12:50:06'),(23,'online_store',NULL,'publish','Front page published',NULL,1,'Tiaan Smith','2026-08-09 12:50:16'),(24,'online_store',9,'unpublish','Product “Bacon & Blue Smash” hidden from the online store',NULL,1,'Tiaan Smith','2026-08-09 12:51:39'),(25,'online_store',9,'publish','Product “Bacon & Blue Smash” shown in the online store',NULL,1,'Tiaan Smith','2026-08-09 12:51:40'),(26,'online_store',9,'unpublish','Product “Bacon & Blue Smash” hidden from the online store',NULL,1,'Tiaan Smith','2026-08-09 12:51:41'),(27,'online_store',9,'publish','Product “Bacon & Blue Smash” shown in the online store',NULL,1,'Tiaan Smith','2026-08-09 12:51:42'),(28,'bank',2,'create','Created bank account NEDBANK — Odyssey George Nedbank Card',NULL,1,'Tiaan Smith','2026-08-10 07:33:21'),(29,'expense',1,'finalise','EXP000001 · 1500.00 · Shell Garage',NULL,1,'Tiaan Smith','2026-08-10 07:41:07'),(30,'online_store',NULL,'image','Picture uploaded: ChatGPT Image Aug 9, 2026, 12_45_08 PM (2).png',NULL,1,'Tiaan Smith','2026-08-10 09:28:01'),(31,'online_store',NULL,'image','Picture uploaded: ChatGPT Image Aug 10, 2026, 08_05_38 AM (5).png',NULL,1,'Tiaan Smith','2026-08-10 09:28:25'),(32,'online_store',2,'create','Page “Tiaan test” added',NULL,1,'Tiaan Smith','2026-08-10 13:14:08'),(33,'online_store',2,'publish','Published “Tiaan test”',NULL,1,'Tiaan Smith','2026-08-10 13:16:08'),(34,'price_schedule',1,'create','Price change \"Tiaan test\" started',NULL,1,'Tiaan Smith','2026-08-10 14:15:30'),(35,'supplier',1,'create','SUPP00001 — Smash burger patties',NULL,1,'Tiaan Smith','2026-08-10 15:54:02'),(36,'customer',1,'ledger','Invoice INV000003 149.50',NULL,1,'Tiaan Smith','2026-08-11 13:46:45'),(37,'customer',1,'reverse','Reversed Invoice INV000003 — Void of INV000003: test',NULL,1,'Tiaan Smith','2026-08-11 13:50:30'),(38,'supplier',4,'create','ORD24876588 — Order Test Suppliers',NULL,1,'Order Test','2026-08-12 10:54:36'),(39,'supplier',4,'ledger','Invoice INV-24876588 460.00',NULL,1,'Order Test','2026-08-12 10:54:36'),(40,'supplier',4,'ledger','Invoice GRV000002 690.00',NULL,1,'Order Test','2026-08-12 10:54:37'),(41,'supplier',5,'create','PUR24885581 — Purchase Test Wholesalers',NULL,1,'Purchase Test','2026-08-12 10:54:45'),(42,'supplier',5,'ledger','Invoice SI-24885581 1150.00',NULL,1,'Purchase Test','2026-08-12 10:54:45'),(43,'supplier',5,'ledger','Invoice SI-24885581-2 2300.00',NULL,1,'Purchase Test','2026-08-12 10:54:45'),(44,'supplier',5,'ledger','Invoice SI-24885581-3 1250.00',NULL,1,'Purchase Test','2026-08-12 10:54:46'),(45,'supplier',5,'ledger','Invoice GRV000006 1250.00',NULL,1,'Purchase Test','2026-08-12 10:54:46'),(46,'supplier',5,'ledger','Credit note REV-GRV000004 -2300.00',NULL,1,'Purchase Test','2026-08-12 10:54:46'),(47,'supplier',6,'create','PUR24901248 — Purchase Test Wholesalers',NULL,1,'Purchase Test','2026-08-12 10:55:01'),(48,'supplier',6,'ledger','Invoice SI-24901248 1150.00',NULL,1,'Purchase Test','2026-08-12 10:55:01'),(49,'supplier',6,'ledger','Invoice SI-24901248-2 2300.00',NULL,1,'Purchase Test','2026-08-12 10:55:01'),(50,'supplier',6,'ledger','Invoice SI-24901248-3 1250.00',NULL,1,'Purchase Test','2026-08-12 10:55:01'),(51,'supplier',6,'ledger','Invoice GRV000010 1250.00',NULL,1,'Purchase Test','2026-08-12 10:55:01'),(52,'supplier',6,'ledger','Credit note REV-GRV000008 -2300.00',NULL,1,'Purchase Test','2026-08-12 10:55:01'),(53,'supplier',7,'create','DFT24942714 — Draft Test Wholesalers',NULL,1,'Draft Test','2026-08-12 10:55:42'),(54,'supplier',7,'ledger','Invoice INV-24942714 1150.00',NULL,1,'Draft Test','2026-08-12 10:55:43'),(55,'supplier',8,'create','RO24949459 — Reorder Test Supply',NULL,1,'Reorder Test','2026-08-12 10:55:49'),(56,'supplier',8,'ledger','Invoice GRV000012 345.00',NULL,1,'Reorder Test','2026-08-12 10:55:49'),(57,'supplier',9,'create','GRD24950513 — Guard Test Supply',NULL,1,'Guard Test','2026-08-12 10:55:50'),(58,'supplier',9,'ledger','Invoice TIE-24950513 1150.00',NULL,1,'Guard Test','2026-08-12 10:55:50'),(59,'supplier',9,'ledger','Invoice GRV000014 1150.00',NULL,1,'Guard Test','2026-08-12 10:55:50'),(60,'supplier',9,'ledger','Invoice GRV000015 1150.00',NULL,1,'Guard Test','2026-08-12 10:55:50'),(61,'supplier',9,'ledger','Invoice GRV000016 11.50',NULL,1,'Guard Test','2026-08-12 10:55:50'),(62,'supplier',10,'create','GRC24950513 — Guard Test Couriers',NULL,1,'Guard Test','2026-08-12 10:55:50'),(63,'supplier',9,'ledger','Invoice GRV000017 1150.00',NULL,1,'Guard Test','2026-08-12 10:55:50'),(64,'supplier',10,'ledger','Invoice GRV000017-F10 230.00',NULL,1,'Guard Test','2026-08-12 10:55:50'),(65,'supplier',9,'ledger','Invoice GRV000018 1150.00',NULL,1,'Guard Test','2026-08-12 10:55:51'),(66,'supplier',7,'ledger','Invoice 12312313 138.00',NULL,1,'Tiaan Smith','2026-08-24 12:49:22'),(67,'special',1,'create','Special created: Test Meeting',NULL,1,'Tiaan Smith','2026-08-24 13:01:08'),(68,'special',2,'create','Special created: Combo test',NULL,1,'Tiaan Smith','2026-08-24 13:02:40'),(69,'special',1,'update','Special switched off: Test Meeting',NULL,1,'Tiaan Smith','2026-08-24 13:03:30'),(70,'special',2,'update','Special changed: Combo test',NULL,1,'Tiaan Smith','2026-08-24 13:04:13'),(71,'price_schedule',2,'create','Price change \"Test\" started',NULL,1,'Tiaan Smith','2026-08-24 13:05:49'),(72,'user',1,'totp_cleared','Two-factor cleared for Tiaan Smith — they can sign in with password alone until they re-enrol',NULL,1,'Tiaan Smith','2026-08-25 19:11:36'),(73,'setting',1,'api_key_created','API key \"oliver\" minted',NULL,1,'Tiaan Smith','2026-08-26 14:22:32'),(74,'customer',2,'create','CUST00001 — Koos',NULL,1,'Tiaan Smith','2026-08-26 15:04:04'),(75,'gift_card',NULL,'gift_cards_generated','5 cards generated',NULL,1,'Tiaan Smith','2026-08-26 15:06:51'),(76,'special',3,'create','Special created: 10% off specials',NULL,1,'Tiaan Smith','2026-08-26 15:59:22'),(77,'special',4,'create','Special created: 5% off special',NULL,1,'Tiaan Smith','2026-08-26 16:20:12'),(78,'special',1,'update','Special switched on: Test Meeting',NULL,1,'Tiaan Smith','2026-08-26 16:20:28'),(79,'special',2,'update','Special changed: 15% off special',NULL,1,'Tiaan Smith','2026-08-26 16:20:54'),(80,'special',1,'update','Special changed: 20% off special',NULL,1,'Tiaan Smith','2026-08-26 16:21:14'),(81,'loyalty',NULL,'settings_changed','Earn R1 = 1 point · 10 points = R1',NULL,1,'Tiaan Smith','2026-08-26 16:44:31'),(82,'gl',NULL,'mirror_failed','Sale INV_01_01_000002 did not reach the ledger — Journal does not balance: debits 40.00, credits 20.00, out by 20.00.',NULL,1,'Tiaan Smith','2026-09-01 11:04:57');
/*!40000 ALTER TABLE `activity_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `alert_rule_runs`
--

DROP TABLE IF EXISTS `alert_rule_runs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `alert_rule_runs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `rule_id` int(10) unsigned NOT NULL,
  `due_at` datetime NOT NULL,
  `claimed_at` datetime NOT NULL DEFAULT current_timestamp(),
  `status` enum('claimed','sent','failed','skipped') NOT NULL DEFAULT 'claimed',
  `finished_at` datetime DEFAULT NULL,
  `item_count` int(10) unsigned NOT NULL DEFAULT 0,
  `created_docs` varchar(500) NOT NULL DEFAULT '',
  `recipients` varchar(500) NOT NULL DEFAULT '',
  `attempts` smallint(5) unsigned NOT NULL DEFAULT 1,
  `error_text` varchar(500) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_alert_rule_due` (`rule_id`,`due_at`),
  KEY `idx_alert_runs_status` (`status`,`due_at`),
  CONSTRAINT `alert_rule_runs_ibfk_1` FOREIGN KEY (`rule_id`) REFERENCES `alert_rules` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `alert_rule_runs`
--

LOCK TABLES `alert_rule_runs` WRITE;
/*!40000 ALTER TABLE `alert_rule_runs` DISABLE KEYS */;
/*!40000 ALTER TABLE `alert_rule_runs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `alert_rules`
--

DROP TABLE IF EXISTS `alert_rules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `alert_rules` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `kind` varchar(40) NOT NULL,
  `name` varchar(120) NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `frequency` enum('daily','weekly','monthly') NOT NULL DEFAULT 'daily',
  `send_time` varchar(5) NOT NULL DEFAULT '07:00',
  `days_of_week` varchar(7) NOT NULL DEFAULT '1111111',
  `day_of_month` tinyint(3) unsigned NOT NULL DEFAULT 1,
  `config_json` text DEFAULT NULL,
  `notify_bell` tinyint(1) NOT NULL DEFAULT 1,
  `notify_email` tinyint(1) NOT NULL DEFAULT 0,
  `notify_whatsapp` tinyint(1) NOT NULL DEFAULT 0,
  `notify_sms` tinyint(1) NOT NULL DEFAULT 0,
  `recipient_user_ids` varchar(500) NOT NULL DEFAULT '',
  `recipient_emails` varchar(2000) NOT NULL DEFAULT '',
  `whatsapp_numbers` varchar(500) NOT NULL DEFAULT '',
  `sms_numbers` varchar(500) NOT NULL DEFAULT '',
  `owner_user_id` int(10) unsigned DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT NULL,
  `created_by_name` varchar(120) NOT NULL DEFAULT '',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `last_run_at` datetime DEFAULT NULL,
  `last_run_status` varchar(20) NOT NULL DEFAULT '',
  `last_run_error` varchar(500) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `idx_alert_rules_active` (`is_active`),
  KEY `fk_alert_rules_owner` (`owner_user_id`),
  CONSTRAINT `alert_rules_ibfk_1` FOREIGN KEY (`owner_user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `alert_rules`
--

LOCK TABLES `alert_rules` WRITE;
/*!40000 ALTER TABLE `alert_rules` DISABLE KEYS */;
/*!40000 ALTER TABLE `alert_rules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `api_keys`
--

DROP TABLE IF EXISTS `api_keys`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `api_keys` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(80) NOT NULL,
  `key_prefix` varchar(16) NOT NULL,
  `token_hash` char(64) NOT NULL,
  `scopes` varchar(255) NOT NULL,
  `created_by` varchar(120) NOT NULL DEFAULT '',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `last_used_at` datetime DEFAULT NULL,
  `revoked_at` datetime DEFAULT NULL,
  `expires_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ux_api_keys_prefix` (`key_prefix`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `api_keys`
--

LOCK TABLES `api_keys` WRITE;
/*!40000 ALTER TABLE `api_keys` DISABLE KEYS */;
INSERT INTO `api_keys` VALUES (1,'oliver','og2I9q7h','a33b0f621e1469aedae67b9c9af09a520b078c67c381166355536b3ca2ab1189','products:read,sales:read,customers:read,suppliers:read,purchases:read,reports:run','Tiaan Smith','2026-08-26 14:22:32',NULL,NULL,'2027-08-26 14:22:32');
/*!40000 ALTER TABLE `api_keys` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `asset_categories`
--

DROP TABLE IF EXISTS `asset_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `asset_categories` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(120) NOT NULL,
  `code` varchar(24) DEFAULT NULL,
  `default_life_months` smallint(5) unsigned NOT NULL DEFAULT 36,
  `default_residual_pct` decimal(5,2) NOT NULL DEFAULT 0.00,
  `cost_account_id` int(10) unsigned DEFAULT NULL,
  `accum_account_id` int(10) unsigned DEFAULT NULL,
  `expense_account_id` int(10) unsigned DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `sort_order` int(11) NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `ix_assetcat_active` (`is_active`,`sort_order`),
  KEY `fk_assetcat_cost` (`cost_account_id`),
  KEY `fk_assetcat_accum` (`accum_account_id`),
  KEY `fk_assetcat_exp` (`expense_account_id`),
  CONSTRAINT `asset_categories_ibfk_1` FOREIGN KEY (`accum_account_id`) REFERENCES `gl_accounts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `asset_categories_ibfk_2` FOREIGN KEY (`cost_account_id`) REFERENCES `gl_accounts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `asset_categories_ibfk_3` FOREIGN KEY (`expense_account_id`) REFERENCES `gl_accounts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `asset_categories`
--

LOCK TABLES `asset_categories` WRITE;
/*!40000 ALTER TABLE `asset_categories` DISABLE KEYS */;
INSERT INTO `asset_categories` VALUES (1,'Equipment','EQUIP',36,0.00,6,7,43,1,10,'2026-08-06 22:26:44','2026-08-06 22:26:44'),(2,'Computers','COMP',36,0.00,6,7,43,1,20,'2026-08-06 22:26:44','2026-08-06 22:26:44'),(3,'Furniture and fittings','FURN',72,0.00,6,7,43,1,30,'2026-08-06 22:26:44','2026-08-06 22:26:44'),(4,'Vehicles','VEH',60,20.00,8,9,43,1,40,'2026-08-06 22:26:44','2026-08-06 22:26:44');
/*!40000 ALTER TABLE `asset_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `asset_types`
--

DROP TABLE IF EXISTS `asset_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `asset_types` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(40) NOT NULL,
  `name` varchar(120) NOT NULL,
  `service_months` smallint(5) unsigned DEFAULT NULL,
  `identifier_label` varchar(40) NOT NULL DEFAULT 'Serial number',
  `sort_order` int(11) NOT NULL DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_asset_type_code` (`code`),
  KEY `ix_asset_type_active` (`is_active`,`sort_order`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `asset_types`
--

LOCK TABLES `asset_types` WRITE;
/*!40000 ALTER TABLE `asset_types` DISABLE KEYS */;
/*!40000 ALTER TABLE `asset_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bank_accounts`
--

DROP TABLE IF EXISTS `bank_accounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bank_accounts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(24) NOT NULL,
  `name` varchar(120) NOT NULL,
  `account_type` enum('bank','cash','card') NOT NULL DEFAULT 'bank',
  `bank_name` varchar(120) DEFAULT NULL,
  `account_number` varchar(40) DEFAULT NULL,
  `branch_code` varchar(20) DEFAULT NULL,
  `opening_balance` decimal(14,4) NOT NULL DEFAULT 0.0000,
  `opening_date` date DEFAULT NULL,
  `balance` decimal(14,4) NOT NULL DEFAULT 0.0000,
  `last_reconciled_date` date DEFAULT NULL,
  `last_reconciled_balance` decimal(14,4) DEFAULT NULL,
  `is_default_receipts` tinyint(1) NOT NULL DEFAULT 0,
  `is_default_payments` tinyint(1) NOT NULL DEFAULT 0,
  `status` enum('active','closed') NOT NULL DEFAULT 'active',
  `sort_order` int(10) unsigned NOT NULL DEFAULT 0,
  `notes` varchar(400) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_bank_code` (`code`),
  KEY `ix_bank_status` (`status`,`sort_order`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bank_accounts`
--

LOCK TABLES `bank_accounts` WRITE;
/*!40000 ALTER TABLE `bank_accounts` DISABLE KEYS */;
INSERT INTO `bank_accounts` VALUES (1,'CASH','Cash on hand','cash',NULL,NULL,NULL,0.0000,NULL,0.0000,NULL,NULL,0,0,'active',10,NULL,'2026-08-06 19:52:59','2026-08-10 07:33:21'),(2,'NEDBANK','Odyssey George Nedbank Card','bank','Nedbank','12345678999','12345',470000.0000,'2026-08-10',468500.0000,NULL,NULL,1,1,'active',100,NULL,'2026-08-10 07:33:21','2026-08-10 07:41:07');
/*!40000 ALTER TABLE `bank_accounts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bank_import_batches`
--

DROP TABLE IF EXISTS `bank_import_batches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bank_import_batches` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `bank_account_id` int(10) unsigned NOT NULL,
  `filename` varchar(255) DEFAULT NULL,
  `format` enum('csv','ofx') NOT NULL DEFAULT 'csv',
  `period_from` date DEFAULT NULL,
  `period_to` date DEFAULT NULL,
  `row_count` int(10) unsigned NOT NULL DEFAULT 0,
  `imported_count` int(10) unsigned NOT NULL DEFAULT 0,
  `duplicate_count` int(10) unsigned NOT NULL DEFAULT 0,
  `auto_matched_count` int(10) unsigned NOT NULL DEFAULT 0,
  `user_id` int(10) unsigned DEFAULT NULL,
  `user_name` varchar(120) NOT NULL DEFAULT '',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `ix_batch_account` (`bank_account_id`,`created_at`),
  CONSTRAINT `bank_import_batches_ibfk_1` FOREIGN KEY (`bank_account_id`) REFERENCES `bank_accounts` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bank_import_batches`
--

LOCK TABLES `bank_import_batches` WRITE;
/*!40000 ALTER TABLE `bank_import_batches` DISABLE KEYS */;
/*!40000 ALTER TABLE `bank_import_batches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bank_reconciliations`
--

DROP TABLE IF EXISTS `bank_reconciliations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bank_reconciliations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `bank_account_id` int(10) unsigned NOT NULL,
  `statement_date` date NOT NULL,
  `statement_balance` decimal(14,4) NOT NULL,
  `book_balance` decimal(14,4) NOT NULL,
  `unreconciled_total` decimal(14,4) NOT NULL DEFAULT 0.0000,
  `difference` decimal(14,4) NOT NULL DEFAULT 0.0000,
  `status` enum('draft','completed') NOT NULL DEFAULT 'draft',
  `matched_count` int(10) unsigned NOT NULL DEFAULT 0,
  `notes` varchar(400) DEFAULT NULL,
  `user_id` int(10) unsigned DEFAULT NULL,
  `user_name` varchar(120) NOT NULL DEFAULT '',
  `completed_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `ix_recon_account` (`bank_account_id`,`statement_date`),
  CONSTRAINT `bank_reconciliations_ibfk_1` FOREIGN KEY (`bank_account_id`) REFERENCES `bank_accounts` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bank_reconciliations`
--

LOCK TABLES `bank_reconciliations` WRITE;
/*!40000 ALTER TABLE `bank_reconciliations` DISABLE KEYS */;
/*!40000 ALTER TABLE `bank_reconciliations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bank_transactions`
--

DROP TABLE IF EXISTS `bank_transactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bank_transactions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `bank_account_id` int(10) unsigned NOT NULL,
  `txn_date` date NOT NULL,
  `amount_signed` decimal(14,4) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `reference` varchar(120) DEFAULT NULL,
  `status` enum('unreconciled','reconciled','void') NOT NULL DEFAULT 'unreconciled',
  `reconciliation_id` int(10) unsigned DEFAULT NULL,
  `source` varchar(24) NOT NULL DEFAULT 'manual',
  `source_doc_id` int(10) unsigned DEFAULT NULL,
  `category_key` varchar(40) DEFAULT NULL,
  `category_ref_id` int(10) unsigned DEFAULT NULL,
  `import_key` varchar(120) DEFAULT NULL,
  `import_batch_id` int(10) unsigned DEFAULT NULL,
  `user_id` int(10) unsigned DEFAULT NULL,
  `user_name` varchar(120) NOT NULL DEFAULT '',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_bank_import` (`bank_account_id`,`import_key`),
  KEY `ix_btxn_account_date` (`bank_account_id`,`txn_date`,`id`),
  KEY `ix_btxn_unrec` (`bank_account_id`,`status`,`txn_date`),
  KEY `ix_btxn_source` (`source`,`source_doc_id`),
  KEY `ix_btxn_recon` (`reconciliation_id`),
  KEY `fk_btxn_batch` (`import_batch_id`),
  CONSTRAINT `bank_transactions_ibfk_1` FOREIGN KEY (`bank_account_id`) REFERENCES `bank_accounts` (`id`),
  CONSTRAINT `bank_transactions_ibfk_2` FOREIGN KEY (`import_batch_id`) REFERENCES `bank_import_batches` (`id`) ON DELETE SET NULL,
  CONSTRAINT `bank_transactions_ibfk_3` FOREIGN KEY (`reconciliation_id`) REFERENCES `bank_reconciliations` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bank_transactions`
--

LOCK TABLES `bank_transactions` WRITE;
/*!40000 ALTER TABLE `bank_transactions` DISABLE KEYS */;
INSERT INTO `bank_transactions` VALUES (1,2,'2026-08-10',-1500.0000,'Petrol',NULL,'unreconciled',NULL,'expense',1,NULL,NULL,NULL,NULL,1,'Tiaan Smith','2026-08-10 07:41:07','2026-08-10 07:41:07');
/*!40000 ALTER TABLE `bank_transactions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `batch_movements`
--

DROP TABLE IF EXISTS `batch_movements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `batch_movements` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `batch_id` int(10) unsigned NOT NULL,
  `movement_id` int(10) unsigned DEFAULT NULL,
  `action` varchar(24) NOT NULL,
  `qty_change` decimal(12,3) NOT NULL,
  `document_id` int(10) unsigned DEFAULT NULL,
  `document_line_id` int(10) unsigned DEFAULT NULL,
  `source` varchar(30) NOT NULL DEFAULT '',
  `user_id` int(10) unsigned DEFAULT NULL,
  `user_name` varchar(120) NOT NULL DEFAULT '',
  `note` varchar(190) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `ix_bmove_batch` (`batch_id`,`created_at`),
  KEY `ix_bmove_movement` (`movement_id`),
  KEY `ix_bmove_doc` (`document_id`),
  KEY `ix_bmove_line` (`document_line_id`),
  CONSTRAINT `batch_movements_ibfk_1` FOREIGN KEY (`batch_id`) REFERENCES `product_batches` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `batch_movements`
--

LOCK TABLES `batch_movements` WRITE;
/*!40000 ALTER TABLE `batch_movements` DISABLE KEYS */;
INSERT INTO `batch_movements` VALUES (1,1,130,'receipt',10.000,27,NULL,'grv',1,'Tiaan Smith',NULL,'2026-08-24 12:49:22'),(2,1,131,'sale',-1.000,10,76,'invoice',1,'Tiaan Smith',NULL,'2026-08-24 12:50:09');
/*!40000 ALTER TABLE `batch_movements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `brands`
--

DROP TABLE IF EXISTS `brands`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `brands` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(120) NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_brand_name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `brands`
--

LOCK TABLES `brands` WRITE;
/*!40000 ALTER TABLE `brands` DISABLE KEYS */;
INSERT INTO `brands` VALUES (1,'House Made',1,'2026-08-09 09:41:05','2026-08-09 09:41:05'),(2,'Coca-Cola',1,'2026-08-09 09:41:05','2026-08-09 09:41:05'),(3,'Fanta',1,'2026-08-09 09:41:05','2026-08-09 09:41:05'),(4,'Sprite',1,'2026-08-09 09:41:05','2026-08-09 09:41:05'),(5,'Appletiser',1,'2026-08-09 09:41:05','2026-08-09 09:41:05'),(6,'Red Bull',1,'2026-08-09 09:41:05','2026-08-09 09:41:05'),(7,'Lipton',1,'2026-08-09 09:41:05','2026-08-09 09:41:05');
/*!40000 ALTER TABLE `brands` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cash_denominations`
--

DROP TABLE IF EXISTS `cash_denominations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cash_denominations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `label` varchar(24) NOT NULL,
  `value` decimal(12,4) NOT NULL,
  `currency_code` varchar(3) NOT NULL DEFAULT 'ZAR',
  `is_note` tinyint(1) NOT NULL DEFAULT 0,
  `position` int(10) unsigned NOT NULL DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_denom_currency_value` (`currency_code`,`value`),
  KEY `ix_denom_active` (`is_active`,`position`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cash_denominations`
--

LOCK TABLES `cash_denominations` WRITE;
/*!40000 ALTER TABLE `cash_denominations` DISABLE KEYS */;
INSERT INTO `cash_denominations` VALUES (1,'R200',200.0000,'ZAR',1,10,1,'2026-08-24 09:10:36','2026-08-24 09:10:36'),(2,'R100',100.0000,'ZAR',1,20,1,'2026-08-24 09:10:36','2026-08-24 09:10:36'),(3,'R50',50.0000,'ZAR',1,30,1,'2026-08-24 09:10:36','2026-08-24 09:10:36'),(4,'R20',20.0000,'ZAR',1,40,1,'2026-08-24 09:10:36','2026-08-24 09:10:36'),(5,'R10',10.0000,'ZAR',1,50,1,'2026-08-24 09:10:36','2026-08-24 09:10:36'),(6,'R5',5.0000,'ZAR',0,60,1,'2026-08-24 09:10:36','2026-08-24 09:10:36'),(7,'R2',2.0000,'ZAR',0,70,1,'2026-08-24 09:10:36','2026-08-24 09:10:36'),(8,'R1',1.0000,'ZAR',0,80,1,'2026-08-24 09:10:36','2026-08-24 09:10:36'),(9,'50c',0.5000,'ZAR',0,90,1,'2026-08-24 09:10:36','2026-08-24 09:10:36'),(10,'20c',0.2000,'ZAR',0,100,1,'2026-08-24 09:10:36','2026-08-24 09:10:36'),(11,'10c',0.1000,'ZAR',0,110,1,'2026-08-24 09:10:36','2026-08-24 09:10:36'),(12,'5c',0.0500,'ZAR',0,120,0,'2026-08-24 09:10:36','2026-08-24 09:10:36');
/*!40000 ALTER TABLE `cash_denominations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cashbook_links`
--

DROP TABLE IF EXISTS `cashbook_links`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cashbook_links` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `bank_txn_id` int(10) unsigned NOT NULL,
  `customer_txn_id` int(10) unsigned DEFAULT NULL,
  `supplier_txn_id` int(10) unsigned DEFAULT NULL,
  `amount` decimal(14,4) NOT NULL,
  `match_type` enum('auto','manual') NOT NULL DEFAULT 'manual',
  `confidence` tinyint(3) unsigned NOT NULL DEFAULT 100,
  `linked_at` datetime NOT NULL DEFAULT current_timestamp(),
  `user_id` int(10) unsigned DEFAULT NULL,
  `user_name` varchar(120) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_link_customer` (`bank_txn_id`,`customer_txn_id`),
  UNIQUE KEY `uq_link_supplier` (`bank_txn_id`,`supplier_txn_id`),
  KEY `ix_link_bank` (`bank_txn_id`),
  KEY `ix_link_ctxn` (`customer_txn_id`),
  KEY `ix_link_stxn` (`supplier_txn_id`),
  CONSTRAINT `cashbook_links_ibfk_1` FOREIGN KEY (`bank_txn_id`) REFERENCES `bank_transactions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cashbook_links`
--

LOCK TABLES `cashbook_links` WRITE;
/*!40000 ALTER TABLE `cashbook_links` DISABLE KEYS */;
/*!40000 ALTER TABLE `cashbook_links` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `commission_entries`
--

DROP TABLE IF EXISTS `commission_entries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `commission_entries` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `run_id` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `user_name` varchar(120) NOT NULL DEFAULT '',
  `line_id` int(10) unsigned DEFAULT NULL,
  `document_id` int(10) unsigned DEFAULT NULL,
  `document_number` varchar(32) DEFAULT NULL,
  `document_date` date DEFAULT NULL,
  `doc_type` varchar(24) NOT NULL DEFAULT 'invoice',
  `product_code` varchar(48) DEFAULT NULL,
  `description` varchar(200) DEFAULT NULL,
  `rule_id` int(10) unsigned DEFAULT NULL,
  `rule_name` varchar(120) NOT NULL DEFAULT '',
  `basis` enum('gross_profit','turnover') NOT NULL DEFAULT 'gross_profit',
  `base_amount` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `rate_pct` decimal(6,3) NOT NULL DEFAULT 0.000,
  `amount` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `ix_commission_entry_run` (`run_id`,`user_id`),
  KEY `ix_commission_entry_user` (`user_id`,`document_date`),
  KEY `ix_commission_entry_line` (`line_id`),
  KEY `fk_commission_entry_rule` (`rule_id`),
  CONSTRAINT `commission_entries_ibfk_1` FOREIGN KEY (`line_id`) REFERENCES `sales_document_lines` (`id`) ON DELETE SET NULL,
  CONSTRAINT `commission_entries_ibfk_2` FOREIGN KEY (`rule_id`) REFERENCES `commission_rules` (`id`) ON DELETE SET NULL,
  CONSTRAINT `commission_entries_ibfk_3` FOREIGN KEY (`run_id`) REFERENCES `commission_runs` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `commission_entries`
--

LOCK TABLES `commission_entries` WRITE;
/*!40000 ALTER TABLE `commission_entries` DISABLE KEYS */;
/*!40000 ALTER TABLE `commission_entries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `commission_rules`
--

DROP TABLE IF EXISTS `commission_rules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `commission_rules` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(120) NOT NULL,
  `priority` int(10) unsigned NOT NULL DEFAULT 100,
  `basis` enum('gross_profit','turnover') NOT NULL DEFAULT 'gross_profit',
  `department_id` int(10) unsigned DEFAULT NULL,
  `product_id` int(10) unsigned DEFAULT NULL,
  `brand_id` int(10) unsigned DEFAULT NULL,
  `supplier_id` int(10) unsigned DEFAULT NULL,
  `user_id` int(10) unsigned DEFAULT NULL,
  `is_exclusion` tinyint(1) NOT NULL DEFAULT 0,
  `rate_pct` decimal(6,3) NOT NULL DEFAULT 0.000,
  `threshold` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `ix_commission_rule_priority` (`is_active`,`priority`,`id`),
  KEY `ix_commission_rule_dept` (`department_id`),
  KEY `ix_commission_rule_product` (`product_id`),
  KEY `ix_commission_rule_user` (`user_id`),
  KEY `fk_commission_rule_brand` (`brand_id`),
  KEY `fk_commission_rule_supplier` (`supplier_id`),
  CONSTRAINT `commission_rules_ibfk_1` FOREIGN KEY (`brand_id`) REFERENCES `brands` (`id`) ON DELETE SET NULL,
  CONSTRAINT `commission_rules_ibfk_2` FOREIGN KEY (`department_id`) REFERENCES `departments` (`id`) ON DELETE SET NULL,
  CONSTRAINT `commission_rules_ibfk_3` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE SET NULL,
  CONSTRAINT `commission_rules_ibfk_4` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `commission_rules`
--

LOCK TABLES `commission_rules` WRITE;
/*!40000 ALTER TABLE `commission_rules` DISABLE KEYS */;
/*!40000 ALTER TABLE `commission_rules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `commission_runs`
--

DROP TABLE IF EXISTS `commission_runs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `commission_runs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `period_start` date NOT NULL,
  `period_end` date NOT NULL,
  `status` enum('open','locked') NOT NULL DEFAULT 'open',
  `calculated_at` datetime DEFAULT NULL,
  `locked_at` datetime DEFAULT NULL,
  `locked_by_user_id` int(10) unsigned DEFAULT NULL,
  `locked_by_name` varchar(120) DEFAULT NULL,
  `total_amount` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `note` varchar(400) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_commission_run_period` (`period_start`,`period_end`),
  KEY `ix_commission_run_status` (`status`,`period_start`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `commission_runs`
--

LOCK TABLES `commission_runs` WRITE;
/*!40000 ALTER TABLE `commission_runs` DISABLE KEYS */;
INSERT INTO `commission_runs` VALUES (1,'2026-06-30','2026-07-30','open','2026-08-08 08:02:08',NULL,NULL,NULL,0.0000,'June payroll','2026-08-08 08:01:54','2026-08-08 08:02:08');
/*!40000 ALTER TABLE `commission_runs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `commission_tiers`
--

DROP TABLE IF EXISTS `commission_tiers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `commission_tiers` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `rule_id` int(10) unsigned NOT NULL,
  `from_amount` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `rate_pct` decimal(6,3) NOT NULL DEFAULT 0.000,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_commission_tier` (`rule_id`,`from_amount`),
  CONSTRAINT `commission_tiers_ibfk_1` FOREIGN KEY (`rule_id`) REFERENCES `commission_rules` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `commission_tiers`
--

LOCK TABLES `commission_tiers` WRITE;
/*!40000 ALTER TABLE `commission_tiers` DISABLE KEYS */;
/*!40000 ALTER TABLE `commission_tiers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contract_invoices`
--

DROP TABLE IF EXISTS `contract_invoices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contract_invoices` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `contract_id` int(10) unsigned NOT NULL,
  `for_date` date NOT NULL,
  `document_id` int(10) unsigned DEFAULT NULL,
  `status` enum('draft','posted','failed') NOT NULL DEFAULT 'draft',
  `email_status` enum('pending','sent','failed','skipped') NOT NULL DEFAULT 'pending',
  `emailed_to` varchar(190) DEFAULT NULL,
  `emailed_at` datetime DEFAULT NULL,
  `email_attempts` smallint(5) unsigned NOT NULL DEFAULT 0,
  `error` varchar(400) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_contract_period` (`contract_id`,`for_date`),
  KEY `ix_cinv_document` (`document_id`),
  KEY `ix_cinv_email` (`email_status`,`created_at`),
  CONSTRAINT `contract_invoices_ibfk_1` FOREIGN KEY (`contract_id`) REFERENCES `contracts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `contract_invoices_ibfk_2` FOREIGN KEY (`document_id`) REFERENCES `sales_documents` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contract_invoices`
--

LOCK TABLES `contract_invoices` WRITE;
/*!40000 ALTER TABLE `contract_invoices` DISABLE KEYS */;
/*!40000 ALTER TABLE `contract_invoices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contract_lines`
--

DROP TABLE IF EXISTS `contract_lines`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contract_lines` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `contract_id` int(10) unsigned NOT NULL,
  `line_number` smallint(5) unsigned NOT NULL DEFAULT 1,
  `product_id` int(10) unsigned DEFAULT NULL,
  `product_code` varchar(40) DEFAULT NULL,
  `description` varchar(190) NOT NULL,
  `qty` decimal(12,3) NOT NULL DEFAULT 1.000,
  `unit_price_incl` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `base_price_incl` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `vat_rate_pct` decimal(6,3) NOT NULL DEFAULT 0.000,
  `department_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_cline_parent` (`contract_id`,`line_number`),
  KEY `fk_cline_product` (`product_id`),
  KEY `fk_cline_dept` (`department_id`),
  CONSTRAINT `contract_lines_ibfk_1` FOREIGN KEY (`department_id`) REFERENCES `departments` (`id`) ON DELETE SET NULL,
  CONSTRAINT `contract_lines_ibfk_2` FOREIGN KEY (`contract_id`) REFERENCES `contracts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `contract_lines_ibfk_3` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contract_lines`
--

LOCK TABLES `contract_lines` WRITE;
/*!40000 ALTER TABLE `contract_lines` DISABLE KEYS */;
/*!40000 ALTER TABLE `contract_lines` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contracts`
--

DROP TABLE IF EXISTS `contracts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contracts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `contract_number` varchar(32) DEFAULT NULL,
  `name` varchar(120) NOT NULL,
  `customer_id` int(10) unsigned NOT NULL,
  `frequency` enum('monthly','quarterly','annually') NOT NULL DEFAULT 'monthly',
  `billing_day` tinyint(3) unsigned NOT NULL DEFAULT 1,
  `starts_on` date NOT NULL,
  `ends_on` date DEFAULT NULL,
  `last_generated_for` date DEFAULT NULL,
  `escalation_pct` decimal(6,3) NOT NULL DEFAULT 0.000,
  `escalation_month` tinyint(3) unsigned DEFAULT NULL,
  `last_escalated_for` date DEFAULT NULL,
  `auto_send` tinyint(1) NOT NULL DEFAULT 0,
  `offer_payment_link` tinyint(1) NOT NULL DEFAULT 1,
  `payment_terms_days` smallint(5) unsigned NOT NULL DEFAULT 30,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `reference` varchar(60) DEFAULT NULL,
  `notes` varchar(400) DEFAULT NULL,
  `internal_note` varchar(400) DEFAULT NULL,
  `user_id` int(10) unsigned DEFAULT NULL,
  `user_name` varchar(120) NOT NULL DEFAULT '',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_contract_number` (`contract_number`),
  KEY `ix_contract_customer` (`customer_id`,`is_active`),
  KEY `ix_contract_active` (`is_active`,`starts_on`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contracts`
--

LOCK TABLES `contracts` WRITE;
/*!40000 ALTER TABLE `contracts` DISABLE KEYS */;
/*!40000 ALTER TABLE `contracts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `credit_contacts`
--

DROP TABLE IF EXISTS `credit_contacts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `credit_contacts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `customer_id` int(10) unsigned NOT NULL,
  `contact_date` date NOT NULL,
  `kind` enum('email','call','note','meeting','letter') NOT NULL DEFAULT 'note',
  `outcome` enum('promised','disputed','no_answer','paid','refused','none') NOT NULL DEFAULT 'none',
  `summary` varchar(300) NOT NULL,
  `detail` text DEFAULT NULL,
  `balance_at` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `run_item_id` int(10) unsigned DEFAULT NULL,
  `promise_id` int(10) unsigned DEFAULT NULL,
  `user_id` int(10) unsigned DEFAULT NULL,
  `user_name` varchar(120) NOT NULL DEFAULT '',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_contact_customer` (`customer_id`,`contact_date`),
  KEY `fk_contact_run_item` (`run_item_id`),
  KEY `fk_contact_promise` (`promise_id`),
  CONSTRAINT `credit_contacts_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE CASCADE,
  CONSTRAINT `credit_contacts_ibfk_2` FOREIGN KEY (`promise_id`) REFERENCES `payment_promises` (`id`) ON DELETE SET NULL,
  CONSTRAINT `credit_contacts_ibfk_3` FOREIGN KEY (`run_item_id`) REFERENCES `dunning_run_items` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `credit_contacts`
--

LOCK TABLES `credit_contacts` WRITE;
/*!40000 ALTER TABLE `credit_contacts` DISABLE KEYS */;
/*!40000 ALTER TABLE `credit_contacts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `custom_field_defs`
--

DROP TABLE IF EXISTS `custom_field_defs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `custom_field_defs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `entity` enum('job','customer','equipment','sale') NOT NULL,
  `code` varchar(40) NOT NULL,
  `name` varchar(120) NOT NULL,
  `hint` varchar(190) DEFAULT NULL,
  `field_type` enum('text','number','date','yesno','list') NOT NULL DEFAULT 'text',
  `options` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`options`)),
  `unit` varchar(20) DEFAULT NULL,
  `is_required` tinyint(1) NOT NULL DEFAULT 0,
  `is_public` tinyint(1) NOT NULL DEFAULT 0,
  `prints_on_slip` tinyint(1) NOT NULL DEFAULT 0,
  `sort_order` int(11) NOT NULL DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_cfdef_entity_code` (`entity`,`code`),
  KEY `ix_cfdef_entity` (`entity`,`is_active`,`sort_order`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `custom_field_defs`
--

LOCK TABLES `custom_field_defs` WRITE;
/*!40000 ALTER TABLE `custom_field_defs` DISABLE KEYS */;
/*!40000 ALTER TABLE `custom_field_defs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `custom_field_values`
--

DROP TABLE IF EXISTS `custom_field_values`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `custom_field_values` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `field_id` int(10) unsigned NOT NULL,
  `entity` enum('job','customer','equipment','sale') NOT NULL,
  `entity_id` int(10) unsigned NOT NULL,
  `value` varchar(500) DEFAULT NULL,
  `set_by_user_id` int(10) unsigned DEFAULT NULL,
  `set_by_name` varchar(120) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_cfval_field_record` (`field_id`,`entity`,`entity_id`),
  KEY `ix_cfval_record` (`entity`,`entity_id`),
  CONSTRAINT `custom_field_values_ibfk_1` FOREIGN KEY (`field_id`) REFERENCES `custom_field_defs` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `custom_field_values`
--

LOCK TABLES `custom_field_values` WRITE;
/*!40000 ALTER TABLE `custom_field_values` DISABLE KEYS */;
/*!40000 ALTER TABLE `custom_field_values` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customer_addresses`
--

DROP TABLE IF EXISTS `customer_addresses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customer_addresses` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `customer_id` int(10) unsigned NOT NULL,
  `kind` enum('billing','delivery') NOT NULL DEFAULT 'delivery',
  `label` varchar(120) NOT NULL,
  `line1` varchar(190) DEFAULT NULL,
  `line2` varchar(190) DEFAULT NULL,
  `city` varchar(120) DEFAULT NULL,
  `postal_code` varchar(20) DEFAULT NULL,
  `province` varchar(80) DEFAULT NULL,
  `country` char(2) NOT NULL DEFAULT 'ZA',
  `notes` varchar(400) DEFAULT NULL,
  `is_default` tinyint(1) NOT NULL DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `sort_order` int(11) NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `ix_caddr_customer` (`customer_id`,`kind`,`is_default`,`sort_order`),
  CONSTRAINT `customer_addresses_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer_addresses`
--

LOCK TABLES `customer_addresses` WRITE;
/*!40000 ALTER TABLE `customer_addresses` DISABLE KEYS */;
/*!40000 ALTER TABLE `customer_addresses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customer_allocations`
--

DROP TABLE IF EXISTS `customer_allocations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customer_allocations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `debit_txn_id` int(10) unsigned NOT NULL,
  `credit_txn_id` int(10) unsigned NOT NULL,
  `amount` decimal(12,4) NOT NULL,
  `allocated_at` datetime NOT NULL DEFAULT current_timestamp(),
  `user_id` int(10) unsigned DEFAULT NULL,
  `user_name` varchar(120) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_alloc_pair` (`debit_txn_id`,`credit_txn_id`),
  KEY `ix_alloc_credit` (`credit_txn_id`),
  KEY `ix_alloc_when` (`allocated_at`),
  CONSTRAINT `customer_allocations_ibfk_1` FOREIGN KEY (`credit_txn_id`) REFERENCES `customer_transactions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `customer_allocations_ibfk_2` FOREIGN KEY (`debit_txn_id`) REFERENCES `customer_transactions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer_allocations`
--

LOCK TABLES `customer_allocations` WRITE;
/*!40000 ALTER TABLE `customer_allocations` DISABLE KEYS */;
INSERT INTO `customer_allocations` VALUES (1,1,2,55.0000,'2026-08-09 12:48:00',1,'Tiaan Smith'),(2,3,4,149.5000,'2026-08-11 13:50:30',1,'Tiaan Smith');
/*!40000 ALTER TABLE `customer_allocations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customer_assets`
--

DROP TABLE IF EXISTS `customer_assets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customer_assets` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `document_number` varchar(32) DEFAULT NULL,
  `asset_type_id` int(10) unsigned DEFAULT NULL,
  `customer_id` int(10) unsigned DEFAULT NULL,
  `service_address_id` int(10) unsigned DEFAULT NULL,
  `description` varchar(190) NOT NULL,
  `make` varchar(120) DEFAULT NULL,
  `model` varchar(120) DEFAULT NULL,
  `serial_text` varchar(64) DEFAULT NULL,
  `serial_key` varchar(64) GENERATED ALWAYS AS (ucase(replace(replace(coalesce(`serial_text`,''),' ',''),'-',''))) STORED,
  `product_id` int(10) unsigned DEFAULT NULL,
  `serial_id` int(10) unsigned DEFAULT NULL,
  `installed_on` date DEFAULT NULL,
  `purchased_on` date DEFAULT NULL,
  `purchase_reference` varchar(60) DEFAULT NULL,
  `warranty_until` date DEFAULT NULL,
  `last_service_on` date DEFAULT NULL,
  `next_service_on` date DEFAULT NULL,
  `condition_note` varchar(190) DEFAULT NULL,
  `note` text DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `status` enum('active','cancelled') NOT NULL DEFAULT 'active',
  `retired_on` date DEFAULT NULL,
  `retired_reason` varchar(190) DEFAULT NULL,
  `user_id` int(10) unsigned DEFAULT NULL,
  `user_name` varchar(120) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_asset_code` (`document_number`),
  KEY `ix_asset_serial` (`serial_key`,`customer_id`),
  KEY `ix_asset_customer` (`customer_id`,`is_active`),
  KEY `ix_asset_address` (`service_address_id`),
  KEY `ix_asset_due` (`is_active`,`next_service_on`),
  KEY `fk_asset_type` (`asset_type_id`),
  KEY `fk_asset_product` (`product_id`),
  KEY `fk_asset_serial` (`serial_id`),
  KEY `ix_asset_status` (`status`,`next_service_on`),
  CONSTRAINT `customer_assets_ibfk_1` FOREIGN KEY (`service_address_id`) REFERENCES `service_addresses` (`id`) ON DELETE SET NULL,
  CONSTRAINT `customer_assets_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE SET NULL,
  CONSTRAINT `customer_assets_ibfk_3` FOREIGN KEY (`serial_id`) REFERENCES `product_serials` (`id`) ON DELETE SET NULL,
  CONSTRAINT `customer_assets_ibfk_4` FOREIGN KEY (`asset_type_id`) REFERENCES `asset_types` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer_assets`
--

LOCK TABLES `customer_assets` WRITE;
/*!40000 ALTER TABLE `customer_assets` DISABLE KEYS */;
/*!40000 ALTER TABLE `customer_assets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customer_comments`
--

DROP TABLE IF EXISTS `customer_comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customer_comments` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `entity` varchar(40) NOT NULL DEFAULT 'customer',
  `entity_id` int(10) unsigned NOT NULL,
  `body` text NOT NULL,
  `is_pinned` tinyint(1) NOT NULL DEFAULT 0,
  `author_id` int(10) unsigned DEFAULT NULL,
  `author_name` varchar(120) NOT NULL DEFAULT '',
  `is_edited` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `ix_ccomment_entity` (`entity`,`entity_id`,`is_pinned`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer_comments`
--

LOCK TABLES `customer_comments` WRITE;
/*!40000 ALTER TABLE `customer_comments` DISABLE KEYS */;
/*!40000 ALTER TABLE `customer_comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customer_contacts`
--

DROP TABLE IF EXISTS `customer_contacts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customer_contacts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `customer_id` int(10) unsigned NOT NULL,
  `name` varchar(120) NOT NULL,
  `role` varchar(60) DEFAULT NULL,
  `email` varchar(190) DEFAULT NULL,
  `phone` varchar(40) DEFAULT NULL,
  `notes` varchar(400) DEFAULT NULL,
  `consent_email` tinyint(1) NOT NULL DEFAULT 1,
  `consent_sms` tinyint(1) NOT NULL DEFAULT 0,
  `consent_whatsapp` tinyint(1) NOT NULL DEFAULT 0,
  `is_primary` tinyint(1) NOT NULL DEFAULT 0,
  `sort_order` int(11) NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `ix_ccontact_customer` (`customer_id`,`sort_order`,`id`),
  KEY `ix_ccontact_email` (`email`),
  KEY `ix_ccontact_phone` (`phone`),
  CONSTRAINT `customer_contacts_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer_contacts`
--

LOCK TABLES `customer_contacts` WRITE;
/*!40000 ALTER TABLE `customer_contacts` DISABLE KEYS */;
/*!40000 ALTER TABLE `customer_contacts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customer_credit_status`
--

DROP TABLE IF EXISTS `customer_credit_status`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customer_credit_status` (
  `customer_id` int(10) unsigned NOT NULL,
  `dunning_level` smallint(5) unsigned NOT NULL DEFAULT 0,
  `last_dunned_at` date DEFAULT NULL,
  `last_run_id` int(10) unsigned DEFAULT NULL,
  `paused_until` date DEFAULT NULL,
  `pause_reason` varchar(200) DEFAULT NULL,
  `held_at` datetime DEFAULT NULL,
  `hold_reason` varchar(200) DEFAULT NULL,
  `promises_made` int(10) unsigned NOT NULL DEFAULT 0,
  `promises_kept` int(10) unsigned NOT NULL DEFAULT 0,
  `promises_broken` int(10) unsigned NOT NULL DEFAULT 0,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`customer_id`),
  KEY `idx_credit_level` (`dunning_level`,`last_dunned_at`),
  CONSTRAINT `customer_credit_status_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer_credit_status`
--

LOCK TABLES `customer_credit_status` WRITE;
/*!40000 ALTER TABLE `customer_credit_status` DISABLE KEYS */;
/*!40000 ALTER TABLE `customer_credit_status` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customer_documents`
--

DROP TABLE IF EXISTS `customer_documents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customer_documents` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `entity` varchar(40) NOT NULL DEFAULT 'customer',
  `entity_id` int(10) unsigned NOT NULL,
  `filename` varchar(255) NOT NULL,
  `stored_name` varchar(190) NOT NULL,
  `mime_type` varchar(120) DEFAULT NULL,
  `size_bytes` bigint(20) unsigned NOT NULL DEFAULT 0,
  `description` varchar(400) DEFAULT NULL,
  `uploaded_by` int(10) unsigned DEFAULT NULL,
  `uploaded_name` varchar(120) NOT NULL DEFAULT '',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_cdoc_stored` (`stored_name`),
  KEY `ix_cdoc_entity` (`entity`,`entity_id`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer_documents`
--

LOCK TABLES `customer_documents` WRITE;
/*!40000 ALTER TABLE `customer_documents` DISABLE KEYS */;
/*!40000 ALTER TABLE `customer_documents` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customer_groups`
--

DROP TABLE IF EXISTS `customer_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customer_groups` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(120) NOT NULL,
  `code` varchar(32) DEFAULT NULL,
  `default_terms_days` smallint(5) unsigned NOT NULL DEFAULT 30,
  `default_credit_limit` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `default_daily_limit` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `default_monthly_limit` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `default_discount_pct` decimal(6,3) DEFAULT NULL,
  `price_structure_id` int(10) unsigned DEFAULT NULL,
  `sort_order` int(11) NOT NULL DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `default_interest_rate_pct` decimal(7,4) NOT NULL DEFAULT 0.0000,
  `default_interest_enabled` tinyint(1) NOT NULL DEFAULT 0,
  `default_interest_grace_days` smallint(5) unsigned NOT NULL DEFAULT 0,
  `default_statement_cycle` enum('monthly','14day','7day') NOT NULL DEFAULT 'monthly',
  `default_statement_anchor_day` tinyint(3) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_customer_group_name` (`name`),
  KEY `ix_customer_group_active` (`is_active`,`sort_order`),
  KEY `fk_cgroup_structure` (`price_structure_id`),
  CONSTRAINT `customer_groups_ibfk_1` FOREIGN KEY (`price_structure_id`) REFERENCES `price_structures` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer_groups`
--

LOCK TABLES `customer_groups` WRITE;
/*!40000 ALTER TABLE `customer_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `customer_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customer_login_links`
--

DROP TABLE IF EXISTS `customer_login_links`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customer_login_links` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `customer_id` int(10) unsigned NOT NULL,
  `token_hash` char(64) NOT NULL,
  `expires_at` datetime NOT NULL,
  `used_at` datetime DEFAULT NULL,
  `used_ip` varchar(45) DEFAULT NULL,
  `requested_ip` varchar(45) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_login_link_hash` (`token_hash`),
  KEY `ix_login_link_customer` (`customer_id`,`created_at`),
  KEY `ix_login_link_expiry` (`expires_at`),
  CONSTRAINT `customer_login_links_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer_login_links`
--

LOCK TABLES `customer_login_links` WRITE;
/*!40000 ALTER TABLE `customer_login_links` DISABLE KEYS */;
/*!40000 ALTER TABLE `customer_login_links` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customer_logins`
--

DROP TABLE IF EXISTS `customer_logins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customer_logins` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `customer_id` int(10) unsigned NOT NULL,
  `email` varchar(190) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `failed_attempts` int(10) unsigned NOT NULL DEFAULT 0,
  `locked_until` datetime DEFAULT NULL,
  `last_login_at` datetime DEFAULT NULL,
  `must_change` tinyint(1) NOT NULL DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_customer_logins_email` (`email`),
  UNIQUE KEY `uq_customer_logins_customer` (`customer_id`),
  CONSTRAINT `customer_logins_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer_logins`
--

LOCK TABLES `customer_logins` WRITE;
/*!40000 ALTER TABLE `customer_logins` DISABLE KEYS */;
/*!40000 ALTER TABLE `customer_logins` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customer_password_resets`
--

DROP TABLE IF EXISTS `customer_password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customer_password_resets` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `login_id` int(10) unsigned NOT NULL,
  `token_hash` char(64) NOT NULL,
  `expires_at` datetime NOT NULL,
  `used_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_reset_token` (`token_hash`),
  KEY `ix_reset_login` (`login_id`),
  CONSTRAINT `customer_password_resets_ibfk_1` FOREIGN KEY (`login_id`) REFERENCES `customer_logins` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer_password_resets`
--

LOCK TABLES `customer_password_resets` WRITE;
/*!40000 ALTER TABLE `customer_password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `customer_password_resets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customer_statement_items`
--

DROP TABLE IF EXISTS `customer_statement_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customer_statement_items` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `run_id` int(10) unsigned NOT NULL,
  `customer_id` int(10) unsigned NOT NULL,
  `customer_code` varchar(32) NOT NULL,
  `customer_name` varchar(160) NOT NULL,
  `email` varchar(190) DEFAULT NULL,
  `period_from` date DEFAULT NULL,
  `period_to` date DEFAULT NULL,
  `status` enum('queued','sent','failed','skipped') NOT NULL DEFAULT 'queued',
  `closing_balance` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `overdue_amount` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `attempts` tinyint(3) unsigned NOT NULL DEFAULT 0,
  `error` varchar(400) DEFAULT NULL,
  `sent_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_item_run_customer` (`run_id`,`customer_id`),
  KEY `ix_item_status` (`run_id`,`status`),
  KEY `ix_item_customer` (`customer_id`,`sent_at`),
  CONSTRAINT `customer_statement_items_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`),
  CONSTRAINT `customer_statement_items_ibfk_2` FOREIGN KEY (`run_id`) REFERENCES `customer_statement_runs` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer_statement_items`
--

LOCK TABLES `customer_statement_items` WRITE;
/*!40000 ALTER TABLE `customer_statement_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `customer_statement_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customer_statement_runs`
--

DROP TABLE IF EXISTS `customer_statement_runs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customer_statement_runs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `period_from` date NOT NULL,
  `period_to` date NOT NULL,
  `format` enum('open-item','activity') NOT NULL DEFAULT 'open-item',
  `status` enum('pending','running','completed','failed') NOT NULL DEFAULT 'pending',
  `total_count` int(10) unsigned NOT NULL DEFAULT 0,
  `sent_count` int(10) unsigned NOT NULL DEFAULT 0,
  `failed_count` int(10) unsigned NOT NULL DEFAULT 0,
  `skipped_count` int(10) unsigned NOT NULL DEFAULT 0,
  `user_id` int(10) unsigned DEFAULT NULL,
  `user_name` varchar(120) NOT NULL DEFAULT '',
  `origin_site_id` int(10) unsigned DEFAULT NULL,
  `started_at` datetime DEFAULT NULL,
  `finished_at` datetime DEFAULT NULL,
  `error` varchar(400) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `ix_run_status` (`status`,`created_at`),
  KEY `ix_run_created` (`created_at`),
  KEY `ix_srun_origin` (`origin_site_id`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer_statement_runs`
--

LOCK TABLES `customer_statement_runs` WRITE;
/*!40000 ALTER TABLE `customer_statement_runs` DISABLE KEYS */;
/*!40000 ALTER TABLE `customer_statement_runs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customer_transactions`
--

DROP TABLE IF EXISTS `customer_transactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customer_transactions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `customer_id` int(10) unsigned NOT NULL,
  `doc_type` enum('invoice','credit_note','payment','journal','opening','interest') NOT NULL,
  `doc_number` varchar(32) DEFAULT NULL,
  `doc_date` date NOT NULL,
  `due_date` date DEFAULT NULL,
  `reference` varchar(60) DEFAULT NULL,
  `description` varchar(190) DEFAULT NULL,
  `amount_gross` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `amount_vat` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `amount_net` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `amount_signed` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `amount_outstanding` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `source` varchar(24) NOT NULL DEFAULT 'manual',
  `source_doc_id` int(10) unsigned DEFAULT NULL,
  `origin_site_id` int(10) unsigned DEFAULT NULL,
  `reverses_id` int(10) unsigned DEFAULT NULL,
  `user_id` int(10) unsigned DEFAULT NULL,
  `user_name` varchar(120) NOT NULL DEFAULT '',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `ix_ctxn_customer_date` (`customer_id`,`doc_date`,`id`),
  KEY `ix_ctxn_outstanding` (`customer_id`,`due_date`,`amount_outstanding`),
  KEY `ix_ctxn_doc` (`doc_type`,`doc_number`),
  KEY `ix_ctxn_date` (`doc_date`),
  KEY `ix_ctxn_source` (`source`,`source_doc_id`),
  KEY `fk_ctxn_reverses` (`reverses_id`),
  KEY `ix_ctxn_origin_source` (`origin_site_id`,`source`,`source_doc_id`),
  CONSTRAINT `customer_transactions_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`),
  CONSTRAINT `customer_transactions_ibfk_2` FOREIGN KEY (`reverses_id`) REFERENCES `customer_transactions` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer_transactions`
--

LOCK TABLES `customer_transactions` WRITE;
/*!40000 ALTER TABLE `customer_transactions` DISABLE KEYS */;
INSERT INTO `customer_transactions` VALUES (1,1,'invoice','INV000002','2026-08-09','2026-09-08',NULL,'Invoice INV000002',317.4000,0.0000,317.4000,317.4000,262.4000,'sale',2,NULL,NULL,1,'Tiaan Smith','2026-08-09 10:14:30','2026-08-09 12:48:00'),(2,1,'payment',NULL,'2026-07-26',NULL,NULL,NULL,55.0000,0.0000,55.0000,-55.0000,0.0000,'manual',NULL,NULL,NULL,1,'Tiaan Smith','2026-08-09 12:48:00','2026-08-09 12:48:00'),(3,1,'invoice','INV000003','2026-08-11','2026-08-25',NULL,'Invoice INV000003',149.5000,0.0000,149.5000,149.5000,0.0000,'sale',9,NULL,NULL,1,'Tiaan Smith','2026-08-11 13:46:45','2026-08-11 13:50:30'),(4,1,'journal','REV-INV000003','2026-08-11',NULL,NULL,'Reversal of Invoice INV000003 — Void of INV000003: test',-149.5000,0.0000,-149.5000,-149.5000,0.0000,'manual',NULL,NULL,3,1,'Tiaan Smith','2026-08-11 13:50:30','2026-08-11 13:50:30');
/*!40000 ALTER TABLE `customer_transactions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customers`
--

DROP TABLE IF EXISTS `customers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customers` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(32) NOT NULL,
  `name` varchar(160) NOT NULL,
  `status` enum('active','on_hold','inactive','closed') NOT NULL DEFAULT 'active',
  `status_reason` varchar(190) DEFAULT NULL,
  `account_type` enum('open_item','balance_fwd','cash','lay_by') NOT NULL DEFAULT 'open_item',
  `contact_name` varchar(120) DEFAULT NULL,
  `email` varchar(190) DEFAULT NULL,
  `phone` varchar(40) DEFAULT NULL,
  `address_line1` varchar(190) DEFAULT NULL,
  `address_line2` varchar(190) DEFAULT NULL,
  `city` varchar(120) DEFAULT NULL,
  `postal_code` varchar(20) DEFAULT NULL,
  `vat_number` varchar(40) DEFAULT NULL,
  `group_id` int(10) unsigned DEFAULT NULL,
  `price_structure_id` int(10) unsigned DEFAULT NULL,
  `rep_id` int(10) unsigned DEFAULT NULL,
  `rep_name` varchar(120) DEFAULT NULL,
  `category` varchar(60) DEFAULT NULL,
  `payment_terms_days` smallint(5) unsigned NOT NULL DEFAULT 30,
  `statement_cycle` enum('monthly','14day','7day') NOT NULL DEFAULT 'monthly',
  `statement_anchor_day` tinyint(3) unsigned NOT NULL DEFAULT 0,
  `statement_anchor_date` date DEFAULT NULL,
  `credit_limit` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `daily_limit` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `monthly_limit` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `auto_email_invoices` tinyint(1) NOT NULL DEFAULT 0,
  `discount_pct` decimal(6,3) DEFAULT NULL,
  `interest_rate_pct` decimal(7,4) NOT NULL DEFAULT 0.0000,
  `interest_enabled` tinyint(1) NOT NULL DEFAULT 0,
  `interest_grace_days` smallint(5) unsigned NOT NULL DEFAULT 0,
  `balance` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `notes` text DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_customer_code` (`code`),
  KEY `ix_customer_name` (`name`),
  KEY `ix_customer_status` (`status`,`name`),
  KEY `ix_customer_group` (`group_id`),
  KEY `ix_customer_rep` (`rep_id`),
  KEY `ix_customer_category` (`category`),
  KEY `ix_customer_balance` (`balance`),
  KEY `ix_customer_account_type` (`account_type`),
  KEY `fk_customer_price_structure` (`price_structure_id`),
  KEY `ix_customer_rep_name` (`rep_name`),
  CONSTRAINT `customers_ibfk_1` FOREIGN KEY (`group_id`) REFERENCES `customer_groups` (`id`) ON DELETE SET NULL,
  CONSTRAINT `customers_ibfk_2` FOREIGN KEY (`price_structure_id`) REFERENCES `price_structures` (`id`) ON DELETE SET NULL,
  CONSTRAINT `customers_ibfk_3` FOREIGN KEY (`rep_id`) REFERENCES `sales_reps` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customers`
--

LOCK TABLES `customers` WRITE;
/*!40000 ALTER TABLE `customers` DISABLE KEYS */;
INSERT INTO `customers` VALUES (1,'CUST-1','Tiaan Smith','active',NULL,'balance_fwd',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,14,'monthly',0,NULL,5000.0000,0.0000,0.0000,0,NULL,0.0000,0,0,262.4000,NULL,'2026-08-09 10:08:58','2026-08-11 13:50:30'),(2,'CUST00001','Koos','active',NULL,'balance_fwd',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,30,'monthly',0,NULL,0.0000,0.0000,0.0000,0,NULL,0.0000,0,0,0.0000,NULL,'2026-08-26 15:04:04','2026-08-26 15:04:04');
/*!40000 ALTER TABLE `customers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cycle_count_programmes`
--

DROP TABLE IF EXISTS `cycle_count_programmes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cycle_count_programmes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `location_id` int(10) unsigned NOT NULL,
  `scope` enum('full','department','brand','supplier') NOT NULL DEFAULT 'department',
  `scope_ref_id` int(10) unsigned DEFAULT NULL,
  `include_zero_stock` tinyint(1) NOT NULL DEFAULT 0,
  `frequency` enum('weekly','monthly','quarterly','annually') NOT NULL DEFAULT 'weekly',
  `day_of_week` tinyint(3) unsigned DEFAULT NULL,
  `day_of_month` tinyint(3) unsigned DEFAULT NULL,
  `starts_on` date NOT NULL,
  `ends_on` date DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `last_generated_for` date DEFAULT NULL,
  `user_name` varchar(120) NOT NULL DEFAULT '',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `fk_ccp_location` (`location_id`),
  CONSTRAINT `cycle_count_programmes_ibfk_1` FOREIGN KEY (`location_id`) REFERENCES `stock_locations` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cycle_count_programmes`
--

LOCK TABLES `cycle_count_programmes` WRITE;
/*!40000 ALTER TABLE `cycle_count_programmes` DISABLE KEYS */;
/*!40000 ALTER TABLE `cycle_count_programmes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `debt_write_offs`
--

DROP TABLE IF EXISTS `debt_write_offs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `debt_write_offs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `customer_id` int(10) unsigned NOT NULL,
  `transaction_id` int(10) unsigned DEFAULT NULL,
  `amount` decimal(12,4) NOT NULL,
  `write_off_date` date NOT NULL,
  `category` enum('bad_debt','small_bal','dispute','goodwill','other') NOT NULL DEFAULT 'bad_debt',
  `reason` varchar(400) NOT NULL,
  `requires_approval` tinyint(1) NOT NULL DEFAULT 0,
  `approved_by` varchar(120) DEFAULT NULL,
  `approved_at` datetime DEFAULT NULL,
  `status` enum('pending','posted','rejected') NOT NULL DEFAULT 'pending',
  `recovered_at` datetime DEFAULT NULL,
  `recovered_txn_id` int(10) unsigned DEFAULT NULL,
  `user_id` int(10) unsigned DEFAULT NULL,
  `user_name` varchar(120) NOT NULL DEFAULT '',
  `origin_site_id` int(10) unsigned DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `ix_wo_customer` (`customer_id`,`write_off_date`),
  KEY `ix_wo_status` (`status`,`write_off_date`),
  KEY `fk_wo_txn` (`transaction_id`),
  KEY `fk_wo_recovered` (`recovered_txn_id`),
  KEY `ix_wo_origin` (`origin_site_id`,`write_off_date`),
  CONSTRAINT `debt_write_offs_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`),
  CONSTRAINT `debt_write_offs_ibfk_2` FOREIGN KEY (`recovered_txn_id`) REFERENCES `customer_transactions` (`id`) ON DELETE SET NULL,
  CONSTRAINT `debt_write_offs_ibfk_3` FOREIGN KEY (`transaction_id`) REFERENCES `customer_transactions` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `debt_write_offs`
--

LOCK TABLES `debt_write_offs` WRITE;
/*!40000 ALTER TABLE `debt_write_offs` DISABLE KEYS */;
/*!40000 ALTER TABLE `debt_write_offs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `departments`
--

DROP TABLE IF EXISTS `departments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `departments` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` int(10) unsigned DEFAULT NULL,
  `name` varchar(120) NOT NULL,
  `code` varchar(32) DEFAULT NULL,
  `color` varchar(9) DEFAULT NULL,
  `sort_order` int(11) NOT NULL DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `show_online` tinyint(1) NOT NULL DEFAULT 0,
  `pos_image_id` bigint(20) unsigned DEFAULT NULL,
  `online_image_id` bigint(20) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_dept_parent` (`parent_id`,`sort_order`),
  CONSTRAINT `departments_ibfk_1` FOREIGN KEY (`parent_id`) REFERENCES `departments` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `departments`
--

LOCK TABLES `departments` WRITE;
/*!40000 ALTER TABLE `departments` DISABLE KEYS */;
INSERT INTO `departments` VALUES (11,NULL,'Smash Burgers','BURG','#c2410c',1,1,'2026-08-09 09:41:05','2026-08-10 09:28:06',1,NULL,11),(12,NULL,'Gourmet Hotdogs','DOGS','#b45309',2,1,'2026-08-09 09:41:05','2026-08-09 09:41:05',1,NULL,NULL),(13,NULL,'Wood-Fired Pizza','PIZZ','#b91c1c',3,1,'2026-08-09 09:41:05','2026-08-09 09:41:05',1,NULL,NULL),(14,NULL,'Sides & Loaded Fries','SIDE','#a16207',4,1,'2026-08-09 09:41:05','2026-08-09 09:41:05',1,NULL,NULL),(15,NULL,'Cooldrinks & Shakes','DRNK','#0369a1',5,1,'2026-08-09 09:41:05','2026-08-10 09:28:29',1,NULL,12),(16,NULL,'Desserts','DSRT','#9d174d',6,1,'2026-08-09 09:41:05','2026-08-09 09:41:05',1,NULL,NULL),(17,11,'Smash sub 1',NULL,NULL,0,1,'2026-08-11 14:12:29','2026-08-11 14:12:29',0,NULL,NULL),(18,17,'Smash sub 2',NULL,NULL,0,1,'2026-08-11 14:12:38','2026-08-11 14:12:38',0,NULL,NULL),(19,NULL,'Guard test',NULL,NULL,0,1,'2026-08-24 13:26:30','2026-08-24 13:26:30',0,NULL,NULL);
/*!40000 ALTER TABLE `departments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `depreciation_run_items`
--

DROP TABLE IF EXISTS `depreciation_run_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `depreciation_run_items` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `run_id` int(10) unsigned NOT NULL,
  `asset_id` int(10) unsigned NOT NULL,
  `asset_code` varchar(32) NOT NULL,
  `asset_name` varchar(160) NOT NULL,
  `cost` decimal(14,4) NOT NULL DEFAULT 0.0000,
  `residual_value` decimal(14,4) NOT NULL DEFAULT 0.0000,
  `life_months` smallint(5) unsigned NOT NULL DEFAULT 0,
  `opening_accumulated` decimal(14,4) NOT NULL DEFAULT 0.0000,
  `amount` decimal(14,4) NOT NULL DEFAULT 0.0000,
  `status` enum('pending','posted','skipped') NOT NULL DEFAULT 'pending',
  `skip_reason` varchar(190) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `ix_depitem_run` (`run_id`,`asset_name`),
  KEY `ix_depitem_asset` (`asset_id`),
  CONSTRAINT `depreciation_run_items_ibfk_1` FOREIGN KEY (`asset_id`) REFERENCES `fixed_assets` (`id`),
  CONSTRAINT `depreciation_run_items_ibfk_2` FOREIGN KEY (`run_id`) REFERENCES `depreciation_runs` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `depreciation_run_items`
--

LOCK TABLES `depreciation_run_items` WRITE;
/*!40000 ALTER TABLE `depreciation_run_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `depreciation_run_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `depreciation_runs`
--

DROP TABLE IF EXISTS `depreciation_runs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `depreciation_runs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `period_month` date NOT NULL,
  `status` enum('draft','posted','cancelled') NOT NULL DEFAULT 'draft',
  `total_amount` decimal(14,4) NOT NULL DEFAULT 0.0000,
  `asset_count` int(10) unsigned NOT NULL DEFAULT 0,
  `posted_count` int(10) unsigned NOT NULL DEFAULT 0,
  `batch_id` int(10) unsigned DEFAULT NULL,
  `notes` varchar(400) DEFAULT NULL,
  `user_id` int(10) unsigned DEFAULT NULL,
  `user_name` varchar(120) NOT NULL DEFAULT '',
  `posted_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_deprun_month` (`period_month`,`status`),
  KEY `ix_deprun_status` (`status`,`period_month`),
  KEY `fk_deprun_batch` (`batch_id`),
  CONSTRAINT `depreciation_runs_ibfk_1` FOREIGN KEY (`batch_id`) REFERENCES `journal_batches` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `depreciation_runs`
--

LOCK TABLES `depreciation_runs` WRITE;
/*!40000 ALTER TABLE `depreciation_runs` DISABLE KEYS */;
/*!40000 ALTER TABLE `depreciation_runs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `discount_code_uses`
--

DROP TABLE IF EXISTS `discount_code_uses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `discount_code_uses` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `code_id` int(10) unsigned NOT NULL,
  `order_id` int(10) unsigned DEFAULT NULL,
  `document_id` int(10) unsigned DEFAULT NULL,
  `customer_id` int(10) unsigned DEFAULT NULL,
  `contact_email` varchar(190) NOT NULL DEFAULT '',
  `amount_incl` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `used_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_use_per_order` (`order_id`),
  UNIQUE KEY `uq_use_per_document` (`document_id`),
  KEY `ix_use_by_customer` (`code_id`,`customer_id`),
  KEY `ix_use_by_email` (`code_id`,`contact_email`),
  KEY `fk_use_customer` (`customer_id`),
  CONSTRAINT `discount_code_uses_ibfk_1` FOREIGN KEY (`code_id`) REFERENCES `discount_codes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `discount_code_uses_ibfk_2` FOREIGN KEY (`document_id`) REFERENCES `sales_documents` (`id`) ON DELETE CASCADE,
  CONSTRAINT `discount_code_uses_ibfk_3` FOREIGN KEY (`order_id`) REFERENCES `online_orders` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `discount_code_uses`
--

LOCK TABLES `discount_code_uses` WRITE;
/*!40000 ALTER TABLE `discount_code_uses` DISABLE KEYS */;
/*!40000 ALTER TABLE `discount_code_uses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `discount_codes`
--

DROP TABLE IF EXISTS `discount_codes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `discount_codes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(40) NOT NULL,
  `description` varchar(190) NOT NULL DEFAULT '',
  `kind` enum('percent','amount','free_delivery') NOT NULL DEFAULT 'percent',
  `value` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `min_order_incl` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `starts_at` datetime DEFAULT NULL,
  `ends_at` datetime DEFAULT NULL,
  `max_uses` int(10) unsigned DEFAULT NULL,
  `uses_count` int(10) unsigned NOT NULL DEFAULT 0,
  `max_uses_per_customer` int(10) unsigned DEFAULT NULL,
  `first_order_only` tinyint(1) NOT NULL DEFAULT 0,
  `department_id` int(10) unsigned DEFAULT NULL,
  `combines_with_specials` tinyint(1) NOT NULL DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_by` varchar(120) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_discount_code` (`code`),
  KEY `ix_discount_active` (`is_active`,`starts_at`,`ends_at`),
  KEY `fk_discount_department` (`department_id`),
  CONSTRAINT `discount_codes_ibfk_1` FOREIGN KEY (`department_id`) REFERENCES `departments` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `discount_codes`
--

LOCK TABLES `discount_codes` WRITE;
/*!40000 ALTER TABLE `discount_codes` DISABLE KEYS */;
/*!40000 ALTER TABLE `discount_codes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `document_audit`
--

DROP TABLE IF EXISTS `document_audit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `document_audit` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `document_id` int(10) unsigned NOT NULL,
  `action` varchar(40) NOT NULL,
  `detail` varchar(400) DEFAULT NULL,
  `before_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`before_json`)),
  `after_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`after_json`)),
  `user_id` int(10) unsigned DEFAULT NULL,
  `user_name` varchar(120) NOT NULL DEFAULT '',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `ix_docaudit_document` (`document_id`,`created_at`),
  CONSTRAINT `document_audit_ibfk_1` FOREIGN KEY (`document_id`) REFERENCES `sales_documents` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `document_audit`
--

LOCK TABLES `document_audit` WRITE;
/*!40000 ALTER TABLE `document_audit` DISABLE KEYS */;
INSERT INTO `document_audit` VALUES (1,1,'finalised','INV000001 · 59.80 · Cash',NULL,NULL,1,'Tiaan Smith','2026-08-09 09:50:14'),(2,2,'finalised','INV000002 · 317.40 · Account',NULL,NULL,1,'Tiaan Smith','2026-08-09 10:14:30'),(3,9,'finalised','INV000003 · 149.50 · Account',NULL,NULL,1,'Tiaan Smith','2026-08-11 13:46:45'),(4,8,'finalised','INV000004 · 774.00 · Cash, Card',NULL,NULL,1,'Tiaan Smith','2026-08-11 13:49:00'),(5,9,'cancelled','test',NULL,NULL,1,'Tiaan Smith','2026-08-11 13:50:30'),(6,10,'finalised','INV_01_01_000001 · 20.00 · Cash',NULL,NULL,1,'Tiaan Smith','2026-08-24 12:50:09'),(7,12,'finalised','INV_01_03_000001 · 139.00 · Cash',NULL,NULL,1,'Tiaan Smith','2026-08-25 19:18:39'),(8,11,'finalised','INV_01_03_000002 · 139.00 · Cash',NULL,NULL,1,'Tiaan Smith','2026-08-25 19:19:45'),(9,18,'finalised','INV_01_04_000001 · 500.00 · Cash',NULL,NULL,1,'Tiaan Smith','2026-08-26 15:23:34'),(10,19,'finalised','INV_01_04_000002 · 119.00 · Exchange credit',NULL,NULL,1,'Tiaan Smith','2026-08-26 15:33:03'),(11,20,'finalised','INV_01_04_000003 · 28.00 · Exchange credit',NULL,NULL,1,'Tiaan Smith','2026-08-26 15:34:12'),(12,23,'finalised','INV_01_04_000004 · 119.00 · Gift card',NULL,NULL,1,'Tiaan Smith','2026-08-26 15:39:13'),(13,30,'finalised','INV_01_05_000001 · 20.00 · Cash',NULL,NULL,1,'Tiaan Smith','2026-08-31 10:55:39'),(14,31,'finalised','INV_01_01_000002 · 0.00 · Cash',NULL,NULL,1,'Tiaan Smith','2026-09-01 11:04:57');
/*!40000 ALTER TABLE `document_audit` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `document_sequences`
--

DROP TABLE IF EXISTS `document_sequences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `document_sequences` (
  `terminal_id` int(10) unsigned NOT NULL DEFAULT 0,
  `doc_type` varchar(24) NOT NULL,
  `prefix` varchar(12) NOT NULL DEFAULT '',
  `next_number` int(10) unsigned NOT NULL DEFAULT 1,
  `last_issued_number` int(10) unsigned DEFAULT NULL,
  `padding` tinyint(3) unsigned NOT NULL DEFAULT 6,
  `reset_period` enum('none','yearly') NOT NULL DEFAULT 'none',
  `period_key` varchar(8) DEFAULT NULL,
  `last_issued_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`doc_type`,`terminal_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `document_sequences`
--

LOCK TABLES `document_sequences` WRITE;
/*!40000 ALTER TABLE `document_sequences` DISABLE KEYS */;
INSERT INTO `document_sequences` VALUES (0,'asset','FA',1,NULL,5,'none',NULL,NULL,'2026-08-06 22:26:44','2026-08-06 22:26:44'),(0,'cashup','CSH',6,5,6,'none',NULL,'2026-09-01 10:18:01','2026-08-25 12:46:20','2026-09-01 10:18:01'),(0,'contract','CON',1,NULL,6,'none',NULL,NULL,'2026-08-07 09:31:40','2026-08-07 09:31:40'),(0,'credit_sale','CRN',1,NULL,6,'none',NULL,NULL,'2026-08-05 13:07:59','2026-08-05 19:50:28'),(1,'credit_sale','CRN',1,NULL,6,'none',NULL,NULL,'2026-08-24 11:04:47','2026-08-24 11:04:47'),(2,'credit_sale','CRN',1,NULL,6,'none',NULL,NULL,'2026-08-24 14:57:06','2026-08-24 14:57:06'),(3,'credit_sale','CRN',1,NULL,6,'none',NULL,NULL,'2026-08-25 19:12:07','2026-08-25 19:12:07'),(4,'credit_sale','CRN',1,NULL,6,'none',NULL,NULL,'2026-08-26 15:07:58','2026-08-26 15:07:58'),(5,'credit_sale','CRN',1,NULL,6,'none',NULL,NULL,'2026-08-31 10:53:44','2026-08-31 10:53:44'),(6,'credit_sale','CRN',1,NULL,6,'none',NULL,NULL,'2026-09-01 10:17:47','2026-09-01 10:17:47'),(0,'customer','CUST',2,1,5,'none',NULL,'2026-08-26 15:04:04','2026-08-07 09:42:26','2026-08-26 15:04:04'),(0,'customer_asset','AST',1,NULL,6,'none',NULL,NULL,'2026-08-24 09:10:34','2026-08-24 09:10:34'),(0,'expense','EXP',2,1,6,'none',NULL,'2026-08-10 07:41:07','2026-08-06 21:21:13','2026-08-10 07:41:07'),(0,'grv','GRV',20,19,6,'none',NULL,'2026-08-24 12:49:22','2026-08-05 15:14:43','2026-08-24 12:49:22'),(0,'invoice','INV',5,4,6,'none',NULL,'2026-08-11 13:49:00','2026-08-05 13:07:59','2026-08-11 13:49:00'),(1,'invoice','INV',3,2,6,'none',NULL,'2026-09-01 11:04:57','2026-08-24 11:04:47','2026-09-01 11:04:57'),(2,'invoice','INV',1,NULL,6,'none',NULL,NULL,'2026-08-24 14:57:06','2026-08-24 14:57:06'),(3,'invoice','INV',3,2,6,'none',NULL,'2026-08-25 19:19:45','2026-08-25 19:12:07','2026-08-25 19:19:45'),(4,'invoice','INV',5,4,6,'none',NULL,'2026-08-26 15:39:13','2026-08-26 15:07:58','2026-08-26 15:39:13'),(5,'invoice','INV',2,1,6,'none',NULL,'2026-08-31 10:55:39','2026-08-31 10:53:44','2026-08-31 10:55:39'),(6,'invoice','INV',1,NULL,6,'none',NULL,NULL,'2026-09-01 10:17:47','2026-09-01 10:17:47'),(0,'job_card','JC',1,NULL,6,'none',NULL,NULL,'2026-08-24 09:10:34','2026-08-24 09:10:34'),(0,'journal','JNL',38,37,6,'none',NULL,'2026-08-31 10:55:39','2026-08-06 21:54:38','2026-08-31 10:55:39'),(0,'layby','LAY',1,NULL,6,'none',NULL,NULL,'2026-08-05 20:16:31','2026-08-05 20:16:31'),(0,'manufacturing_order','MO',1,NULL,6,'none',NULL,NULL,'2026-08-10 13:35:33','2026-08-10 13:35:33'),(0,'product','PRD',21,20,5,'none',NULL,'2026-08-26 16:01:44','2026-08-07 09:42:26','2026-08-26 16:01:44'),(0,'purchase_order','PO',3,2,6,'none',NULL,'2026-08-12 10:55:49','2026-08-05 15:14:43','2026-08-12 10:55:49'),(0,'quote','QUO',1,NULL,6,'none',NULL,NULL,'2026-08-05 13:07:59','2026-08-05 13:07:59'),(1,'quote','QUO',1,NULL,6,'none',NULL,NULL,'2026-08-24 11:04:47','2026-08-24 11:04:47'),(2,'quote','QUO',1,NULL,6,'none',NULL,NULL,'2026-08-24 14:57:06','2026-08-24 14:57:06'),(3,'quote','QUO',1,NULL,6,'none',NULL,NULL,'2026-08-25 19:12:07','2026-08-25 19:12:07'),(4,'quote','QUO',1,NULL,6,'none',NULL,NULL,'2026-08-26 15:07:58','2026-08-26 15:07:58'),(5,'quote','QUO',1,NULL,6,'none',NULL,NULL,'2026-08-31 10:53:44','2026-08-31 10:53:44'),(6,'quote','QUO',1,NULL,6,'none',NULL,NULL,'2026-09-01 10:17:47','2026-09-01 10:17:47'),(0,'sales_order','SO',1,NULL,6,'none',NULL,NULL,'2026-08-05 13:07:59','2026-08-05 13:07:59'),(1,'sales_order','SO',1,NULL,6,'none',NULL,NULL,'2026-08-24 11:04:47','2026-08-24 11:04:47'),(2,'sales_order','SO',1,NULL,6,'none',NULL,NULL,'2026-08-24 14:57:06','2026-08-24 14:57:06'),(3,'sales_order','SO',1,NULL,6,'none',NULL,NULL,'2026-08-25 19:12:07','2026-08-25 19:12:07'),(4,'sales_order','SO',1,NULL,6,'none',NULL,NULL,'2026-08-26 15:07:58','2026-08-26 15:07:58'),(5,'sales_order','SO',1,NULL,6,'none',NULL,NULL,'2026-08-31 10:53:44','2026-08-31 10:53:44'),(6,'sales_order','SO',1,NULL,6,'none',NULL,NULL,'2026-09-01 10:17:47','2026-09-01 10:17:47'),(0,'stock_adjustment','ADJ',5,4,6,'none',NULL,'2026-08-26 16:51:23','2026-08-12 08:49:30','2026-08-26 16:51:23'),(0,'stock_take','STK',2,1,6,'none',NULL,'2026-08-26 16:47:38','2026-08-10 13:35:32','2026-08-26 16:47:38'),(0,'stock_transfer','TRF',1,NULL,6,'none',NULL,NULL,'2026-08-05 20:50:09','2026-08-05 20:50:09'),(0,'supplier','SUPP',1,NULL,5,'none',NULL,NULL,'2026-08-07 09:42:26','2026-08-07 09:42:26'),(0,'supplier_return','SRT',1,NULL,6,'none',NULL,NULL,'2026-08-05 15:14:43','2026-08-05 15:14:43'),(0,'terminal','TILL',7,6,2,'none',NULL,'2026-09-01 10:17:47','2026-08-24 09:10:37','2026-09-01 10:17:47'),(0,'ticket','TK',1,NULL,6,'none',NULL,NULL,'2026-08-24 09:10:36','2026-08-24 09:10:36');
/*!40000 ALTER TABLE `document_sequences` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dunning_levels`
--

DROP TABLE IF EXISTS `dunning_levels`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dunning_levels` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `step` smallint(5) unsigned NOT NULL,
  `name` varchar(80) NOT NULL,
  `min_days_overdue` smallint(5) unsigned NOT NULL,
  `min_amount` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `subject` varchar(200) NOT NULL,
  `body` text NOT NULL,
  `channel` enum('email','sms','both') NOT NULL DEFAULT 'email',
  `sms_body` varchar(320) DEFAULT NULL,
  `blocks_account` tinyint(1) NOT NULL DEFAULT 0,
  `requires_call` tinyint(1) NOT NULL DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_dunning_step` (`step`),
  KEY `idx_dunning_active` (`is_active`,`min_days_overdue`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dunning_levels`
--

LOCK TABLES `dunning_levels` WRITE;
/*!40000 ALTER TABLE `dunning_levels` DISABLE KEYS */;
INSERT INTO `dunning_levels` VALUES (1,1,'Friendly reminder',7,50.0000,'Your account with {company} — {overdue} outstanding','Hi {customer},\n\nThis is a friendly reminder that {overdue} on your account is now past due. The oldest item is {oldest_days} days overdue.\n\n{lines}\nIf you have already paid, thank you — please ignore this note and accept our apologies for the crossed wires.\n\nKind regards\n{company}','email',NULL,0,0,1,'2026-08-06 21:22:50','2026-08-06 21:22:50'),(2,2,'Second reminder',30,50.0000,'Second reminder — {overdue} overdue on your account','Hi {customer},\n\nWe wrote to you previously about {overdue} outstanding on your account. That amount is still unpaid, and the oldest item is now {oldest_days} days overdue.\n\n{lines}\nPlease arrange payment, or contact us to discuss the account if something is holding it up.\n\nKind regards\n{company}','email',NULL,0,0,1,'2026-08-06 21:22:50','2026-08-06 21:22:50'),(3,3,'Final demand',60,50.0000,'Final demand — {overdue} on your account','Dear {customer},\n\nDespite previous reminders, {overdue} remains outstanding on your account. The oldest item is {oldest_days} days overdue.\n\n{lines}\nYour account has been placed on hold and no further orders can be processed on credit until it is settled. Please contact us immediately to arrange payment.\n\n{company}','email',NULL,1,1,1,'2026-08-06 21:22:50','2026-08-06 21:22:50');
/*!40000 ALTER TABLE `dunning_levels` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dunning_run_items`
--

DROP TABLE IF EXISTS `dunning_run_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dunning_run_items` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `run_id` int(10) unsigned NOT NULL,
  `customer_id` int(10) unsigned NOT NULL,
  `customer_code` varchar(40) NOT NULL,
  `customer_name` varchar(200) NOT NULL,
  `email` varchar(190) DEFAULT NULL,
  `phone` varchar(40) DEFAULT NULL,
  `level_id` int(10) unsigned DEFAULT NULL,
  `level_step` smallint(5) unsigned NOT NULL,
  `level_name` varchar(80) NOT NULL,
  `overdue_amount` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `total_balance` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `oldest_days` smallint(6) NOT NULL DEFAULT 0,
  `status` enum('queued','sent','failed','skipped','excluded') NOT NULL DEFAULT 'queued',
  `sms_status` enum('none','sent','failed','skipped') NOT NULL DEFAULT 'none',
  `sms_error` varchar(400) DEFAULT NULL,
  `attempts` smallint(5) unsigned NOT NULL DEFAULT 0,
  `error` text DEFAULT NULL,
  `sent_at` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_dunning_item_run` (`run_id`,`status`),
  KEY `idx_dunning_item_customer` (`customer_id`,`created_at`),
  CONSTRAINT `dunning_run_items_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE CASCADE,
  CONSTRAINT `dunning_run_items_ibfk_2` FOREIGN KEY (`run_id`) REFERENCES `dunning_runs` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dunning_run_items`
--

LOCK TABLES `dunning_run_items` WRITE;
/*!40000 ALTER TABLE `dunning_run_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `dunning_run_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dunning_runs`
--

DROP TABLE IF EXISTS `dunning_runs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dunning_runs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `as_at` date NOT NULL,
  `status` enum('draft','sending','completed','cancelled') NOT NULL DEFAULT 'draft',
  `total_count` int(10) unsigned NOT NULL DEFAULT 0,
  `sent_count` int(10) unsigned NOT NULL DEFAULT 0,
  `failed_count` int(10) unsigned NOT NULL DEFAULT 0,
  `skipped_count` int(10) unsigned NOT NULL DEFAULT 0,
  `total_overdue` decimal(14,4) NOT NULL DEFAULT 0.0000,
  `user_id` int(10) unsigned DEFAULT NULL,
  `user_name` varchar(120) NOT NULL DEFAULT '',
  `sent_by_id` int(10) unsigned DEFAULT NULL,
  `sent_by_name` varchar(120) DEFAULT NULL,
  `started_at` datetime DEFAULT NULL,
  `finished_at` datetime DEFAULT NULL,
  `error` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_dunning_run_status` (`status`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dunning_runs`
--

LOCK TABLES `dunning_runs` WRITE;
/*!40000 ALTER TABLE `dunning_runs` DISABLE KEYS */;
/*!40000 ALTER TABLE `dunning_runs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `expense_categories`
--

DROP TABLE IF EXISTS `expense_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `expense_categories` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `account_code` varchar(16) NOT NULL,
  `name` varchar(120) NOT NULL,
  `parent_id` int(10) unsigned DEFAULT NULL,
  `category_type` enum('operating','cost_of_sales','capital','other') NOT NULL DEFAULT 'operating',
  `default_vat_rate_id` int(10) unsigned DEFAULT NULL,
  `vat_claimable` tinyint(1) NOT NULL DEFAULT 1,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `sort_order` int(11) NOT NULL DEFAULT 0,
  `notes` varchar(400) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_expcat_code` (`account_code`),
  KEY `ix_expcat_parent` (`parent_id`,`sort_order`),
  KEY `ix_expcat_active` (`is_active`,`sort_order`),
  KEY `fk_expcat_vat` (`default_vat_rate_id`),
  CONSTRAINT `expense_categories_ibfk_1` FOREIGN KEY (`parent_id`) REFERENCES `expense_categories` (`id`),
  CONSTRAINT `expense_categories_ibfk_2` FOREIGN KEY (`default_vat_rate_id`) REFERENCES `vat_rates` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `expense_categories`
--

LOCK TABLES `expense_categories` WRITE;
/*!40000 ALTER TABLE `expense_categories` DISABLE KEYS */;
INSERT INTO `expense_categories` VALUES (1,'4000','Cost of sales — freight in',NULL,'cost_of_sales',NULL,1,1,10,NULL,'2026-08-06 21:18:43','2026-08-06 21:18:43'),(2,'4010','Cost of sales — subcontractors',NULL,'cost_of_sales',NULL,1,1,20,NULL,'2026-08-06 21:18:43','2026-08-06 21:18:43'),(3,'5000','Rent',NULL,'operating',NULL,1,1,100,NULL,'2026-08-06 21:18:43','2026-08-06 21:18:43'),(4,'5010','Electricity and water',NULL,'operating',NULL,1,1,110,NULL,'2026-08-06 21:18:43','2026-08-06 21:18:43'),(5,'5020','Telephone and internet',NULL,'operating',NULL,1,1,120,NULL,'2026-08-06 21:18:43','2026-08-06 21:18:43'),(6,'5030','Salaries and wages',NULL,'operating',NULL,0,1,130,NULL,'2026-08-06 21:18:43','2026-08-06 21:18:43'),(7,'5040','Insurance',NULL,'operating',NULL,1,1,140,NULL,'2026-08-06 21:18:43','2026-08-06 21:18:43'),(8,'5050','Repairs and maintenance',NULL,'operating',NULL,1,1,150,NULL,'2026-08-06 21:18:43','2026-08-06 21:18:43'),(9,'5060','Motor vehicle expenses',NULL,'operating',NULL,1,1,160,NULL,'2026-08-06 21:18:43','2026-08-06 21:18:43'),(10,'5070','Fuel',NULL,'operating',NULL,1,1,170,NULL,'2026-08-06 21:18:43','2026-08-06 21:18:43'),(11,'5080','Cleaning and consumables',NULL,'operating',NULL,1,1,180,NULL,'2026-08-06 21:18:43','2026-08-06 21:18:43'),(12,'5090','Printing and stationery',NULL,'operating',NULL,1,1,190,NULL,'2026-08-06 21:18:43','2026-08-06 21:18:43'),(13,'5100','Advertising and marketing',NULL,'operating',NULL,1,1,200,NULL,'2026-08-06 21:18:43','2026-08-06 21:18:43'),(14,'5110','Accounting and legal fees',NULL,'operating',NULL,1,1,210,NULL,'2026-08-06 21:18:43','2026-08-06 21:18:43'),(15,'5120','Security',NULL,'operating',NULL,1,1,220,NULL,'2026-08-06 21:18:43','2026-08-06 21:18:43'),(16,'5130','Software and subscriptions',NULL,'operating',NULL,1,1,230,NULL,'2026-08-06 21:18:43','2026-08-06 21:18:43'),(17,'5140','Staff welfare and training',NULL,'operating',NULL,1,1,240,NULL,'2026-08-06 21:18:43','2026-08-06 21:18:43'),(18,'5150','Entertainment',NULL,'operating',NULL,0,1,250,NULL,'2026-08-06 21:18:43','2026-08-06 21:18:43'),(19,'5160','Travel and accommodation',NULL,'operating',NULL,1,1,260,NULL,'2026-08-06 21:18:43','2026-08-06 21:18:43'),(20,'5170','Licences and permits',NULL,'operating',NULL,1,1,270,NULL,'2026-08-06 21:18:43','2026-08-06 21:18:43'),(21,'5900','Sundry expenses',NULL,'operating',NULL,1,1,900,NULL,'2026-08-06 21:18:43','2026-08-06 21:18:43'),(22,'6000','Bank charges',NULL,'other',NULL,1,1,1000,NULL,'2026-08-06 21:18:43','2026-08-06 21:18:43'),(23,'6010','Interest paid',NULL,'other',NULL,0,1,1010,NULL,'2026-08-06 21:18:43','2026-08-06 21:18:43'),(24,'7000','Equipment purchases (capital)',NULL,'capital',NULL,1,1,2000,NULL,'2026-08-06 21:18:43','2026-08-06 21:18:43'),(25,'7010','Vehicle purchases (capital)',NULL,'capital',NULL,1,1,2010,NULL,'2026-08-06 21:18:43','2026-08-06 21:18:43');
/*!40000 ALTER TABLE `expense_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `expense_lines`
--

DROP TABLE IF EXISTS `expense_lines`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `expense_lines` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `expense_id` int(10) unsigned NOT NULL,
  `line_number` smallint(5) unsigned NOT NULL DEFAULT 1,
  `category_id` int(10) unsigned NOT NULL,
  `category_code` varchar(16) DEFAULT NULL,
  `category_name` varchar(120) DEFAULT NULL,
  `description` varchar(190) DEFAULT NULL,
  `department_id` int(10) unsigned DEFAULT NULL,
  `vat_rate_pct` decimal(6,3) NOT NULL DEFAULT 0.000,
  `line_excl` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `line_vat` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `line_incl` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `vat_claimable` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `ix_expline_expense` (`expense_id`,`line_number`),
  KEY `ix_expline_category` (`category_id`),
  KEY `ix_expline_dept` (`department_id`),
  CONSTRAINT `expense_lines_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `expense_categories` (`id`),
  CONSTRAINT `expense_lines_ibfk_2` FOREIGN KEY (`department_id`) REFERENCES `departments` (`id`) ON DELETE SET NULL,
  CONSTRAINT `expense_lines_ibfk_3` FOREIGN KEY (`expense_id`) REFERENCES `expenses` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `expense_lines`
--

LOCK TABLES `expense_lines` WRITE;
/*!40000 ALTER TABLE `expense_lines` DISABLE KEYS */;
INSERT INTO `expense_lines` VALUES (1,1,1,10,'5070','Fuel',NULL,NULL,15.000,1304.3500,195.6500,1500.0000,1,'2026-08-10 07:41:07');
/*!40000 ALTER TABLE `expense_lines` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `expenses`
--

DROP TABLE IF EXISTS `expenses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `expenses` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `status` enum('draft','finalised','void') NOT NULL DEFAULT 'draft',
  `document_number` varchar(32) DEFAULT NULL,
  `expense_date` date NOT NULL,
  `due_date` date DEFAULT NULL,
  `payment_type` enum('on_account','direct') NOT NULL DEFAULT 'direct',
  `supplier_id` int(10) unsigned DEFAULT NULL,
  `supplier_name` varchar(160) DEFAULT NULL,
  `supplier_invoice_no` varchar(60) DEFAULT NULL,
  `bank_account_id` int(10) unsigned DEFAULT NULL,
  `bank_txn_id` int(10) unsigned DEFAULT NULL,
  `supplier_txn_id` int(10) unsigned DEFAULT NULL,
  `subtotal_excl` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `vat_total` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `total_incl` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `vat_claimable` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `reference` varchar(60) DEFAULT NULL,
  `description` varchar(190) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `recurring_id` int(10) unsigned DEFAULT NULL,
  `reverses_id` int(10) unsigned DEFAULT NULL,
  `user_id` int(10) unsigned DEFAULT NULL,
  `user_name` varchar(120) NOT NULL DEFAULT '',
  `finalised_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_exp_number` (`document_number`),
  KEY `ix_exp_date` (`expense_date`,`id`),
  KEY `ix_exp_status` (`status`,`expense_date`),
  KEY `ix_exp_supplier` (`supplier_id`,`expense_date`),
  KEY `ix_exp_bank` (`bank_account_id`),
  KEY `ix_exp_recurring` (`recurring_id`),
  KEY `ix_exp_supplier_invoice` (`supplier_id`,`supplier_invoice_no`),
  KEY `fk_exp_bank_txn` (`bank_txn_id`),
  KEY `fk_exp_supplier_txn` (`supplier_txn_id`),
  KEY `fk_exp_reverses` (`reverses_id`),
  CONSTRAINT `expenses_ibfk_1` FOREIGN KEY (`bank_account_id`) REFERENCES `bank_accounts` (`id`),
  CONSTRAINT `expenses_ibfk_2` FOREIGN KEY (`bank_txn_id`) REFERENCES `bank_transactions` (`id`) ON DELETE SET NULL,
  CONSTRAINT `expenses_ibfk_3` FOREIGN KEY (`recurring_id`) REFERENCES `recurring_expenses` (`id`) ON DELETE SET NULL,
  CONSTRAINT `expenses_ibfk_4` FOREIGN KEY (`reverses_id`) REFERENCES `expenses` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `expenses`
--

LOCK TABLES `expenses` WRITE;
/*!40000 ALTER TABLE `expenses` DISABLE KEYS */;
INSERT INTO `expenses` VALUES (1,'finalised','EXP000001','2026-08-10',NULL,'direct',NULL,'Shell Garage',NULL,2,1,NULL,1304.3500,195.6500,1500.0000,195.6500,NULL,'Petrol',NULL,NULL,NULL,1,'Tiaan Smith','2026-08-10 07:41:07','2026-08-10 07:41:07','2026-08-10 07:41:07');
/*!40000 ALTER TABLE `expenses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fixed_assets`
--

DROP TABLE IF EXISTS `fixed_assets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fixed_assets` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `asset_code` varchar(32) NOT NULL,
  `name` varchar(160) NOT NULL,
  `description` varchar(400) DEFAULT NULL,
  `category_id` int(10) unsigned NOT NULL,
  `serial_number` varchar(120) DEFAULT NULL,
  `location` varchar(160) DEFAULT NULL,
  `status` enum('pending','active','disposed') NOT NULL DEFAULT 'active',
  `acquired_on` date NOT NULL,
  `cost` decimal(14,4) NOT NULL DEFAULT 0.0000,
  `residual_value` decimal(14,4) NOT NULL DEFAULT 0.0000,
  `life_months` smallint(5) unsigned NOT NULL DEFAULT 36,
  `depreciation_start` date NOT NULL,
  `depreciation_method` enum('straight_line') NOT NULL DEFAULT 'straight_line',
  `accumulated_depreciation` decimal(14,4) NOT NULL DEFAULT 0.0000,
  `last_depreciated_to` date DEFAULT NULL,
  `expense_id` int(10) unsigned DEFAULT NULL,
  `supplier_id` int(10) unsigned DEFAULT NULL,
  `invoice_number` varchar(60) DEFAULT NULL,
  `disposed_on` date DEFAULT NULL,
  `disposal_proceeds` decimal(14,4) DEFAULT NULL,
  `disposal_result` decimal(14,4) DEFAULT NULL,
  `disposal_reason` varchar(400) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `user_id` int(10) unsigned DEFAULT NULL,
  `user_name` varchar(120) NOT NULL DEFAULT '',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_asset_code` (`asset_code`),
  KEY `ix_asset_status` (`status`,`acquired_on`),
  KEY `ix_asset_category` (`category_id`),
  KEY `ix_asset_expense` (`expense_id`),
  KEY `ix_asset_supplier` (`supplier_id`),
  CONSTRAINT `fixed_assets_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `asset_categories` (`id`),
  CONSTRAINT `fixed_assets_ibfk_2` FOREIGN KEY (`expense_id`) REFERENCES `expenses` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fixed_assets`
--

LOCK TABLES `fixed_assets` WRITE;
/*!40000 ALTER TABLE `fixed_assets` DISABLE KEYS */;
/*!40000 ALTER TABLE `fixed_assets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gift_card_events`
--

DROP TABLE IF EXISTS `gift_card_events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gift_card_events` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `card_id` bigint(20) unsigned NOT NULL,
  `entry_type` enum('activation','redeem','reload','refund','expire','adjust') NOT NULL,
  `amount` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `document_id` int(10) unsigned DEFAULT NULL,
  `document_number` varchar(40) NOT NULL DEFAULT '',
  `origin_site_id` int(10) unsigned DEFAULT NULL,
  `order_id` int(10) unsigned DEFAULT NULL,
  `shift_id` int(10) unsigned DEFAULT NULL,
  `terminal_id` int(10) unsigned DEFAULT NULL,
  `note` varchar(255) NOT NULL DEFAULT '',
  `user_id` int(10) unsigned DEFAULT NULL,
  `user_name` varchar(120) NOT NULL DEFAULT '',
  `created_at` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_gc_event_doc` (`card_id`,`origin_site_id`,`document_id`,`entry_type`),
  KEY `idx_gc_event_card` (`card_id`,`created_at`),
  KEY `idx_gc_event_type_date` (`entry_type`,`created_at`),
  KEY `idx_gc_event_document` (`origin_site_id`,`document_id`),
  KEY `idx_gc_event_shift` (`origin_site_id`,`shift_id`,`entry_type`),
  CONSTRAINT `gift_card_events_ibfk_1` FOREIGN KEY (`card_id`) REFERENCES `gift_cards` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gift_card_events`
--

LOCK TABLES `gift_card_events` WRITE;
/*!40000 ALTER TABLE `gift_card_events` DISABLE KEYS */;
INSERT INTO `gift_card_events` VALUES (1,5,'activation',500.0000,18,'INV_01_04_000001',1,NULL,3,4,'',1,'Tiaan Smith','2026-08-26 15:23:34.115'),(2,5,'redeem',-119.0000,23,'INV_01_04_000004',1,NULL,3,4,'',1,'Tiaan Smith','2026-08-26 15:39:13.623');
/*!40000 ALTER TABLE `gift_card_events` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gift_cards`
--

DROP TABLE IF EXISTS `gift_cards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gift_cards` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(30) NOT NULL,
  `status` enum('pending','active','redeemed','expired','void') NOT NULL DEFAULT 'pending',
  `initial_value` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `balance` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `expires_on` date DEFAULT NULL,
  `activated_at` datetime(3) DEFAULT NULL,
  `activated_doc_id` int(10) unsigned DEFAULT NULL,
  `activated_doc_number` varchar(40) NOT NULL DEFAULT '',
  `origin_site_id` int(10) unsigned DEFAULT NULL,
  `customer_id` int(10) unsigned DEFAULT NULL,
  `customer_origin_site_id` int(10) unsigned DEFAULT NULL,
  `note` varchar(255) NOT NULL DEFAULT '',
  `user_id` int(10) unsigned DEFAULT NULL,
  `user_name` varchar(120) NOT NULL DEFAULT '',
  `created_at` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_gift_card_code` (`code`),
  KEY `idx_gift_card_status_expiry` (`status`,`expires_on`),
  KEY `fk_gift_card_customer` (`customer_id`),
  KEY `idx_gift_card_document` (`origin_site_id`,`activated_doc_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gift_cards`
--

LOCK TABLES `gift_cards` WRITE;
/*!40000 ALTER TABLE `gift_cards` DISABLE KEYS */;
INSERT INTO `gift_cards` VALUES (1,'R3CVK3L6FK88','pending',0.0000,0.0000,NULL,NULL,NULL,'',NULL,NULL,NULL,'Vouchers',1,'Tiaan Smith','2026-08-26 15:06:51.709','2026-08-26 13:06:51'),(2,'PLG72JJWBFJX','pending',0.0000,0.0000,NULL,NULL,NULL,'',NULL,NULL,NULL,'Vouchers',1,'Tiaan Smith','2026-08-26 15:06:51.710','2026-08-26 13:06:51'),(3,'MVGV273BNGM6','pending',0.0000,0.0000,NULL,NULL,NULL,'',NULL,NULL,NULL,'Vouchers',1,'Tiaan Smith','2026-08-26 15:06:51.710','2026-08-26 13:06:51'),(4,'JW64NY7YC6GX','pending',0.0000,0.0000,NULL,NULL,NULL,'',NULL,NULL,NULL,'Vouchers',1,'Tiaan Smith','2026-08-26 15:06:51.710','2026-08-26 13:06:51'),(5,'MH7QBXHHCCX6','active',500.0000,381.0000,'2029-08-26','2026-08-26 15:23:34.115',18,'INV_01_04_000001',NULL,NULL,NULL,'Vouchers',1,'Tiaan Smith','2026-08-26 15:06:51.711','2026-08-26 13:39:13');
/*!40000 ALTER TABLE `gift_cards` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gl_accounts`
--

DROP TABLE IF EXISTS `gl_accounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gl_accounts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `account_code` varchar(16) NOT NULL,
  `name` varchar(120) NOT NULL,
  `account_type` enum('asset','liability','equity','income','expense') NOT NULL,
  `subtype` varchar(40) DEFAULT NULL,
  `parent_id` int(10) unsigned DEFAULT NULL,
  `control_type` enum('debtors','creditors','bank','stock','vat_input','vat_output') DEFAULT NULL,
  `control_ref_id` int(10) unsigned DEFAULT NULL,
  `is_postable` tinyint(1) NOT NULL DEFAULT 1,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `balance` decimal(16,4) NOT NULL DEFAULT 0.0000,
  `sort_order` int(11) NOT NULL DEFAULT 0,
  `notes` varchar(400) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_gl_code` (`account_code`),
  KEY `ix_gl_type` (`account_type`,`account_code`),
  KEY `ix_gl_control` (`control_type`,`control_ref_id`),
  KEY `ix_gl_parent` (`parent_id`,`sort_order`),
  CONSTRAINT `gl_accounts_ibfk_1` FOREIGN KEY (`parent_id`) REFERENCES `gl_accounts` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=52 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gl_accounts`
--

LOCK TABLES `gl_accounts` WRITE;
/*!40000 ALTER TABLE `gl_accounts` DISABLE KEYS */;
INSERT INTO `gl_accounts` VALUES (1,'1000','Bank and cash','asset','current_asset',NULL,NULL,NULL,1,1,298.8000,100,NULL,'2026-08-06 21:54:38','2026-08-31 10:55:39'),(2,'1100','Debtors control','asset','current_asset',NULL,'debtors',NULL,0,1,466.9000,110,NULL,'2026-08-06 21:54:38','2026-08-11 13:46:45'),(3,'1200','Stock on hand','asset','current_asset',NULL,'stock',NULL,0,1,40750.4000,120,NULL,'2026-08-06 21:54:38','2026-08-31 10:55:39'),(4,'1300','VAT input','asset','current_asset',NULL,'vat_input',NULL,0,1,2840.1500,130,NULL,'2026-08-06 21:54:38','2026-08-24 12:49:22'),(5,'1400','Deposits and prepayments','asset','current_asset',NULL,NULL,NULL,1,1,0.0000,140,NULL,'2026-08-06 21:54:38','2026-08-06 21:54:38'),(6,'1500','Equipment','asset','fixed_asset',NULL,NULL,NULL,1,1,0.0000,200,NULL,'2026-08-06 21:54:38','2026-08-06 21:54:38'),(7,'1510','Equipment — depreciation','asset','fixed_asset',NULL,NULL,NULL,1,1,0.0000,210,NULL,'2026-08-06 21:54:38','2026-08-06 21:54:38'),(8,'1600','Vehicles','asset','fixed_asset',NULL,NULL,NULL,1,1,0.0000,220,NULL,'2026-08-06 21:54:38','2026-08-06 21:54:38'),(9,'1610','Vehicles — depreciation','asset','fixed_asset',NULL,NULL,NULL,1,1,0.0000,230,NULL,'2026-08-06 21:54:38','2026-08-06 21:54:38'),(10,'2000','Creditors control','liability','current_liability',NULL,'creditors',NULL,0,1,-20274.5000,300,NULL,'2026-08-06 21:54:38','2026-08-24 12:49:22'),(11,'2100','VAT output','liability','current_liability',NULL,'vat_output',NULL,0,1,-245.8000,310,NULL,'2026-08-06 21:54:38','2026-08-31 10:55:39'),(12,'2200','Customer deposits','liability','current_liability',NULL,NULL,NULL,1,1,0.0000,320,NULL,'2026-08-06 21:54:38','2026-08-06 21:54:38'),(13,'2300','Salaries payable','liability','current_liability',NULL,NULL,NULL,1,1,0.0000,330,NULL,'2026-08-06 21:54:38','2026-08-06 21:54:38'),(14,'2400','Loans','liability','long_term_liability',NULL,NULL,NULL,1,1,0.0000,400,NULL,'2026-08-06 21:54:38','2026-08-06 21:54:38'),(15,'3000','Owner capital','equity','equity',NULL,NULL,NULL,1,1,0.0000,500,NULL,'2026-08-06 21:54:38','2026-08-06 21:54:38'),(16,'3100','Owner drawings','equity','equity',NULL,NULL,NULL,1,1,0.0000,510,NULL,'2026-08-06 21:54:38','2026-08-06 21:54:38'),(17,'3200','Retained earnings','equity','equity',NULL,NULL,NULL,1,1,0.0000,520,NULL,'2026-08-06 21:54:38','2026-08-06 21:54:38'),(18,'4000','Sales','income','revenue',NULL,NULL,NULL,1,1,-1638.9000,600,NULL,'2026-08-06 21:54:38','2026-08-31 10:55:39'),(19,'4100','Sales returns','income','revenue',NULL,NULL,NULL,1,1,0.0000,610,NULL,'2026-08-06 21:54:38','2026-08-06 21:54:38'),(20,'4200','Discounts allowed','income','revenue',NULL,NULL,NULL,1,1,0.0000,620,NULL,'2026-08-06 21:54:38','2026-08-06 21:54:38'),(21,'4900','Other income','income','other_income',NULL,NULL,NULL,1,1,0.0000,690,NULL,'2026-08-06 21:54:38','2026-08-06 21:54:38'),(22,'5000','Cost of sales','expense','cost_of_sales',NULL,NULL,NULL,1,1,1043.0000,700,NULL,'2026-08-06 21:54:38','2026-08-31 10:55:39'),(23,'5100','Stock adjustments','expense','cost_of_sales',NULL,NULL,NULL,1,1,-24363.4000,710,NULL,'2026-08-06 21:54:38','2026-08-26 16:51:23'),(24,'5200','Freight in','expense','cost_of_sales',NULL,NULL,NULL,1,1,200.0000,720,NULL,'2026-08-06 21:54:38','2026-08-12 10:55:51'),(25,'6000','Rent','expense','operating',NULL,NULL,NULL,1,1,0.0000,800,NULL,'2026-08-06 21:54:38','2026-08-06 21:54:38'),(26,'6010','Electricity and water','expense','operating',NULL,NULL,NULL,1,1,0.0000,810,NULL,'2026-08-06 21:54:38','2026-08-06 21:54:38'),(27,'6020','Telephone and internet','expense','operating',NULL,NULL,NULL,1,1,0.0000,820,NULL,'2026-08-06 21:54:38','2026-08-06 21:54:38'),(28,'6030','Salaries and wages','expense','operating',NULL,NULL,NULL,1,1,0.0000,830,NULL,'2026-08-06 21:54:38','2026-08-06 21:54:38'),(29,'6040','Insurance','expense','operating',NULL,NULL,NULL,1,1,0.0000,840,NULL,'2026-08-06 21:54:38','2026-08-06 21:54:38'),(30,'6050','Repairs and maintenance','expense','operating',NULL,NULL,NULL,1,1,0.0000,850,NULL,'2026-08-06 21:54:38','2026-08-06 21:54:38'),(31,'6060','Motor vehicle expenses','expense','operating',NULL,NULL,NULL,1,1,0.0000,860,NULL,'2026-08-06 21:54:38','2026-08-06 21:54:38'),(32,'6070','Fuel','expense','operating',NULL,NULL,NULL,1,1,1304.3500,870,NULL,'2026-08-06 21:54:38','2026-08-10 07:41:07'),(33,'6080','Cleaning and consumables','expense','operating',NULL,NULL,NULL,1,1,0.0000,880,NULL,'2026-08-06 21:54:38','2026-08-06 21:54:38'),(34,'6090','Printing and stationery','expense','operating',NULL,NULL,NULL,1,1,0.0000,890,NULL,'2026-08-06 21:54:38','2026-08-06 21:54:38'),(35,'6100','Advertising and marketing','expense','operating',NULL,NULL,NULL,1,1,0.0000,900,NULL,'2026-08-06 21:54:38','2026-08-06 21:54:38'),(36,'6110','Accounting and legal fees','expense','operating',NULL,NULL,NULL,1,1,0.0000,910,NULL,'2026-08-06 21:54:38','2026-08-06 21:54:38'),(37,'6120','Security','expense','operating',NULL,NULL,NULL,1,1,0.0000,920,NULL,'2026-08-06 21:54:38','2026-08-06 21:54:38'),(38,'6130','Software and subscriptions','expense','operating',NULL,NULL,NULL,1,1,0.0000,930,NULL,'2026-08-06 21:54:38','2026-08-06 21:54:38'),(39,'6140','Staff welfare and training','expense','operating',NULL,NULL,NULL,1,1,0.0000,940,NULL,'2026-08-06 21:54:38','2026-08-06 21:54:38'),(40,'6150','Entertainment','expense','operating',NULL,NULL,NULL,1,1,0.0000,950,NULL,'2026-08-06 21:54:38','2026-08-06 21:54:38'),(41,'6160','Travel and accommodation','expense','operating',NULL,NULL,NULL,1,1,0.0000,960,NULL,'2026-08-06 21:54:38','2026-08-06 21:54:38'),(42,'6170','Licences and permits','expense','operating',NULL,NULL,NULL,1,1,0.0000,970,NULL,'2026-08-06 21:54:38','2026-08-06 21:54:38'),(43,'6180','Depreciation','expense','operating',NULL,NULL,NULL,1,1,0.0000,980,NULL,'2026-08-06 21:54:38','2026-08-06 21:54:38'),(44,'6900','Sundry expenses','expense','operating',NULL,NULL,NULL,1,1,0.0000,990,NULL,'2026-08-06 21:54:38','2026-08-06 21:54:38'),(45,'7000','Bank charges','expense','financial',NULL,NULL,NULL,1,1,0.0000,1000,NULL,'2026-08-06 21:54:38','2026-08-06 21:54:38'),(46,'7010','Interest paid','expense','financial',NULL,NULL,NULL,1,1,0.0000,1010,NULL,'2026-08-06 21:54:38','2026-08-06 21:54:38'),(47,'7020','Bad debts written off','expense','financial',NULL,NULL,NULL,1,1,0.0000,1020,NULL,'2026-08-06 21:54:38','2026-08-06 21:54:38'),(48,'7030','Cash rounding','expense','financial',NULL,NULL,NULL,1,1,0.0000,1030,NULL,'2026-08-06 21:54:38','2026-08-06 21:54:38'),(49,'6910','Cash over and short','expense','operating',NULL,NULL,NULL,1,1,0.0000,995,NULL,'2026-08-24 09:10:35','2026-08-24 09:10:35'),(50,'2500','Gift card liability','liability','current_liability',NULL,NULL,NULL,1,1,-381.0000,335,NULL,'2026-08-24 09:10:35','2026-08-26 15:39:13'),(51,'4910','Gift card breakage','income','other_income',NULL,NULL,NULL,1,1,0.0000,695,NULL,'2026-08-24 09:10:35','2026-08-24 09:10:35');
/*!40000 ALTER TABLE `gl_accounts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gl_budgets`
--

DROP TABLE IF EXISTS `gl_budgets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gl_budgets` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `account_id` int(10) unsigned NOT NULL,
  `period_month` char(7) NOT NULL,
  `amount` decimal(16,4) NOT NULL DEFAULT 0.0000,
  `user_id` int(10) unsigned DEFAULT NULL,
  `user_name` varchar(120) NOT NULL DEFAULT '',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_budget` (`account_id`,`period_month`),
  KEY `ix_budget_month` (`period_month`),
  CONSTRAINT `gl_budgets_ibfk_1` FOREIGN KEY (`account_id`) REFERENCES `gl_accounts` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gl_budgets`
--

LOCK TABLES `gl_budgets` WRITE;
/*!40000 ALTER TABLE `gl_budgets` DISABLE KEYS */;
/*!40000 ALTER TABLE `gl_budgets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gl_mappings`
--

DROP TABLE IF EXISTS `gl_mappings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gl_mappings` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `mapping_key` varchar(40) NOT NULL,
  `ref_id` int(10) unsigned DEFAULT NULL,
  `account_id` int(10) unsigned NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_mapping` (`mapping_key`,`ref_id`),
  KEY `ix_mapping_account` (`account_id`),
  CONSTRAINT `gl_mappings_ibfk_1` FOREIGN KEY (`account_id`) REFERENCES `gl_accounts` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=58 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gl_mappings`
--

LOCK TABLES `gl_mappings` WRITE;
/*!40000 ALTER TABLE `gl_mappings` DISABLE KEYS */;
INSERT INTO `gl_mappings` VALUES (1,'sales_income',NULL,18,'2026-08-06 21:54:38','2026-08-06 21:54:38'),(2,'sales_returns',NULL,19,'2026-08-06 21:54:38','2026-08-06 21:54:38'),(3,'cost_of_sales',NULL,22,'2026-08-06 21:54:38','2026-08-06 21:54:38'),(4,'stock_control',NULL,3,'2026-08-06 21:54:38','2026-08-06 21:54:38'),(5,'debtors_control',NULL,2,'2026-08-06 21:54:38','2026-08-06 21:54:38'),(6,'creditors_control',NULL,10,'2026-08-06 21:54:38','2026-08-06 21:54:38'),(7,'vat_output',NULL,11,'2026-08-06 21:54:38','2026-08-06 21:54:38'),(8,'vat_input',NULL,4,'2026-08-06 21:54:38','2026-08-06 21:54:38'),(9,'tender',NULL,1,'2026-08-06 21:54:38','2026-08-06 21:54:38'),(10,'bank_account',NULL,1,'2026-08-06 21:54:38','2026-08-06 21:54:38'),(11,'expense_category',NULL,44,'2026-08-06 21:54:38','2026-08-06 21:54:38'),(12,'rounding',NULL,48,'2026-08-06 21:54:38','2026-08-06 21:54:38'),(13,'interest_received',NULL,21,'2026-08-06 21:54:38','2026-08-06 21:54:38'),(14,'bad_debts',NULL,47,'2026-08-06 21:54:38','2026-08-06 21:54:38'),(15,'retained_earnings',NULL,17,'2026-08-06 21:54:38','2026-08-06 21:54:38'),(16,'expense_category',1,24,'2026-08-06 21:54:38','2026-08-06 21:54:38'),(17,'expense_category',2,22,'2026-08-06 21:54:38','2026-08-06 21:54:38'),(18,'expense_category',3,25,'2026-08-06 21:54:38','2026-08-06 21:54:38'),(19,'expense_category',4,26,'2026-08-06 21:54:38','2026-08-06 21:54:38'),(20,'expense_category',5,27,'2026-08-06 21:54:38','2026-08-06 21:54:38'),(21,'expense_category',6,28,'2026-08-06 21:54:38','2026-08-06 21:54:38'),(22,'expense_category',7,29,'2026-08-06 21:54:38','2026-08-06 21:54:38'),(23,'expense_category',8,30,'2026-08-06 21:54:38','2026-08-06 21:54:38'),(24,'expense_category',9,31,'2026-08-06 21:54:38','2026-08-06 21:54:38'),(25,'expense_category',10,32,'2026-08-06 21:54:38','2026-08-06 21:54:38'),(26,'expense_category',11,33,'2026-08-06 21:54:38','2026-08-06 21:54:38'),(27,'expense_category',12,34,'2026-08-06 21:54:38','2026-08-06 21:54:38'),(28,'expense_category',13,35,'2026-08-06 21:54:38','2026-08-06 21:54:38'),(29,'expense_category',14,36,'2026-08-06 21:54:38','2026-08-06 21:54:38'),(30,'expense_category',15,37,'2026-08-06 21:54:38','2026-08-06 21:54:38'),(31,'expense_category',16,38,'2026-08-06 21:54:38','2026-08-06 21:54:38'),(32,'expense_category',17,39,'2026-08-06 21:54:38','2026-08-06 21:54:38'),(33,'expense_category',18,40,'2026-08-06 21:54:38','2026-08-06 21:54:38'),(34,'expense_category',19,41,'2026-08-06 21:54:38','2026-08-06 21:54:38'),(35,'expense_category',20,42,'2026-08-06 21:54:38','2026-08-06 21:54:38'),(36,'expense_category',21,44,'2026-08-06 21:54:38','2026-08-06 21:54:38'),(37,'expense_category',22,45,'2026-08-06 21:54:38','2026-08-06 21:54:38'),(38,'expense_category',23,46,'2026-08-06 21:54:38','2026-08-06 21:54:38'),(39,'expense_category',24,6,'2026-08-06 21:54:38','2026-08-06 21:54:38'),(40,'expense_category',25,8,'2026-08-06 21:54:38','2026-08-06 21:54:38'),(47,'asset_disposal',NULL,21,'2026-08-06 22:26:44','2026-08-06 22:26:44'),(48,'stock_adjustment',NULL,23,'2026-08-10 13:35:32','2026-08-10 13:35:32'),(49,'manufacturing_overhead',NULL,23,'2026-08-10 13:35:33','2026-08-10 13:35:33'),(50,'freight_in',NULL,24,'2026-08-10 16:58:18','2026-08-10 16:58:18'),(51,'owner_drawings',NULL,16,'2026-08-24 09:10:35','2026-08-24 09:10:35'),(52,'capital_introduced',NULL,15,'2026-08-24 09:10:35','2026-08-24 09:10:35'),(53,'other_income',NULL,21,'2026-08-24 09:10:35','2026-08-24 09:10:35'),(54,'cash_over_short',NULL,49,'2026-08-24 09:10:35','2026-08-24 09:10:35'),(55,'gift_card_liability',NULL,50,'2026-08-24 09:10:35','2026-08-24 09:10:35'),(56,'gift_card_breakage',NULL,51,'2026-08-24 09:10:35','2026-08-24 09:10:35'),(57,'tender',9,50,'2026-08-24 09:10:35','2026-08-24 09:10:35');
/*!40000 ALTER TABLE `gl_mappings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gl_year_ends`
--

DROP TABLE IF EXISTS `gl_year_ends`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gl_year_ends` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `year_start` date NOT NULL,
  `year_end` date NOT NULL,
  `batch_id` int(10) unsigned DEFAULT NULL,
  `total_income` decimal(16,4) NOT NULL DEFAULT 0.0000,
  `total_expense` decimal(16,4) NOT NULL DEFAULT 0.0000,
  `net_result` decimal(16,4) NOT NULL DEFAULT 0.0000,
  `status` enum('closed','reopened') NOT NULL DEFAULT 'closed',
  `user_id` int(10) unsigned DEFAULT NULL,
  `user_name` varchar(120) NOT NULL DEFAULT '',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_year` (`year_start`,`year_end`),
  KEY `fk_yearend_batch` (`batch_id`),
  CONSTRAINT `gl_year_ends_ibfk_1` FOREIGN KEY (`batch_id`) REFERENCES `journal_batches` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gl_year_ends`
--

LOCK TABLES `gl_year_ends` WRITE;
/*!40000 ALTER TABLE `gl_year_ends` DISABLE KEYS */;
/*!40000 ALTER TABLE `gl_year_ends` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `instruction_groups`
--

DROP TABLE IF EXISTS `instruction_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `instruction_groups` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(120) NOT NULL,
  `prompt` varchar(190) NOT NULL DEFAULT '',
  `is_required` tinyint(1) NOT NULL DEFAULT 0,
  `min_choices` smallint(5) unsigned NOT NULL DEFAULT 0,
  `max_choices` smallint(5) unsigned NOT NULL DEFAULT 1,
  `sort_order` int(11) NOT NULL DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `image_id` bigint(20) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_instruction_group_name` (`name`),
  KEY `ix_instruction_group_active` (`is_active`,`sort_order`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `instruction_groups`
--

LOCK TABLES `instruction_groups` WRITE;
/*!40000 ALTER TABLE `instruction_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `instruction_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `instruction_option_reveals`
--

DROP TABLE IF EXISTS `instruction_option_reveals`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `instruction_option_reveals` (
  `option_id` int(10) unsigned NOT NULL,
  `group_id` int(10) unsigned NOT NULL,
  `sort_order` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`option_id`,`group_id`),
  KEY `ix_reveal_group` (`group_id`),
  CONSTRAINT `instruction_option_reveals_ibfk_1` FOREIGN KEY (`group_id`) REFERENCES `instruction_groups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `instruction_option_reveals_ibfk_2` FOREIGN KEY (`option_id`) REFERENCES `instruction_options` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `instruction_option_reveals`
--

LOCK TABLES `instruction_option_reveals` WRITE;
/*!40000 ALTER TABLE `instruction_option_reveals` DISABLE KEYS */;
/*!40000 ALTER TABLE `instruction_option_reveals` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `instruction_options`
--

DROP TABLE IF EXISTS `instruction_options`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `instruction_options` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `group_id` int(10) unsigned NOT NULL,
  `name` varchar(120) NOT NULL,
  `price_adjust` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `product_id` int(10) unsigned DEFAULT NULL,
  `quantity` decimal(12,3) NOT NULL DEFAULT 1.000,
  `is_default` tinyint(1) NOT NULL DEFAULT 0,
  `sort_order` int(11) NOT NULL DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `max_qty` smallint(5) unsigned NOT NULL DEFAULT 1,
  `min_qty` smallint(5) unsigned NOT NULL DEFAULT 0,
  `default_qty` smallint(5) unsigned NOT NULL DEFAULT 0,
  `image_id` bigint(20) unsigned DEFAULT NULL,
  `prints_on_kitchen` tinyint(1) NOT NULL DEFAULT 1,
  `prints_on_receipt` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `ix_instruction_option_group` (`group_id`,`sort_order`),
  KEY `ix_instruction_option_product` (`product_id`),
  CONSTRAINT `instruction_options_ibfk_1` FOREIGN KEY (`group_id`) REFERENCES `instruction_groups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `instruction_options_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `instruction_options`
--

LOCK TABLES `instruction_options` WRITE;
/*!40000 ALTER TABLE `instruction_options` DISABLE KEYS */;
/*!40000 ALTER TABLE `instruction_options` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `interest_run_items`
--

DROP TABLE IF EXISTS `interest_run_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `interest_run_items` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `run_id` int(10) unsigned NOT NULL,
  `customer_id` int(10) unsigned NOT NULL,
  `customer_code` varchar(32) NOT NULL,
  `customer_name` varchar(190) NOT NULL,
  `base_amount` decimal(14,4) NOT NULL DEFAULT 0.0000,
  `rate_pct` decimal(7,4) NOT NULL DEFAULT 0.0000,
  `days` smallint(5) unsigned NOT NULL DEFAULT 0,
  `amount` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `status` enum('pending','posted','skipped') NOT NULL DEFAULT 'pending',
  `skip_reason` varchar(190) DEFAULT NULL,
  `transaction_id` int(10) unsigned DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `ix_iitem_run` (`run_id`,`customer_name`),
  KEY `ix_iitem_customer` (`customer_id`),
  KEY `fk_iitem_txn` (`transaction_id`),
  CONSTRAINT `interest_run_items_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`),
  CONSTRAINT `interest_run_items_ibfk_2` FOREIGN KEY (`run_id`) REFERENCES `interest_runs` (`id`) ON DELETE CASCADE,
  CONSTRAINT `interest_run_items_ibfk_3` FOREIGN KEY (`transaction_id`) REFERENCES `customer_transactions` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `interest_run_items`
--

LOCK TABLES `interest_run_items` WRITE;
/*!40000 ALTER TABLE `interest_run_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `interest_run_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `interest_runs`
--

DROP TABLE IF EXISTS `interest_runs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `interest_runs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `as_at_date` date NOT NULL,
  `period_from` date NOT NULL,
  `period_to` date NOT NULL,
  `status` enum('draft','posted','cancelled') NOT NULL DEFAULT 'draft',
  `total_amount` decimal(14,4) NOT NULL DEFAULT 0.0000,
  `account_count` int(10) unsigned NOT NULL DEFAULT 0,
  `posted_count` int(10) unsigned NOT NULL DEFAULT 0,
  `minimum_charge` decimal(10,4) NOT NULL DEFAULT 0.0000,
  `notes` varchar(400) DEFAULT NULL,
  `user_id` int(10) unsigned DEFAULT NULL,
  `user_name` varchar(120) NOT NULL DEFAULT '',
  `origin_site_id` int(10) unsigned DEFAULT NULL,
  `posted_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `ix_irun_status` (`status`,`as_at_date`),
  KEY `ix_irun_origin` (`origin_site_id`,`as_at_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `interest_runs`
--

LOCK TABLES `interest_runs` WRITE;
/*!40000 ALTER TABLE `interest_runs` DISABLE KEYS */;
/*!40000 ALTER TABLE `interest_runs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `job_appointment_assignees`
--

DROP TABLE IF EXISTS `job_appointment_assignees`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `job_appointment_assignees` (
  `appointment_id` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `user_name` varchar(120) NOT NULL DEFAULT '',
  `is_lead` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`appointment_id`,`user_id`),
  KEY `ix_jassign_user` (`user_id`),
  CONSTRAINT `job_appointment_assignees_ibfk_1` FOREIGN KEY (`appointment_id`) REFERENCES `job_card_appointments` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job_appointment_assignees`
--

LOCK TABLES `job_appointment_assignees` WRITE;
/*!40000 ALTER TABLE `job_appointment_assignees` DISABLE KEYS */;
/*!40000 ALTER TABLE `job_appointment_assignees` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `job_automation_runs`
--

DROP TABLE IF EXISTS `job_automation_runs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `job_automation_runs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `job_card_id` int(10) unsigned NOT NULL,
  `event` enum('respond_breach','resolve_breach','visit_reminder','auto_invoice') NOT NULL,
  `for_date` date NOT NULL,
  `result_id` int(10) unsigned DEFAULT NULL,
  `status` enum('claimed','done','failed') NOT NULL DEFAULT 'claimed',
  `detail` varchar(400) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_job_event_day` (`job_card_id`,`event`,`for_date`),
  KEY `ix_jauto_stuck` (`status`,`created_at`),
  CONSTRAINT `job_automation_runs_ibfk_1` FOREIGN KEY (`job_card_id`) REFERENCES `job_cards` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job_automation_runs`
--

LOCK TABLES `job_automation_runs` WRITE;
/*!40000 ALTER TABLE `job_automation_runs` DISABLE KEYS */;
/*!40000 ALTER TABLE `job_automation_runs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `job_board_statuses`
--

DROP TABLE IF EXISTS `job_board_statuses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `job_board_statuses` (
  `board_id` int(10) unsigned NOT NULL,
  `status_id` int(10) unsigned NOT NULL,
  `column_order` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`board_id`,`status_id`),
  KEY `ix_jbs_status` (`status_id`),
  CONSTRAINT `job_board_statuses_ibfk_1` FOREIGN KEY (`board_id`) REFERENCES `job_boards` (`id`) ON DELETE CASCADE,
  CONSTRAINT `job_board_statuses_ibfk_2` FOREIGN KEY (`status_id`) REFERENCES `job_statuses` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job_board_statuses`
--

LOCK TABLES `job_board_statuses` WRITE;
/*!40000 ALTER TABLE `job_board_statuses` DISABLE KEYS */;
INSERT INTO `job_board_statuses` VALUES (1,1,10),(1,2,20),(1,3,30),(1,4,40),(1,5,50),(1,6,60),(1,7,70),(1,8,80);
/*!40000 ALTER TABLE `job_board_statuses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `job_boards`
--

DROP TABLE IF EXISTS `job_boards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `job_boards` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(60) NOT NULL,
  `slug` varchar(60) NOT NULL,
  `layout` enum('kanban','grid') NOT NULL DEFAULT 'kanban',
  `sort_order` int(11) NOT NULL DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_jboard_slug` (`slug`),
  KEY `ix_jboard_sort` (`sort_order`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job_boards`
--

LOCK TABLES `job_boards` WRITE;
/*!40000 ALTER TABLE `job_boards` DISABLE KEYS */;
INSERT INTO `job_boards` VALUES (1,'Jobs','jobs','kanban',10,1,'2026-08-24 09:10:33','2026-08-24 09:10:33');
/*!40000 ALTER TABLE `job_boards` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `job_calendar_accounts`
--

DROP TABLE IF EXISTS `job_calendar_accounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `job_calendar_accounts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `user_name` varchar(120) NOT NULL DEFAULT '',
  `provider` enum('google','microsoft') NOT NULL,
  `account_email` varchar(190) NOT NULL DEFAULT '',
  `calendar_id` varchar(255) NOT NULL DEFAULT 'primary',
  `refresh_token_enc` text DEFAULT NULL,
  `push_enabled` tinyint(1) NOT NULL DEFAULT 1,
  `pull_enabled` tinyint(1) NOT NULL DEFAULT 1,
  `last_error` varchar(400) NOT NULL DEFAULT '',
  `last_push_at` datetime DEFAULT NULL,
  `last_pull_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_jcalacct_user` (`user_id`,`provider`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job_calendar_accounts`
--

LOCK TABLES `job_calendar_accounts` WRITE;
/*!40000 ALTER TABLE `job_calendar_accounts` DISABLE KEYS */;
/*!40000 ALTER TABLE `job_calendar_accounts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `job_calendar_busy`
--

DROP TABLE IF EXISTS `job_calendar_busy`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `job_calendar_busy` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `account_id` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `starts_at` datetime NOT NULL,
  `ends_at` datetime NOT NULL,
  `is_ours` tinyint(1) NOT NULL DEFAULT 0,
  `fetched_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `ix_jcalbusy_when` (`user_id`,`starts_at`,`ends_at`),
  KEY `ix_jcalbusy_acct` (`account_id`),
  CONSTRAINT `job_calendar_busy_ibfk_1` FOREIGN KEY (`account_id`) REFERENCES `job_calendar_accounts` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job_calendar_busy`
--

LOCK TABLES `job_calendar_busy` WRITE;
/*!40000 ALTER TABLE `job_calendar_busy` DISABLE KEYS */;
/*!40000 ALTER TABLE `job_calendar_busy` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `job_calendar_changes`
--

DROP TABLE IF EXISTS `job_calendar_changes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `job_calendar_changes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `account_id` int(10) unsigned NOT NULL,
  `appointment_id` int(10) unsigned NOT NULL,
  `proposed_starts_at` datetime NOT NULL,
  `proposed_duration_minutes` smallint(5) unsigned DEFAULT NULL,
  `previous_starts_at` datetime NOT NULL,
  `previous_duration_minutes` smallint(5) unsigned NOT NULL,
  `status` enum('pending','accepted','declined','stale') NOT NULL DEFAULT 'pending',
  `decided_at` datetime DEFAULT NULL,
  `decided_by_user_id` int(10) unsigned DEFAULT NULL,
  `decided_by_name` varchar(120) NOT NULL DEFAULT '',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `ix_jcalchg_pending` (`status`,`created_at`),
  KEY `ix_jcalchg_appt` (`appointment_id`),
  KEY `fk_jcalchg_acct` (`account_id`),
  CONSTRAINT `job_calendar_changes_ibfk_1` FOREIGN KEY (`account_id`) REFERENCES `job_calendar_accounts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `job_calendar_changes_ibfk_2` FOREIGN KEY (`appointment_id`) REFERENCES `job_card_appointments` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job_calendar_changes`
--

LOCK TABLES `job_calendar_changes` WRITE;
/*!40000 ALTER TABLE `job_calendar_changes` DISABLE KEYS */;
/*!40000 ALTER TABLE `job_calendar_changes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `job_calendar_links`
--

DROP TABLE IF EXISTS `job_calendar_links`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `job_calendar_links` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `account_id` int(10) unsigned NOT NULL,
  `appointment_id` int(10) unsigned NOT NULL,
  `external_id` varchar(255) NOT NULL,
  `pushed_hash` char(40) NOT NULL DEFAULT '',
  `pushed_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_jcallink` (`account_id`,`appointment_id`),
  KEY `ix_jcallink_ext` (`external_id`),
  KEY `fk_jcallink_appt` (`appointment_id`),
  CONSTRAINT `job_calendar_links_ibfk_1` FOREIGN KEY (`account_id`) REFERENCES `job_calendar_accounts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `job_calendar_links_ibfk_2` FOREIGN KEY (`appointment_id`) REFERENCES `job_card_appointments` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job_calendar_links`
--

LOCK TABLES `job_calendar_links` WRITE;
/*!40000 ALTER TABLE `job_calendar_links` DISABLE KEYS */;
/*!40000 ALTER TABLE `job_calendar_links` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `job_card_appointments`
--

DROP TABLE IF EXISTS `job_card_appointments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `job_card_appointments` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `job_card_id` int(10) unsigned NOT NULL,
  `visit_number` smallint(5) unsigned NOT NULL DEFAULT 1,
  `status` enum('scheduled','confirmed','en_route','on_site','completed','cancelled','no_show') NOT NULL DEFAULT 'scheduled',
  `starts_at` datetime NOT NULL,
  `duration_minutes` smallint(5) unsigned NOT NULL DEFAULT 60,
  `service_address_id` int(10) unsigned DEFAULT NULL,
  `visit_type` varchar(60) DEFAULT NULL,
  `notes` varchar(1000) DEFAULT NULL,
  `travel_started_at` datetime DEFAULT NULL,
  `arrived_at` datetime DEFAULT NULL,
  `departed_at` datetime DEFAULT NULL,
  `outcome_reason` varchar(190) DEFAULT NULL,
  `override_reason` varchar(190) DEFAULT NULL,
  `user_id` int(10) unsigned DEFAULT NULL,
  `user_name` varchar(120) NOT NULL DEFAULT '',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `ix_jappt_job` (`job_card_id`,`visit_number`),
  KEY `ix_jappt_when` (`starts_at`,`status`),
  KEY `ix_jappt_address` (`service_address_id`),
  CONSTRAINT `job_card_appointments_ibfk_1` FOREIGN KEY (`service_address_id`) REFERENCES `service_addresses` (`id`) ON DELETE SET NULL,
  CONSTRAINT `job_card_appointments_ibfk_2` FOREIGN KEY (`job_card_id`) REFERENCES `job_cards` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job_card_appointments`
--

LOCK TABLES `job_card_appointments` WRITE;
/*!40000 ALTER TABLE `job_card_appointments` DISABLE KEYS */;
/*!40000 ALTER TABLE `job_card_appointments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `job_card_assets`
--

DROP TABLE IF EXISTS `job_card_assets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `job_card_assets` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `job_card_id` int(10) unsigned NOT NULL,
  `asset_id` int(10) unsigned NOT NULL,
  `note` varchar(400) DEFAULT NULL,
  `sort_order` int(11) NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_jca` (`job_card_id`,`asset_id`),
  KEY `ix_jca_asset` (`asset_id`),
  CONSTRAINT `job_card_assets_ibfk_1` FOREIGN KEY (`asset_id`) REFERENCES `customer_assets` (`id`),
  CONSTRAINT `job_card_assets_ibfk_2` FOREIGN KEY (`job_card_id`) REFERENCES `job_cards` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job_card_assets`
--

LOCK TABLES `job_card_assets` WRITE;
/*!40000 ALTER TABLE `job_card_assets` DISABLE KEYS */;
/*!40000 ALTER TABLE `job_card_assets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `job_card_headlines`
--

DROP TABLE IF EXISTS `job_card_headlines`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `job_card_headlines` (
  `job_card_id` int(10) unsigned NOT NULL,
  `headline_id` int(10) unsigned NOT NULL,
  `sort_order` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`job_card_id`,`headline_id`),
  KEY `ix_jch_headline` (`headline_id`),
  CONSTRAINT `job_card_headlines_ibfk_1` FOREIGN KEY (`headline_id`) REFERENCES `job_headlines` (`id`),
  CONSTRAINT `job_card_headlines_ibfk_2` FOREIGN KEY (`job_card_id`) REFERENCES `job_cards` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job_card_headlines`
--

LOCK TABLES `job_card_headlines` WRITE;
/*!40000 ALTER TABLE `job_card_headlines` DISABLE KEYS */;
/*!40000 ALTER TABLE `job_card_headlines` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `job_card_lines`
--

DROP TABLE IF EXISTS `job_card_lines`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `job_card_lines` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `job_card_id` int(10) unsigned NOT NULL,
  `line_number` smallint(5) unsigned NOT NULL DEFAULT 1,
  `line_kind` enum('part','labour','travel','charge','expense') NOT NULL DEFAULT 'part',
  `billing_state` enum('quoted','variation','additional','internal','pending','written_off') NOT NULL DEFAULT 'pending',
  `product_id` int(10) unsigned DEFAULT NULL,
  `supplier_id` int(10) unsigned DEFAULT NULL,
  `expense_category_id` int(10) unsigned DEFAULT NULL,
  `asset_id` int(10) unsigned DEFAULT NULL,
  `product_code` varchar(40) DEFAULT NULL,
  `description` varchar(190) NOT NULL,
  `qty` decimal(12,3) NOT NULL DEFAULT 0.000,
  `unit_cost_excl` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `quoted_cost_excl` decimal(14,4) DEFAULT NULL,
  `quoted_qty` decimal(14,4) DEFAULT NULL,
  `unit_price_incl` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `vat_rate_pct` decimal(6,3) NOT NULL DEFAULT 0.000,
  `discount_pct` decimal(6,3) NOT NULL DEFAULT 0.000,
  `source_line_id` int(10) unsigned DEFAULT NULL,
  `invoiced_doc_id` int(10) unsigned DEFAULT NULL,
  `invoiced_qty` decimal(12,3) NOT NULL DEFAULT 0.000,
  `issued_qty` decimal(12,3) NOT NULL DEFAULT 0.000,
  `movement_id` bigint(20) unsigned DEFAULT NULL,
  `time_entry_id` int(10) unsigned DEFAULT NULL,
  `travel_id` int(10) unsigned DEFAULT NULL,
  `decided_by_user_id` int(10) unsigned DEFAULT NULL,
  `decided_at` datetime DEFAULT NULL,
  `decided_reason` varchar(190) DEFAULT NULL,
  `note` varchar(190) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `ix_jcl_job` (`job_card_id`,`line_number`),
  KEY `ix_jcl_state` (`job_card_id`,`billing_state`),
  KEY `ix_jcl_invoiced` (`invoiced_doc_id`),
  KEY `ix_jcl_product` (`product_id`),
  KEY `fk_jcl_source` (`source_line_id`),
  KEY `ix_jcl_issued` (`job_card_id`,`issued_qty`),
  KEY `ix_jcl_supplier` (`supplier_id`),
  KEY `ix_jcl_expense_category` (`expense_category_id`),
  KEY `ix_jcl_asset` (`asset_id`),
  CONSTRAINT `job_card_lines_ibfk_1` FOREIGN KEY (`asset_id`) REFERENCES `customer_assets` (`id`) ON DELETE SET NULL,
  CONSTRAINT `job_card_lines_ibfk_2` FOREIGN KEY (`expense_category_id`) REFERENCES `expense_categories` (`id`) ON DELETE SET NULL,
  CONSTRAINT `job_card_lines_ibfk_3` FOREIGN KEY (`invoiced_doc_id`) REFERENCES `sales_documents` (`id`) ON DELETE SET NULL,
  CONSTRAINT `job_card_lines_ibfk_4` FOREIGN KEY (`job_card_id`) REFERENCES `job_cards` (`id`) ON DELETE CASCADE,
  CONSTRAINT `job_card_lines_ibfk_5` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`),
  CONSTRAINT `job_card_lines_ibfk_6` FOREIGN KEY (`source_line_id`) REFERENCES `job_card_lines` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job_card_lines`
--

LOCK TABLES `job_card_lines` WRITE;
/*!40000 ALTER TABLE `job_card_lines` DISABLE KEYS */;
/*!40000 ALTER TABLE `job_card_lines` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `job_card_people`
--

DROP TABLE IF EXISTS `job_card_people`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `job_card_people` (
  `job_card_id` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `user_name` varchar(120) NOT NULL DEFAULT '',
  `role` enum('assignee','follower') NOT NULL DEFAULT 'follower',
  `added_by_user_id` int(10) unsigned DEFAULT NULL,
  `added_by_name` varchar(120) NOT NULL DEFAULT '',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`job_card_id`,`user_id`),
  KEY `ix_jperson_user` (`user_id`,`role`),
  CONSTRAINT `job_card_people_ibfk_1` FOREIGN KEY (`job_card_id`) REFERENCES `job_cards` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job_card_people`
--

LOCK TABLES `job_card_people` WRITE;
/*!40000 ALTER TABLE `job_card_people` DISABLE KEYS */;
/*!40000 ALTER TABLE `job_card_people` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `job_card_travel`
--

DROP TABLE IF EXISTS `job_card_travel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `job_card_travel` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `job_card_id` int(10) unsigned NOT NULL,
  `appointment_id` int(10) unsigned DEFAULT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `user_name` varchar(120) NOT NULL DEFAULT '',
  `travelled_on` date NOT NULL,
  `from_label` varchar(190) DEFAULT NULL,
  `to_label` varchar(190) DEFAULT NULL,
  `service_address_id` int(10) unsigned DEFAULT NULL,
  `expected_km` decimal(8,2) DEFAULT NULL,
  `expected_source` enum('estimated','provider','manual') DEFAULT NULL,
  `recorded_km` decimal(8,2) NOT NULL DEFAULT 0.00,
  `recorded_source` enum('manual','odometer','gps') NOT NULL DEFAULT 'manual',
  `is_return` tinyint(1) NOT NULL DEFAULT 1,
  `verified_km` decimal(8,2) DEFAULT NULL,
  `verified_by_user_id` int(10) unsigned DEFAULT NULL,
  `verified_by_name` varchar(120) DEFAULT NULL,
  `verified_at` datetime DEFAULT NULL,
  `verify_note` varchar(190) DEFAULT NULL,
  `chargeable_km` decimal(8,2) NOT NULL DEFAULT 0.00,
  `rate_per_km` decimal(10,4) NOT NULL DEFAULT 0.0000,
  `cost_per_km` decimal(10,4) NOT NULL DEFAULT 0.0000,
  `travel_minutes` smallint(5) unsigned NOT NULL DEFAULT 0,
  `departed_lat` decimal(10,7) DEFAULT NULL,
  `departed_lng` decimal(10,7) DEFAULT NULL,
  `arrived_lat` decimal(10,7) DEFAULT NULL,
  `arrived_lng` decimal(10,7) DEFAULT NULL,
  `arrived_accuracy_m` smallint(5) unsigned DEFAULT NULL,
  `tolerance_breached` tinyint(1) NOT NULL DEFAULT 0,
  `note` varchar(400) DEFAULT NULL,
  `line_id` int(10) unsigned DEFAULT NULL,
  `user_created_id` int(10) unsigned DEFAULT NULL,
  `user_created_name` varchar(120) NOT NULL DEFAULT '',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `ix_jtravel_job` (`job_card_id`,`travelled_on`),
  KEY `ix_jtravel_appointment` (`appointment_id`),
  KEY `ix_jtravel_verify` (`tolerance_breached`,`verified_at`),
  KEY `ix_jtravel_user` (`user_id`,`travelled_on`),
  KEY `fk_jtravel_address` (`service_address_id`),
  KEY `fk_jtravel_line` (`line_id`),
  CONSTRAINT `job_card_travel_ibfk_1` FOREIGN KEY (`service_address_id`) REFERENCES `service_addresses` (`id`) ON DELETE SET NULL,
  CONSTRAINT `job_card_travel_ibfk_2` FOREIGN KEY (`appointment_id`) REFERENCES `job_card_appointments` (`id`) ON DELETE SET NULL,
  CONSTRAINT `job_card_travel_ibfk_3` FOREIGN KEY (`job_card_id`) REFERENCES `job_cards` (`id`) ON DELETE CASCADE,
  CONSTRAINT `job_card_travel_ibfk_4` FOREIGN KEY (`line_id`) REFERENCES `job_card_lines` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job_card_travel`
--

LOCK TABLES `job_card_travel` WRITE;
/*!40000 ALTER TABLE `job_card_travel` DISABLE KEYS */;
/*!40000 ALTER TABLE `job_card_travel` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `job_cards`
--

DROP TABLE IF EXISTS `job_cards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `job_cards` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `document_number` varchar(32) DEFAULT NULL,
  `customer_id` int(10) unsigned DEFAULT NULL,
  `customer_code` varchar(32) DEFAULT NULL,
  `customer_name` varchar(160) DEFAULT NULL,
  `customer_phone` varchar(40) DEFAULT NULL,
  `customer_email` varchar(190) DEFAULT NULL,
  `service_address_id` int(10) unsigned DEFAULT NULL,
  `asset_id` int(10) unsigned DEFAULT NULL,
  `location_id` int(10) unsigned DEFAULT NULL,
  `status` enum('open','closed','cancelled') NOT NULL DEFAULT 'open',
  `status_id` int(10) unsigned NOT NULL,
  `priority` enum('low','normal','high','urgent') NOT NULL DEFAULT 'normal',
  `sla_policy_id` int(10) unsigned DEFAULT NULL,
  `respond_by` datetime DEFAULT NULL,
  `resolve_by` datetime DEFAULT NULL,
  `responded_at` datetime DEFAULT NULL,
  `responded_by_user_id` int(10) unsigned DEFAULT NULL,
  `responded_by_name` varchar(120) DEFAULT NULL,
  `owner_user_id` int(10) unsigned DEFAULT NULL,
  `owner_name` varchar(120) NOT NULL DEFAULT '',
  `title` varchar(190) NOT NULL,
  `description` text DEFAULT NULL,
  `reported_at` datetime NOT NULL DEFAULT current_timestamp(),
  `due_at` datetime DEFAULT NULL,
  `started_at` datetime DEFAULT NULL,
  `closed_at` datetime DEFAULT NULL,
  `close_reason` varchar(190) DEFAULT NULL,
  `accepted_quote_id` int(10) unsigned DEFAULT NULL,
  `source` enum('manual','phone','email','walk_in','internal','quote','portal','public_form') NOT NULL DEFAULT 'manual',
  `series_id` int(10) unsigned DEFAULT NULL,
  `reference` varchar(60) DEFAULT NULL,
  `internal_note` varchar(400) DEFAULT NULL,
  `cancelled_at` datetime DEFAULT NULL,
  `cancel_reason` varchar(190) DEFAULT NULL,
  `user_id` int(10) unsigned DEFAULT NULL,
  `user_name` varchar(120) NOT NULL DEFAULT '',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `customer_signed_at` datetime DEFAULT NULL,
  `customer_signed_name` varchar(120) DEFAULT NULL,
  `customer_signature_id` bigint(20) unsigned DEFAULT NULL,
  `technician_signed_at` datetime DEFAULT NULL,
  `technician_signed_name` varchar(120) DEFAULT NULL,
  `technician_signature_id` bigint(20) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_jcard_number` (`document_number`),
  KEY `ix_jcard_status` (`status_id`,`priority`,`id`),
  KEY `ix_jcard_state` (`status`,`priority`,`id`),
  KEY `ix_jcard_customer` (`customer_id`,`reported_at`),
  KEY `ix_jcard_owner` (`owner_user_id`,`status`),
  KEY `ix_jcard_reported` (`reported_at`,`id`),
  KEY `ix_jcard_due` (`due_at`),
  KEY `ix_jcard_address` (`service_address_id`),
  KEY `fk_jcard_location` (`location_id`),
  KEY `fk_jcard_quote` (`accepted_quote_id`),
  KEY `fk_job_sla` (`sla_policy_id`),
  KEY `ix_job_respond` (`status`,`responded_at`,`respond_by`),
  KEY `ix_job_resolve` (`status`,`resolve_by`),
  KEY `ix_jcard_asset` (`asset_id`,`reported_at`),
  KEY `ix_jcard_series` (`series_id`,`reported_at`),
  KEY `ix_jcard_customer_signed` (`customer_signed_at`,`status`),
  KEY `ix_jcard_tech_signed` (`technician_signed_at`,`status`),
  KEY `ix_jcard_customer_sig` (`customer_signature_id`),
  KEY `ix_jcard_tech_sig` (`technician_signature_id`),
  CONSTRAINT `job_cards_ibfk_1` FOREIGN KEY (`service_address_id`) REFERENCES `service_addresses` (`id`) ON DELETE SET NULL,
  CONSTRAINT `job_cards_ibfk_2` FOREIGN KEY (`asset_id`) REFERENCES `customer_assets` (`id`),
  CONSTRAINT `job_cards_ibfk_3` FOREIGN KEY (`customer_signature_id`) REFERENCES `party_documents` (`id`) ON DELETE SET NULL,
  CONSTRAINT `job_cards_ibfk_4` FOREIGN KEY (`location_id`) REFERENCES `stock_locations` (`id`) ON DELETE SET NULL,
  CONSTRAINT `job_cards_ibfk_5` FOREIGN KEY (`accepted_quote_id`) REFERENCES `sales_documents` (`id`) ON DELETE SET NULL,
  CONSTRAINT `job_cards_ibfk_6` FOREIGN KEY (`series_id`) REFERENCES `job_series` (`id`) ON DELETE SET NULL,
  CONSTRAINT `job_cards_ibfk_7` FOREIGN KEY (`status_id`) REFERENCES `job_statuses` (`id`),
  CONSTRAINT `job_cards_ibfk_8` FOREIGN KEY (`technician_signature_id`) REFERENCES `party_documents` (`id`) ON DELETE SET NULL,
  CONSTRAINT `job_cards_ibfk_9` FOREIGN KEY (`sla_policy_id`) REFERENCES `job_sla_policies` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job_cards`
--

LOCK TABLES `job_cards` WRITE;
/*!40000 ALTER TABLE `job_cards` DISABLE KEYS */;
/*!40000 ALTER TABLE `job_cards` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `job_comments`
--

DROP TABLE IF EXISTS `job_comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `job_comments` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `entity` varchar(40) NOT NULL,
  `entity_id` int(10) unsigned NOT NULL,
  `body` text NOT NULL,
  `is_pinned` tinyint(1) NOT NULL DEFAULT 0,
  `author_id` int(10) unsigned DEFAULT NULL,
  `author_name` varchar(120) NOT NULL DEFAULT '',
  `is_edited` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `ix_jcomment_entity` (`entity`,`entity_id`,`is_pinned`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job_comments`
--

LOCK TABLES `job_comments` WRITE;
/*!40000 ALTER TABLE `job_comments` DISABLE KEYS */;
/*!40000 ALTER TABLE `job_comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `job_documents`
--

DROP TABLE IF EXISTS `job_documents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `job_documents` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `entity` varchar(40) NOT NULL,
  `entity_id` int(10) unsigned NOT NULL,
  `filename` varchar(255) NOT NULL,
  `stored_name` varchar(190) NOT NULL,
  `mime_type` varchar(120) DEFAULT NULL,
  `size_bytes` bigint(20) unsigned NOT NULL DEFAULT 0,
  `description` varchar(400) DEFAULT NULL,
  `uploaded_by` int(10) unsigned DEFAULT NULL,
  `uploaded_name` varchar(120) NOT NULL DEFAULT '',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_jdoc_stored` (`stored_name`),
  KEY `ix_jdoc_entity` (`entity`,`entity_id`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job_documents`
--

LOCK TABLES `job_documents` WRITE;
/*!40000 ALTER TABLE `job_documents` DISABLE KEYS */;
/*!40000 ALTER TABLE `job_documents` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `job_feedback`
--

DROP TABLE IF EXISTS `job_feedback`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `job_feedback` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `job_card_id` int(10) unsigned NOT NULL,
  `customer_id` int(10) unsigned DEFAULT NULL,
  `requested_at` datetime NOT NULL DEFAULT current_timestamp(),
  `responded_at` datetime DEFAULT NULL,
  `rating` tinyint(3) unsigned DEFAULT NULL,
  `comment` varchar(1000) DEFAULT NULL,
  `seen_at` datetime DEFAULT NULL,
  `seen_by_user_id` int(10) unsigned DEFAULT NULL,
  `seen_by_name` varchar(120) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_feedback_job` (`job_card_id`),
  KEY `ix_feedback_unseen` (`responded_at`,`seen_at`),
  KEY `ix_feedback_rating` (`rating`,`responded_at`),
  KEY `ix_feedback_customer` (`customer_id`),
  CONSTRAINT `job_feedback_ibfk_1` FOREIGN KEY (`job_card_id`) REFERENCES `job_cards` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job_feedback`
--

LOCK TABLES `job_feedback` WRITE;
/*!40000 ALTER TABLE `job_feedback` DISABLE KEYS */;
/*!40000 ALTER TABLE `job_feedback` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `job_form_answers`
--

DROP TABLE IF EXISTS `job_form_answers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `job_form_answers` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `response_id` int(10) unsigned NOT NULL,
  `field_id` int(10) unsigned NOT NULL,
  `value_text` varchar(1000) DEFAULT NULL,
  `value_number` decimal(14,4) DEFAULT NULL,
  `value_date` datetime DEFAULT NULL,
  `value_bool` tinyint(1) DEFAULT NULL,
  `attachment_id` bigint(20) unsigned DEFAULT NULL,
  `record_id` int(10) unsigned DEFAULT NULL,
  `latitude` decimal(10,7) DEFAULT NULL,
  `longitude` decimal(10,7) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_answer` (`response_id`,`field_id`),
  KEY `ix_answer_field` (`field_id`),
  KEY `fk_answer_attachment` (`attachment_id`),
  CONSTRAINT `job_form_answers_ibfk_1` FOREIGN KEY (`attachment_id`) REFERENCES `party_documents` (`id`) ON DELETE SET NULL,
  CONSTRAINT `job_form_answers_ibfk_2` FOREIGN KEY (`field_id`) REFERENCES `job_form_fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `job_form_answers_ibfk_3` FOREIGN KEY (`response_id`) REFERENCES `job_form_responses` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job_form_answers`
--

LOCK TABLES `job_form_answers` WRITE;
/*!40000 ALTER TABLE `job_form_answers` DISABLE KEYS */;
/*!40000 ALTER TABLE `job_form_answers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `job_form_fields`
--

DROP TABLE IF EXISTS `job_form_fields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `job_form_fields` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `version_id` int(10) unsigned NOT NULL,
  `field_type` enum('short_text','long_text','number','measure','date','time','dropdown','multi_select','choice','checkbox','yesno','file','photo','signature','gps','record','heading','page_break') NOT NULL DEFAULT 'short_text',
  `label` varchar(190) NOT NULL,
  `hint` varchar(190) DEFAULT NULL,
  `unit` varchar(20) DEFAULT NULL,
  `record_kind` enum('customer','contact','site','asset') DEFAULT NULL,
  `options` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`options`)),
  `is_required` tinyint(1) NOT NULL DEFAULT 0,
  `min_value` decimal(14,4) DEFAULT NULL,
  `max_value` decimal(14,4) DEFAULT NULL,
  `max_length` int(10) unsigned DEFAULT NULL,
  `pattern` varchar(190) DEFAULT NULL,
  `show_if_field_id` int(10) unsigned DEFAULT NULL,
  `show_if_value` varchar(190) DEFAULT NULL,
  `sort_order` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `ix_formfield_version` (`version_id`,`sort_order`),
  KEY `fk_formfield_showif` (`show_if_field_id`),
  CONSTRAINT `job_form_fields_ibfk_1` FOREIGN KEY (`show_if_field_id`) REFERENCES `job_form_fields` (`id`) ON DELETE SET NULL,
  CONSTRAINT `job_form_fields_ibfk_2` FOREIGN KEY (`version_id`) REFERENCES `job_form_versions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job_form_fields`
--

LOCK TABLES `job_form_fields` WRITE;
/*!40000 ALTER TABLE `job_form_fields` DISABLE KEYS */;
/*!40000 ALTER TABLE `job_form_fields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `job_form_responses`
--

DROP TABLE IF EXISTS `job_form_responses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `job_form_responses` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `job_card_id` int(10) unsigned NOT NULL,
  `form_id` int(10) unsigned NOT NULL,
  `version_id` int(10) unsigned NOT NULL,
  `asset_id` int(10) unsigned DEFAULT NULL,
  `submitted_at` datetime DEFAULT NULL,
  `respondent_user_id` int(10) unsigned DEFAULT NULL,
  `respondent_name` varchar(120) NOT NULL DEFAULT '',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `ix_formresp_job` (`job_card_id`,`form_id`),
  KEY `ix_formresp_version` (`version_id`),
  KEY `fk_formresp_form` (`form_id`),
  KEY `fk_formresp_asset` (`asset_id`),
  CONSTRAINT `job_form_responses_ibfk_1` FOREIGN KEY (`asset_id`) REFERENCES `customer_assets` (`id`) ON DELETE SET NULL,
  CONSTRAINT `job_form_responses_ibfk_2` FOREIGN KEY (`form_id`) REFERENCES `job_forms` (`id`),
  CONSTRAINT `job_form_responses_ibfk_3` FOREIGN KEY (`job_card_id`) REFERENCES `job_cards` (`id`) ON DELETE CASCADE,
  CONSTRAINT `job_form_responses_ibfk_4` FOREIGN KEY (`version_id`) REFERENCES `job_form_versions` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job_form_responses`
--

LOCK TABLES `job_form_responses` WRITE;
/*!40000 ALTER TABLE `job_form_responses` DISABLE KEYS */;
/*!40000 ALTER TABLE `job_form_responses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `job_form_versions`
--

DROP TABLE IF EXISTS `job_form_versions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `job_form_versions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `form_id` int(10) unsigned NOT NULL,
  `version` int(10) unsigned NOT NULL DEFAULT 1,
  `is_draft` tinyint(1) NOT NULL DEFAULT 1,
  `published_at` datetime DEFAULT NULL,
  `published_by_name` varchar(120) NOT NULL DEFAULT '',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_formver` (`form_id`,`version`),
  KEY `ix_formver_form` (`form_id`,`is_draft`),
  CONSTRAINT `job_form_versions_ibfk_1` FOREIGN KEY (`form_id`) REFERENCES `job_forms` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job_form_versions`
--

LOCK TABLES `job_form_versions` WRITE;
/*!40000 ALTER TABLE `job_form_versions` DISABLE KEYS */;
/*!40000 ALTER TABLE `job_form_versions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `job_forms`
--

DROP TABLE IF EXISTS `job_forms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `job_forms` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(190) NOT NULL,
  `description` varchar(400) DEFAULT NULL,
  `code` varchar(60) NOT NULL,
  `is_public` tinyint(1) NOT NULL DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_form_code` (`code`),
  KEY `ix_form_active` (`is_active`,`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job_forms`
--

LOCK TABLES `job_forms` WRITE;
/*!40000 ALTER TABLE `job_forms` DISABLE KEYS */;
/*!40000 ALTER TABLE `job_forms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `job_headline_forms`
--

DROP TABLE IF EXISTS `job_headline_forms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `job_headline_forms` (
  `headline_id` int(10) unsigned NOT NULL,
  `form_id` int(10) unsigned NOT NULL,
  `is_required` tinyint(1) NOT NULL DEFAULT 0,
  `sort_order` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`headline_id`,`form_id`),
  KEY `ix_hform_form` (`form_id`),
  CONSTRAINT `job_headline_forms_ibfk_1` FOREIGN KEY (`form_id`) REFERENCES `job_forms` (`id`) ON DELETE CASCADE,
  CONSTRAINT `job_headline_forms_ibfk_2` FOREIGN KEY (`headline_id`) REFERENCES `job_headlines` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job_headline_forms`
--

LOCK TABLES `job_headline_forms` WRITE;
/*!40000 ALTER TABLE `job_headline_forms` DISABLE KEYS */;
/*!40000 ALTER TABLE `job_headline_forms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `job_headline_parts`
--

DROP TABLE IF EXISTS `job_headline_parts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `job_headline_parts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `headline_id` int(10) unsigned NOT NULL,
  `product_id` int(10) unsigned NOT NULL,
  `qty` decimal(12,3) NOT NULL DEFAULT 1.000,
  `line_kind` enum('part','labour','travel','charge') NOT NULL DEFAULT 'part',
  `sort_order` int(11) NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_hpart` (`headline_id`,`product_id`,`line_kind`),
  KEY `ix_hpart_product` (`product_id`),
  CONSTRAINT `job_headline_parts_ibfk_1` FOREIGN KEY (`headline_id`) REFERENCES `job_headlines` (`id`) ON DELETE CASCADE,
  CONSTRAINT `job_headline_parts_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job_headline_parts`
--

LOCK TABLES `job_headline_parts` WRITE;
/*!40000 ALTER TABLE `job_headline_parts` DISABLE KEYS */;
/*!40000 ALTER TABLE `job_headline_parts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `job_headlines`
--

DROP TABLE IF EXISTS `job_headlines`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `job_headlines` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(40) NOT NULL,
  `name` varchar(120) NOT NULL,
  `description` varchar(190) DEFAULT NULL,
  `default_priority` enum('low','normal','high','urgent') DEFAULT NULL,
  `default_board_id` int(10) unsigned DEFAULT NULL,
  `suggested_minutes` int(10) unsigned DEFAULT NULL,
  `required_skills` varchar(190) DEFAULT NULL,
  `sort_order` int(11) NOT NULL DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_headline_code` (`code`),
  KEY `ix_headline_active` (`is_active`,`sort_order`),
  KEY `fk_headline_board` (`default_board_id`),
  CONSTRAINT `job_headlines_ibfk_1` FOREIGN KEY (`default_board_id`) REFERENCES `job_boards` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job_headlines`
--

LOCK TABLES `job_headlines` WRITE;
/*!40000 ALTER TABLE `job_headlines` DISABLE KEYS */;
/*!40000 ALTER TABLE `job_headlines` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `job_line_serials`
--

DROP TABLE IF EXISTS `job_line_serials`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `job_line_serials` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `job_card_line_id` int(10) unsigned NOT NULL,
  `serial_id` int(10) unsigned NOT NULL,
  `serial_text` varchar(64) NOT NULL,
  `allocated_by_user_id` int(10) unsigned DEFAULT NULL,
  `allocated_by_name` varchar(120) NOT NULL DEFAULT '',
  `allocated_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_jls_serial` (`serial_id`),
  KEY `ix_jls_line` (`job_card_line_id`),
  CONSTRAINT `job_line_serials_ibfk_1` FOREIGN KEY (`job_card_line_id`) REFERENCES `job_card_lines` (`id`) ON DELETE CASCADE,
  CONSTRAINT `job_line_serials_ibfk_2` FOREIGN KEY (`serial_id`) REFERENCES `product_serials` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job_line_serials`
--

LOCK TABLES `job_line_serials` WRITE;
/*!40000 ALTER TABLE `job_line_serials` DISABLE KEYS */;
/*!40000 ALTER TABLE `job_line_serials` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `job_notifications`
--

DROP TABLE IF EXISTS `job_notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `job_notifications` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `job_card_id` int(10) unsigned NOT NULL,
  `event` varchar(40) NOT NULL,
  `channel` enum('bell','email','sms','whatsapp','push') NOT NULL,
  `user_id` int(10) unsigned DEFAULT NULL,
  `contact_id` int(10) unsigned DEFAULT NULL,
  `destination` varchar(190) NOT NULL DEFAULT '',
  `status` enum('sent','failed','skipped','suppressed') NOT NULL,
  `reason` varchar(300) NOT NULL DEFAULT '',
  `summary` varchar(190) NOT NULL DEFAULT '',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `ix_jobnotif_job` (`job_card_id`,`created_at`),
  KEY `ix_jobnotif_dedupe` (`job_card_id`,`event`,`channel`,`user_id`,`contact_id`,`created_at`),
  CONSTRAINT `job_notifications_ibfk_1` FOREIGN KEY (`job_card_id`) REFERENCES `job_cards` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job_notifications`
--

LOCK TABLES `job_notifications` WRITE;
/*!40000 ALTER TABLE `job_notifications` DISABLE KEYS */;
/*!40000 ALTER TABLE `job_notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `job_part_requests`
--

DROP TABLE IF EXISTS `job_part_requests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `job_part_requests` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `job_card_id` int(10) unsigned NOT NULL,
  `job_card_line_id` int(10) unsigned DEFAULT NULL,
  `product_id` int(10) unsigned DEFAULT NULL,
  `product_code` varchar(48) DEFAULT NULL,
  `description` varchar(190) NOT NULL,
  `qty` decimal(12,3) NOT NULL DEFAULT 1.000,
  `status` enum('requested','approved','ordered','received','cancelled') NOT NULL DEFAULT 'requested',
  `reason` varchar(400) DEFAULT NULL,
  `requested_by_user_id` int(10) unsigned DEFAULT NULL,
  `requested_by_name` varchar(120) NOT NULL DEFAULT '',
  `decided_by_user_id` int(10) unsigned DEFAULT NULL,
  `decided_by_name` varchar(120) DEFAULT NULL,
  `decided_at` datetime DEFAULT NULL,
  `decided_note` varchar(400) DEFAULT NULL,
  `purchase_line_id` int(10) unsigned DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `ix_jpr_job` (`job_card_id`,`status`),
  KEY `ix_jpr_status` (`status`,`created_at`),
  KEY `ix_jpr_line` (`job_card_line_id`),
  KEY `ix_jpr_purchase_line` (`purchase_line_id`),
  KEY `fk_jpr_product` (`product_id`),
  CONSTRAINT `job_part_requests_ibfk_1` FOREIGN KEY (`job_card_id`) REFERENCES `job_cards` (`id`) ON DELETE CASCADE,
  CONSTRAINT `job_part_requests_ibfk_2` FOREIGN KEY (`job_card_line_id`) REFERENCES `job_card_lines` (`id`) ON DELETE SET NULL,
  CONSTRAINT `job_part_requests_ibfk_3` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE SET NULL,
  CONSTRAINT `job_part_requests_ibfk_4` FOREIGN KEY (`purchase_line_id`) REFERENCES `purchase_document_lines` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job_part_requests`
--

LOCK TABLES `job_part_requests` WRITE;
/*!40000 ALTER TABLE `job_part_requests` DISABLE KEYS */;
/*!40000 ALTER TABLE `job_part_requests` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `job_requests`
--

DROP TABLE IF EXISTS `job_requests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `job_requests` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `reference` varchar(20) DEFAULT NULL,
  `contact_name` varchar(120) NOT NULL,
  `contact_phone` varchar(40) NOT NULL,
  `contact_email` varchar(190) DEFAULT NULL,
  `title` varchar(190) NOT NULL,
  `description` text DEFAULT NULL,
  `address_text` varchar(400) DEFAULT NULL,
  `headline_id` int(10) unsigned DEFAULT NULL,
  `status` enum('new','accepted','rejected','spam') NOT NULL DEFAULT 'new',
  `job_card_id` int(10) unsigned DEFAULT NULL,
  `customer_id` int(10) unsigned DEFAULT NULL,
  `decided_at` datetime DEFAULT NULL,
  `decided_by_user_id` int(10) unsigned DEFAULT NULL,
  `decided_by_name` varchar(120) DEFAULT NULL,
  `decided_reason` varchar(400) DEFAULT NULL,
  `submitted_ip` varchar(45) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_request_reference` (`reference`),
  KEY `ix_request_status` (`status`,`created_at`),
  KEY `ix_request_phone` (`contact_phone`,`created_at`),
  KEY `ix_request_job` (`job_card_id`),
  KEY `fk_request_headline` (`headline_id`),
  CONSTRAINT `job_requests_ibfk_1` FOREIGN KEY (`headline_id`) REFERENCES `job_headlines` (`id`) ON DELETE SET NULL,
  CONSTRAINT `job_requests_ibfk_2` FOREIGN KEY (`job_card_id`) REFERENCES `job_cards` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job_requests`
--

LOCK TABLES `job_requests` WRITE;
/*!40000 ALTER TABLE `job_requests` DISABLE KEYS */;
/*!40000 ALTER TABLE `job_requests` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `job_rule_runs`
--

DROP TABLE IF EXISTS `job_rule_runs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `job_rule_runs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `rule_id` int(10) unsigned NOT NULL,
  `job_card_id` int(10) unsigned NOT NULL,
  `status` enum('claimed','done','failed') NOT NULL DEFAULT 'claimed',
  `detail` varchar(400) NOT NULL DEFAULT '',
  `claimed_at` datetime NOT NULL DEFAULT current_timestamp(),
  `finished_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_jobrulerun_guard` (`rule_id`,`job_card_id`,`claimed_at`),
  KEY `fk_jobrulerun_job` (`job_card_id`),
  CONSTRAINT `job_rule_runs_ibfk_1` FOREIGN KEY (`job_card_id`) REFERENCES `job_cards` (`id`) ON DELETE CASCADE,
  CONSTRAINT `job_rule_runs_ibfk_2` FOREIGN KEY (`rule_id`) REFERENCES `job_rules` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job_rule_runs`
--

LOCK TABLES `job_rule_runs` WRITE;
/*!40000 ALTER TABLE `job_rule_runs` DISABLE KEYS */;
/*!40000 ALTER TABLE `job_rule_runs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `job_rules`
--

DROP TABLE IF EXISTS `job_rules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `job_rules` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(190) NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `trigger_event` enum('created','status_entered','status_exited','priority_changed','assigned','closed','quote_accepted','quote_declined','part_requested','part_received','form_submitted') NOT NULL,
  `trigger_status_id` int(10) unsigned DEFAULT NULL,
  `if_board_id` int(10) unsigned DEFAULT NULL,
  `if_priority` enum('low','normal','high','urgent') DEFAULT NULL,
  `if_headline_id` int(10) unsigned DEFAULT NULL,
  `if_idle_hours` int(10) unsigned DEFAULT NULL,
  `do_notify` tinyint(1) NOT NULL DEFAULT 0,
  `do_status_id` int(10) unsigned DEFAULT NULL,
  `do_priority` enum('low','normal','high','urgent') DEFAULT NULL,
  `do_follower_user_id` int(10) unsigned DEFAULT NULL,
  `message` varchar(400) NOT NULL DEFAULT '',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `ix_jobrule_event` (`is_active`,`trigger_event`),
  KEY `fk_jobrule_trigger_status` (`trigger_status_id`),
  KEY `fk_jobrule_do_status` (`do_status_id`),
  KEY `fk_jobrule_if_board_only` (`if_board_id`),
  CONSTRAINT `job_rules_ibfk_1` FOREIGN KEY (`do_status_id`) REFERENCES `job_statuses` (`id`) ON DELETE SET NULL,
  CONSTRAINT `job_rules_ibfk_2` FOREIGN KEY (`if_board_id`) REFERENCES `job_boards` (`id`) ON DELETE SET NULL,
  CONSTRAINT `job_rules_ibfk_3` FOREIGN KEY (`trigger_status_id`) REFERENCES `job_statuses` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job_rules`
--

LOCK TABLES `job_rules` WRITE;
/*!40000 ALTER TABLE `job_rules` DISABLE KEYS */;
/*!40000 ALTER TABLE `job_rules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `job_saved_views`
--

DROP TABLE IF EXISTS `job_saved_views`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `job_saved_views` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(80) NOT NULL,
  `filters` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`filters`)),
  `owner_user_id` int(10) unsigned DEFAULT NULL,
  `owner_name` varchar(120) NOT NULL DEFAULT '',
  `is_shared` tinyint(1) NOT NULL DEFAULT 0,
  `is_pinned` tinyint(1) NOT NULL DEFAULT 0,
  `sort_order` int(11) NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_view_owner_name` (`owner_user_id`,`name`),
  KEY `ix_jview_visible` (`is_shared`,`owner_user_id`,`sort_order`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job_saved_views`
--

LOCK TABLES `job_saved_views` WRITE;
/*!40000 ALTER TABLE `job_saved_views` DISABLE KEYS */;
/*!40000 ALTER TABLE `job_saved_views` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `job_series`
--

DROP TABLE IF EXISTS `job_series`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `job_series` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(120) NOT NULL,
  `customer_id` int(10) unsigned NOT NULL,
  `service_address_id` int(10) unsigned DEFAULT NULL,
  `asset_id` int(10) unsigned DEFAULT NULL,
  `title` varchar(190) NOT NULL,
  `description` text DEFAULT NULL,
  `priority` enum('low','normal','high','urgent') NOT NULL DEFAULT 'normal',
  `owner_user_id` int(10) unsigned DEFAULT NULL,
  `owner_name` varchar(120) DEFAULT NULL,
  `location_id` int(10) unsigned DEFAULT NULL,
  `frequency` enum('weekly','monthly','quarterly','annually') NOT NULL DEFAULT 'monthly',
  `day_of_month` tinyint(3) unsigned NOT NULL DEFAULT 1,
  `day_of_week` tinyint(3) unsigned DEFAULT NULL,
  `starts_on` date NOT NULL,
  `ends_on` date DEFAULT NULL,
  `last_generated_for` date DEFAULT NULL,
  `lead_days` smallint(5) unsigned NOT NULL DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `auto_create` tinyint(1) NOT NULL DEFAULT 0,
  `note` varchar(190) DEFAULT NULL,
  `user_id` int(10) unsigned DEFAULT NULL,
  `user_name` varchar(120) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `ix_series_customer` (`customer_id`,`is_active`),
  KEY `ix_series_asset` (`asset_id`),
  KEY `ix_series_due` (`is_active`,`auto_create`,`last_generated_for`),
  KEY `fk_series_address` (`service_address_id`),
  CONSTRAINT `job_series_ibfk_1` FOREIGN KEY (`service_address_id`) REFERENCES `service_addresses` (`id`) ON DELETE SET NULL,
  CONSTRAINT `job_series_ibfk_2` FOREIGN KEY (`asset_id`) REFERENCES `customer_assets` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job_series`
--

LOCK TABLES `job_series` WRITE;
/*!40000 ALTER TABLE `job_series` DISABLE KEYS */;
/*!40000 ALTER TABLE `job_series` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `job_series_headlines`
--

DROP TABLE IF EXISTS `job_series_headlines`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `job_series_headlines` (
  `series_id` int(10) unsigned NOT NULL,
  `headline_id` int(10) unsigned NOT NULL,
  `sort_order` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`series_id`,`headline_id`),
  KEY `ix_jsh_headline` (`headline_id`),
  CONSTRAINT `job_series_headlines_ibfk_1` FOREIGN KEY (`headline_id`) REFERENCES `job_headlines` (`id`),
  CONSTRAINT `job_series_headlines_ibfk_2` FOREIGN KEY (`series_id`) REFERENCES `job_series` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job_series_headlines`
--

LOCK TABLES `job_series_headlines` WRITE;
/*!40000 ALTER TABLE `job_series_headlines` DISABLE KEYS */;
/*!40000 ALTER TABLE `job_series_headlines` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `job_series_runs`
--

DROP TABLE IF EXISTS `job_series_runs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `job_series_runs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `series_id` int(10) unsigned NOT NULL,
  `for_date` date NOT NULL,
  `job_card_id` int(10) unsigned DEFAULT NULL,
  `status` enum('created','failed') NOT NULL DEFAULT 'created',
  `error` varchar(400) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_series_period` (`series_id`,`for_date`),
  KEY `ix_jsr_job` (`job_card_id`),
  KEY `ix_jsr_failed` (`status`,`created_at`),
  CONSTRAINT `job_series_runs_ibfk_1` FOREIGN KEY (`job_card_id`) REFERENCES `job_cards` (`id`) ON DELETE SET NULL,
  CONSTRAINT `job_series_runs_ibfk_2` FOREIGN KEY (`series_id`) REFERENCES `job_series` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job_series_runs`
--

LOCK TABLES `job_series_runs` WRITE;
/*!40000 ALTER TABLE `job_series_runs` DISABLE KEYS */;
/*!40000 ALTER TABLE `job_series_runs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `job_sla_escalations`
--

DROP TABLE IF EXISTS `job_sla_escalations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `job_sla_escalations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `job_card_id` int(10) unsigned NOT NULL,
  `record_type` enum('job','ticket') NOT NULL DEFAULT 'job',
  `kind` enum('respond','resolve') NOT NULL,
  `notified_user_id` int(10) unsigned DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_sla_escalation` (`record_type`,`job_card_id`,`kind`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job_sla_escalations`
--

LOCK TABLES `job_sla_escalations` WRITE;
/*!40000 ALTER TABLE `job_sla_escalations` DISABLE KEYS */;
/*!40000 ALTER TABLE `job_sla_escalations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `job_sla_policies`
--

DROP TABLE IF EXISTS `job_sla_policies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `job_sla_policies` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `customer_id` int(10) unsigned DEFAULT NULL,
  `priority` enum('low','normal','high','urgent') NOT NULL,
  `name` varchar(120) NOT NULL,
  `respond_minutes` int(10) unsigned DEFAULT NULL,
  `resolve_minutes` int(10) unsigned DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `note` varchar(190) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `escalate_after_minutes` int(10) unsigned DEFAULT NULL,
  `escalate_to_user_id` int(10) unsigned DEFAULT NULL,
  `for_tickets` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_sla_customer_priority` (`customer_id`,`priority`),
  KEY `ix_sla_customer` (`customer_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job_sla_policies`
--

LOCK TABLES `job_sla_policies` WRITE;
/*!40000 ALTER TABLE `job_sla_policies` DISABLE KEYS */;
INSERT INTO `job_sla_policies` VALUES (1,NULL,'urgent','Urgent',60,540,1,NULL,'2026-08-24 09:10:34','2026-08-24 09:10:34',NULL,NULL,0),(2,NULL,'high','High',240,1080,1,NULL,'2026-08-24 09:10:34','2026-08-24 09:10:34',NULL,NULL,0),(3,NULL,'normal','Standard',540,2700,1,NULL,'2026-08-24 09:10:34','2026-08-24 09:10:34',NULL,NULL,0),(4,NULL,'low','Low',1080,NULL,1,NULL,'2026-08-24 09:10:34','2026-08-24 09:10:34',NULL,NULL,0);
/*!40000 ALTER TABLE `job_sla_policies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `job_statuses`
--

DROP TABLE IF EXISTS `job_statuses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `job_statuses` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(40) NOT NULL,
  `name` varchar(60) NOT NULL,
  `tone` enum('neutral','brand','success','warning','danger') NOT NULL DEFAULT 'neutral',
  `sort_order` int(11) NOT NULL DEFAULT 0,
  `role` enum('','new','assigned','in_progress','on_hold','completed','cancelled') NOT NULL DEFAULT '',
  `requires_reason` tinyint(1) NOT NULL DEFAULT 0,
  `blocks_on_incomplete` tinyint(1) DEFAULT NULL,
  `audience` enum('anyone','office') NOT NULL DEFAULT 'anyone',
  `is_closed_stage` tinyint(1) NOT NULL DEFAULT 0,
  `is_system` tinyint(1) NOT NULL DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_jstatus_code` (`code`),
  KEY `ix_jstatus_sort` (`sort_order`),
  KEY `ix_jstatus_role` (`role`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job_statuses`
--

LOCK TABLES `job_statuses` WRITE;
/*!40000 ALTER TABLE `job_statuses` DISABLE KEYS */;
INSERT INTO `job_statuses` VALUES (1,'new','New','brand',10,'new',0,NULL,'anyone',0,1,1,'2026-08-24 09:10:33','2026-08-24 09:10:33'),(2,'assigned','Assigned','brand',20,'assigned',0,NULL,'anyone',0,1,1,'2026-08-24 09:10:33','2026-08-24 09:10:33'),(3,'scheduled','Scheduled','neutral',30,'',0,NULL,'anyone',0,0,1,'2026-08-24 09:10:33','2026-08-24 09:10:33'),(4,'in_progress','In Progress','warning',40,'in_progress',0,NULL,'anyone',0,1,1,'2026-08-24 09:10:33','2026-08-24 09:10:33'),(5,'on_hold','On Hold','neutral',50,'on_hold',0,NULL,'anyone',0,1,1,'2026-08-24 09:10:33','2026-08-24 09:10:34'),(6,'parts','Awaiting Parts','warning',60,'',0,NULL,'anyone',0,0,1,'2026-08-24 09:10:33','2026-08-24 09:10:33'),(7,'completed','Work Completed','success',70,'completed',0,1,'anyone',0,1,1,'2026-08-24 09:10:33','2026-08-24 09:10:34'),(8,'cancelled','Cancelled','danger',80,'cancelled',0,0,'anyone',0,1,1,'2026-08-24 09:10:33','2026-08-24 09:10:34'),(9,'paused','Paused','neutral',45,'',1,NULL,'anyone',0,0,1,'2026-08-24 09:10:34','2026-08-24 09:10:34'),(10,'awaiting_customer','Awaiting Customer','warning',65,'',1,NULL,'anyone',0,0,1,'2026-08-24 09:10:34','2026-08-24 09:10:34'),(11,'ready_invoice','Ready to Invoice','brand',72,'',0,1,'office',0,0,1,'2026-08-24 09:10:34','2026-08-24 09:10:34'),(12,'invoiced','Invoiced','success',74,'',0,NULL,'office',0,0,1,'2026-08-24 09:10:34','2026-08-24 09:10:34'),(13,'closed','Closed','neutral',76,'',0,0,'office',1,0,1,'2026-08-24 09:10:34','2026-08-24 09:10:34');
/*!40000 ALTER TABLE `job_statuses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `job_stock_reservations`
--

DROP TABLE IF EXISTS `job_stock_reservations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `job_stock_reservations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `job_card_line_id` int(10) unsigned NOT NULL,
  `job_card_id` int(10) unsigned NOT NULL,
  `product_id` int(10) unsigned NOT NULL,
  `location_id` int(10) unsigned NOT NULL,
  `qty` decimal(12,3) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_jobres_line` (`job_card_line_id`),
  KEY `ix_jobres_product` (`product_id`,`location_id`),
  KEY `fk_jobres_job` (`job_card_id`),
  CONSTRAINT `job_stock_reservations_ibfk_1` FOREIGN KEY (`job_card_id`) REFERENCES `job_cards` (`id`) ON DELETE CASCADE,
  CONSTRAINT `job_stock_reservations_ibfk_2` FOREIGN KEY (`job_card_line_id`) REFERENCES `job_card_lines` (`id`) ON DELETE CASCADE,
  CONSTRAINT `job_stock_reservations_ibfk_3` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job_stock_reservations`
--

LOCK TABLES `job_stock_reservations` WRITE;
/*!40000 ALTER TABLE `job_stock_reservations` DISABLE KEYS */;
/*!40000 ALTER TABLE `job_stock_reservations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `job_team_members`
--

DROP TABLE IF EXISTS `job_team_members`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `job_team_members` (
  `team_id` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `user_name` varchar(120) NOT NULL DEFAULT '',
  `is_lead` tinyint(1) NOT NULL DEFAULT 0,
  `sort_order` int(11) NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`team_id`,`user_id`),
  KEY `ix_jteam_user` (`user_id`),
  CONSTRAINT `job_team_members_ibfk_1` FOREIGN KEY (`team_id`) REFERENCES `job_teams` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job_team_members`
--

LOCK TABLES `job_team_members` WRITE;
/*!40000 ALTER TABLE `job_team_members` DISABLE KEYS */;
/*!40000 ALTER TABLE `job_team_members` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `job_teams`
--

DROP TABLE IF EXISTS `job_teams`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `job_teams` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(80) NOT NULL,
  `description` varchar(190) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `sort_order` int(11) NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_team_name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job_teams`
--

LOCK TABLES `job_teams` WRITE;
/*!40000 ALTER TABLE `job_teams` DISABLE KEYS */;
/*!40000 ALTER TABLE `job_teams` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `journal_batches`
--

DROP TABLE IF EXISTS `journal_batches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `journal_batches` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `journal_number` varchar(32) DEFAULT NULL,
  `journal_date` date NOT NULL,
  `status` enum('draft','posted','void') NOT NULL DEFAULT 'draft',
  `source` varchar(24) NOT NULL DEFAULT 'manual',
  `source_doc_id` int(10) unsigned DEFAULT NULL,
  `description` varchar(255) NOT NULL,
  `reference` varchar(60) DEFAULT NULL,
  `total_debit` decimal(16,4) NOT NULL DEFAULT 0.0000,
  `total_credit` decimal(16,4) NOT NULL DEFAULT 0.0000,
  `reverses_id` int(10) unsigned DEFAULT NULL,
  `user_id` int(10) unsigned DEFAULT NULL,
  `user_name` varchar(120) NOT NULL DEFAULT '',
  `posted_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_journal_number` (`journal_number`),
  KEY `ix_journal_date` (`journal_date`,`id`),
  KEY `ix_journal_status` (`status`,`journal_date`),
  KEY `ix_journal_source` (`source`,`source_doc_id`),
  KEY `fk_journal_reverses` (`reverses_id`),
  CONSTRAINT `journal_batches_ibfk_1` FOREIGN KEY (`reverses_id`) REFERENCES `journal_batches` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `journal_batches`
--

LOCK TABLES `journal_batches` WRITE;
/*!40000 ALTER TABLE `journal_batches` DISABLE KEYS */;
INSERT INTO `journal_batches` VALUES (1,'JNL000001','2026-08-08','posted','sale',1,'Sale INV000001','INV000001',182.8000,182.8000,NULL,1,'Tiaan Smith','2026-08-09 09:50:14','2026-08-09 09:50:14','2026-08-09 09:50:14'),(2,'JNL000002','2026-08-09','posted','sale',2,'Sale INV000002','INV000002',532.4000,532.4000,NULL,1,'Tiaan Smith','2026-08-09 10:14:30','2026-08-09 10:14:30','2026-08-09 10:14:30'),(3,'JNL000003','2026-08-10','posted','expense',1,'Expense EXP000001','EXP000001',1500.0000,1500.0000,NULL,1,'Tiaan Smith','2026-08-10 07:41:07','2026-08-10 07:41:07','2026-08-10 07:41:07'),(4,'JNL000004','2026-08-11','posted','sale',9,'Sale INV000003','INV000003',290.5000,290.5000,NULL,1,'Tiaan Smith','2026-08-11 13:46:45','2026-08-11 13:46:45','2026-08-11 13:46:45'),(5,'JNL000005','2026-08-10','posted','sale',8,'Sale INV000004','INV000004',1092.0000,1092.0000,NULL,1,'Tiaan Smith','2026-08-11 13:49:00','2026-08-11 13:49:00','2026-08-11 13:49:00'),(6,'JNL000006','2026-08-12','posted','grv',3,'Goods received GRV000001','GRV000001',460.0000,460.0000,NULL,1,'Order Test','2026-08-12 10:54:37','2026-08-12 10:54:37','2026-08-12 10:54:37'),(7,'JNL000007','2026-08-12','posted','grv',4,'Goods received GRV000002','GRV000002',690.0000,690.0000,NULL,1,'Order Test','2026-08-12 10:54:37','2026-08-12 10:54:37','2026-08-12 10:54:37'),(8,'JNL000008','2026-08-12','posted','grv',6,'Goods received GRV000003','GRV000003',1150.0000,1150.0000,NULL,1,'Purchase Test','2026-08-12 10:54:45','2026-08-12 10:54:45','2026-08-12 10:54:45'),(9,'JNL000009','2026-08-12','posted','grv',7,'Goods received GRV000004','GRV000004',2300.0000,2300.0000,NULL,1,'Purchase Test','2026-08-12 10:54:45','2026-08-12 10:54:45','2026-08-12 10:54:45'),(10,'JNL000010','2026-08-12','posted','grv',8,'Goods received GRV000005','GRV000005',1150.0000,1150.0000,NULL,1,'Purchase Test','2026-08-12 10:54:46','2026-08-12 10:54:46','2026-08-12 10:54:46'),(11,'JNL000011','2026-08-12','posted','grv',9,'Goods received GRV000006','GRV000006',1150.0000,1150.0000,NULL,1,'Purchase Test','2026-08-12 10:54:46','2026-08-12 10:54:46','2026-08-12 10:54:46'),(12,'JNL000012','2026-08-12','posted','grv',10,'Goods received GRV000007','GRV000007',1150.0000,1150.0000,NULL,1,'Purchase Test','2026-08-12 10:55:01','2026-08-12 10:55:01','2026-08-12 10:55:01'),(13,'JNL000013','2026-08-12','posted','grv',11,'Goods received GRV000008','GRV000008',2300.0000,2300.0000,NULL,1,'Purchase Test','2026-08-12 10:55:01','2026-08-12 10:55:01','2026-08-12 10:55:01'),(14,'JNL000014','2026-08-12','posted','grv',12,'Goods received GRV000009','GRV000009',1150.0000,1150.0000,NULL,1,'Purchase Test','2026-08-12 10:55:01','2026-08-12 10:55:01','2026-08-12 10:55:01'),(15,'JNL000015','2026-08-12','posted','grv',13,'Goods received GRV000010','GRV000010',1150.0000,1150.0000,NULL,1,'Purchase Test','2026-08-12 10:55:01','2026-08-12 10:55:01','2026-08-12 10:55:01'),(16,'JNL000016','2026-08-12','posted','grv',14,'Goods received GRV000011','GRV000011',1150.0000,1150.0000,NULL,1,'Draft Test','2026-08-12 10:55:43','2026-08-12 10:55:43','2026-08-12 10:55:43'),(17,'JNL000017','2026-08-12','posted','grv',20,'Goods received GRV000012','GRV000012',345.0000,345.0000,NULL,1,'Reorder Test','2026-08-12 10:55:49','2026-08-12 10:55:49','2026-08-12 10:55:49'),(18,'JNL000018','2026-08-12','posted','grv',21,'Goods received GRV000013','GRV000013',1150.0000,1150.0000,NULL,1,'Guard Test','2026-08-12 10:55:50','2026-08-12 10:55:50','2026-08-12 10:55:50'),(19,'JNL000019','2026-08-12','posted','grv',22,'Goods received GRV000014','GRV000014',1150.0000,1150.0000,NULL,1,'Guard Test','2026-08-12 10:55:50','2026-08-12 10:55:50','2026-08-12 10:55:50'),(20,'JNL000020','2026-08-12','posted','grv',23,'Goods received GRV000015','GRV000015',1150.0000,1150.0000,NULL,1,'Guard Test','2026-08-12 10:55:50','2026-08-12 10:55:50','2026-08-12 10:55:50'),(21,'JNL000021','2026-08-12','posted','grv',24,'Goods received GRV000016','GRV000016',11.5000,11.5000,NULL,1,'Guard Test','2026-08-12 10:55:50','2026-08-12 10:55:50','2026-08-12 10:55:50'),(22,'JNL000022','2026-08-12','posted','grv',25,'Goods received GRV000017','GRV000017',1380.0000,1380.0000,NULL,1,'Guard Test','2026-08-12 10:55:51','2026-08-12 10:55:51','2026-08-12 10:55:51'),(23,'JNL000023','2026-08-12','posted','grv',26,'Goods received GRV000018','GRV000018',1150.0000,1150.0000,NULL,1,'Guard Test','2026-08-12 10:55:51','2026-08-12 10:55:51','2026-08-12 10:55:51'),(24,'JNL000024','2026-08-24','posted','grv',27,'Goods received GRV000019','GRV000019',138.0000,138.0000,NULL,1,'Tiaan Smith','2026-08-24 12:49:22','2026-08-24 12:49:22','2026-08-24 12:49:22'),(25,'JNL000025','2026-08-24','posted','sale',10,'Sale INV_01_01_000001','INV_01_01_000001',32.0000,32.0000,NULL,1,'Tiaan Smith','2026-08-24 12:50:09','2026-08-24 12:50:09','2026-08-24 12:50:09'),(26,'JNL000026','2026-08-24','posted','stock_adjustment',1,'Stock adjustment ADJ000001','ADJ000001',360.0000,360.0000,NULL,1,'Tiaan Smith','2026-08-24 13:08:53','2026-08-24 13:08:53','2026-08-24 13:08:53'),(27,'JNL000027','2026-08-25','posted','sale',12,'Sale INV_01_03_000001','INV_01_03_000001',190.0000,190.0000,NULL,1,'Tiaan Smith','2026-08-25 19:18:39','2026-08-25 19:18:39','2026-08-25 19:18:39'),(28,'JNL000028','2026-08-25','posted','sale',11,'Sale INV_01_03_000002','INV_01_03_000002',190.0000,190.0000,NULL,1,'Tiaan Smith','2026-08-25 19:19:45','2026-08-25 19:19:45','2026-08-25 19:19:45'),(29,'JNL000029','2026-08-26','posted','sale',18,'Sale INV_01_04_000001','INV_01_04_000001',500.0000,500.0000,NULL,1,'Tiaan Smith','2026-08-26 15:23:34','2026-08-26 15:23:34','2026-08-26 15:23:34'),(30,'JNL000030','2026-08-26','posted','sale',19,'Sale INV_01_04_000002','INV_01_04_000002',161.0000,161.0000,NULL,1,'Tiaan Smith','2026-08-26 15:33:03','2026-08-26 15:33:03','2026-08-26 15:33:03'),(31,'JNL000031','2026-08-26','posted','sale',20,'Sale INV_01_04_000003','INV_01_04_000003',40.0000,40.0000,NULL,1,'Tiaan Smith','2026-08-26 15:34:12','2026-08-26 15:34:12','2026-08-26 15:34:12'),(32,'JNL000032','2026-08-26','posted','sale',23,'Sale INV_01_04_000004','INV_01_04_000004',161.0000,161.0000,NULL,1,'Tiaan Smith','2026-08-26 15:39:13','2026-08-26 15:39:13','2026-08-26 15:39:13'),(33,'JNL000033','2026-08-26','posted','stock_adjustment',2,'Stock adjustment ADJ000002','ADJ000002',1200.0000,1200.0000,NULL,1,'Tiaan Smith','2026-08-26 16:03:10','2026-08-26 16:03:10','2026-08-26 16:03:10'),(34,'JNL000034','2026-08-26','posted','stock_adjustment',3,'Stock adjustment ADJ000003','ADJ000003',6000.0000,6000.0000,NULL,1,'Tiaan Smith','2026-08-26 16:19:05','2026-08-26 16:19:05','2026-08-26 16:19:05'),(35,'JNL000035','2026-08-26','posted','stock_take',2,'Stock take STK000001','STK000001',17420.0000,17420.0000,NULL,1,'Tiaan Smith','2026-08-26 16:47:38','2026-08-26 16:47:38','2026-08-26 16:47:38'),(36,'JNL000036','2026-08-26','posted','stock_adjustment',4,'Stock adjustment ADJ000004','ADJ000004',616.6000,616.6000,NULL,1,'Tiaan Smith','2026-08-26 16:51:23','2026-08-26 16:51:23','2026-08-26 16:51:23'),(37,'JNL000037','2026-08-31','posted','sale',30,'Sale INV_01_05_000001','INV_01_05_000001',56.0000,56.0000,NULL,1,'Tiaan Smith','2026-08-31 10:55:39','2026-08-31 10:55:39','2026-08-31 10:55:39');
/*!40000 ALTER TABLE `journal_batches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `journal_lines`
--

DROP TABLE IF EXISTS `journal_lines`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `journal_lines` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `batch_id` int(10) unsigned NOT NULL,
  `line_number` smallint(5) unsigned NOT NULL DEFAULT 1,
  `account_id` int(10) unsigned NOT NULL,
  `account_code` varchar(16) DEFAULT NULL,
  `account_name` varchar(120) DEFAULT NULL,
  `amount` decimal(16,4) NOT NULL,
  `description` varchar(190) DEFAULT NULL,
  `department_id` int(10) unsigned DEFAULT NULL,
  `customer_id` int(10) unsigned DEFAULT NULL,
  `supplier_id` int(10) unsigned DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `ix_jline_batch` (`batch_id`,`line_number`),
  KEY `ix_jline_account` (`account_id`,`id`),
  KEY `ix_jline_dept` (`department_id`),
  KEY `ix_jline_customer` (`customer_id`),
  KEY `ix_jline_supplier` (`supplier_id`),
  CONSTRAINT `journal_lines_ibfk_1` FOREIGN KEY (`account_id`) REFERENCES `gl_accounts` (`id`),
  CONSTRAINT `journal_lines_ibfk_2` FOREIGN KEY (`batch_id`) REFERENCES `journal_batches` (`id`) ON DELETE CASCADE,
  CONSTRAINT `journal_lines_ibfk_3` FOREIGN KEY (`department_id`) REFERENCES `departments` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=140 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `journal_lines`
--

LOCK TABLES `journal_lines` WRITE;
/*!40000 ALTER TABLE `journal_lines` DISABLE KEYS */;
INSERT INTO `journal_lines` VALUES (1,1,1,1,'1000','Bank and cash',59.8000,'Received',NULL,NULL,NULL,'2026-08-09 09:50:14'),(2,1,2,18,'4000','Sales',-27.0000,'Revenue',15,NULL,NULL,'2026-08-09 09:50:14'),(3,1,3,18,'4000','Sales',-15.0000,'Revenue',11,NULL,NULL,'2026-08-09 09:50:14'),(4,1,4,18,'4000','Sales',-10.0000,'Revenue',12,NULL,NULL,'2026-08-09 09:50:14'),(5,1,5,11,'2100','VAT output',-7.8000,'VAT on sales',NULL,NULL,NULL,'2026-08-09 09:50:14'),(6,1,6,22,'5000','Cost of sales',123.0000,'Cost of goods sold',NULL,NULL,NULL,'2026-08-09 09:50:14'),(7,1,7,3,'1200','Stock on hand',-123.0000,'Stock out',NULL,NULL,NULL,'2026-08-09 09:50:14'),(8,2,1,2,'1100','Debtors control',317.4000,'On account',NULL,1,NULL,'2026-08-09 10:14:30'),(9,2,2,18,'4000','Sales',-242.0000,'Revenue',11,NULL,NULL,'2026-08-09 10:14:30'),(10,2,3,18,'4000','Sales',-12.0000,'Revenue',13,NULL,NULL,'2026-08-09 10:14:30'),(11,2,4,18,'4000','Sales',-22.0000,'Revenue',16,NULL,NULL,'2026-08-09 10:14:30'),(12,2,5,11,'2100','VAT output',-41.4000,'VAT on sales',NULL,NULL,NULL,'2026-08-09 10:14:30'),(13,2,6,22,'5000','Cost of sales',215.0000,'Cost of goods sold',NULL,NULL,NULL,'2026-08-09 10:14:30'),(14,2,7,3,'1200','Stock on hand',-215.0000,'Stock out',NULL,NULL,NULL,'2026-08-09 10:14:30'),(15,3,1,32,'6070','Fuel',1304.3500,'Expense',NULL,NULL,NULL,'2026-08-10 07:41:07'),(16,3,2,4,'1300','VAT input',195.6500,'VAT on expense',NULL,NULL,NULL,'2026-08-10 07:41:07'),(17,3,3,1,'1000','Bank and cash',-1500.0000,'Paid',NULL,NULL,NULL,'2026-08-10 07:41:07'),(18,4,1,2,'1100','Debtors control',149.5000,'On account',NULL,1,NULL,'2026-08-11 13:46:45'),(19,4,2,18,'4000','Sales',-10.0000,'Revenue',15,NULL,NULL,'2026-08-11 13:46:45'),(20,4,3,18,'4000','Sales',-10.0000,'Revenue',13,NULL,NULL,'2026-08-11 13:46:45'),(21,4,4,18,'4000','Sales',-10.0000,'Revenue',11,NULL,NULL,'2026-08-11 13:46:45'),(22,4,5,18,'4000','Sales',-100.0000,'Revenue',12,NULL,NULL,'2026-08-11 13:46:45'),(23,4,6,11,'2100','VAT output',-19.5000,'VAT on sales',NULL,NULL,NULL,'2026-08-11 13:46:45'),(24,4,7,22,'5000','Cost of sales',141.0000,'Cost of goods sold',NULL,NULL,NULL,'2026-08-11 13:46:45'),(25,4,8,3,'1200','Stock on hand',-141.0000,'Stock out',NULL,NULL,NULL,'2026-08-11 13:46:45'),(26,5,1,1,'1000','Bank and cash',500.0000,'Received',NULL,NULL,NULL,'2026-08-11 13:49:00'),(27,5,2,1,'1000','Bank and cash',274.0000,'Received',NULL,NULL,NULL,'2026-08-11 13:49:00'),(28,5,3,18,'4000','Sales',-575.6600,'Revenue',13,NULL,NULL,'2026-08-11 13:49:00'),(29,5,4,18,'4000','Sales',-97.4000,'Revenue',15,NULL,NULL,'2026-08-11 13:49:00'),(30,5,5,11,'2100','VAT output',-100.9400,'VAT on sales',NULL,NULL,NULL,'2026-08-11 13:49:00'),(31,5,6,22,'5000','Cost of sales',318.0000,'Cost of goods sold',NULL,NULL,NULL,'2026-08-11 13:49:00'),(32,5,7,3,'1200','Stock on hand',-318.0000,'Stock out',NULL,NULL,NULL,'2026-08-11 13:49:00'),(33,6,1,3,'1200','Stock on hand',400.0000,'Stock in',NULL,NULL,NULL,'2026-08-12 10:54:37'),(34,6,2,4,'1300','VAT input',60.0000,'VAT on purchases',NULL,NULL,NULL,'2026-08-12 10:54:37'),(35,6,3,10,'2000','Creditors control',-460.0000,'Owed to supplier',NULL,NULL,4,'2026-08-12 10:54:37'),(36,7,1,3,'1200','Stock on hand',600.0000,'Stock in',NULL,NULL,NULL,'2026-08-12 10:54:37'),(37,7,2,4,'1300','VAT input',90.0000,'VAT on purchases',NULL,NULL,NULL,'2026-08-12 10:54:37'),(38,7,3,10,'2000','Creditors control',-690.0000,'Owed to supplier',NULL,NULL,4,'2026-08-12 10:54:37'),(39,8,1,3,'1200','Stock on hand',1000.0000,'Stock in',NULL,NULL,NULL,'2026-08-12 10:54:45'),(40,8,2,4,'1300','VAT input',150.0000,'VAT on purchases',NULL,NULL,NULL,'2026-08-12 10:54:45'),(41,8,3,10,'2000','Creditors control',-1150.0000,'Owed to supplier',NULL,NULL,5,'2026-08-12 10:54:45'),(42,9,1,3,'1200','Stock on hand',2000.0000,'Stock in',NULL,NULL,NULL,'2026-08-12 10:54:45'),(43,9,2,4,'1300','VAT input',300.0000,'VAT on purchases',NULL,NULL,NULL,'2026-08-12 10:54:45'),(44,9,3,10,'2000','Creditors control',-2300.0000,'Owed to supplier',NULL,NULL,5,'2026-08-12 10:54:45'),(45,10,1,3,'1200','Stock on hand',1000.0000,'Stock in',NULL,NULL,NULL,'2026-08-12 10:54:46'),(46,10,2,4,'1300','VAT input',150.0000,'VAT on purchases',NULL,NULL,NULL,'2026-08-12 10:54:46'),(47,10,3,10,'2000','Creditors control',-1150.0000,'Owed to supplier',NULL,NULL,5,'2026-08-12 10:54:46'),(48,11,1,3,'1200','Stock on hand',1000.0000,'Stock in',NULL,NULL,NULL,'2026-08-12 10:54:46'),(49,11,2,4,'1300','VAT input',150.0000,'VAT on purchases',NULL,NULL,NULL,'2026-08-12 10:54:46'),(50,11,3,10,'2000','Creditors control',-1150.0000,'Owed to supplier',NULL,NULL,5,'2026-08-12 10:54:46'),(51,12,1,3,'1200','Stock on hand',1000.0000,'Stock in',NULL,NULL,NULL,'2026-08-12 10:55:01'),(52,12,2,4,'1300','VAT input',150.0000,'VAT on purchases',NULL,NULL,NULL,'2026-08-12 10:55:01'),(53,12,3,10,'2000','Creditors control',-1150.0000,'Owed to supplier',NULL,NULL,6,'2026-08-12 10:55:01'),(54,13,1,3,'1200','Stock on hand',2000.0000,'Stock in',NULL,NULL,NULL,'2026-08-12 10:55:01'),(55,13,2,4,'1300','VAT input',300.0000,'VAT on purchases',NULL,NULL,NULL,'2026-08-12 10:55:01'),(56,13,3,10,'2000','Creditors control',-2300.0000,'Owed to supplier',NULL,NULL,6,'2026-08-12 10:55:01'),(57,14,1,3,'1200','Stock on hand',1000.0000,'Stock in',NULL,NULL,NULL,'2026-08-12 10:55:01'),(58,14,2,4,'1300','VAT input',150.0000,'VAT on purchases',NULL,NULL,NULL,'2026-08-12 10:55:01'),(59,14,3,10,'2000','Creditors control',-1150.0000,'Owed to supplier',NULL,NULL,6,'2026-08-12 10:55:01'),(60,15,1,3,'1200','Stock on hand',1000.0000,'Stock in',NULL,NULL,NULL,'2026-08-12 10:55:01'),(61,15,2,4,'1300','VAT input',150.0000,'VAT on purchases',NULL,NULL,NULL,'2026-08-12 10:55:01'),(62,15,3,10,'2000','Creditors control',-1150.0000,'Owed to supplier',NULL,NULL,6,'2026-08-12 10:55:01'),(63,16,1,3,'1200','Stock on hand',1000.0000,'Stock in',NULL,NULL,NULL,'2026-08-12 10:55:43'),(64,16,2,4,'1300','VAT input',150.0000,'VAT on purchases',NULL,NULL,NULL,'2026-08-12 10:55:43'),(65,16,3,10,'2000','Creditors control',-1150.0000,'Owed to supplier',NULL,NULL,7,'2026-08-12 10:55:43'),(66,17,1,3,'1200','Stock on hand',300.0000,'Stock in',NULL,NULL,NULL,'2026-08-12 10:55:49'),(67,17,2,4,'1300','VAT input',45.0000,'VAT on purchases',NULL,NULL,NULL,'2026-08-12 10:55:49'),(68,17,3,10,'2000','Creditors control',-345.0000,'Owed to supplier',NULL,NULL,8,'2026-08-12 10:55:49'),(69,18,1,3,'1200','Stock on hand',1000.0000,'Stock in',NULL,NULL,NULL,'2026-08-12 10:55:50'),(70,18,2,4,'1300','VAT input',150.0000,'VAT on purchases',NULL,NULL,NULL,'2026-08-12 10:55:50'),(71,18,3,10,'2000','Creditors control',-1150.0000,'Owed to supplier',NULL,NULL,9,'2026-08-12 10:55:50'),(72,19,1,3,'1200','Stock on hand',1000.0000,'Stock in',NULL,NULL,NULL,'2026-08-12 10:55:50'),(73,19,2,4,'1300','VAT input',150.0000,'VAT on purchases',NULL,NULL,NULL,'2026-08-12 10:55:50'),(74,19,3,10,'2000','Creditors control',-1150.0000,'Owed to supplier',NULL,NULL,9,'2026-08-12 10:55:50'),(75,20,1,3,'1200','Stock on hand',1000.0000,'Stock in',NULL,NULL,NULL,'2026-08-12 10:55:50'),(76,20,2,4,'1300','VAT input',150.0000,'VAT on purchases',NULL,NULL,NULL,'2026-08-12 10:55:50'),(77,20,3,10,'2000','Creditors control',-1150.0000,'Owed to supplier',NULL,NULL,9,'2026-08-12 10:55:50'),(78,21,1,3,'1200','Stock on hand',10.0000,'Stock in',NULL,NULL,NULL,'2026-08-12 10:55:50'),(79,21,2,4,'1300','VAT input',1.5000,'VAT on purchases',NULL,NULL,NULL,'2026-08-12 10:55:50'),(80,21,3,10,'2000','Creditors control',-11.5000,'Owed to supplier',NULL,NULL,9,'2026-08-12 10:55:50'),(81,22,1,3,'1200','Stock on hand',1000.0000,'Stock in',NULL,NULL,NULL,'2026-08-12 10:55:51'),(82,22,2,4,'1300','VAT input',150.0000,'VAT on purchases',NULL,NULL,NULL,'2026-08-12 10:55:51'),(83,22,3,10,'2000','Creditors control',-1150.0000,'Owed to supplier',NULL,NULL,9,'2026-08-12 10:55:51'),(84,22,4,24,'5200','Freight in',200.0000,'Freight in',NULL,NULL,NULL,'2026-08-12 10:55:51'),(85,22,5,4,'1300','VAT input',30.0000,'VAT on freight',NULL,NULL,NULL,'2026-08-12 10:55:51'),(86,22,6,10,'2000','Creditors control',-230.0000,'Owed to carrier',NULL,NULL,10,'2026-08-12 10:55:51'),(87,23,1,3,'1200','Stock on hand',1000.0000,'Stock in',NULL,NULL,NULL,'2026-08-12 10:55:51'),(88,23,2,4,'1300','VAT input',150.0000,'VAT on purchases',NULL,NULL,NULL,'2026-08-12 10:55:51'),(89,23,3,10,'2000','Creditors control',-1150.0000,'Owed to supplier',NULL,NULL,9,'2026-08-12 10:55:51'),(90,24,1,3,'1200','Stock on hand',120.0000,'Stock in',NULL,NULL,NULL,'2026-08-24 12:49:22'),(91,24,2,4,'1300','VAT input',18.0000,'VAT on purchases',NULL,NULL,NULL,'2026-08-24 12:49:22'),(92,24,3,10,'2000','Creditors control',-138.0000,'Owed to supplier',NULL,NULL,7,'2026-08-24 12:49:22'),(93,25,1,1,'1000','Bank and cash',20.0000,'Received',NULL,NULL,NULL,'2026-08-24 12:50:09'),(94,25,2,18,'4000','Sales',-17.3900,'Revenue',NULL,NULL,NULL,'2026-08-24 12:50:09'),(95,25,3,11,'2100','VAT output',-2.6100,'VAT on sales',NULL,NULL,NULL,'2026-08-24 12:50:09'),(96,25,4,22,'5000','Cost of sales',12.0000,'Cost of goods sold',NULL,NULL,NULL,'2026-08-24 12:50:09'),(97,25,5,3,'1200','Stock on hand',-12.0000,'Stock out',NULL,NULL,NULL,'2026-08-24 12:50:09'),(98,26,1,3,'1200','Stock on hand',360.0000,'Stock written on',NULL,NULL,NULL,'2026-08-24 13:08:53'),(99,26,2,23,'5100','Stock adjustments',-360.0000,'Stock surplus',NULL,NULL,NULL,'2026-08-24 13:08:53'),(100,27,1,1,'1000','Bank and cash',139.0000,'Received',NULL,NULL,NULL,'2026-08-25 19:18:39'),(101,27,2,18,'4000','Sales',-120.8700,'Revenue',13,NULL,NULL,'2026-08-25 19:18:39'),(102,27,3,11,'2100','VAT output',-18.1300,'VAT on sales',NULL,NULL,NULL,'2026-08-25 19:18:39'),(103,27,4,22,'5000','Cost of sales',51.0000,'Cost of goods sold',NULL,NULL,NULL,'2026-08-25 19:18:39'),(104,27,5,3,'1200','Stock on hand',-51.0000,'Stock out',NULL,NULL,NULL,'2026-08-25 19:18:39'),(105,28,1,1,'1000','Bank and cash',139.0000,'Received',NULL,NULL,NULL,'2026-08-25 19:19:45'),(106,28,2,18,'4000','Sales',-120.8700,'Revenue',13,NULL,NULL,'2026-08-25 19:19:45'),(107,28,3,11,'2100','VAT output',-18.1300,'VAT on sales',NULL,NULL,NULL,'2026-08-25 19:19:45'),(108,28,4,22,'5000','Cost of sales',51.0000,'Cost of goods sold',NULL,NULL,NULL,'2026-08-25 19:19:45'),(109,28,5,3,'1200','Stock on hand',-51.0000,'Stock out',NULL,NULL,NULL,'2026-08-25 19:19:45'),(110,29,1,1,'1000','Bank and cash',500.0000,'Received',NULL,NULL,NULL,'2026-08-26 15:23:34'),(111,29,2,50,'2500','Gift card liability',-500.0000,'Gift cards sold',NULL,NULL,NULL,'2026-08-26 15:23:34'),(112,30,1,1,'1000','Bank and cash',119.0000,'Received',NULL,NULL,NULL,'2026-08-26 15:33:03'),(113,30,2,18,'4000','Sales',-103.4800,'Revenue',12,NULL,NULL,'2026-08-26 15:33:03'),(114,30,3,11,'2100','VAT output',-15.5200,'VAT on sales',NULL,NULL,NULL,'2026-08-26 15:33:03'),(115,30,4,22,'5000','Cost of sales',42.0000,'Cost of goods sold',NULL,NULL,NULL,'2026-08-26 15:33:03'),(116,30,5,3,'1200','Stock on hand',-42.0000,'Stock out',NULL,NULL,NULL,'2026-08-26 15:33:03'),(117,31,1,1,'1000','Bank and cash',28.0000,'Received',NULL,NULL,NULL,'2026-08-26 15:34:12'),(118,31,2,18,'4000','Sales',-24.3500,'Revenue',15,NULL,NULL,'2026-08-26 15:34:12'),(119,31,3,11,'2100','VAT output',-3.6500,'VAT on sales',NULL,NULL,NULL,'2026-08-26 15:34:12'),(120,31,4,22,'5000','Cost of sales',12.0000,'Cost of goods sold',NULL,NULL,NULL,'2026-08-26 15:34:12'),(121,31,5,3,'1200','Stock on hand',-12.0000,'Stock out',NULL,NULL,NULL,'2026-08-26 15:34:12'),(122,32,1,50,'2500','Gift card liability',119.0000,'Received',NULL,NULL,NULL,'2026-08-26 15:39:13'),(123,32,2,18,'4000','Sales',-103.4800,'Revenue',12,NULL,NULL,'2026-08-26 15:39:13'),(124,32,3,11,'2100','VAT output',-15.5200,'VAT on sales',NULL,NULL,NULL,'2026-08-26 15:39:13'),(125,32,4,22,'5000','Cost of sales',42.0000,'Cost of goods sold',NULL,NULL,NULL,'2026-08-26 15:39:13'),(126,32,5,3,'1200','Stock on hand',-42.0000,'Stock out',NULL,NULL,NULL,'2026-08-26 15:39:13'),(127,33,1,3,'1200','Stock on hand',1200.0000,'Stock written on',NULL,NULL,NULL,'2026-08-26 16:03:10'),(128,33,2,23,'5100','Stock adjustments',-1200.0000,'Stock surplus',NULL,NULL,NULL,'2026-08-26 16:03:10'),(129,34,1,3,'1200','Stock on hand',6000.0000,'Stock written on',NULL,NULL,NULL,'2026-08-26 16:19:05'),(130,34,2,23,'5100','Stock adjustments',-6000.0000,'Stock surplus',NULL,NULL,NULL,'2026-08-26 16:19:05'),(131,35,1,3,'1200','Stock on hand',17420.0000,'Stock found',NULL,NULL,NULL,'2026-08-26 16:47:38'),(132,35,2,23,'5100','Stock adjustments',-17420.0000,'Stock surplus',NULL,NULL,NULL,'2026-08-26 16:47:38'),(133,36,1,3,'1200','Stock on hand',-616.6000,'Stock written off',NULL,NULL,NULL,'2026-08-26 16:51:23'),(134,36,2,23,'5100','Stock adjustments',616.6000,'Stock shortfall',NULL,NULL,NULL,'2026-08-26 16:51:23'),(135,37,1,1,'1000','Bank and cash',20.0000,'Received',NULL,NULL,NULL,'2026-08-31 10:55:39'),(136,37,2,18,'4000','Sales',-17.4000,'Revenue',14,NULL,NULL,'2026-08-31 10:55:39'),(137,37,3,11,'2100','VAT output',-2.6000,'VAT on sales',NULL,NULL,NULL,'2026-08-31 10:55:39'),(138,37,4,22,'5000','Cost of sales',36.0000,'Cost of goods sold',NULL,NULL,NULL,'2026-08-31 10:55:39'),(139,37,5,3,'1200','Stock on hand',-36.0000,'Stock out',NULL,NULL,NULL,'2026-08-31 10:55:39');
/*!40000 ALTER TABLE `journal_lines` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `kitchen_printers`
--

DROP TABLE IF EXISTS `kitchen_printers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `kitchen_printers` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(60) NOT NULL,
  `sort_order` int(11) NOT NULL DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_kitchen_printer_name` (`name`),
  KEY `ix_kitchen_printer_active` (`is_active`,`sort_order`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `kitchen_printers`
--

LOCK TABLES `kitchen_printers` WRITE;
/*!40000 ALTER TABLE `kitchen_printers` DISABLE KEYS */;
/*!40000 ALTER TABLE `kitchen_printers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `kitchen_send_lines`
--

DROP TABLE IF EXISTS `kitchen_send_lines`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `kitchen_send_lines` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `send_id` int(10) unsigned NOT NULL,
  `line_id` int(10) unsigned NOT NULL,
  `qty` decimal(12,3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_ksl_line` (`line_id`),
  KEY `fk_ksl_send` (`send_id`),
  CONSTRAINT `kitchen_send_lines_ibfk_1` FOREIGN KEY (`line_id`) REFERENCES `sales_document_lines` (`id`) ON DELETE CASCADE,
  CONSTRAINT `kitchen_send_lines_ibfk_2` FOREIGN KEY (`send_id`) REFERENCES `kitchen_sends` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `kitchen_send_lines`
--

LOCK TABLES `kitchen_send_lines` WRITE;
/*!40000 ALTER TABLE `kitchen_send_lines` DISABLE KEYS */;
/*!40000 ALTER TABLE `kitchen_send_lines` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `kitchen_sends`
--

DROP TABLE IF EXISTS `kitchen_sends`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `kitchen_sends` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `document_id` int(10) unsigned NOT NULL,
  `printer_id` int(10) unsigned NOT NULL,
  `terminal_id` int(10) unsigned DEFAULT NULL,
  `sent_by` int(10) unsigned DEFAULT NULL,
  `sent_by_name` varchar(120) NOT NULL DEFAULT '',
  `source` varchar(16) NOT NULL DEFAULT 'auto',
  `sent_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `ix_kitchen_sends_doc` (`document_id`,`printer_id`),
  KEY `fk_ks_printer` (`printer_id`),
  CONSTRAINT `kitchen_sends_ibfk_1` FOREIGN KEY (`document_id`) REFERENCES `sales_documents` (`id`) ON DELETE CASCADE,
  CONSTRAINT `kitchen_sends_ibfk_2` FOREIGN KEY (`printer_id`) REFERENCES `kitchen_printers` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `kitchen_sends`
--

LOCK TABLES `kitchen_sends` WRITE;
/*!40000 ALTER TABLE `kitchen_sends` DISABLE KEYS */;
/*!40000 ALTER TABLE `kitchen_sends` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `layby_lines`
--

DROP TABLE IF EXISTS `layby_lines`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `layby_lines` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `layby_id` int(10) unsigned NOT NULL,
  `line_number` smallint(5) unsigned NOT NULL DEFAULT 1,
  `product_id` int(10) unsigned DEFAULT NULL,
  `product_code` varchar(48) DEFAULT NULL,
  `description` varchar(190) NOT NULL,
  `product_type` varchar(24) NOT NULL DEFAULT 'normal',
  `department_id` int(10) unsigned DEFAULT NULL,
  `qty` decimal(12,3) NOT NULL DEFAULT 1.000,
  `unit_price_incl` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `discount_pct` decimal(6,3) NOT NULL DEFAULT 0.000,
  `discount_incl` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `vat_rate_pct` decimal(6,3) NOT NULL DEFAULT 0.000,
  `line_total_incl` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `line_total_excl` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `line_vat` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `unit_cost_excl` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `ix_layby_line_layby` (`layby_id`),
  KEY `ix_layby_line_product` (`product_id`),
  CONSTRAINT `layby_lines_ibfk_1` FOREIGN KEY (`layby_id`) REFERENCES `laybys` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `layby_lines`
--

LOCK TABLES `layby_lines` WRITE;
/*!40000 ALTER TABLE `layby_lines` DISABLE KEYS */;
/*!40000 ALTER TABLE `layby_lines` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `layby_payments`
--

DROP TABLE IF EXISTS `layby_payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `layby_payments` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `layby_id` int(10) unsigned NOT NULL,
  `kind` enum('deposit','instalment','refund','forfeit') NOT NULL DEFAULT 'instalment',
  `amount` decimal(12,4) NOT NULL,
  `tender_type_id` int(10) unsigned DEFAULT NULL,
  `tender_name` varchar(60) NOT NULL DEFAULT '',
  `reference` varchar(120) DEFAULT NULL,
  `paid_on` date NOT NULL,
  `terminal_id` int(10) unsigned DEFAULT NULL,
  `shift_id` int(10) unsigned DEFAULT NULL,
  `user_id` int(10) unsigned DEFAULT NULL,
  `user_name` varchar(120) NOT NULL DEFAULT '',
  `note` varchar(190) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `ix_layby_pay_layby` (`layby_id`,`paid_on`),
  KEY `ix_layby_pay_shift` (`shift_id`),
  CONSTRAINT `layby_payments_ibfk_1` FOREIGN KEY (`layby_id`) REFERENCES `laybys` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `layby_payments`
--

LOCK TABLES `layby_payments` WRITE;
/*!40000 ALTER TABLE `layby_payments` DISABLE KEYS */;
/*!40000 ALTER TABLE `layby_payments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `laybys`
--

DROP TABLE IF EXISTS `laybys`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `laybys` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `document_number` varchar(32) DEFAULT NULL,
  `customer_id` int(10) unsigned NOT NULL,
  `status` enum('open','completed','cancelled','expired') NOT NULL DEFAULT 'open',
  `total_incl` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `paid_total` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `due_date` date DEFAULT NULL,
  `reminded_at` datetime DEFAULT NULL,
  `invoice_doc_id` int(10) unsigned DEFAULT NULL,
  `completed_at` datetime DEFAULT NULL,
  `cancelled_at` datetime DEFAULT NULL,
  `cancel_reason` varchar(190) DEFAULT NULL,
  `cancellation_fee` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `cancellation_fee_pct` decimal(6,3) NOT NULL DEFAULT 0.000,
  `fee_waived_reason` varchar(190) DEFAULT NULL,
  `terminal_id` int(10) unsigned DEFAULT NULL,
  `user_id` int(10) unsigned DEFAULT NULL,
  `user_name` varchar(120) NOT NULL DEFAULT '',
  `note` varchar(400) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_layby_number` (`document_number`),
  KEY `ix_layby_customer` (`customer_id`,`status`),
  KEY `ix_layby_status` (`status`,`due_date`),
  KEY `fk_layby_invoice` (`invoice_doc_id`),
  CONSTRAINT `laybys_ibfk_1` FOREIGN KEY (`invoice_doc_id`) REFERENCES `sales_documents` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `laybys`
--

LOCK TABLES `laybys` WRITE;
/*!40000 ALTER TABLE `laybys` DISABLE KEYS */;
/*!40000 ALTER TABLE `laybys` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `leave_ledger`
--

DROP TABLE IF EXISTS `leave_ledger`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `leave_ledger` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `leave_type_id` int(10) unsigned NOT NULL,
  `entry_date` date NOT NULL,
  `days` decimal(6,2) NOT NULL,
  `source` enum('accrual','taken','adjustment','opening','forfeit','payout') NOT NULL,
  `request_id` int(10) unsigned DEFAULT NULL,
  `note` varchar(400) DEFAULT NULL,
  `created_by_user_id` int(10) unsigned DEFAULT NULL,
  `created_by_name` varchar(120) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_leave_accrual` (`user_id`,`leave_type_id`,`entry_date`,`source`),
  KEY `ix_leave_ledger_balance` (`user_id`,`leave_type_id`,`entry_date`),
  KEY `ix_leave_ledger_request` (`request_id`),
  KEY `fk_leave_ledger_type` (`leave_type_id`),
  CONSTRAINT `leave_ledger_ibfk_1` FOREIGN KEY (`request_id`) REFERENCES `leave_requests` (`id`) ON DELETE SET NULL,
  CONSTRAINT `leave_ledger_ibfk_2` FOREIGN KEY (`leave_type_id`) REFERENCES `leave_types` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `leave_ledger`
--

LOCK TABLES `leave_ledger` WRITE;
/*!40000 ALTER TABLE `leave_ledger` DISABLE KEYS */;
INSERT INTO `leave_ledger` VALUES (1,1,1,'2026-08-24',-2.00,'taken',1,'Annual leave 2026-08-24 to 2026-08-25',1,'Tiaan Smith','2026-08-24 13:22:00'),(2,1,1,'2026-08-24',3.75,'accrual',NULL,'Accrued to 2026-08-24',1,'Tiaan Smith','2026-08-24 13:22:11'),(3,1,2,'2026-08-24',30.00,'accrual',NULL,'Accrued to 2026-08-24',1,'Tiaan Smith','2026-08-24 13:22:11'),(4,1,3,'2026-08-24',3.00,'accrual',NULL,'Accrued to 2026-08-24',1,'Tiaan Smith','2026-08-24 13:22:11');
/*!40000 ALTER TABLE `leave_ledger` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `leave_requests`
--

DROP TABLE IF EXISTS `leave_requests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `leave_requests` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `user_name` varchar(120) NOT NULL DEFAULT '',
  `leave_type_id` int(10) unsigned NOT NULL,
  `leave_type_name` varchar(60) NOT NULL DEFAULT '',
  `period_from` date NOT NULL,
  `period_to` date NOT NULL,
  `days` decimal(6,2) NOT NULL DEFAULT 0.00,
  `is_half_day` tinyint(1) NOT NULL DEFAULT 0,
  `status` enum('requested','approved','declined','cancelled') NOT NULL DEFAULT 'requested',
  `reason` varchar(400) DEFAULT NULL,
  `decided_by_user_id` int(10) unsigned DEFAULT NULL,
  `decided_by_name` varchar(120) DEFAULT NULL,
  `decided_at` datetime DEFAULT NULL,
  `decided_note` varchar(400) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `ix_leave_req_user` (`user_id`,`period_from`),
  KEY `ix_leave_req_status` (`status`,`period_from`),
  KEY `fk_leave_req_type` (`leave_type_id`),
  CONSTRAINT `leave_requests_ibfk_1` FOREIGN KEY (`leave_type_id`) REFERENCES `leave_types` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `leave_requests`
--

LOCK TABLES `leave_requests` WRITE;
/*!40000 ALTER TABLE `leave_requests` DISABLE KEYS */;
INSERT INTO `leave_requests` VALUES (1,1,'Tiaan Smith',1,'Annual leave','2026-08-24','2026-08-25',2.00,0,'approved','test',1,'Tiaan Smith','2026-08-24 13:22:00',NULL,'2026-08-24 13:21:49','2026-08-24 13:22:00');
/*!40000 ALTER TABLE `leave_requests` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `leave_types`
--

DROP TABLE IF EXISTS `leave_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `leave_types` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(60) NOT NULL,
  `code` varchar(24) NOT NULL,
  `is_paid` tinyint(1) NOT NULL DEFAULT 1,
  `accrual_method` enum('none','monthly','annual_grant','cycle_36m') NOT NULL DEFAULT 'none',
  `accrual_days` decimal(6,3) NOT NULL DEFAULT 0.000,
  `cycle_months` int(10) unsigned NOT NULL DEFAULT 12,
  `max_balance_days` decimal(6,2) DEFAULT NULL,
  `is_system` tinyint(1) NOT NULL DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `sort_order` int(11) NOT NULL DEFAULT 0,
  `notes` varchar(400) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_leave_type_code` (`code`),
  KEY `ix_leave_type_active` (`is_active`,`sort_order`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `leave_types`
--

LOCK TABLES `leave_types` WRITE;
/*!40000 ALTER TABLE `leave_types` DISABLE KEYS */;
INSERT INTO `leave_types` VALUES (1,'Annual leave','ANNUAL',1,'monthly',1.250,12,NULL,1,1,10,'BCEA s20 — 21 consecutive days per cycle. 1.25 days a month on a five-day week; raise to 1.75 on six.','2026-08-07 06:43:27','2026-08-07 06:43:27'),(2,'Sick leave','SICK',1,'cycle_36m',30.000,36,NULL,1,1,20,'BCEA s22 — six weeks\' worth per 36-month cycle. 30 days on a five-day week.','2026-08-07 06:43:27','2026-08-07 06:43:27'),(3,'Family responsibility','FAMILY',1,'annual_grant',3.000,12,NULL,1,1,30,'BCEA s27 — 3 days a year, after four months\' employment.','2026-08-07 06:43:27','2026-08-07 06:43:27'),(4,'Maternity leave','MATERNITY',0,'none',0.000,12,NULL,1,1,40,'BCEA s25 — four consecutive months. Unpaid by the employer; UIF pays.','2026-08-07 06:43:27','2026-08-07 06:43:27'),(5,'Unpaid leave','UNPAID',0,'none',0.000,12,NULL,1,1,50,'No entitlement accrues. Used once paid leave is exhausted.','2026-08-07 06:43:27','2026-08-07 06:43:27');
/*!40000 ALTER TABLE `leave_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `licence_lease`
--

DROP TABLE IF EXISTS `licence_lease`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `licence_lease` (
  `id` tinyint(3) unsigned NOT NULL DEFAULT 1,
  `site_id` int(11) NOT NULL,
  `device_serial` varchar(190) DEFAULT NULL,
  `licence_status` varchar(32) NOT NULL,
  `modules_json` text NOT NULL,
  `ending_on_json` text DEFAULT NULL,
  `account_status` varchar(32) DEFAULT NULL,
  `checked_at` datetime NOT NULL,
  `expires_at` datetime NOT NULL,
  `unlock_secret_enc` text DEFAULT NULL,
  `unlock_counter` int(11) NOT NULL DEFAULT 0,
  `last_unlock_at` datetime DEFAULT NULL,
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  CONSTRAINT `CONSTRAINT_1` CHECK (`id` = 1)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `licence_lease`
--

LOCK TABLES `licence_lease` WRITE;
/*!40000 ALTER TABLE `licence_lease` DISABLE KEYS */;
INSERT INTO `licence_lease` VALUES (1,1,NULL,'licensed','[\"accounting\",\"customers\",\"inventory_advanced\",\"job_cards\",\"loyalty\",\"multi_branch\",\"online_store\",\"starter\"]','{}','active','2026-08-26 15:44:59','2026-09-02 15:44:59',NULL,0,NULL,'2026-08-26 17:44:59');
/*!40000 ALTER TABLE `licence_lease` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `list_columns`
--

DROP TABLE IF EXISTS `list_columns`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `list_columns` (
  `list_key` varchar(60) NOT NULL,
  `columns` text NOT NULL,
  `updated_by` int(10) unsigned DEFAULT NULL,
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`list_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `list_columns`
--

LOCK TABLES `list_columns` WRITE;
/*!40000 ALTER TABLE `list_columns` DISABLE KEYS */;
/*!40000 ALTER TABLE `list_columns` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `list_filters`
--

DROP TABLE IF EXISTS `list_filters`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `list_filters` (
  `list_key` varchar(60) NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `filters` text NOT NULL,
  `expires_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`list_key`,`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `list_filters`
--

LOCK TABLES `list_filters` WRITE;
/*!40000 ALTER TABLE `list_filters` DISABLE KEYS */;
/*!40000 ALTER TABLE `list_filters` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `loyalty_card_items`
--

DROP TABLE IF EXISTS `loyalty_card_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `loyalty_card_items` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `card_id` int(10) unsigned NOT NULL,
  `product_id` int(10) unsigned DEFAULT NULL,
  `department_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_card_product` (`card_id`,`product_id`),
  UNIQUE KEY `uq_card_department` (`card_id`,`department_id`),
  KEY `idx_card_item_card` (`card_id`),
  KEY `fk_card_item_product` (`product_id`),
  KEY `fk_card_item_department` (`department_id`),
  CONSTRAINT `loyalty_card_items_ibfk_1` FOREIGN KEY (`card_id`) REFERENCES `loyalty_cards` (`id`) ON DELETE CASCADE,
  CONSTRAINT `loyalty_card_items_ibfk_2` FOREIGN KEY (`department_id`) REFERENCES `departments` (`id`) ON DELETE CASCADE,
  CONSTRAINT `loyalty_card_items_ibfk_3` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  CONSTRAINT `CONSTRAINT_1` CHECK (`product_id` is not null and `department_id` is null or `product_id` is null and `department_id` is not null)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `loyalty_card_items`
--

LOCK TABLES `loyalty_card_items` WRITE;
/*!40000 ALTER TABLE `loyalty_card_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `loyalty_card_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `loyalty_cards`
--

DROP TABLE IF EXISTS `loyalty_cards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `loyalty_cards` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `required_stamps` smallint(5) unsigned NOT NULL DEFAULT 10,
  `reward_type` enum('free_item','value','points') NOT NULL DEFAULT 'free_item',
  `reward_product_id` int(10) unsigned DEFAULT NULL,
  `reward_value` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `one_stamp_per_sale` tinyint(1) NOT NULL DEFAULT 1,
  `min_line_amount` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `voucher_valid_days` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starts_on` date DEFAULT NULL,
  `ends_on` date DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_card_active` (`is_active`),
  KEY `fk_loyalty_card_product` (`reward_product_id`),
  CONSTRAINT `loyalty_cards_ibfk_1` FOREIGN KEY (`reward_product_id`) REFERENCES `products` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `loyalty_cards`
--

LOCK TABLES `loyalty_cards` WRITE;
/*!40000 ALTER TABLE `loyalty_cards` DISABLE KEYS */;
/*!40000 ALTER TABLE `loyalty_cards` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `loyalty_ledger`
--

DROP TABLE IF EXISTS `loyalty_ledger`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `loyalty_ledger` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `customer_id` int(10) unsigned NOT NULL,
  `entry_type` enum('earn','redeem','expire','adjust','reverse') NOT NULL,
  `points` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `basis_amount` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `document_id` int(10) unsigned DEFAULT NULL,
  `document_number` varchar(40) NOT NULL DEFAULT '',
  `origin_site_id` int(10) unsigned DEFAULT NULL,
  `tier_name` varchar(40) NOT NULL DEFAULT '',
  `multiplier` decimal(6,3) NOT NULL DEFAULT 1.000,
  `note` varchar(255) NOT NULL DEFAULT '',
  `user_id` int(10) unsigned DEFAULT NULL,
  `user_name` varchar(120) NOT NULL DEFAULT '',
  `created_at` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_ledger_document_earn` (`origin_site_id`,`document_id`,`entry_type`),
  KEY `idx_ledger_customer` (`customer_id`,`created_at`),
  KEY `idx_ledger_document` (`document_id`),
  KEY `idx_ledger_type_date` (`entry_type`,`created_at`),
  CONSTRAINT `loyalty_ledger_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE CASCADE,
  CONSTRAINT `loyalty_ledger_ibfk_2` FOREIGN KEY (`document_id`) REFERENCES `sales_documents` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `loyalty_ledger`
--

LOCK TABLES `loyalty_ledger` WRITE;
/*!40000 ALTER TABLE `loyalty_ledger` DISABLE KEYS */;
/*!40000 ALTER TABLE `loyalty_ledger` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `loyalty_members`
--

DROP TABLE IF EXISTS `loyalty_members`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `loyalty_members` (
  `customer_id` int(10) unsigned NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `points_balance` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `wallet_balance` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `tier_id` int(10) unsigned DEFAULT NULL,
  `tier_since` datetime DEFAULT NULL,
  `tier_review_date` date DEFAULT NULL,
  `joined_at` datetime NOT NULL DEFAULT current_timestamp(),
  `last_activity_at` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`customer_id`),
  KEY `idx_member_tier` (`tier_id`),
  KEY `idx_member_activity` (`last_activity_at`),
  CONSTRAINT `loyalty_members_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE CASCADE,
  CONSTRAINT `loyalty_members_ibfk_2` FOREIGN KEY (`tier_id`) REFERENCES `loyalty_tiers` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `loyalty_members`
--

LOCK TABLES `loyalty_members` WRITE;
/*!40000 ALTER TABLE `loyalty_members` DISABLE KEYS */;
/*!40000 ALTER TABLE `loyalty_members` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `loyalty_stamps`
--

DROP TABLE IF EXISTS `loyalty_stamps`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `loyalty_stamps` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `card_id` int(10) unsigned NOT NULL,
  `customer_id` int(10) unsigned NOT NULL,
  `document_id` int(10) unsigned DEFAULT NULL,
  `stamp_seq` smallint(5) unsigned NOT NULL DEFAULT 1,
  `product_id` int(10) unsigned DEFAULT NULL,
  `completed` tinyint(1) NOT NULL DEFAULT 0,
  `voucher_id` bigint(20) unsigned DEFAULT NULL,
  `created_at` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_stamp_sale` (`card_id`,`customer_id`,`document_id`,`stamp_seq`),
  KEY `idx_stamp_customer_card` (`customer_id`,`card_id`,`created_at`),
  KEY `idx_stamp_document` (`document_id`),
  KEY `fk_stamp_voucher` (`voucher_id`),
  CONSTRAINT `loyalty_stamps_ibfk_1` FOREIGN KEY (`card_id`) REFERENCES `loyalty_cards` (`id`) ON DELETE CASCADE,
  CONSTRAINT `loyalty_stamps_ibfk_2` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE CASCADE,
  CONSTRAINT `loyalty_stamps_ibfk_3` FOREIGN KEY (`document_id`) REFERENCES `sales_documents` (`id`) ON DELETE SET NULL,
  CONSTRAINT `loyalty_stamps_ibfk_4` FOREIGN KEY (`voucher_id`) REFERENCES `loyalty_vouchers` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `loyalty_stamps`
--

LOCK TABLES `loyalty_stamps` WRITE;
/*!40000 ALTER TABLE `loyalty_stamps` DISABLE KEYS */;
/*!40000 ALTER TABLE `loyalty_stamps` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `loyalty_tiers`
--

DROP TABLE IF EXISTS `loyalty_tiers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `loyalty_tiers` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(40) NOT NULL,
  `step` smallint(5) unsigned NOT NULL,
  `qualifying_spend` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `multiplier` decimal(6,3) NOT NULL DEFAULT 1.000,
  `discount_pct` decimal(6,3) NOT NULL DEFAULT 0.000,
  `color` varchar(40) NOT NULL DEFAULT '',
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_tier_name` (`name`),
  UNIQUE KEY `uq_tier_step` (`step`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `loyalty_tiers`
--

LOCK TABLES `loyalty_tiers` WRITE;
/*!40000 ALTER TABLE `loyalty_tiers` DISABLE KEYS */;
INSERT INTO `loyalty_tiers` VALUES (1,'Bronze',1,0.0000,1.000,0.000,'muted',1,'2026-08-07 03:41:55','2026-08-07 03:41:55'),(2,'Silver',2,5000.0000,1.250,0.000,'info',1,'2026-08-07 03:41:55','2026-08-07 03:41:55'),(3,'Gold',3,15000.0000,1.500,2.000,'warning',1,'2026-08-07 03:41:55','2026-08-07 03:41:55'),(4,'Platinum',4,40000.0000,2.000,5.000,'brand',1,'2026-08-07 03:41:55','2026-08-07 03:41:55');
/*!40000 ALTER TABLE `loyalty_tiers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `loyalty_vouchers`
--

DROP TABLE IF EXISTS `loyalty_vouchers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `loyalty_vouchers` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(30) NOT NULL,
  `customer_id` int(10) unsigned DEFAULT NULL,
  `reward_type` enum('free_item','value') NOT NULL DEFAULT 'value',
  `reward_product_id` int(10) unsigned DEFAULT NULL,
  `reward_value` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `description` varchar(150) NOT NULL DEFAULT '',
  `status` enum('issued','redeemed','expired','void') NOT NULL DEFAULT 'issued',
  `issued_by` enum('card','manual','birthday','tier') NOT NULL DEFAULT 'manual',
  `card_id` int(10) unsigned DEFAULT NULL,
  `expires_on` date DEFAULT NULL,
  `redeemed_at` datetime(3) DEFAULT NULL,
  `redeemed_doc_id` int(10) unsigned DEFAULT NULL,
  `redeemed_doc_number` varchar(40) NOT NULL DEFAULT '',
  `user_id` int(10) unsigned DEFAULT NULL,
  `user_name` varchar(120) NOT NULL DEFAULT '',
  `created_at` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_voucher_code` (`code`),
  KEY `idx_voucher_customer` (`customer_id`,`status`),
  KEY `idx_voucher_status_expiry` (`status`,`expires_on`),
  KEY `idx_voucher_document` (`redeemed_doc_id`),
  KEY `fk_voucher_card` (`card_id`),
  KEY `fk_voucher_product` (`reward_product_id`),
  CONSTRAINT `loyalty_vouchers_ibfk_1` FOREIGN KEY (`card_id`) REFERENCES `loyalty_cards` (`id`) ON DELETE SET NULL,
  CONSTRAINT `loyalty_vouchers_ibfk_2` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE CASCADE,
  CONSTRAINT `loyalty_vouchers_ibfk_3` FOREIGN KEY (`redeemed_doc_id`) REFERENCES `sales_documents` (`id`) ON DELETE SET NULL,
  CONSTRAINT `loyalty_vouchers_ibfk_4` FOREIGN KEY (`reward_product_id`) REFERENCES `products` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `loyalty_vouchers`
--

LOCK TABLES `loyalty_vouchers` WRITE;
/*!40000 ALTER TABLE `loyalty_vouchers` DISABLE KEYS */;
/*!40000 ALTER TABLE `loyalty_vouchers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `loyalty_wallet`
--

DROP TABLE IF EXISTS `loyalty_wallet`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `loyalty_wallet` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `customer_id` int(10) unsigned NOT NULL,
  `entry_type` enum('topup','spend','refund','adjust') NOT NULL,
  `amount` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `tender_type_id` int(10) unsigned DEFAULT NULL,
  `shift_id` int(10) unsigned DEFAULT NULL,
  `terminal_id` int(10) unsigned DEFAULT NULL,
  `document_id` int(10) unsigned DEFAULT NULL,
  `document_number` varchar(40) NOT NULL DEFAULT '',
  `origin_site_id` int(10) unsigned DEFAULT NULL,
  `note` varchar(255) NOT NULL DEFAULT '',
  `user_id` int(10) unsigned DEFAULT NULL,
  `user_name` varchar(120) NOT NULL DEFAULT '',
  `created_at` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_wallet_document_spend` (`origin_site_id`,`document_id`,`entry_type`),
  KEY `idx_wallet_customer` (`customer_id`,`created_at`),
  KEY `idx_wallet_document` (`document_id`),
  KEY `idx_wallet_shift` (`shift_id`,`entry_type`),
  KEY `idx_wallet_type_date` (`entry_type`,`created_at`),
  KEY `fk_loyalty_wallet_tender` (`tender_type_id`),
  CONSTRAINT `loyalty_wallet_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE CASCADE,
  CONSTRAINT `loyalty_wallet_ibfk_2` FOREIGN KEY (`document_id`) REFERENCES `sales_documents` (`id`) ON DELETE SET NULL,
  CONSTRAINT `loyalty_wallet_ibfk_3` FOREIGN KEY (`tender_type_id`) REFERENCES `tender_types` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `loyalty_wallet`
--

LOCK TABLES `loyalty_wallet` WRITE;
/*!40000 ALTER TABLE `loyalty_wallet` DISABLE KEYS */;
/*!40000 ALTER TABLE `loyalty_wallet` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `manufacturing_order_costs`
--

DROP TABLE IF EXISTS `manufacturing_order_costs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `manufacturing_order_costs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `order_id` int(10) unsigned NOT NULL,
  `line_number` smallint(5) unsigned NOT NULL DEFAULT 1,
  `description` varchar(190) NOT NULL DEFAULT '',
  `amount_excl` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `account_id` int(10) unsigned DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `ix_mo_cost_order` (`order_id`,`line_number`),
  KEY `fk_mo_cost_account` (`account_id`),
  CONSTRAINT `manufacturing_order_costs_ibfk_1` FOREIGN KEY (`account_id`) REFERENCES `gl_accounts` (`id`),
  CONSTRAINT `manufacturing_order_costs_ibfk_2` FOREIGN KEY (`order_id`) REFERENCES `manufacturing_orders` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `manufacturing_order_costs`
--

LOCK TABLES `manufacturing_order_costs` WRITE;
/*!40000 ALTER TABLE `manufacturing_order_costs` DISABLE KEYS */;
/*!40000 ALTER TABLE `manufacturing_order_costs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `manufacturing_order_lines`
--

DROP TABLE IF EXISTS `manufacturing_order_lines`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `manufacturing_order_lines` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `order_id` int(10) unsigned NOT NULL,
  `line_number` smallint(5) unsigned NOT NULL DEFAULT 1,
  `product_id` int(10) unsigned NOT NULL,
  `product_code` varchar(48) NOT NULL DEFAULT '',
  `description` varchar(190) NOT NULL DEFAULT '',
  `qty_per_unit` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `qty_consumed` decimal(12,3) NOT NULL DEFAULT 0.000,
  `unit_cost_excl` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `line_cost_excl` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `movement_id` bigint(20) unsigned DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_mo_line` (`order_id`,`product_id`),
  KEY `ix_mo_line_product` (`product_id`),
  CONSTRAINT `manufacturing_order_lines_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `manufacturing_orders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `manufacturing_order_lines_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `manufacturing_order_lines`
--

LOCK TABLES `manufacturing_order_lines` WRITE;
/*!40000 ALTER TABLE `manufacturing_order_lines` DISABLE KEYS */;
/*!40000 ALTER TABLE `manufacturing_order_lines` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `manufacturing_orders`
--

DROP TABLE IF EXISTS `manufacturing_orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `manufacturing_orders` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `document_number` varchar(32) DEFAULT NULL,
  `document_date` date NOT NULL,
  `product_id` int(10) unsigned NOT NULL,
  `product_code` varchar(48) NOT NULL DEFAULT '',
  `description` varchar(190) NOT NULL DEFAULT '',
  `qty` decimal(12,3) NOT NULL DEFAULT 0.000,
  `status` enum('draft','posted','cancelled') NOT NULL DEFAULT 'draft',
  `from_location_id` int(10) unsigned NOT NULL,
  `to_location_id` int(10) unsigned NOT NULL,
  `component_cost` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `overhead_cost` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `unit_cost_excl` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `reference` varchar(60) DEFAULT NULL,
  `note` varchar(400) DEFAULT NULL,
  `posted_at` datetime DEFAULT NULL,
  `cancelled_at` datetime DEFAULT NULL,
  `cancel_reason` varchar(200) DEFAULT NULL,
  `user_id` int(10) unsigned DEFAULT NULL,
  `user_name` varchar(120) NOT NULL DEFAULT '',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_mo_number` (`document_number`),
  KEY `ix_mo_date` (`document_date`,`id`),
  KEY `ix_mo_status` (`status`,`document_date`),
  KEY `ix_mo_product` (`product_id`,`document_date`),
  KEY `fk_mo_from` (`from_location_id`),
  KEY `fk_mo_to` (`to_location_id`),
  CONSTRAINT `manufacturing_orders_ibfk_1` FOREIGN KEY (`from_location_id`) REFERENCES `stock_locations` (`id`),
  CONSTRAINT `manufacturing_orders_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`),
  CONSTRAINT `manufacturing_orders_ibfk_3` FOREIGN KEY (`to_location_id`) REFERENCES `stock_locations` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `manufacturing_orders`
--

LOCK TABLES `manufacturing_orders` WRITE;
/*!40000 ALTER TABLE `manufacturing_orders` DISABLE KEYS */;
/*!40000 ALTER TABLE `manufacturing_orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notification_reads`
--

DROP TABLE IF EXISTS `notification_reads`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `notification_reads` (
  `notification_id` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `read_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`notification_id`,`user_id`),
  KEY `fk_notifreads_user` (`user_id`),
  CONSTRAINT `notification_reads_ibfk_1` FOREIGN KEY (`notification_id`) REFERENCES `notifications` (`id`) ON DELETE CASCADE,
  CONSTRAINT `notification_reads_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notification_reads`
--

LOCK TABLES `notification_reads` WRITE;
/*!40000 ALTER TABLE `notification_reads` DISABLE KEYS */;
INSERT INTO `notification_reads` VALUES (1,1,'2026-08-24 13:27:54');
/*!40000 ALTER TABLE `notification_reads` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notifications`
--

DROP TABLE IF EXISTS `notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `notifications` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `event` varchar(40) NOT NULL,
  `audience` varchar(60) DEFAULT NULL,
  `user_id` int(10) unsigned DEFAULT NULL,
  `title` varchar(160) NOT NULL,
  `body` varchar(400) DEFAULT NULL,
  `href` varchar(190) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `ix_notifications_created` (`created_at`,`id`),
  KEY `fk_notifications_user` (`user_id`),
  CONSTRAINT `notifications_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notifications`
--

LOCK TABLES `notifications` WRITE;
/*!40000 ALTER TABLE `notifications` DISABLE KEYS */;
INSERT INTO `notifications` VALUES (1,'grv_received','purchasing.view',NULL,'GRV000019 received','Goods received — R138.00, by Tiaan Smith','/purchasing/27','2026-08-24 12:49:22');
/*!40000 ALTER TABLE `notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `offline_cancelled_sales`
--

DROP TABLE IF EXISTS `offline_cancelled_sales`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `offline_cancelled_sales` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `sale_uid` char(36) NOT NULL,
  `document_number` varchar(32) DEFAULT NULL,
  `terminal_id` int(10) unsigned DEFAULT NULL,
  `terminal_code` varchar(24) DEFAULT NULL,
  `user_id` int(10) unsigned DEFAULT NULL,
  `user_name` varchar(120) NOT NULL DEFAULT '',
  `total_incl` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `reason` varchar(190) DEFAULT NULL,
  `taken_at` datetime DEFAULT NULL,
  `cancelled_at` datetime DEFAULT NULL,
  `payload` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`payload`)),
  `synced_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_cancelled_uid` (`sale_uid`),
  KEY `ix_cancelled_user` (`user_id`,`cancelled_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `offline_cancelled_sales`
--

LOCK TABLES `offline_cancelled_sales` WRITE;
/*!40000 ALTER TABLE `offline_cancelled_sales` DISABLE KEYS */;
/*!40000 ALTER TABLE `offline_cancelled_sales` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `offline_return_claims`
--

DROP TABLE IF EXISTS `offline_return_claims`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `offline_return_claims` (
  `return_uid` char(36) NOT NULL,
  `terminal_id` int(10) unsigned DEFAULT NULL,
  `status` enum('claimed','posted','rejected') NOT NULL DEFAULT 'claimed',
  `document_id` int(10) unsigned DEFAULT NULL,
  `document_number` varchar(32) DEFAULT NULL,
  `operator_name` varchar(120) NOT NULL DEFAULT '',
  `error` varchar(400) DEFAULT NULL,
  `attempts` smallint(5) unsigned NOT NULL DEFAULT 0,
  `claimed_at` datetime NOT NULL DEFAULT current_timestamp(),
  `posted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`return_uid`),
  KEY `ix_return_claims_status` (`status`,`claimed_at`),
  KEY `fk_return_claim_doc` (`document_id`),
  CONSTRAINT `offline_return_claims_ibfk_1` FOREIGN KEY (`document_id`) REFERENCES `sales_documents` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `offline_return_claims`
--

LOCK TABLES `offline_return_claims` WRITE;
/*!40000 ALTER TABLE `offline_return_claims` DISABLE KEYS */;
/*!40000 ALTER TABLE `offline_return_claims` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `offline_signin`
--

DROP TABLE IF EXISTS `offline_signin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `offline_signin` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `verifier` varchar(64) NOT NULL,
  `iterations` int(10) unsigned NOT NULL,
  `confirmed_at` datetime NOT NULL,
  `failed_attempts` int(10) unsigned NOT NULL DEFAULT 0,
  `locked_until` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_offline_signin_user` (`user_id`),
  CONSTRAINT `offline_signin_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `offline_signin`
--

LOCK TABLES `offline_signin` WRITE;
/*!40000 ALTER TABLE `offline_signin` DISABLE KEYS */;
/*!40000 ALTER TABLE `offline_signin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `offline_sync_claims`
--

DROP TABLE IF EXISTS `offline_sync_claims`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `offline_sync_claims` (
  `sale_uid` char(36) NOT NULL,
  `terminal_id` int(10) unsigned DEFAULT NULL,
  `status` enum('claimed','posted','rejected') NOT NULL DEFAULT 'claimed',
  `document_id` int(10) unsigned DEFAULT NULL,
  `document_number` varchar(32) DEFAULT NULL,
  `operator_name` varchar(120) NOT NULL DEFAULT '',
  `error` varchar(400) DEFAULT NULL,
  `attempts` smallint(5) unsigned NOT NULL DEFAULT 0,
  `claimed_at` datetime NOT NULL DEFAULT current_timestamp(),
  `posted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`sale_uid`),
  KEY `ix_claims_status` (`status`,`claimed_at`),
  KEY `fk_claim_doc` (`document_id`),
  CONSTRAINT `offline_sync_claims_ibfk_1` FOREIGN KEY (`document_id`) REFERENCES `sales_documents` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `offline_sync_claims`
--

LOCK TABLES `offline_sync_claims` WRITE;
/*!40000 ALTER TABLE `offline_sync_claims` DISABLE KEYS */;
/*!40000 ALTER TABLE `offline_sync_claims` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `online_delivery_zones`
--

DROP TABLE IF EXISTS `online_delivery_zones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `online_delivery_zones` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(120) NOT NULL,
  `match_type` enum('suburb','postcode') NOT NULL DEFAULT 'suburb',
  `match_value` varchar(190) NOT NULL,
  `fee_incl` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `free_over_incl` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `min_order_incl` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `sort_order` int(11) NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_zone_match` (`match_type`,`match_value`),
  KEY `ix_zone_active` (`is_active`,`sort_order`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `online_delivery_zones`
--

LOCK TABLES `online_delivery_zones` WRITE;
/*!40000 ALTER TABLE `online_delivery_zones` DISABLE KEYS */;
INSERT INTO `online_delivery_zones` VALUES (1,'George','suburb','Kingswood',50.0000,0.0000,0.0000,1,0,'2026-08-09 12:29:02','2026-08-09 12:29:02');
/*!40000 ALTER TABLE `online_delivery_zones` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `online_listing_presets`
--

DROP TABLE IF EXISTS `online_listing_presets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `online_listing_presets` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `department_id` int(10) unsigned NOT NULL DEFAULT 0,
  `columns_desktop` tinyint(3) unsigned NOT NULL DEFAULT 4,
  `columns_phone` tinyint(3) unsigned NOT NULL DEFAULT 2,
  `per_page` smallint(5) unsigned NOT NULL DEFAULT 24,
  `default_sort` varchar(16) NOT NULL DEFAULT 'name',
  `layout` varchar(8) NOT NULL DEFAULT 'grid',
  `card_fields` varchar(160) NOT NULL DEFAULT 'department,saving,stock,brand,variants,rating,price,add',
  `facets` varchar(60) NOT NULL DEFAULT 'brand,price',
  `updated_at` datetime DEFAULT NULL,
  `updated_by` varchar(120) DEFAULT NULL,
  `badge_new_label` varchar(24) NOT NULL DEFAULT '',
  `badge_new_days` smallint(5) unsigned NOT NULL DEFAULT 30,
  `badge_new_tone` varchar(12) NOT NULL DEFAULT 'brand',
  `badge_best_label` varchar(24) NOT NULL DEFAULT '',
  `badge_best_tone` varchar(12) NOT NULL DEFAULT 'success',
  `badge_low_label` varchar(24) NOT NULL DEFAULT '',
  `badge_low_at` smallint(5) unsigned NOT NULL DEFAULT 3,
  `badge_low_tone` varchar(12) NOT NULL DEFAULT 'warning',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_listing_department` (`department_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `online_listing_presets`
--

LOCK TABLES `online_listing_presets` WRITE;
/*!40000 ALTER TABLE `online_listing_presets` DISABLE KEYS */;
/*!40000 ALTER TABLE `online_listing_presets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `online_order_lines`
--

DROP TABLE IF EXISTS `online_order_lines`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `online_order_lines` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `order_id` int(10) unsigned NOT NULL,
  `line_number` smallint(5) unsigned NOT NULL DEFAULT 0,
  `product_id` int(10) unsigned DEFAULT NULL,
  `product_code` varchar(48) DEFAULT NULL,
  `description` varchar(190) NOT NULL,
  `qty` decimal(12,3) NOT NULL DEFAULT 0.000,
  `unit_price_incl` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `line_total_incl` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `line_note` varchar(190) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `ix_online_line_order` (`order_id`,`line_number`),
  KEY `fk_online_line_product` (`product_id`),
  CONSTRAINT `online_order_lines_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `online_orders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `online_order_lines_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `online_order_lines`
--

LOCK TABLES `online_order_lines` WRITE;
/*!40000 ALTER TABLE `online_order_lines` DISABLE KEYS */;
/*!40000 ALTER TABLE `online_order_lines` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `online_order_statuses`
--

DROP TABLE IF EXISTS `online_order_statuses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `online_order_statuses` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(40) NOT NULL,
  `name` varchar(60) NOT NULL,
  `tone` enum('neutral','brand','success','warning','danger') NOT NULL DEFAULT 'neutral',
  `sort_order` int(11) NOT NULL DEFAULT 0,
  `role` enum('','new','completed','cancelled','dispatched') NOT NULL DEFAULT '',
  `notify_kind` enum('','accepted','ready','on_the_way','cancelled') NOT NULL DEFAULT '',
  `use_template` tinyint(1) NOT NULL DEFAULT 0,
  `email_subject` varchar(255) NOT NULL DEFAULT '',
  `email_html` mediumtext DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_status_code` (`code`),
  KEY `ix_status_sort` (`sort_order`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `online_order_statuses`
--

LOCK TABLES `online_order_statuses` WRITE;
/*!40000 ALTER TABLE `online_order_statuses` DISABLE KEYS */;
INSERT INTO `online_order_statuses` VALUES (1,'new','New','brand',10,'new','',0,'',NULL,1,'2026-08-06 18:57:49'),(2,'accepted','Accepted','brand',20,'','accepted',0,'',NULL,1,'2026-08-06 18:57:49'),(3,'preparing','Preparing','warning',30,'','',0,'',NULL,1,'2026-08-06 18:57:49'),(4,'ready','Ready','success',40,'','ready',0,'',NULL,1,'2026-08-06 18:57:49'),(5,'dispatched','Out for delivery','warning',50,'dispatched','on_the_way',0,'',NULL,1,'2026-08-06 18:57:49'),(6,'completed','Completed','success',60,'completed','',0,'',NULL,1,'2026-08-06 18:57:49'),(7,'cancelled','Cancelled','danger',70,'cancelled','cancelled',0,'',NULL,1,'2026-08-06 18:57:49');
/*!40000 ALTER TABLE `online_order_statuses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `online_orders`
--

DROP TABLE IF EXISTS `online_orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `online_orders` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `order_number` varchar(32) NOT NULL,
  `status_id` int(10) unsigned NOT NULL,
  `fulfilment` enum('collect','deliver') NOT NULL DEFAULT 'collect',
  `document_id` int(10) unsigned DEFAULT NULL,
  `customer_id` int(10) unsigned DEFAULT NULL,
  `contact_name` varchar(160) NOT NULL DEFAULT '',
  `contact_phone` varchar(40) NOT NULL DEFAULT '',
  `contact_email` varchar(190) NOT NULL DEFAULT '',
  `delivery_line1` varchar(190) NOT NULL DEFAULT '',
  `delivery_line2` varchar(190) NOT NULL DEFAULT '',
  `delivery_suburb` varchar(120) NOT NULL DEFAULT '',
  `delivery_postcode` varchar(20) NOT NULL DEFAULT '',
  `delivery_notes` varchar(500) NOT NULL DEFAULT '',
  `delivery_fee_incl` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `zone_id` int(10) unsigned DEFAULT NULL,
  `total_incl` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `requested_for` datetime DEFAULT NULL,
  `customer_note` varchar(500) NOT NULL DEFAULT '',
  `decline_reason` varchar(190) NOT NULL DEFAULT '',
  `is_archived` tinyint(1) NOT NULL DEFAULT 0,
  `archived_at` datetime DEFAULT NULL,
  `placed_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `payment_status` enum('unpaid','pending','paid') NOT NULL DEFAULT 'unpaid',
  `pay_on_account` tinyint(1) NOT NULL DEFAULT 0,
  `paid_at` datetime DEFAULT NULL,
  `internal_note` varchar(500) NOT NULL DEFAULT '',
  `discount_code_id` int(10) unsigned DEFAULT NULL,
  `discount_code` varchar(40) NOT NULL DEFAULT '',
  `discount_incl` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `voucher_code` varchar(32) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_online_order_number` (`order_number`),
  KEY `ix_online_order_queue` (`is_archived`,`status_id`,`placed_at`),
  KEY `ix_online_order_customer` (`customer_id`,`placed_at`),
  KEY `ix_online_order_document` (`document_id`),
  KEY `fk_online_order_status` (`status_id`),
  KEY `fk_online_order_zone` (`zone_id`),
  KEY `ix_online_order_discount` (`discount_code_id`),
  CONSTRAINT `online_orders_ibfk_1` FOREIGN KEY (`discount_code_id`) REFERENCES `discount_codes` (`id`) ON DELETE SET NULL,
  CONSTRAINT `online_orders_ibfk_2` FOREIGN KEY (`document_id`) REFERENCES `sales_documents` (`id`) ON DELETE SET NULL,
  CONSTRAINT `online_orders_ibfk_3` FOREIGN KEY (`status_id`) REFERENCES `online_order_statuses` (`id`),
  CONSTRAINT `online_orders_ibfk_4` FOREIGN KEY (`zone_id`) REFERENCES `online_delivery_zones` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `online_orders`
--

LOCK TABLES `online_orders` WRITE;
/*!40000 ALTER TABLE `online_orders` DISABLE KEYS */;
/*!40000 ALTER TABLE `online_orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `online_product_availability`
--

DROP TABLE IF EXISTS `online_product_availability`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `online_product_availability` (
  `product_id` int(10) unsigned NOT NULL,
  `unavailable_until` date NOT NULL,
  `note` varchar(120) NOT NULL DEFAULT '',
  `set_at` datetime NOT NULL DEFAULT current_timestamp(),
  `set_by` varchar(120) NOT NULL DEFAULT '',
  PRIMARY KEY (`product_id`),
  KEY `ix_unavailable_until` (`unavailable_until`),
  CONSTRAINT `online_product_availability_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `online_product_availability`
--

LOCK TABLES `online_product_availability` WRITE;
/*!40000 ALTER TABLE `online_product_availability` DISABLE KEYS */;
/*!40000 ALTER TABLE `online_product_availability` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `online_saved_baskets`
--

DROP TABLE IF EXISTS `online_saved_baskets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `online_saved_baskets` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `contact_email` varchar(190) NOT NULL,
  `contact_name` varchar(160) NOT NULL DEFAULT '',
  `customer_id` int(10) unsigned DEFAULT NULL,
  `basket_lines` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`basket_lines`)),
  `subtotal_incl` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `recovery_token` char(43) NOT NULL,
  `reminded_at` datetime DEFAULT NULL,
  `recovered_at` datetime DEFAULT NULL,
  `ordered_at` datetime DEFAULT NULL,
  `unsubscribed` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_saved_basket_email` (`contact_email`),
  UNIQUE KEY `uq_saved_basket_token` (`recovery_token`),
  KEY `ix_saved_basket_due` (`reminded_at`,`recovered_at`,`ordered_at`,`updated_at`),
  KEY `fk_saved_basket_customer` (`customer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `online_saved_baskets`
--

LOCK TABLES `online_saved_baskets` WRITE;
/*!40000 ALTER TABLE `online_saved_baskets` DISABLE KEYS */;
/*!40000 ALTER TABLE `online_saved_baskets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `online_stock_holds`
--

DROP TABLE IF EXISTS `online_stock_holds`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `online_stock_holds` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `order_id` int(10) unsigned NOT NULL,
  `product_id` int(10) unsigned NOT NULL,
  `qty` decimal(12,3) NOT NULL DEFAULT 0.000,
  `expires_at` datetime NOT NULL,
  `released_at` datetime DEFAULT NULL,
  `release_note` varchar(40) NOT NULL DEFAULT '',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `ix_hold_live` (`product_id`,`released_at`,`expires_at`),
  KEY `ix_hold_order` (`order_id`,`released_at`),
  CONSTRAINT `online_stock_holds_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `online_orders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `online_stock_holds_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `online_stock_holds`
--

LOCK TABLES `online_stock_holds` WRITE;
/*!40000 ALTER TABLE `online_stock_holds` DISABLE KEYS */;
/*!40000 ALTER TABLE `online_stock_holds` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `online_store_settings`
--

DROP TABLE IF EXISTS `online_store_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `online_store_settings` (
  `id` tinyint(3) unsigned NOT NULL DEFAULT 1,
  `is_enabled` tinyint(1) NOT NULL DEFAULT 0,
  `collect_enabled` tinyint(1) NOT NULL DEFAULT 1,
  `deliver_enabled` tinyint(1) NOT NULL DEFAULT 0,
  `payment_mode` enum('on_collection','online') NOT NULL DEFAULT 'on_collection',
  `allow_account` tinyint(1) NOT NULL DEFAULT 0,
  `publish_mode` enum('departments','flagged','all') NOT NULL DEFAULT 'departments',
  `price_structure_id` int(10) unsigned DEFAULT NULL,
  `lead_time_minutes` smallint(5) unsigned NOT NULL DEFAULT 30,
  `min_order_incl` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `blurb` varchar(500) NOT NULL DEFAULT '',
  `paid_status_id` int(10) unsigned DEFAULT NULL,
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_by` varchar(120) NOT NULL DEFAULT '',
  `reviews_enabled` tinyint(1) NOT NULL DEFAULT 0,
  `show_stock` tinyint(1) NOT NULL DEFAULT 0,
  `show_photos` tinyint(1) NOT NULL DEFAULT 1,
  `show_brands` tinyint(1) NOT NULL DEFAULT 1,
  `brand_colour` varchar(9) NOT NULL DEFAULT '#2f6fed',
  `product_layout` varchar(10) NOT NULL DEFAULT 'grid',
  `logo_image_id` bigint(20) unsigned DEFAULT NULL,
  `hero_headline` varchar(120) NOT NULL DEFAULT '',
  `hero_subtext` varchar(300) NOT NULL DEFAULT '',
  `footer_about` varchar(600) NOT NULL DEFAULT '',
  `footer_hours` varchar(400) NOT NULL DEFAULT '',
  `social_facebook` varchar(200) NOT NULL DEFAULT '',
  `social_instagram` varchar(200) NOT NULL DEFAULT '',
  `social_whatsapp` varchar(30) NOT NULL DEFAULT '',
  `show_department_images` tinyint(1) NOT NULL DEFAULT 0,
  `basket_reminders` tinyint(1) NOT NULL DEFAULT 0,
  `basket_reminder_hours` smallint(5) unsigned NOT NULL DEFAULT 4,
  `basket_reminder_note` varchar(500) NOT NULL DEFAULT '',
  `hold_minutes` smallint(5) unsigned NOT NULL DEFAULT 60,
  `share_image_id` bigint(20) unsigned DEFAULT NULL,
  `allow_indexing` tinyint(1) NOT NULL DEFAULT 0,
  `announce_text` varchar(200) NOT NULL DEFAULT '',
  `announce_link` varchar(300) NOT NULL DEFAULT '',
  `announce_from` varchar(10) NOT NULL DEFAULT '',
  `announce_until` varchar(10) NOT NULL DEFAULT '',
  `font_key` varchar(24) NOT NULL DEFAULT 'system',
  `public_domain` varchar(190) NOT NULL DEFAULT '',
  `trading_hours` text DEFAULT NULL,
  `accepting_orders` tinyint(1) NOT NULL DEFAULT 1,
  `accepting_note` varchar(200) NOT NULL DEFAULT '',
  `order_horizon_days` tinyint(3) unsigned NOT NULL DEFAULT 2,
  `design_tokens` text DEFAULT NULL,
  `design_tokens_draft` text DEFAULT NULL,
  `currency_code` varchar(3) NOT NULL DEFAULT 'ZAR',
  `currency_symbol` varchar(4) NOT NULL DEFAULT 'R',
  `checkout_policy_pages` varchar(60) NOT NULL DEFAULT '',
  `checkout_trust_line` varchar(200) NOT NULL DEFAULT '',
  `checkout_note_label` varchar(60) NOT NULL DEFAULT '',
  `checkout_note_required` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `fk_online_price_structure` (`price_structure_id`),
  KEY `fk_online_paid_status` (`paid_status_id`),
  KEY `fk_settings_share_image` (`share_image_id`),
  CONSTRAINT `online_store_settings_ibfk_1` FOREIGN KEY (`paid_status_id`) REFERENCES `online_order_statuses` (`id`) ON DELETE SET NULL,
  CONSTRAINT `online_store_settings_ibfk_2` FOREIGN KEY (`price_structure_id`) REFERENCES `price_structures` (`id`) ON DELETE SET NULL,
  CONSTRAINT `online_store_settings_ibfk_3` FOREIGN KEY (`share_image_id`) REFERENCES `storefront_images` (`id`) ON DELETE SET NULL,
  CONSTRAINT `CONSTRAINT_1` CHECK (`id` = 1)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `online_store_settings`
--

LOCK TABLES `online_store_settings` WRITE;
/*!40000 ALTER TABLE `online_store_settings` DISABLE KEYS */;
INSERT INTO `online_store_settings` VALUES (1,1,1,1,'on_collection',0,'departments',1,25,0.0000,'Smashed to order on a screaming hot flat-top. Order online, collect in 25 minutes.',NULL,'2026-08-09 12:50:16','Tiaan Smith',1,1,1,1,'#c2410c','grid',3,'Smash Burger Joint','Smashed patties, gourmet dogs and wood-fired pizza — ready when you are.','Smash Burger Joint has been smashing patties on a screaming hot flat-top since 2019. Everything is made to order: the beef is ground fresh daily, the buns are baked down the road, and the pizza comes out of a real wood-fired oven.','Monday – Thursday: 11:00 – 21:00\nFriday – Saturday: 11:00 – 22:30\nSunday: 12:00 – 20:00','https://facebook.com/smashburgerjoint','https://instagram.com/smashburgerjoint','+27821234567',1,0,4,'',60,NULL,0,'','','','','system','',NULL,1,'',2,NULL,NULL,'ZAR','R','','','',0);
/*!40000 ALTER TABLE `online_store_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `online_trading_exceptions`
--

DROP TABLE IF EXISTS `online_trading_exceptions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `online_trading_exceptions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `on_date` date NOT NULL,
  `is_closed` tinyint(1) NOT NULL DEFAULT 1,
  `open_time` time DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `note` varchar(200) NOT NULL DEFAULT '',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_trading_exception_date` (`on_date`),
  KEY `ix_trading_exception_date` (`on_date`,`is_closed`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `online_trading_exceptions`
--

LOCK TABLES `online_trading_exceptions` WRITE;
/*!40000 ALTER TABLE `online_trading_exceptions` DISABLE KEYS */;
/*!40000 ALTER TABLE `online_trading_exceptions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `party_comments`
--

DROP TABLE IF EXISTS `party_comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `party_comments` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `entity` varchar(40) NOT NULL,
  `entity_id` int(10) unsigned NOT NULL,
  `body` text NOT NULL,
  `is_pinned` tinyint(1) NOT NULL DEFAULT 0,
  `author_id` int(10) unsigned DEFAULT NULL,
  `author_name` varchar(120) NOT NULL DEFAULT '',
  `is_edited` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `is_customer` tinyint(1) NOT NULL DEFAULT 0,
  `is_visible` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `ix_pcomment_entity` (`entity`,`entity_id`,`is_pinned`,`created_at`),
  KEY `ix_comment_visible` (`entity`,`entity_id`,`is_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `party_comments`
--

LOCK TABLES `party_comments` WRITE;
/*!40000 ALTER TABLE `party_comments` DISABLE KEYS */;
/*!40000 ALTER TABLE `party_comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `party_documents`
--

DROP TABLE IF EXISTS `party_documents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `party_documents` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `entity` varchar(40) NOT NULL,
  `entity_id` int(10) unsigned NOT NULL,
  `filename` varchar(255) NOT NULL,
  `stored_name` varchar(190) NOT NULL,
  `mime_type` varchar(120) DEFAULT NULL,
  `size_bytes` bigint(20) unsigned NOT NULL DEFAULT 0,
  `description` varchar(400) DEFAULT NULL,
  `uploaded_by` int(10) unsigned DEFAULT NULL,
  `uploaded_name` varchar(120) NOT NULL DEFAULT '',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `is_customer` tinyint(1) NOT NULL DEFAULT 0,
  `is_visible` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_pdoc_stored` (`stored_name`),
  KEY `ix_pdoc_entity` (`entity`,`entity_id`,`created_at`),
  KEY `ix_document_visible` (`entity`,`entity_id`,`is_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `party_documents`
--

LOCK TABLES `party_documents` WRITE;
/*!40000 ALTER TABLE `party_documents` DISABLE KEYS */;
/*!40000 ALTER TABLE `party_documents` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pay_links`
--

DROP TABLE IF EXISTS `pay_links`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pay_links` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `slug` varchar(24) NOT NULL,
  `purpose` enum('debtor_invoice','customer_account','layby','job_deposit','document_deposit') NOT NULL,
  `target_id` int(10) unsigned NOT NULL,
  `amount_incl` decimal(12,4) DEFAULT NULL,
  `expires_at` datetime DEFAULT NULL,
  `revoked_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `created_by` varchar(120) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_pay_link_slug` (`slug`),
  KEY `ix_pay_link_target` (`purpose`,`target_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pay_links`
--

LOCK TABLES `pay_links` WRITE;
/*!40000 ALTER TABLE `pay_links` DISABLE KEYS */;
/*!40000 ALTER TABLE `pay_links` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payment_gateways`
--

DROP TABLE IF EXISTS `payment_gateways`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `payment_gateways` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `provider` varchar(20) NOT NULL DEFAULT 'payfast',
  `is_active` tinyint(1) NOT NULL DEFAULT 0,
  `is_sandbox` tinyint(1) NOT NULL DEFAULT 1,
  `merchant_id` varchar(64) NOT NULL DEFAULT '',
  `merchant_key` varchar(512) NOT NULL DEFAULT '',
  `passphrase` varchar(512) NOT NULL DEFAULT '',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_by` varchar(120) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_gateway_provider` (`provider`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payment_gateways`
--

LOCK TABLES `payment_gateways` WRITE;
/*!40000 ALTER TABLE `payment_gateways` DISABLE KEYS */;
/*!40000 ALTER TABLE `payment_gateways` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payment_intents`
--

DROP TABLE IF EXISTS `payment_intents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `payment_intents` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `reference` varchar(64) NOT NULL,
  `provider` varchar(20) NOT NULL DEFAULT 'payfast',
  `purpose` enum('online_order','debtor_invoice','customer_account','layby','job_deposit','document_deposit') NOT NULL DEFAULT 'online_order',
  `target_id` int(10) unsigned NOT NULL,
  `amount_incl` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `status` enum('pending','paid','failed','cancelled') NOT NULL DEFAULT 'pending',
  `provider_ref` varchar(64) NOT NULL DEFAULT '',
  `failure_reason` varchar(190) NOT NULL DEFAULT '',
  `raw_payload` mediumtext DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `settled_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_intent_reference` (`reference`),
  KEY `ix_intent_target` (`purpose`,`target_id`),
  KEY `ix_intent_status` (`status`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payment_intents`
--

LOCK TABLES `payment_intents` WRITE;
/*!40000 ALTER TABLE `payment_intents` DISABLE KEYS */;
/*!40000 ALTER TABLE `payment_intents` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payment_promises`
--

DROP TABLE IF EXISTS `payment_promises`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `payment_promises` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `customer_id` int(10) unsigned NOT NULL,
  `promised_date` date NOT NULL,
  `promised_amount` decimal(12,4) NOT NULL,
  `balance_at_promise` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `status` enum('open','kept','broken','cancelled') NOT NULL DEFAULT 'open',
  `received_amount` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `promised_by` varchar(120) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `run_item_id` int(10) unsigned DEFAULT NULL,
  `user_id` int(10) unsigned DEFAULT NULL,
  `user_name` varchar(120) NOT NULL DEFAULT '',
  `resolved_at` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_promise_customer` (`customer_id`,`status`),
  KEY `idx_promise_due` (`status`,`promised_date`),
  KEY `fk_promise_run_item` (`run_item_id`),
  CONSTRAINT `payment_promises_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE CASCADE,
  CONSTRAINT `payment_promises_ibfk_2` FOREIGN KEY (`run_item_id`) REFERENCES `dunning_run_items` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payment_promises`
--

LOCK TABLES `payment_promises` WRITE;
/*!40000 ALTER TABLE `payment_promises` DISABLE KEYS */;
/*!40000 ALTER TABLE `payment_promises` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `period_locks`
--

DROP TABLE IF EXISTS `period_locks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `period_locks` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `period_from` date NOT NULL,
  `period_to` date NOT NULL,
  `lock_type` enum('soft','hard') NOT NULL DEFAULT 'hard',
  `scope` enum('all','sales','purchases','ledger','stock') NOT NULL DEFAULT 'all',
  `reason` varchar(190) DEFAULT NULL,
  `locked_at` datetime NOT NULL DEFAULT current_timestamp(),
  `locked_by` varchar(120) NOT NULL DEFAULT '',
  `unlocked_at` datetime DEFAULT NULL,
  `unlocked_by` varchar(120) DEFAULT NULL,
  `unlock_reason` varchar(190) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `ix_lock_span` (`unlocked_at`,`period_from`,`period_to`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `period_locks`
--

LOCK TABLES `period_locks` WRITE;
/*!40000 ALTER TABLE `period_locks` DISABLE KEYS */;
/*!40000 ALTER TABLE `period_locks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pos_floor_features`
--

DROP TABLE IF EXISTS `pos_floor_features`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pos_floor_features` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `room_id` int(10) unsigned NOT NULL,
  `kind` enum('wall','bar','pass','door','plant','text') NOT NULL DEFAULT 'wall',
  `label` varchar(60) NOT NULL DEFAULT '',
  `pos_x` decimal(7,2) NOT NULL DEFAULT 0.00,
  `pos_y` decimal(7,2) NOT NULL DEFAULT 0.00,
  `width` decimal(7,2) NOT NULL DEFAULT 20.00,
  `height` decimal(7,2) NOT NULL DEFAULT 2.00,
  `rotation` smallint(6) NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_feature_room` (`room_id`),
  CONSTRAINT `pos_floor_features_ibfk_1` FOREIGN KEY (`room_id`) REFERENCES `pos_floor_rooms` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pos_floor_features`
--

LOCK TABLES `pos_floor_features` WRITE;
/*!40000 ALTER TABLE `pos_floor_features` DISABLE KEYS */;
INSERT INTO `pos_floor_features` VALUES (7,2,'wall','',4.00,4.00,24.00,2.00,0,'2026-08-24 13:35:23','2026-08-24 13:35:23'),(8,2,'bar','',16.00,38.32,54.39,28.71,0,'2026-08-24 13:35:34','2026-08-24 13:35:44');
/*!40000 ALTER TABLE `pos_floor_features` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pos_floor_rooms`
--

DROP TABLE IF EXISTS `pos_floor_rooms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pos_floor_rooms` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(60) NOT NULL,
  `width` decimal(7,2) NOT NULL DEFAULT 100.00,
  `height` decimal(7,2) NOT NULL DEFAULT 70.00,
  `sort_order` int(10) unsigned NOT NULL DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_room_name` (`name`),
  KEY `idx_room_order` (`is_active`,`sort_order`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pos_floor_rooms`
--

LOCK TABLES `pos_floor_rooms` WRITE;
/*!40000 ALTER TABLE `pos_floor_rooms` DISABLE KEYS */;
INSERT INTO `pos_floor_rooms` VALUES (2,'Main Room',200.00,140.00,1,1,'2026-08-24 13:34:10','2026-08-24 13:34:10');
/*!40000 ALTER TABLE `pos_floor_rooms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pos_menu_items`
--

DROP TABLE IF EXISTS `pos_menu_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pos_menu_items` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `menu_id` int(10) unsigned NOT NULL,
  `effect` enum('include','exclude') NOT NULL DEFAULT 'include',
  `product_id` int(10) unsigned DEFAULT NULL,
  `department_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_menu_target` (`menu_id`,`product_id`,`department_id`),
  KEY `ix_menu_items_menu` (`menu_id`,`effect`),
  KEY `fk_pos_menu_item_product` (`product_id`),
  KEY `fk_pos_menu_item_department` (`department_id`),
  CONSTRAINT `pos_menu_items_ibfk_1` FOREIGN KEY (`department_id`) REFERENCES `departments` (`id`) ON DELETE CASCADE,
  CONSTRAINT `pos_menu_items_ibfk_2` FOREIGN KEY (`menu_id`) REFERENCES `pos_menus` (`id`) ON DELETE CASCADE,
  CONSTRAINT `pos_menu_items_ibfk_3` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pos_menu_items`
--

LOCK TABLES `pos_menu_items` WRITE;
/*!40000 ALTER TABLE `pos_menu_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `pos_menu_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pos_menu_terminals`
--

DROP TABLE IF EXISTS `pos_menu_terminals`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pos_menu_terminals` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `menu_id` int(10) unsigned NOT NULL,
  `terminal_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_menu_terminal` (`menu_id`,`terminal_id`),
  KEY `ix_menu_terminal_terminal` (`terminal_id`),
  CONSTRAINT `pos_menu_terminals_ibfk_1` FOREIGN KEY (`menu_id`) REFERENCES `pos_menus` (`id`) ON DELETE CASCADE,
  CONSTRAINT `pos_menu_terminals_ibfk_2` FOREIGN KEY (`terminal_id`) REFERENCES `terminals` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pos_menu_terminals`
--

LOCK TABLES `pos_menu_terminals` WRITE;
/*!40000 ALTER TABLE `pos_menu_terminals` DISABLE KEYS */;
/*!40000 ALTER TABLE `pos_menu_terminals` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pos_menus`
--

DROP TABLE IF EXISTS `pos_menus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pos_menus` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(80) NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `daily_start` varchar(5) NOT NULL DEFAULT '',
  `daily_end` varchar(5) NOT NULL DEFAULT '',
  `days_of_week` char(7) NOT NULL DEFAULT '1111111',
  `priority` int(11) NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `created_by` varchar(120) NOT NULL DEFAULT '',
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_by` varchar(120) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `ix_pos_menu_live` (`is_active`,`priority`,`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pos_menus`
--

LOCK TABLES `pos_menus` WRITE;
/*!40000 ALTER TABLE `pos_menus` DISABLE KEYS */;
/*!40000 ALTER TABLE `pos_menus` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pos_quick_keys`
--

DROP TABLE IF EXISTS `pos_quick_keys`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pos_quick_keys` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` int(10) unsigned DEFAULT NULL,
  `section` enum('main','tables') NOT NULL DEFAULT 'main',
  `kind` enum('action','product','department','group') NOT NULL DEFAULT 'action',
  `action_slug` varchar(50) NOT NULL DEFAULT '',
  `product_id` int(10) unsigned DEFAULT NULL,
  `department_id` int(10) unsigned DEFAULT NULL,
  `caption` varchar(60) NOT NULL DEFAULT '',
  `icon` varchar(40) NOT NULL DEFAULT '',
  `colour_token` varchar(32) NOT NULL DEFAULT '',
  `position` int(10) unsigned NOT NULL DEFAULT 0,
  `is_hidden` tinyint(1) NOT NULL DEFAULT 0,
  `require_auth` tinyint(1) NOT NULL DEFAULT 0,
  `capability` varchar(60) NOT NULL DEFAULT '',
  `sig` varchar(80) NOT NULL DEFAULT '',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_slot` (`parent_id`,`section`,`sig`),
  KEY `idx_scope` (`section`,`parent_id`,`position`),
  KEY `fk_quick_keys_product` (`product_id`),
  KEY `fk_quick_keys_department` (`department_id`),
  CONSTRAINT `pos_quick_keys_ibfk_1` FOREIGN KEY (`department_id`) REFERENCES `departments` (`id`) ON DELETE CASCADE,
  CONSTRAINT `pos_quick_keys_ibfk_2` FOREIGN KEY (`parent_id`) REFERENCES `pos_quick_keys` (`id`) ON DELETE CASCADE,
  CONSTRAINT `pos_quick_keys_ibfk_3` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pos_quick_keys`
--

LOCK TABLES `pos_quick_keys` WRITE;
/*!40000 ALTER TABLE `pos_quick_keys` DISABLE KEYS */;
INSERT INTO `pos_quick_keys` VALUES (1,NULL,'main','group','',NULL,NULL,'Supervisor','ShieldCheck','tile-4',0,0,0,'','g:supervisor','2026-08-10 16:48:23','2026-08-10 16:48:23'),(2,1,'main','action','void-sale',NULL,NULL,'','Trash','tile-1',3,0,0,'sales.till','a:void-sale','2026-08-10 16:48:56','2026-08-24 13:30:17'),(3,1,'main','action','global-discount',NULL,NULL,'','Percent','tile-1',4,0,0,'sales.discount_override','a:global-discount','2026-08-10 16:49:09','2026-08-24 13:30:17'),(4,1,'main','action','refund',NULL,NULL,'','Reverse','tile-1',5,0,0,'sales.credit_note','a:refund','2026-08-10 16:49:24','2026-08-24 13:30:17'),(5,NULL,'main','action','split-table',NULL,NULL,'','Shapes','tile-1',2,0,0,'sales.till','a:split-table','2026-08-10 16:49:58','2026-08-24 13:29:36'),(6,NULL,'main','action','table-transfer',NULL,NULL,'','ArrowLeftRight','tile-1',3,0,0,'sales.till','a:table-transfer','2026-08-10 16:50:05','2026-08-24 13:29:36'),(7,NULL,'main','action','save-sale',NULL,NULL,'','Save','tile-1',4,0,0,'sales.till','a:save-sale','2026-08-24 13:28:05','2026-08-24 13:29:36'),(8,NULL,'main','action','undo',NULL,NULL,'','Reverse','tile-1',5,0,0,'sales.till','a:undo','2026-08-24 13:28:06','2026-08-24 13:29:36'),(9,1,'main','action','price-change',NULL,NULL,'','Tag','tile-1',1,0,0,'sales.price_override','a:price-change','2026-08-24 13:28:08','2026-08-24 13:30:17'),(10,1,'main','action','price-enquiry',NULL,NULL,'','Search','tile-1',2,0,0,'products.view','a:price-enquiry','2026-08-24 13:28:09','2026-08-24 13:30:17'),(11,27,'main','action','gift-card-balance',NULL,NULL,'','Gift','tile-1',1,0,0,'sales.till','a:gift-card-balance','2026-08-24 13:28:10','2026-08-24 13:30:00'),(12,NULL,'main','action','customer-payment',NULL,NULL,'','HandCoins','tile-1',6,0,0,'cashbook.edit','a:customer-payment','2026-08-24 13:28:12','2026-08-24 13:30:12'),(13,NULL,'main','action','take-deposit',NULL,NULL,'','HandCoins','tile-1',7,0,0,'sales.till','a:take-deposit','2026-08-24 13:28:13','2026-08-24 13:30:12'),(14,1,'main','action','credit-sale',NULL,NULL,'','Reverse','tile-1',0,0,0,'sales.credit_note','a:credit-sale','2026-08-24 13:28:14','2026-08-24 13:30:17'),(15,NULL,'main','action','cashup',NULL,NULL,'','Coins','tile-1',8,0,0,'sales.cashup','a:cashup','2026-08-24 13:28:15','2026-08-24 13:30:17'),(16,NULL,'main','action','payout',NULL,NULL,'','Banknote','tile-1',9,0,0,'sales.cashup','a:payout','2026-08-24 13:28:16','2026-08-24 13:30:17'),(17,NULL,'main','action','payin',NULL,NULL,'','Wallet','tile-1',10,0,0,'sales.cashup','a:payin','2026-08-24 13:28:17','2026-08-24 13:30:17'),(18,NULL,'main','action','drop-to-safe',NULL,NULL,'','Lock','tile-1',11,0,0,'sales.cashup','a:drop-to-safe','2026-08-24 13:28:18','2026-08-24 13:30:17'),(19,27,'main','action','loyalty-payment',NULL,NULL,'','Gem','tile-1',2,0,0,'loyalty.adjust','a:loyalty-payment','2026-08-24 13:28:19','2026-08-24 13:30:00'),(20,NULL,'main','action','reprint-invoice',NULL,NULL,'','Printer','tile-1',12,0,0,'sales.view','a:reprint-invoice','2026-08-24 13:28:20','2026-08-24 13:30:17'),(21,NULL,'main','action','reprint-last-slip',NULL,NULL,'','Printer','tile-1',13,0,0,'sales.view','a:reprint-last-slip','2026-08-24 13:28:21','2026-08-24 13:30:17'),(22,27,'main','action','online-orders',NULL,NULL,'','ShoppingCart','tile-1',0,0,0,'online.view','a:online-orders','2026-08-24 13:28:22','2026-08-24 13:30:00'),(23,NULL,'main','action','save-as-layby',NULL,NULL,'','Package','tile-1',14,0,0,'sales.view','a:save-as-layby','2026-08-24 13:28:26','2026-08-24 13:30:17'),(24,NULL,'main','action','save-as-order',NULL,NULL,'','ListOrdered','tile-1',15,0,0,'sales.edit','a:save-as-order','2026-08-24 13:28:27','2026-08-24 13:30:17'),(25,NULL,'main','action','clock-in-out',NULL,NULL,'','Clock','tile-1',16,0,0,'staff.clock','a:clock-in-out','2026-08-24 13:28:28','2026-08-24 13:30:17'),(26,NULL,'main','action','start-layby',NULL,NULL,'','Package','tile-1',17,0,0,'sales.till','a:start-layby','2026-08-24 13:28:29','2026-08-24 13:30:17'),(27,NULL,'main','group','',NULL,NULL,'Integrations','Gift','tile-1',1,0,0,'','g:integrations','2026-08-24 13:28:54','2026-08-24 13:29:36');
/*!40000 ALTER TABLE `pos_quick_keys` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pos_tables`
--

DROP TABLE IF EXISTS `pos_tables`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pos_tables` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(16) NOT NULL,
  `name` varchar(60) NOT NULL DEFAULT '',
  `section` varchar(40) NOT NULL DEFAULT '',
  `seats` tinyint(3) unsigned NOT NULL DEFAULT 0,
  `visit_type_id` int(10) unsigned DEFAULT NULL,
  `document_id` int(10) unsigned DEFAULT NULL,
  `bill_asked_at` datetime DEFAULT NULL,
  `sort_order` int(10) unsigned NOT NULL DEFAULT 0,
  `pos_x` decimal(7,2) DEFAULT NULL,
  `pos_y` decimal(7,2) DEFAULT NULL,
  `width` decimal(7,2) NOT NULL DEFAULT 8.00,
  `height` decimal(7,2) NOT NULL DEFAULT 8.00,
  `rotation` smallint(6) NOT NULL DEFAULT 0,
  `shape` enum('rect','round','oval','counter') NOT NULL DEFAULT 'rect',
  `room_id` int(10) unsigned DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_table_code` (`code`),
  UNIQUE KEY `uq_table_document` (`document_id`),
  KEY `idx_table_order` (`is_active`,`section`,`sort_order`),
  KEY `fk_table_room` (`room_id`),
  KEY `idx_table_visit_type` (`visit_type_id`),
  CONSTRAINT `pos_tables_ibfk_1` FOREIGN KEY (`document_id`) REFERENCES `sales_documents` (`id`) ON DELETE SET NULL,
  CONSTRAINT `pos_tables_ibfk_2` FOREIGN KEY (`room_id`) REFERENCES `pos_floor_rooms` (`id`) ON DELETE SET NULL,
  CONSTRAINT `pos_tables_ibfk_3` FOREIGN KEY (`visit_type_id`) REFERENCES `pos_visit_types` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pos_tables`
--

LOCK TABLES `pos_tables` WRITE;
/*!40000 ALTER TABLE `pos_tables` DISABLE KEYS */;
INSERT INTO `pos_tables` VALUES (1,'Table 1','','',0,NULL,8,NULL,0,NULL,NULL,8.00,8.00,0,'rect',NULL,1,'2026-08-10 16:01:11','2026-08-10 16:50:22'),(2,'1','','',4,NULL,NULL,NULL,1,8.29,17.50,12.00,8.00,0,'rect',2,1,'2026-08-24 13:34:26','2026-08-24 13:35:44'),(3,'2','','',4,NULL,NULL,NULL,2,37.20,17.50,12.00,8.00,0,'rect',2,1,'2026-08-24 13:34:29','2026-08-24 13:35:44'),(4,'3','','',4,NULL,NULL,NULL,3,58.39,17.50,12.00,8.00,0,'rect',2,1,'2026-08-24 13:34:32','2026-08-24 13:35:44');
/*!40000 ALTER TABLE `pos_tables` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pos_visit_types`
--

DROP TABLE IF EXISTS `pos_visit_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pos_visit_types` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(40) NOT NULL,
  `is_default` tinyint(1) NOT NULL DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `sort_order` smallint(5) unsigned NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_visit_type_name` (`name`),
  KEY `idx_visit_type_order` (`is_active`,`sort_order`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pos_visit_types`
--

LOCK TABLES `pos_visit_types` WRITE;
/*!40000 ALTER TABLE `pos_visit_types` DISABLE KEYS */;
INSERT INTO `pos_visit_types` VALUES (1,'Sit down',1,1,10,'2026-08-10 20:05:29','2026-08-10 20:05:29'),(2,'Takeaway',0,1,20,'2026-08-10 20:05:29','2026-08-10 20:05:29'),(3,'Delivery',0,1,30,'2026-08-10 20:05:29','2026-08-10 20:05:29');
/*!40000 ALTER TABLE `pos_visit_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pos_void_events`
--

DROP TABLE IF EXISTS `pos_void_events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pos_void_events` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `void_type` enum('item','line','sale') NOT NULL,
  `group_id` char(36) DEFAULT NULL,
  `reason_id` int(10) unsigned DEFAULT NULL,
  `reason_code` varchar(24) DEFAULT NULL,
  `note` varchar(500) DEFAULT NULL,
  `document_id` int(10) unsigned DEFAULT NULL,
  `product_id` int(10) unsigned DEFAULT NULL,
  `product_code` varchar(64) DEFAULT NULL,
  `description` varchar(255) NOT NULL,
  `qty` decimal(12,3) NOT NULL DEFAULT 0.000,
  `value_incl` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `user_id` int(10) unsigned DEFAULT NULL,
  `user_name` varchar(120) DEFAULT NULL,
  `terminal_id` int(10) unsigned DEFAULT NULL,
  `terminal_code` varchar(32) DEFAULT NULL,
  `shift_id` int(10) unsigned DEFAULT NULL,
  `voided_at` datetime NOT NULL DEFAULT current_timestamp(),
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `ix_void_when` (`voided_at`,`void_type`),
  KEY `ix_void_reason` (`reason_id`,`voided_at`),
  KEY `ix_void_user` (`user_id`,`voided_at`),
  KEY `ix_void_terminal` (`terminal_id`,`voided_at`),
  KEY `ix_void_shift` (`shift_id`),
  KEY `ix_void_product` (`product_id`,`voided_at`),
  KEY `ix_void_group` (`group_id`),
  KEY `ix_void_document` (`document_id`),
  CONSTRAINT `pos_void_events_ibfk_1` FOREIGN KEY (`reason_id`) REFERENCES `sales_void_reasons` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pos_void_events`
--

LOCK TABLES `pos_void_events` WRITE;
/*!40000 ALTER TABLE `pos_void_events` DISABLE KEYS */;
INSERT INTO `pos_void_events` VALUES (1,'line',NULL,2,'WRONG-QTY',NULL,NULL,117,'DOGS001','New York Dog',1.000,69.0000,1,'Tiaan Smith',1,'TILL01',1,'2026-08-24 11:03:03','2026-08-24 13:03:03'),(2,'line',NULL,2,'WRONG-QTY',NULL,NULL,119,'DOGS003','Boerewors Dog',1.000,89.0000,1,'Tiaan Smith',1,'TILL01',1,'2026-08-24 11:03:06','2026-08-24 13:03:06'),(3,'line',NULL,2,'WRONG-QTY',NULL,NULL,120,'DOGS004','Bratwurst & Sauerkraut Dog',1.000,95.0000,1,'Tiaan Smith',1,'TILL01',1,'2026-08-24 11:03:12','2026-08-24 13:03:12'),(4,'item',NULL,6,'TRAINING',NULL,NULL,152,'DP24942714','Draft test item 24942714',1.000,0.0000,1,'Tiaan Smith',3,'TILL03',2,'2026-08-25 17:12:49','2026-08-25 19:12:49'),(5,'line',NULL,1,'WRONG-ITEM',NULL,NULL,162,'GDA24950513','Guard test A',1.000,0.0000,1,'Tiaan Smith',3,'TILL03',2,'2026-08-25 17:12:53','2026-08-25 19:12:53'),(6,'item',NULL,3,'DOUBLE-RUNG',NULL,NULL,112,'BURG004','Bacon & Cheddar Smash',1.000,119.0000,1,'Tiaan Smith',3,'TILL03',2,'2026-08-25 17:13:03','2026-08-25 19:13:03'),(7,'line',NULL,6,'TRAINING',NULL,NULL,119,'DOGS003','Boerewors Dog',1.000,89.0000,1,'Tiaan Smith',3,'TILL03',2,'2026-08-25 17:13:30','2026-08-25 19:13:30'),(8,'line',NULL,6,'TRAINING',NULL,NULL,187,'PRD00015','Refer test',1.000,0.0000,1,'Tiaan Smith',4,'TILL04',3,'2026-08-26 14:04:15','2026-08-26 16:04:15'),(9,'line',NULL,3,'DOUBLE-RUNG',NULL,NULL,187,'PRD00015','Refer test',1.000,250.0000,1,'Tiaan Smith',4,'TILL04',3,'2026-08-26 14:18:14','2026-08-26 16:18:14'),(10,'line',NULL,3,'DOUBLE-RUNG',NULL,NULL,190,'PRD00018','Refer 2 item',1.000,0.0000,1,'Tiaan Smith',4,'TILL04',3,'2026-08-26 14:20:19','2026-08-26 16:20:19'),(11,'line',NULL,6,'TRAINING',NULL,NULL,190,'PRD00018','Refer 2 item',1.000,80.0000,1,'Tiaan Smith',4,'TILL04',3,'2026-08-26 14:20:52','2026-08-26 16:20:52'),(12,'line',NULL,3,'DOUBLE-RUNG',NULL,NULL,190,'PRD00018','Refer 2 item',6.000,480.0000,1,'Tiaan Smith',4,'TILL04',3,'2026-08-26 14:22:57','2026-08-26 16:22:57');
/*!40000 ALTER TABLE `pos_void_events` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `price_schedule_lines`
--

DROP TABLE IF EXISTS `price_schedule_lines`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `price_schedule_lines` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `schedule_id` int(10) unsigned NOT NULL,
  `product_id` int(10) unsigned NOT NULL,
  `price_structure_id` int(10) unsigned NOT NULL,
  `new_price_incl` decimal(12,4) NOT NULL,
  `old_price_incl` decimal(12,4) DEFAULT NULL,
  `origin` enum('typed','rule') NOT NULL DEFAULT 'typed',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_sched_line` (`schedule_id`,`product_id`,`price_structure_id`),
  KEY `ix_sched_line_product` (`product_id`),
  KEY `fk_sched_line_structure` (`price_structure_id`),
  CONSTRAINT `price_schedule_lines_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  CONSTRAINT `price_schedule_lines_ibfk_2` FOREIGN KEY (`schedule_id`) REFERENCES `price_schedules` (`id`) ON DELETE CASCADE,
  CONSTRAINT `price_schedule_lines_ibfk_3` FOREIGN KEY (`price_structure_id`) REFERENCES `price_structures` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `price_schedule_lines`
--

LOCK TABLES `price_schedule_lines` WRITE;
/*!40000 ALTER TABLE `price_schedule_lines` DISABLE KEYS */;
INSERT INTO `price_schedule_lines` VALUES (1,1,7,1,89.0000,89.0000,'typed'),(2,1,8,1,129.0000,129.0000,'typed'),(3,1,9,1,139.0000,139.0000,'typed'),(4,1,10,1,132.0000,132.0000,'typed'),(5,1,11,1,125.0000,125.0000,'typed'),(6,1,12,1,119.0000,119.0000,'typed'),(7,1,13,1,115.0000,115.0000,'typed'),(8,1,14,1,122.0000,122.0000,'typed'),(9,1,15,1,175.0000,175.0000,'typed'),(10,1,16,1,149.0000,149.0000,'typed'),(11,1,17,1,65.0000,65.0000,'typed'),(12,1,18,1,155.0000,155.0000,'typed');
/*!40000 ALTER TABLE `price_schedule_lines` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `price_schedules`
--

DROP TABLE IF EXISTS `price_schedules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `price_schedules` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(120) NOT NULL,
  `effective_at` varchar(16) NOT NULL DEFAULT '',
  `status` enum('draft','armed','applied','cancelled') NOT NULL DEFAULT 'draft',
  `applied_at` datetime DEFAULT NULL,
  `applied_count` int(10) unsigned NOT NULL DEFAULT 0,
  `note` varchar(400) NOT NULL DEFAULT '',
  `fail_count` int(10) unsigned NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `created_by` varchar(120) NOT NULL DEFAULT '',
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_by` varchar(120) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `ix_sched_due` (`status`,`effective_at`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `price_schedules`
--

LOCK TABLES `price_schedules` WRITE;
/*!40000 ALTER TABLE `price_schedules` DISABLE KEYS */;
INSERT INTO `price_schedules` VALUES (1,'Tiaan test','2026-08-11T06:00','draft',NULL,0,'',0,'2026-08-10 14:15:30','Tiaan Smith','2026-08-10 14:15:47','Tiaan Smith'),(2,'Test','2026-08-25T08:00','draft',NULL,0,'',0,'2026-08-24 13:05:49','Tiaan Smith','2026-08-24 13:06:05','Tiaan Smith');
/*!40000 ALTER TABLE `price_schedules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `price_structures`
--

DROP TABLE IF EXISTS `price_structures`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `price_structures` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `position` int(11) NOT NULL,
  `name` varchar(60) NOT NULL,
  `is_default` tinyint(1) NOT NULL DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_price_position` (`position`),
  UNIQUE KEY `uq_price_name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `price_structures`
--

LOCK TABLES `price_structures` WRITE;
/*!40000 ALTER TABLE `price_structures` DISABLE KEYS */;
INSERT INTO `price_structures` VALUES (1,1,'Retail',1,1,'2026-08-04 14:12:30','2026-08-04 14:12:30');
/*!40000 ALTER TABLE `price_structures` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_barcodes`
--

DROP TABLE IF EXISTS `product_barcodes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `product_barcodes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `product_id` int(10) unsigned NOT NULL,
  `barcode` varchar(48) NOT NULL,
  `note` varchar(60) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_pbarcode` (`barcode`),
  KEY `ix_pbarcode_product` (`product_id`),
  CONSTRAINT `product_barcodes_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_barcodes`
--

LOCK TABLES `product_barcodes` WRITE;
/*!40000 ALTER TABLE `product_barcodes` DISABLE KEYS */;
/*!40000 ALTER TABLE `product_barcodes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_batches`
--

DROP TABLE IF EXISTS `product_batches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `product_batches` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `product_id` int(10) unsigned NOT NULL,
  `location_id` int(10) unsigned NOT NULL,
  `batch_no` varchar(64) NOT NULL DEFAULT '',
  `expiry_date` date DEFAULT NULL,
  `qty_received` decimal(12,3) NOT NULL DEFAULT 0.000,
  `qty_remaining` decimal(12,3) NOT NULL DEFAULT 0.000,
  `cost_excl` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `received_doc_id` int(10) unsigned DEFAULT NULL,
  `received_at` datetime DEFAULT NULL,
  `note` varchar(190) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_batch_identity` (`product_id`,`location_id`,`batch_no`),
  KEY `ix_batch_fefo` (`product_id`,`location_id`,`expiry_date`),
  KEY `ix_batch_expiry` (`expiry_date`),
  KEY `ix_batch_received_doc` (`received_doc_id`),
  KEY `fk_batch_location` (`location_id`),
  CONSTRAINT `product_batches_ibfk_1` FOREIGN KEY (`location_id`) REFERENCES `stock_locations` (`id`),
  CONSTRAINT `product_batches_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_batches`
--

LOCK TABLES `product_batches` WRITE;
/*!40000 ALTER TABLE `product_batches` DISABLE KEYS */;
INSERT INTO `product_batches` VALUES (1,170,1,'BATCH001','2026-08-31',10.000,9.000,12.0000,27,'2026-08-24 12:49:22',NULL,'2026-08-24 12:49:22','2026-08-24 12:50:09');
/*!40000 ALTER TABLE `product_batches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_images`
--

DROP TABLE IF EXISTS `product_images`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `product_images` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `product_id` int(10) unsigned NOT NULL,
  `stored_name` varchar(190) NOT NULL,
  `filename` varchar(255) NOT NULL,
  `mime_type` varchar(40) NOT NULL,
  `size_bytes` bigint(20) unsigned NOT NULL DEFAULT 0,
  `alt_text` varchar(190) NOT NULL DEFAULT '',
  `sort_order` int(11) NOT NULL DEFAULT 0,
  `is_primary` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_pimg_stored` (`stored_name`),
  KEY `ix_pimg_product` (`product_id`,`sort_order`,`id`),
  KEY `ix_pimg_primary` (`product_id`,`is_primary`),
  CONSTRAINT `product_images_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=112 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_images`
--

LOCK TABLES `product_images` WRITE;
/*!40000 ALTER TABLE `product_images` DISABLE KEYS */;
INSERT INTO `product_images` VALUES (60,7,'c4b68323-dc38-4510-9611-03d0303b1002.jpg','SB-101.jpg','image/jpeg',84708,'Classic smash burger with melted cheese',0,1,'2026-08-09 09:53:46'),(61,8,'c86dbe77-1b10-498c-84c6-70e050df93e9.jpg','SB-102.jpg','image/jpeg',130340,'Double smash cheeseburger stacked high',0,1,'2026-08-09 09:53:46'),(62,9,'4cadf174-349e-4142-acfb-af19de399e33.jpg','SB-103.jpg','image/jpeg',130914,'Bacon and blue cheese burger',0,1,'2026-08-09 09:53:46'),(63,10,'2138639d-edc5-4aec-a4bb-9976f9d57595.jpg','SB-104.jpg','image/jpeg',96060,'Mushroom and swiss cheese burger',0,1,'2026-08-09 09:53:46'),(64,11,'23135823-1d1a-4aed-8444-696c5cece0c8.jpg','SB-105.jpg','image/jpeg',110619,'Spicy jalapeno burger with chilli',0,1,'2026-08-09 09:53:46'),(65,12,'72a3d6be-cef9-47c5-9c17-536bd06d44e3.jpg','SB-106.jpg','image/jpeg',128498,'Crispy fried chicken burger',0,1,'2026-08-09 09:53:46'),(66,13,'178a7914-010d-4909-9a8f-383e873742ee.jpg','SB-107.jpg','image/jpeg',91096,'Buttermilk chicken burger with slaw',0,1,'2026-08-09 09:53:46'),(67,14,'a2792d92-0765-4167-ad34-8941ed7994da.jpg','SB-108.jpg','image/jpeg',78268,'Plant based veggie burger',0,1,'2026-08-09 09:53:46'),(68,15,'331f1b7f-fdc3-478a-bc38-852f069672a9.jpg','SB-109.jpg','image/jpeg',106006,'Triple patty stacked burger',0,1,'2026-08-09 09:53:46'),(69,16,'a7b061f2-93c3-479f-9c6c-4ba025e9513d.jpg','SB-110.jpg','image/jpeg',110633,'Truffle burger with caramelised onion',0,1,'2026-08-09 09:53:46'),(70,17,'31636f15-e347-4f25-923a-d338ebf29d49.jpg','SB-111.jpg','image/jpeg',107364,'Small kids burger with fries',0,1,'2026-08-09 09:53:46'),(71,18,'bee443b4-9a6a-4b8b-affa-26b86095c40e.jpg','SB-112.jpg','image/jpeg',66550,'BBQ brisket burger with sauce',0,1,'2026-08-09 09:53:46'),(72,19,'6dd15f55-aa44-4fa7-a1f1-7e94aeb602e6.jpg','HD-201.jpg','image/jpeg',121645,'New York style hotdog with mustard',0,1,'2026-08-09 09:53:46'),(73,20,'f8dde2c0-c933-46eb-b1ea-520938b949e7.jpg','HD-202.jpg','image/jpeg',101448,'Chilli cheese loaded hotdog',0,1,'2026-08-09 09:53:46'),(74,21,'66bad127-d1d8-42ed-a3e5-610d71ae7baa.jpg','HD-203.jpg','image/jpeg',198374,'Loaded hotdog with fresh toppings',0,1,'2026-08-09 09:53:46'),(75,22,'65df0a7c-037e-45b3-856b-7967cd664a77.jpg','HD-204.jpg','image/jpeg',145464,'Golden crispy fried chicken strips',0,1,'2026-08-09 09:53:46'),(76,23,'48bd04fb-042b-47e2-8bab-1cd95814974f.jpg','HD-205.jpg','image/jpeg',115785,'Toasted sub roll with steak and salad',0,1,'2026-08-09 09:53:46'),(77,24,'e4b214a1-815a-4066-91b2-9e574c2d0b03.jpg','HD-206.jpg','image/jpeg',109771,'Fried chicken and chips basket',0,1,'2026-08-09 09:53:46'),(78,27,'f3e07d04-0faf-4133-a65e-12c11c4181b4.jpg','PZ-301.jpg','image/jpeg',185527,'Margherita pizza with fresh basil',0,1,'2026-08-09 09:53:46'),(79,28,'d4f4358b-50fc-4925-8094-06f2c7db8e5c.jpg','PZ-302.jpg','image/jpeg',216484,'Pepperoni pizza fresh from the oven',0,1,'2026-08-09 09:53:46'),(80,29,'7074f11a-cc9c-41a7-8af4-537bd851a185.jpg','PZ-303.jpg','image/jpeg',178645,'Four cheese pizza melted golden',0,1,'2026-08-09 09:53:46'),(81,30,'1d330c4d-0447-46a9-bc8c-8d6fef2dbd86.jpg','PZ-304.jpg','image/jpeg',192368,'BBQ chicken and bacon pizza',0,1,'2026-08-09 09:53:46'),(82,31,'fd22e5db-616f-490d-a009-ceaae09ad644.jpg','PZ-305.jpg','image/jpeg',127933,'Meat lovers pizza loaded with toppings',0,1,'2026-08-09 09:53:46'),(83,32,'cf9af665-bb73-4b94-8aba-8abf53919e4e.jpg','PZ-306.jpg','image/jpeg',138906,'Wild mushroom and truffle pizza',0,1,'2026-08-09 09:53:46'),(84,33,'306b921e-6d86-4b0e-af53-b8dea9cafc96.jpg','PZ-307.jpg','image/jpeg',159755,'Hawaiian pizza with ham and pineapple',0,1,'2026-08-09 09:53:46'),(85,34,'922f7c5a-4040-4743-b397-4fe89c118791.jpg','PZ-308.jpg','image/jpeg',203224,'Spicy salami diavola pizza',0,1,'2026-08-09 09:53:46'),(86,35,'a7e6c648-3888-46bc-9cc7-8af3ba647bed.jpg','PZ-309.jpg','image/jpeg',165754,'Vegetable garden pizza',0,1,'2026-08-09 09:53:46'),(87,36,'c3274aa4-0e52-432b-8c43-53fb63d06843.jpg','PZ-310.jpg','image/jpeg',206954,'Prosciutto and rocket pizza',0,1,'2026-08-09 09:53:46'),(88,37,'69c03c29-e6fd-46b7-937d-eacba8fbf9f9.jpg','SD-401.jpg','image/jpeg',107478,'Golden skin on fries',0,1,'2026-08-09 09:53:46'),(89,38,'55eb8e23-2991-442c-b1e7-1b33f25df587.jpg','SD-402.jpg','image/jpeg',58798,'Cheese loaded fries',0,1,'2026-08-09 09:53:46'),(90,39,'1b1439d0-b6ce-4457-a150-b778ac34eae5.jpg','SD-403.jpg','image/jpeg',89311,'Seasoned peri-peri fries',0,1,'2026-08-09 09:53:46'),(91,40,'73ade0a0-8b82-4a4a-9b03-a9823e7e0ba9.jpg','SD-404.jpg','image/jpeg',182045,'Cheesy chicken and vegetable bowl',0,1,'2026-08-09 09:53:46'),(92,41,'7890615a-3126-4512-90c5-471365ce8e2a.jpg','SD-405.jpg','image/jpeg',144168,'Crispy battered onion rings',0,1,'2026-08-09 09:53:46'),(93,42,'8fbc8221-3a38-4bb8-982b-38fa78bb763e.jpg','SD-406.jpg','image/jpeg',194415,'Buffalo chicken wings with sauce',0,1,'2026-08-09 09:53:46'),(94,43,'ad9de417-4c64-43e3-8c8d-6253be80bbb9.jpg','SD-407.jpg','image/jpeg',79105,'Fried mozzarella sticks',0,1,'2026-08-09 09:53:46'),(95,44,'1f815a84-d708-4b4a-9da1-c5af0efa4f3a.jpg','SD-408.jpg','image/jpeg',67408,'Regular fries with ketchup',0,1,'2026-08-09 09:53:46'),(96,45,'a0e57171-cfd5-4ce5-9e89-e94dcbf80cf4.jpg','DR-501.jpg','image/jpeg',68770,'Chilled can of Coca-Cola',0,1,'2026-08-09 09:53:46'),(97,46,'7b90d501-907d-4692-9e83-86e2d13f5341.jpg','DR-502.jpg','image/jpeg',150276,'Can of Coke Zero',0,1,'2026-08-09 09:53:46'),(98,47,'36bca9b6-a35a-494a-ac98-7b44b15db2d3.jpg','DR-503.jpg','image/jpeg',62966,'Bottle of orange Fanta',0,1,'2026-08-09 09:53:46'),(99,48,'e8841e56-f7b8-41d4-b2b7-66a67772fd4a.jpg','DR-504.jpg','image/jpeg',79817,'Can of Sprite lemonade',0,1,'2026-08-09 09:53:46'),(100,49,'07d95c97-ffe1-449b-8694-14b6f2d0fdc4.jpg','DR-505.jpg','image/jpeg',56239,'Tall glass of fresh orange juice',0,1,'2026-08-09 09:53:46'),(101,50,'bd4e5cdc-17a5-4180-b673-8a57156ef75d.jpg','DR-506.jpg','image/jpeg',51095,'Chilled can of energy drink',0,1,'2026-08-09 09:53:46'),(102,51,'d3858fcc-94c4-44e5-afe4-9e74e1fec344.jpg','DR-507.jpg','image/jpeg',90855,'Iced citrus cooler by a window',0,1,'2026-08-09 09:53:46'),(103,52,'3a2fe5e9-dd28-4800-be01-def2925cc071.jpg','DR-508.jpg','image/jpeg',83254,'Glass of iced lemon tea',0,1,'2026-08-09 09:53:46'),(104,53,'cab8f4e2-036b-44e6-9cce-4afe92610c27.jpg','DR-509.jpg','image/jpeg',90559,'Thick chocolate milkshake',0,1,'2026-08-09 09:53:46'),(105,54,'45cd369c-6a3c-4286-a4b4-bc35a73d891c.jpg','DR-510.jpg','image/jpeg',76821,'Caramel fudge milkshake with cream',0,1,'2026-08-09 09:53:46'),(106,55,'1d3e1017-d2a6-4e48-b7fb-39271f3dec58.jpg','DR-511.jpg','image/jpeg',48021,'Salted caramel milkshake',0,1,'2026-08-09 09:53:46'),(107,56,'ccd57345-e519-4b75-9282-3e3b256d9dd3.jpg','DR-512.jpg','image/jpeg',111271,'Freshly squeezed orange juice',0,1,'2026-08-09 09:53:46'),(108,57,'e8a6a82a-a4bf-45f2-8373-3f438f2f0baa.jpg','DS-601.jpg','image/jpeg',97965,'Chocolate brownie with fudge',0,1,'2026-08-09 09:53:46'),(109,58,'5d137899-189c-4cf0-bc4f-775ded9cfb52.jpg','DS-602.jpg','image/jpeg',73956,'Slice of New York cheesecake',0,1,'2026-08-09 09:53:46'),(110,59,'2cf3c0f0-33ba-48d2-95b8-a9ed61ee9c48.jpg','DS-603.jpg','image/jpeg',112324,'Warm churros with cinnamon sugar',0,1,'2026-08-09 09:53:46'),(111,60,'c9baf6a3-c68c-4a66-bd31-6c605e68faef.jpg','DS-604.jpg','image/jpeg',101820,'Soft serve ice cream sundae',0,1,'2026-08-09 09:53:46');
/*!40000 ALTER TABLE `product_images` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_instruction_groups`
--

DROP TABLE IF EXISTS `product_instruction_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `product_instruction_groups` (
  `product_id` int(10) unsigned NOT NULL,
  `group_id` int(10) unsigned NOT NULL,
  `sort_order` int(11) NOT NULL DEFAULT 0,
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`product_id`,`group_id`),
  KEY `ix_pig_group` (`group_id`),
  CONSTRAINT `product_instruction_groups_ibfk_1` FOREIGN KEY (`group_id`) REFERENCES `instruction_groups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `product_instruction_groups_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_instruction_groups`
--

LOCK TABLES `product_instruction_groups` WRITE;
/*!40000 ALTER TABLE `product_instruction_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `product_instruction_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_kitchen_printers`
--

DROP TABLE IF EXISTS `product_kitchen_printers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `product_kitchen_printers` (
  `product_id` int(10) unsigned NOT NULL,
  `printer_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`product_id`,`printer_id`),
  KEY `ix_pkp_printer` (`printer_id`),
  CONSTRAINT `product_kitchen_printers_ibfk_1` FOREIGN KEY (`printer_id`) REFERENCES `kitchen_printers` (`id`) ON DELETE CASCADE,
  CONSTRAINT `product_kitchen_printers_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_kitchen_printers`
--

LOCK TABLES `product_kitchen_printers` WRITE;
/*!40000 ALTER TABLE `product_kitchen_printers` DISABLE KEYS */;
/*!40000 ALTER TABLE `product_kitchen_printers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_location_stock`
--

DROP TABLE IF EXISTS `product_location_stock`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `product_location_stock` (
  `product_id` int(10) unsigned NOT NULL,
  `location_id` int(10) unsigned NOT NULL,
  `stock_on_hand` decimal(12,3) NOT NULL DEFAULT 0.000,
  `min_stock` decimal(12,3) NOT NULL DEFAULT 0.000,
  `max_stock` decimal(12,3) NOT NULL DEFAULT 0.000,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`product_id`,`location_id`),
  KEY `ix_pls_location` (`location_id`),
  CONSTRAINT `product_location_stock_ibfk_1` FOREIGN KEY (`location_id`) REFERENCES `stock_locations` (`id`),
  CONSTRAINT `product_location_stock_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_location_stock`
--

LOCK TABLES `product_location_stock` WRITE;
/*!40000 ALTER TABLE `product_location_stock` DISABLE KEYS */;
INSERT INTO `product_location_stock` VALUES (7,1,40.000,0.000,0.000,'2026-08-09 09:41:05','2026-08-09 09:41:05'),(8,1,40.000,0.000,0.000,'2026-08-09 09:41:05','2026-08-09 09:41:05'),(9,1,39.000,0.000,0.000,'2026-08-09 09:41:05','2026-08-09 10:14:30'),(10,1,40.000,0.000,0.000,'2026-08-09 09:41:05','2026-08-09 09:41:05'),(11,1,40.000,0.000,0.000,'2026-08-09 09:41:05','2026-08-09 09:41:05'),(12,1,40.000,0.000,0.000,'2026-08-09 09:41:05','2026-08-09 09:41:05'),(13,1,40.000,0.000,0.000,'2026-08-09 09:41:05','2026-08-09 09:41:05'),(14,1,40.000,0.000,0.000,'2026-08-09 09:41:05','2026-08-09 09:41:05'),(15,1,40.000,0.000,0.000,'2026-08-09 09:41:05','2026-08-09 09:41:05'),(16,1,3.000,0.000,0.000,'2026-08-09 09:41:05','2026-08-09 09:41:05'),(17,1,40.000,0.000,0.000,'2026-08-09 09:41:05','2026-08-09 09:41:05'),(18,1,39.000,0.000,0.000,'2026-08-09 09:41:05','2026-08-09 10:14:30'),(19,1,40.000,0.000,0.000,'2026-08-09 09:41:05','2026-08-09 09:41:05'),(20,1,40.000,0.000,0.000,'2026-08-09 09:41:06','2026-08-09 09:41:06'),(21,1,40.000,0.000,0.000,'2026-08-09 09:41:06','2026-08-09 09:41:06'),(22,1,40.000,0.000,0.000,'2026-08-09 09:41:06','2026-08-09 09:51:58'),(23,1,40.000,0.000,0.000,'2026-08-09 09:41:06','2026-08-09 09:41:06'),(24,1,40.000,0.000,0.000,'2026-08-09 09:41:06','2026-08-09 09:41:06'),(25,1,40.000,0.000,0.000,'2026-08-09 09:41:06','2026-08-09 09:41:06'),(26,1,40.000,0.000,0.000,'2026-08-09 09:41:06','2026-08-09 09:41:06'),(27,1,40.000,0.000,0.000,'2026-08-09 09:41:06','2026-08-09 09:41:06'),(28,1,39.000,0.000,0.000,'2026-08-09 09:41:06','2026-08-11 13:49:00'),(29,1,39.000,0.000,0.000,'2026-08-09 09:41:06','2026-08-11 13:49:00'),(30,1,38.000,0.000,0.000,'2026-08-09 09:41:06','2026-08-11 13:49:00'),(31,1,40.000,0.000,0.000,'2026-08-09 09:41:06','2026-08-09 09:41:06'),(32,1,40.000,0.000,0.000,'2026-08-09 09:41:06','2026-08-09 09:41:06'),(33,1,40.000,0.000,0.000,'2026-08-09 09:41:06','2026-08-09 09:41:06'),(34,1,40.000,0.000,0.000,'2026-08-09 09:41:06','2026-08-09 09:41:06'),(35,1,40.000,0.000,0.000,'2026-08-09 09:41:06','2026-08-09 09:41:06'),(36,1,39.000,0.000,0.000,'2026-08-09 09:41:06','2026-08-11 13:49:00'),(37,1,40.000,0.000,0.000,'2026-08-09 09:41:06','2026-08-09 09:41:06'),(38,1,40.000,0.000,0.000,'2026-08-09 09:41:06','2026-08-09 09:41:06'),(39,1,40.000,0.000,0.000,'2026-08-09 09:41:06','2026-08-09 09:41:06'),(40,1,40.000,0.000,0.000,'2026-08-09 09:41:06','2026-08-09 09:41:06'),(41,1,40.000,0.000,0.000,'2026-08-09 09:41:06','2026-08-09 09:41:06'),(42,1,40.000,0.000,0.000,'2026-08-09 09:41:06','2026-08-09 09:41:06'),(43,1,40.000,0.000,0.000,'2026-08-09 09:41:06','2026-08-09 09:41:06'),(44,1,40.000,0.000,0.000,'2026-08-09 09:41:06','2026-08-09 09:41:06'),(45,1,40.000,0.000,0.000,'2026-08-09 09:41:06','2026-08-09 09:41:06'),(46,1,40.000,0.000,0.000,'2026-08-09 09:41:06','2026-08-09 09:41:06'),(47,1,40.000,0.000,0.000,'2026-08-09 09:41:06','2026-08-09 09:41:06'),(48,1,40.000,0.000,0.000,'2026-08-09 09:41:06','2026-08-09 09:41:06'),(49,1,40.000,0.000,0.000,'2026-08-09 09:41:06','2026-08-09 09:51:58'),(50,1,40.000,0.000,0.000,'2026-08-09 09:41:06','2026-08-09 09:41:06'),(51,1,40.000,0.000,0.000,'2026-08-09 09:41:06','2026-08-09 09:41:06'),(52,1,40.000,0.000,0.000,'2026-08-09 09:41:06','2026-08-09 09:41:06'),(53,1,40.000,0.000,0.000,'2026-08-09 09:41:06','2026-08-09 09:41:06'),(54,1,40.000,0.000,0.000,'2026-08-09 09:41:06','2026-08-09 09:41:06'),(55,1,40.000,0.000,0.000,'2026-08-09 09:41:06','2026-08-09 09:41:06'),(56,1,40.000,0.000,0.000,'2026-08-09 09:41:06','2026-08-09 09:41:06'),(57,1,39.000,0.000,0.000,'2026-08-09 09:41:06','2026-08-09 10:14:30'),(58,1,40.000,0.000,0.000,'2026-08-09 09:41:06','2026-08-09 09:41:06'),(59,1,40.000,0.000,0.000,'2026-08-09 09:41:06','2026-08-09 09:41:06'),(60,1,40.000,0.000,0.000,'2026-08-09 09:41:06','2026-08-09 09:41:06'),(109,1,30.000,0.000,0.000,'2026-08-11 13:20:53','2026-08-11 13:20:53'),(110,1,5.000,0.000,0.000,'2026-08-11 13:20:53','2026-08-26 16:47:38'),(111,1,50.000,0.000,0.000,'2026-08-11 13:20:53','2026-08-26 16:47:38'),(112,1,50.000,0.000,0.000,'2026-08-11 13:20:53','2026-08-26 16:47:38'),(113,1,50.000,0.000,0.000,'2026-08-11 13:20:53','2026-08-26 16:47:38'),(114,1,550.000,0.000,0.000,'2026-08-11 13:20:53','2026-08-26 16:47:38'),(115,1,50.000,0.000,0.000,'2026-08-11 13:20:53','2026-08-26 16:47:38'),(116,1,72.000,0.000,0.000,'2026-08-11 13:20:53','2026-08-11 13:50:30'),(117,1,30.000,0.000,0.000,'2026-08-11 13:20:53','2026-08-11 13:20:53'),(118,1,36.000,0.000,0.000,'2026-08-11 13:20:53','2026-08-11 13:20:53'),(119,1,42.000,0.000,0.000,'2026-08-11 13:20:53','2026-08-11 13:20:53'),(120,1,48.000,0.000,0.000,'2026-08-11 13:20:53','2026-08-11 13:50:30'),(121,1,54.000,0.000,0.000,'2026-08-11 13:20:53','2026-08-11 13:20:53'),(122,1,60.000,0.000,0.000,'2026-08-11 13:20:53','2026-08-11 13:20:53'),(123,1,30.000,0.000,0.000,'2026-08-11 13:20:53','2026-08-11 13:20:53'),(124,1,36.000,0.000,0.000,'2026-08-11 13:20:53','2026-08-11 13:20:53'),(125,1,42.000,0.000,0.000,'2026-08-11 13:20:53','2026-08-11 13:20:53'),(126,1,48.000,0.000,0.000,'2026-08-11 13:20:53','2026-08-11 13:20:53'),(127,1,52.000,0.000,0.000,'2026-08-11 13:20:53','2026-08-25 19:19:45'),(128,1,60.000,0.000,0.000,'2026-08-11 13:20:53','2026-08-11 13:20:53'),(129,1,66.000,0.000,0.000,'2026-08-11 13:20:53','2026-08-11 13:20:53'),(130,1,72.000,0.000,0.000,'2026-08-11 13:20:53','2026-08-11 13:20:53'),(131,1,30.000,0.000,0.000,'2026-08-11 13:20:53','2026-08-11 13:20:53'),(132,1,36.000,0.000,0.000,'2026-08-11 13:20:53','2026-08-11 13:20:53'),(133,1,42.000,0.000,0.000,'2026-08-11 13:20:53','2026-08-11 13:20:53'),(134,1,47.000,0.000,0.000,'2026-08-11 13:20:53','2026-08-31 10:55:39'),(135,1,54.000,0.000,0.000,'2026-08-11 13:20:53','2026-08-11 13:20:53'),(136,1,59.000,0.000,0.000,'2026-08-11 13:20:53','2026-08-31 10:55:39'),(137,1,60.000,0.000,0.000,'2026-08-11 13:20:53','2026-08-11 13:20:53'),(138,1,72.000,0.000,0.000,'2026-08-11 13:20:53','2026-08-11 13:20:53'),(139,1,83.000,0.000,0.000,'2026-08-11 13:20:53','2026-08-26 16:51:23'),(140,1,95.000,0.000,0.000,'2026-08-11 13:20:53','2026-08-26 16:51:23'),(141,1,103.000,0.000,0.000,'2026-08-11 13:20:53','2026-08-26 15:34:12'),(142,1,120.000,0.000,0.000,'2026-08-11 13:20:53','2026-08-11 13:20:53'),(143,1,132.000,0.000,0.000,'2026-08-11 13:20:53','2026-08-11 13:20:53'),(144,1,72.000,0.000,0.000,'2026-08-11 13:20:53','2026-08-11 13:20:53'),(145,1,30.000,0.000,0.000,'2026-08-11 13:20:53','2026-08-11 13:20:53'),(146,1,36.000,0.000,0.000,'2026-08-11 13:20:53','2026-08-11 13:20:53'),(147,1,42.000,0.000,0.000,'2026-08-11 13:20:53','2026-08-11 13:20:53'),(148,1,48.000,0.000,0.000,'2026-08-11 13:20:53','2026-08-11 13:20:53'),(149,1,100.000,0.000,0.000,'2026-08-12 10:54:36','2026-08-12 10:54:37'),(152,1,100.000,0.000,0.000,'2026-08-12 10:55:43','2026-08-12 10:55:43'),(162,1,100.000,0.000,0.000,'2026-08-12 10:55:50','2026-08-12 10:55:50'),(164,1,99.000,0.000,0.000,'2026-08-12 10:55:50','2026-09-01 11:04:57'),(165,1,-1.000,0.000,0.000,'2026-09-01 11:04:57','2026-09-01 11:04:57'),(166,1,101.000,0.000,0.000,'2026-08-12 10:55:50','2026-08-12 10:55:50'),(167,1,100.000,0.000,0.000,'2026-08-12 10:55:50','2026-08-12 10:55:50'),(169,1,100.000,0.000,0.000,'2026-08-12 10:55:51','2026-08-12 10:55:51'),(170,1,9.000,0.000,0.000,'2026-08-24 12:49:22','2026-08-24 12:50:09'),(171,1,0.000,0.000,0.000,'2026-08-25 19:30:32','2026-08-25 19:30:32'),(171,2,0.000,0.000,0.000,'2026-08-25 19:30:32','2026-08-25 19:30:32'),(171,3,0.000,0.000,0.000,'2026-08-25 19:30:32','2026-08-25 19:30:32'),(186,1,0.000,0.000,0.000,'2026-08-26 15:13:40','2026-08-26 15:13:40'),(186,2,0.000,0.000,0.000,'2026-08-26 15:13:40','2026-08-26 15:13:40'),(186,3,0.000,0.000,0.000,'2026-08-26 15:13:40','2026-08-26 15:13:40'),(187,1,0.000,0.000,0.000,'2026-08-26 15:47:45','2026-08-26 15:47:45'),(187,2,0.000,0.000,0.000,'2026-08-26 15:47:45','2026-08-26 15:47:45'),(187,3,0.000,0.000,0.000,'2026-08-26 15:47:45','2026-08-26 15:47:45'),(189,1,10.000,0.000,0.000,'2026-08-26 16:03:10','2026-08-26 16:03:10'),(190,1,0.000,0.000,0.000,'2026-08-26 16:01:46','2026-08-26 16:01:46'),(190,2,0.000,0.000,0.000,'2026-08-26 16:01:46','2026-08-26 16:01:46'),(190,3,0.000,0.000,0.000,'2026-08-26 16:01:46','2026-08-26 16:01:46'),(192,1,9.000,0.000,0.000,'2026-08-26 16:19:05','2026-08-26 16:51:23');
/*!40000 ALTER TABLE `product_location_stock` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_price_history`
--

DROP TABLE IF EXISTS `product_price_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `product_price_history` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `product_id` int(10) unsigned NOT NULL,
  `price_structure_id` int(10) unsigned NOT NULL,
  `old_price_incl` decimal(12,4) DEFAULT NULL,
  `new_price_incl` decimal(12,4) DEFAULT NULL,
  `source` varchar(24) NOT NULL DEFAULT 'editor',
  `source_doc_id` int(10) unsigned DEFAULT NULL,
  `user_name` varchar(120) NOT NULL DEFAULT '',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `ix_pph_product` (`product_id`,`created_at`),
  KEY `ix_pph_structure` (`product_id`,`price_structure_id`,`created_at`),
  KEY `fk_pph_structure` (`price_structure_id`),
  CONSTRAINT `product_price_history_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  CONSTRAINT `product_price_history_ibfk_2` FOREIGN KEY (`price_structure_id`) REFERENCES `price_structures` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_price_history`
--

LOCK TABLES `product_price_history` WRITE;
/*!40000 ALTER TABLE `product_price_history` DISABLE KEYS */;
INSERT INTO `product_price_history` VALUES (1,170,1,NULL,0.0000,'editor',NULL,'Tiaan Smith','2026-08-24 12:48:34'),(2,170,1,0.0000,20.0000,'grv',27,'Tiaan Smith','2026-08-24 12:49:22'),(3,171,1,NULL,60.0000,'editor',NULL,'Tiaan Smith','2026-08-25 19:26:40'),(4,186,1,NULL,1.0000,'editor',NULL,'Tiaan Smith','2026-08-26 15:13:27'),(5,187,1,NULL,0.0000,'editor',NULL,'Tiaan Smith','2026-08-26 15:47:02'),(6,190,1,NULL,0.0000,'editor',NULL,'Tiaan Smith','2026-08-26 16:01:30'),(7,187,1,0.0000,250.0000,'editor',NULL,'Tiaan Smith','2026-08-26 16:04:33'),(8,190,1,0.0000,80.0000,'editor',NULL,'Tiaan Smith','2026-08-26 16:19:40');
/*!40000 ALTER TABLE `product_price_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_prices`
--

DROP TABLE IF EXISTS `product_prices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `product_prices` (
  `product_id` int(10) unsigned NOT NULL,
  `price_structure_id` int(10) unsigned NOT NULL,
  `selling_price_incl` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`product_id`,`price_structure_id`),
  KEY `ix_pp_structure` (`price_structure_id`),
  CONSTRAINT `product_prices_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  CONSTRAINT `product_prices_ibfk_2` FOREIGN KEY (`price_structure_id`) REFERENCES `price_structures` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_prices`
--

LOCK TABLES `product_prices` WRITE;
/*!40000 ALTER TABLE `product_prices` DISABLE KEYS */;
INSERT INTO `product_prices` VALUES (109,1,79.0000,'2026-08-11 13:20:53'),(110,1,109.0000,'2026-08-11 13:20:53'),(111,1,139.0000,'2026-08-11 13:20:53'),(112,1,119.0000,'2026-08-11 13:20:53'),(113,1,115.0000,'2026-08-11 13:20:53'),(114,1,112.0000,'2026-08-11 13:20:53'),(115,1,105.0000,'2026-08-11 13:20:53'),(116,1,99.0000,'2026-08-11 13:20:53'),(117,1,69.0000,'2026-08-11 13:20:53'),(118,1,85.0000,'2026-08-11 13:20:53'),(119,1,89.0000,'2026-08-11 13:20:53'),(120,1,95.0000,'2026-08-11 13:20:53'),(121,1,92.0000,'2026-08-11 13:20:53'),(122,1,55.0000,'2026-08-11 13:20:53'),(123,1,99.0000,'2026-08-11 13:20:53'),(124,1,119.0000,'2026-08-11 13:20:53'),(125,1,125.0000,'2026-08-11 13:20:53'),(126,1,135.0000,'2026-08-11 13:20:53'),(127,1,139.0000,'2026-08-11 13:20:53'),(128,1,159.0000,'2026-08-11 13:20:53'),(129,1,115.0000,'2026-08-11 13:20:53'),(130,1,79.0000,'2026-08-11 13:20:53'),(131,1,35.0000,'2026-08-11 13:20:53'),(132,1,49.0000,'2026-08-11 13:20:53'),(133,1,69.0000,'2026-08-11 13:20:53'),(134,1,75.0000,'2026-08-11 13:20:53'),(135,1,45.0000,'2026-08-11 13:20:53'),(136,1,28.0000,'2026-08-11 13:20:53'),(137,1,22.0000,'2026-08-11 13:20:53'),(138,1,22.0000,'2026-08-11 13:20:53'),(139,1,22.0000,'2026-08-11 13:20:53'),(140,1,22.0000,'2026-08-11 13:20:53'),(141,1,28.0000,'2026-08-11 13:20:53'),(142,1,38.0000,'2026-08-11 13:20:53'),(143,1,26.0000,'2026-08-11 13:20:53'),(144,1,45.0000,'2026-08-11 13:20:53'),(145,1,49.0000,'2026-08-11 13:20:53'),(146,1,25.0000,'2026-08-11 13:20:53'),(147,1,59.0000,'2026-08-11 13:20:53'),(148,1,55.0000,'2026-08-11 13:20:53'),(170,1,20.0000,'2026-08-24 12:49:22'),(171,1,60.0000,'2026-08-25 19:26:40'),(186,1,1.0000,'2026-08-26 15:13:27'),(187,1,250.0000,'2026-08-26 16:04:33'),(190,1,80.0000,'2026-08-26 16:19:40');
/*!40000 ALTER TABLE `product_prices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_recipes`
--

DROP TABLE IF EXISTS `product_recipes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `product_recipes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` int(10) unsigned NOT NULL,
  `component_id` int(10) unsigned NOT NULL,
  `qty` decimal(12,3) NOT NULL DEFAULT 1.000,
  `wastage_pct` decimal(6,3) NOT NULL DEFAULT 0.000,
  `position` smallint(5) unsigned NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_recipe_line` (`parent_id`,`component_id`),
  KEY `ix_recipe_component` (`component_id`),
  CONSTRAINT `product_recipes_ibfk_1` FOREIGN KEY (`component_id`) REFERENCES `products` (`id`),
  CONSTRAINT `product_recipes_ibfk_2` FOREIGN KEY (`parent_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_recipes`
--

LOCK TABLES `product_recipes` WRITE;
/*!40000 ALTER TABLE `product_recipes` DISABLE KEYS */;
/*!40000 ALTER TABLE `product_recipes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_refers`
--

DROP TABLE IF EXISTS `product_refers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `product_refers` (
  `product_id` int(10) unsigned NOT NULL,
  `target_id` int(10) unsigned NOT NULL,
  `factor` decimal(12,3) NOT NULL DEFAULT 1.000,
  `method` enum('normal','subtract') NOT NULL DEFAULT 'subtract',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`product_id`),
  KEY `ix_refer_target` (`target_id`),
  KEY `ix_refer_target_method` (`target_id`,`method`),
  CONSTRAINT `product_refers_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  CONSTRAINT `product_refers_ibfk_2` FOREIGN KEY (`target_id`) REFERENCES `products` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_refers`
--

LOCK TABLES `product_refers` WRITE;
/*!40000 ALTER TABLE `product_refers` DISABLE KEYS */;
INSERT INTO `product_refers` VALUES (184,171,6.000,'normal','2026-08-25 19:31:21','2026-08-25 19:31:21'),(185,184,4.000,'normal','2026-08-25 19:31:21','2026-08-25 19:31:21'),(191,190,6.000,'normal','2026-08-26 16:01:44','2026-08-26 16:01:44'),(192,191,2.000,'normal','2026-08-26 16:01:44','2026-08-26 16:01:44');
/*!40000 ALTER TABLE `product_refers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_reviews`
--

DROP TABLE IF EXISTS `product_reviews`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `product_reviews` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `product_id` int(10) unsigned NOT NULL,
  `rating` tinyint(3) unsigned NOT NULL DEFAULT 5,
  `title` varchar(120) NOT NULL DEFAULT '',
  `body` varchar(1000) NOT NULL DEFAULT '',
  `author_name` varchar(80) NOT NULL DEFAULT '',
  `order_number` varchar(32) NOT NULL DEFAULT '',
  `status` enum('pending','approved','rejected') NOT NULL DEFAULT 'pending',
  `decline_reason` varchar(190) NOT NULL DEFAULT '',
  `submitted_at` datetime NOT NULL DEFAULT current_timestamp(),
  `moderated_at` datetime DEFAULT NULL,
  `moderated_by` varchar(120) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `ix_review_status` (`status`,`submitted_at`),
  KEY `ix_review_product` (`product_id`,`status`),
  CONSTRAINT `product_reviews_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  CONSTRAINT `CONSTRAINT_1` CHECK (`rating` between 1 and 5)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_reviews`
--

LOCK TABLES `product_reviews` WRITE;
/*!40000 ALTER TABLE `product_reviews` DISABLE KEYS */;
/*!40000 ALTER TABLE `product_reviews` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_serials`
--

DROP TABLE IF EXISTS `product_serials`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `product_serials` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `product_id` int(10) unsigned NOT NULL,
  `location_id` int(10) unsigned DEFAULT NULL,
  `serial` varchar(64) NOT NULL,
  `status` enum('in_stock','sold','returned','written_off','returned_to_supplier') NOT NULL DEFAULT 'in_stock',
  `received_doc_id` int(10) unsigned DEFAULT NULL,
  `received_at` datetime DEFAULT NULL,
  `cost_excl` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `sold_doc_id` int(10) unsigned DEFAULT NULL,
  `sold_line_id` int(10) unsigned DEFAULT NULL,
  `sold_at` datetime DEFAULT NULL,
  `customer_id` int(10) unsigned DEFAULT NULL,
  `warranty_until` date DEFAULT NULL,
  `note` varchar(190) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_serial_product` (`product_id`,`serial`),
  KEY `ix_serial_status` (`product_id`,`status`),
  KEY `ix_serial_number` (`serial`),
  KEY `ix_serial_sold_doc` (`sold_doc_id`),
  KEY `ix_serial_location` (`location_id`,`status`),
  KEY `ix_serial_product_location` (`product_id`,`location_id`,`status`),
  CONSTRAINT `product_serials_ibfk_1` FOREIGN KEY (`location_id`) REFERENCES `stock_locations` (`id`),
  CONSTRAINT `product_serials_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  CONSTRAINT `product_serials_ibfk_3` FOREIGN KEY (`sold_doc_id`) REFERENCES `sales_documents` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_serials`
--

LOCK TABLES `product_serials` WRITE;
/*!40000 ALTER TABLE `product_serials` DISABLE KEYS */;
/*!40000 ALTER TABLE `product_serials` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_share_settings`
--

DROP TABLE IF EXISTS `product_share_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `product_share_settings` (
  `product_code` varchar(48) NOT NULL,
  `available` tinyint(1) NOT NULL DEFAULT 1,
  `shares_cost` tinyint(1) NOT NULL DEFAULT 1,
  `shares_selling` tinyint(1) NOT NULL DEFAULT 1,
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`product_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_share_settings`
--

LOCK TABLES `product_share_settings` WRITE;
/*!40000 ALTER TABLE `product_share_settings` DISABLE KEYS */;
INSERT INTO `product_share_settings` VALUES ('6529',0,1,1,'2026-08-09 12:00:56'),('CC500',0,1,1,'2026-08-10 14:04:38');
/*!40000 ALTER TABLE `product_share_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_suppliers`
--

DROP TABLE IF EXISTS `product_suppliers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `product_suppliers` (
  `product_id` int(10) unsigned NOT NULL,
  `supplier_id` int(10) unsigned NOT NULL,
  `supplier_code` varchar(48) DEFAULT NULL,
  `last_cost` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `pack_size` decimal(12,3) NOT NULL DEFAULT 1.000,
  `is_preferred` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`product_id`,`supplier_id`),
  KEY `ix_prodsupp_supplier` (`supplier_id`),
  KEY `ix_prodsupp_code` (`supplier_code`),
  CONSTRAINT `product_suppliers_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_suppliers`
--

LOCK TABLES `product_suppliers` WRITE;
/*!40000 ALTER TABLE `product_suppliers` DISABLE KEYS */;
INSERT INTO `product_suppliers` VALUES (149,4,NULL,10.0000,1.000,0,'2026-08-12 10:54:36','2026-08-12 10:54:36'),(152,7,NULL,10.0000,1.000,0,'2026-08-12 10:55:43','2026-08-12 10:55:43'),(162,9,NULL,10.0000,1.000,0,'2026-08-12 10:55:50','2026-08-12 10:55:50'),(164,9,NULL,10.0000,1.000,0,'2026-08-12 10:55:50','2026-08-12 10:55:50'),(166,9,NULL,10.0000,1.000,0,'2026-08-12 10:55:50','2026-08-12 10:55:50'),(167,9,NULL,10.0000,1.000,0,'2026-08-12 10:55:50','2026-08-12 10:55:50'),(169,9,NULL,10.0000,1.000,0,'2026-08-12 10:55:51','2026-08-12 10:55:51'),(170,7,NULL,12.0000,1.000,0,'2026-08-24 12:49:22','2026-08-24 12:49:22');
/*!40000 ALTER TABLE `product_suppliers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_variant_axes`
--

DROP TABLE IF EXISTS `product_variant_axes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `product_variant_axes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `product_id` int(10) unsigned NOT NULL,
  `position` tinyint(3) unsigned NOT NULL,
  `label` varchar(60) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_variant_axis` (`product_id`,`position`),
  CONSTRAINT `product_variant_axes_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_variant_axes`
--

LOCK TABLES `product_variant_axes` WRITE;
/*!40000 ALTER TABLE `product_variant_axes` DISABLE KEYS */;
/*!40000 ALTER TABLE `product_variant_axes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `products` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(48) NOT NULL,
  `barcode` varchar(64) DEFAULT NULL,
  `description` varchar(190) NOT NULL,
  `extra_description` mediumtext DEFAULT NULL,
  `product_type` varchar(30) NOT NULL DEFAULT 'normal',
  `is_manufactured` tinyint(1) NOT NULL DEFAULT 0,
  `department_id` int(10) unsigned DEFAULT NULL,
  `brand_id` int(10) unsigned DEFAULT NULL,
  `image_path` varchar(255) DEFAULT NULL,
  `image_icon` varchar(64) DEFAULT NULL,
  `image_color` varchar(32) DEFAULT NULL,
  `purchase_vat_rate_id` int(10) unsigned DEFAULT NULL,
  `selling_vat_rate_id` int(10) unsigned DEFAULT NULL,
  `last_cost` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `average_cost` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `stock_on_hand` decimal(12,3) NOT NULL DEFAULT 0.000,
  `is_archived` tinyint(1) NOT NULL DEFAULT 0,
  `origin_site_id` int(10) unsigned DEFAULT NULL,
  `last_edit_date` datetime DEFAULT NULL,
  `last_purchase_date` datetime DEFAULT NULL,
  `last_sold_date` datetime DEFAULT NULL,
  `last_adjust_date` datetime DEFAULT NULL,
  `last_stock_take_date` datetime DEFAULT NULL,
  `last_transfer_date` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `visible_in_pos` tinyint(1) NOT NULL DEFAULT 1,
  `pos_sort_order` int(11) NOT NULL DEFAULT 0,
  `change_description` tinyint(1) NOT NULL DEFAULT 0,
  `ask_price_at_sale` tinyint(1) NOT NULL DEFAULT 0,
  `allow_fractions` tinyint(1) NOT NULL DEFAULT 0,
  `charge_pct_subtotal` tinyint(1) NOT NULL DEFAULT 0,
  `non_gp_product` tinyint(1) NOT NULL DEFAULT 0,
  `max_discount_pct` decimal(6,3) NOT NULL DEFAULT 0.000,
  `variable_type` varchar(16) NOT NULL DEFAULT 'none',
  `price_calc` varchar(16) NOT NULL DEFAULT 'selling',
  `pack_weight` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `weight_description` varchar(24) NOT NULL DEFAULT 'Kg',
  `pack_size` decimal(12,3) NOT NULL DEFAULT 0.000,
  `pack_description` varchar(24) NOT NULL DEFAULT 'None',
  `length_mm` decimal(10,2) NOT NULL DEFAULT 0.00,
  `width_mm` decimal(10,2) NOT NULL DEFAULT 0.00,
  `height_mm` decimal(10,2) NOT NULL DEFAULT 0.00,
  `prep_time_minutes` int(11) NOT NULL DEFAULT 0,
  `scale_item` tinyint(1) NOT NULL DEFAULT 0,
  `label_scale_item` tinyint(1) NOT NULL DEFAULT 0,
  `fixed_price_scale` tinyint(1) NOT NULL DEFAULT 0,
  `expires_in_days` int(11) NOT NULL DEFAULT 0,
  `show_online` tinyint(1) NOT NULL DEFAULT 0,
  `parent_id` int(10) unsigned DEFAULT NULL,
  `has_variants` tinyint(1) NOT NULL DEFAULT 0,
  `axis_1_value` varchar(60) NOT NULL DEFAULT '',
  `axis_2_value` varchar(60) NOT NULL DEFAULT '',
  `variant_sort` int(11) NOT NULL DEFAULT 0,
  `online_badge` varchar(24) DEFAULT NULL,
  `online_badge_tone` varchar(12) DEFAULT NULL,
  `kitchen_group` varchar(60) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_product_code` (`code`),
  KEY `ix_product_barcode` (`barcode`),
  KEY `ix_product_description` (`description`),
  KEY `ix_product_department` (`department_id`),
  KEY `ix_product_brand` (`brand_id`),
  KEY `ix_product_archived` (`is_archived`,`description`),
  KEY `ix_product_show_online` (`show_online`,`is_archived`),
  KEY `ix_product_parent` (`parent_id`,`variant_sort`),
  KEY `ix_product_has_variants` (`has_variants`,`is_archived`),
  KEY `fk_product_vat_buy` (`purchase_vat_rate_id`),
  KEY `fk_product_vat_sel` (`selling_vat_rate_id`),
  KEY `ix_product_menu_order` (`department_id`,`pos_sort_order`),
  KEY `ix_product_origin` (`origin_site_id`),
  CONSTRAINT `products_ibfk_1` FOREIGN KEY (`brand_id`) REFERENCES `brands` (`id`) ON DELETE SET NULL,
  CONSTRAINT `products_ibfk_2` FOREIGN KEY (`department_id`) REFERENCES `departments` (`id`) ON DELETE SET NULL,
  CONSTRAINT `products_ibfk_3` FOREIGN KEY (`parent_id`) REFERENCES `products` (`id`),
  CONSTRAINT `products_ibfk_4` FOREIGN KEY (`purchase_vat_rate_id`) REFERENCES `vat_rates` (`id`) ON DELETE SET NULL,
  CONSTRAINT `products_ibfk_5` FOREIGN KEY (`selling_vat_rate_id`) REFERENCES `vat_rates` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=193 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products`
--

LOCK TABLES `products` WRITE;
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
INSERT INTO `products` VALUES (7,'DELETED-7',NULL,'(deleted product #7)',NULL,'normal',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,0.0000,0.000,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-11 11:53:23','2026-08-11 11:53:23',0,0,0,0,0,0,0,0.000,'none','selling',0.0000,'Kg',0.000,'None',0.00,0.00,0.00,0,0,0,0,0,0,NULL,0,'','',0,NULL,NULL,''),(8,'DELETED-8',NULL,'(deleted product #8)',NULL,'normal',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,0.0000,0.000,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-11 11:53:23','2026-08-11 11:53:23',0,0,0,0,0,0,0,0.000,'none','selling',0.0000,'Kg',0.000,'None',0.00,0.00,0.00,0,0,0,0,0,0,NULL,0,'','',0,NULL,NULL,''),(9,'DELETED-9',NULL,'(deleted product #9)',NULL,'normal',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,0.0000,0.000,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-11 11:53:23','2026-08-11 11:53:23',0,0,0,0,0,0,0,0.000,'none','selling',0.0000,'Kg',0.000,'None',0.00,0.00,0.00,0,0,0,0,0,0,NULL,0,'','',0,NULL,NULL,''),(10,'DELETED-10',NULL,'(deleted product #10)',NULL,'normal',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,0.0000,0.000,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-11 11:53:23','2026-08-11 11:53:23',0,0,0,0,0,0,0,0.000,'none','selling',0.0000,'Kg',0.000,'None',0.00,0.00,0.00,0,0,0,0,0,0,NULL,0,'','',0,NULL,NULL,''),(11,'DELETED-11',NULL,'(deleted product #11)',NULL,'normal',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,0.0000,0.000,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-11 11:53:23','2026-08-11 11:53:23',0,0,0,0,0,0,0,0.000,'none','selling',0.0000,'Kg',0.000,'None',0.00,0.00,0.00,0,0,0,0,0,0,NULL,0,'','',0,NULL,NULL,''),(12,'DELETED-12',NULL,'(deleted product #12)',NULL,'normal',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,0.0000,0.000,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-11 11:53:23','2026-08-11 11:53:23',0,0,0,0,0,0,0,0.000,'none','selling',0.0000,'Kg',0.000,'None',0.00,0.00,0.00,0,0,0,0,0,0,NULL,0,'','',0,NULL,NULL,''),(13,'DELETED-13',NULL,'(deleted product #13)',NULL,'normal',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,0.0000,0.000,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-11 11:53:23','2026-08-11 11:53:23',0,0,0,0,0,0,0,0.000,'none','selling',0.0000,'Kg',0.000,'None',0.00,0.00,0.00,0,0,0,0,0,0,NULL,0,'','',0,NULL,NULL,''),(14,'DELETED-14',NULL,'(deleted product #14)',NULL,'normal',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,0.0000,0.000,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-11 11:53:23','2026-08-11 11:53:23',0,0,0,0,0,0,0,0.000,'none','selling',0.0000,'Kg',0.000,'None',0.00,0.00,0.00,0,0,0,0,0,0,NULL,0,'','',0,NULL,NULL,''),(15,'DELETED-15',NULL,'(deleted product #15)',NULL,'normal',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,0.0000,0.000,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-11 11:53:23','2026-08-11 11:53:23',0,0,0,0,0,0,0,0.000,'none','selling',0.0000,'Kg',0.000,'None',0.00,0.00,0.00,0,0,0,0,0,0,NULL,0,'','',0,NULL,NULL,''),(16,'DELETED-16',NULL,'(deleted product #16)',NULL,'normal',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,0.0000,0.000,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-11 11:53:23','2026-08-11 11:53:23',0,0,0,0,0,0,0,0.000,'none','selling',0.0000,'Kg',0.000,'None',0.00,0.00,0.00,0,0,0,0,0,0,NULL,0,'','',0,NULL,NULL,''),(17,'DELETED-17',NULL,'(deleted product #17)',NULL,'normal',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,0.0000,0.000,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-11 11:53:23','2026-08-11 11:53:23',0,0,0,0,0,0,0,0.000,'none','selling',0.0000,'Kg',0.000,'None',0.00,0.00,0.00,0,0,0,0,0,0,NULL,0,'','',0,NULL,NULL,''),(18,'DELETED-18',NULL,'(deleted product #18)',NULL,'normal',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,0.0000,0.000,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-11 11:53:23','2026-08-11 11:53:23',0,0,0,0,0,0,0,0.000,'none','selling',0.0000,'Kg',0.000,'None',0.00,0.00,0.00,0,0,0,0,0,0,NULL,0,'','',0,NULL,NULL,''),(19,'DELETED-19',NULL,'(deleted product #19)',NULL,'normal',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,0.0000,0.000,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-11 11:53:23','2026-08-11 11:53:23',0,0,0,0,0,0,0,0.000,'none','selling',0.0000,'Kg',0.000,'None',0.00,0.00,0.00,0,0,0,0,0,0,NULL,0,'','',0,NULL,NULL,''),(20,'DELETED-20',NULL,'(deleted product #20)',NULL,'normal',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,0.0000,0.000,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-11 11:53:23','2026-08-11 11:53:23',0,0,0,0,0,0,0,0.000,'none','selling',0.0000,'Kg',0.000,'None',0.00,0.00,0.00,0,0,0,0,0,0,NULL,0,'','',0,NULL,NULL,''),(21,'DELETED-21',NULL,'(deleted product #21)',NULL,'normal',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,0.0000,0.000,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-11 11:53:23','2026-08-11 11:53:23',0,0,0,0,0,0,0,0.000,'none','selling',0.0000,'Kg',0.000,'None',0.00,0.00,0.00,0,0,0,0,0,0,NULL,0,'','',0,NULL,NULL,''),(22,'DELETED-22',NULL,'(deleted product #22)',NULL,'normal',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,0.0000,0.000,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-11 11:53:23','2026-08-11 11:53:23',0,0,0,0,0,0,0,0.000,'none','selling',0.0000,'Kg',0.000,'None',0.00,0.00,0.00,0,0,0,0,0,0,NULL,0,'','',0,NULL,NULL,''),(23,'DELETED-23',NULL,'(deleted product #23)',NULL,'normal',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,0.0000,0.000,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-11 11:53:23','2026-08-11 11:53:23',0,0,0,0,0,0,0,0.000,'none','selling',0.0000,'Kg',0.000,'None',0.00,0.00,0.00,0,0,0,0,0,0,NULL,0,'','',0,NULL,NULL,''),(24,'DELETED-24',NULL,'(deleted product #24)',NULL,'normal',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,0.0000,0.000,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-11 11:53:23','2026-08-11 11:53:23',0,0,0,0,0,0,0,0.000,'none','selling',0.0000,'Kg',0.000,'None',0.00,0.00,0.00,0,0,0,0,0,0,NULL,0,'','',0,NULL,NULL,''),(25,'DELETED-25',NULL,'(deleted product #25)',NULL,'normal',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,0.0000,0.000,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-11 11:53:23','2026-08-11 11:53:23',0,0,0,0,0,0,0,0.000,'none','selling',0.0000,'Kg',0.000,'None',0.00,0.00,0.00,0,0,0,0,0,0,NULL,0,'','',0,NULL,NULL,''),(26,'DELETED-26',NULL,'(deleted product #26)',NULL,'normal',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,0.0000,0.000,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-11 11:53:23','2026-08-11 11:53:23',0,0,0,0,0,0,0,0.000,'none','selling',0.0000,'Kg',0.000,'None',0.00,0.00,0.00,0,0,0,0,0,0,NULL,0,'','',0,NULL,NULL,''),(27,'DELETED-27',NULL,'(deleted product #27)',NULL,'normal',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,0.0000,0.000,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-11 11:53:23','2026-08-11 11:53:23',0,0,0,0,0,0,0,0.000,'none','selling',0.0000,'Kg',0.000,'None',0.00,0.00,0.00,0,0,0,0,0,0,NULL,0,'','',0,NULL,NULL,''),(28,'DELETED-28',NULL,'(deleted product #28)',NULL,'normal',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,0.0000,-1.000,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-11 11:53:23','2026-08-11 13:49:00',0,0,0,0,0,0,0,0.000,'none','selling',0.0000,'Kg',0.000,'None',0.00,0.00,0.00,0,0,0,0,0,0,NULL,0,'','',0,NULL,NULL,''),(29,'DELETED-29',NULL,'(deleted product #29)',NULL,'normal',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,0.0000,-1.000,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-11 11:53:23','2026-08-11 13:49:00',0,0,0,0,0,0,0,0.000,'none','selling',0.0000,'Kg',0.000,'None',0.00,0.00,0.00,0,0,0,0,0,0,NULL,0,'','',0,NULL,NULL,''),(30,'DELETED-30',NULL,'(deleted product #30)',NULL,'normal',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,0.0000,-1.000,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-11 11:53:23','2026-08-11 13:49:00',0,0,0,0,0,0,0,0.000,'none','selling',0.0000,'Kg',0.000,'None',0.00,0.00,0.00,0,0,0,0,0,0,NULL,0,'','',0,NULL,NULL,''),(31,'DELETED-31',NULL,'(deleted product #31)',NULL,'normal',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,0.0000,0.000,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-11 11:53:23','2026-08-11 11:53:23',0,0,0,0,0,0,0,0.000,'none','selling',0.0000,'Kg',0.000,'None',0.00,0.00,0.00,0,0,0,0,0,0,NULL,0,'','',0,NULL,NULL,''),(32,'DELETED-32',NULL,'(deleted product #32)',NULL,'normal',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,0.0000,0.000,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-11 11:53:23','2026-08-11 11:53:23',0,0,0,0,0,0,0,0.000,'none','selling',0.0000,'Kg',0.000,'None',0.00,0.00,0.00,0,0,0,0,0,0,NULL,0,'','',0,NULL,NULL,''),(33,'DELETED-33',NULL,'(deleted product #33)',NULL,'normal',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,0.0000,0.000,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-11 11:53:23','2026-08-11 11:53:23',0,0,0,0,0,0,0,0.000,'none','selling',0.0000,'Kg',0.000,'None',0.00,0.00,0.00,0,0,0,0,0,0,NULL,0,'','',0,NULL,NULL,''),(34,'DELETED-34',NULL,'(deleted product #34)',NULL,'normal',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,0.0000,0.000,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-11 11:53:23','2026-08-11 11:53:23',0,0,0,0,0,0,0,0.000,'none','selling',0.0000,'Kg',0.000,'None',0.00,0.00,0.00,0,0,0,0,0,0,NULL,0,'','',0,NULL,NULL,''),(35,'DELETED-35',NULL,'(deleted product #35)',NULL,'normal',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,0.0000,0.000,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-11 11:53:23','2026-08-11 11:53:23',0,0,0,0,0,0,0,0.000,'none','selling',0.0000,'Kg',0.000,'None',0.00,0.00,0.00,0,0,0,0,0,0,NULL,0,'','',0,NULL,NULL,''),(36,'DELETED-36',NULL,'(deleted product #36)',NULL,'normal',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,0.0000,-1.000,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-11 11:53:23','2026-08-11 13:49:00',0,0,0,0,0,0,0,0.000,'none','selling',0.0000,'Kg',0.000,'None',0.00,0.00,0.00,0,0,0,0,0,0,NULL,0,'','',0,NULL,NULL,''),(37,'DELETED-37',NULL,'(deleted product #37)',NULL,'normal',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,0.0000,0.000,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-11 11:53:23','2026-08-11 11:53:23',0,0,0,0,0,0,0,0.000,'none','selling',0.0000,'Kg',0.000,'None',0.00,0.00,0.00,0,0,0,0,0,0,NULL,0,'','',0,NULL,NULL,''),(38,'DELETED-38',NULL,'(deleted product #38)',NULL,'normal',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,0.0000,0.000,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-11 11:53:23','2026-08-11 11:53:23',0,0,0,0,0,0,0,0.000,'none','selling',0.0000,'Kg',0.000,'None',0.00,0.00,0.00,0,0,0,0,0,0,NULL,0,'','',0,NULL,NULL,''),(39,'DELETED-39',NULL,'(deleted product #39)',NULL,'normal',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,0.0000,0.000,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-11 11:53:23','2026-08-11 11:53:23',0,0,0,0,0,0,0,0.000,'none','selling',0.0000,'Kg',0.000,'None',0.00,0.00,0.00,0,0,0,0,0,0,NULL,0,'','',0,NULL,NULL,''),(40,'DELETED-40',NULL,'(deleted product #40)',NULL,'normal',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,0.0000,0.000,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-11 11:53:23','2026-08-11 11:53:23',0,0,0,0,0,0,0,0.000,'none','selling',0.0000,'Kg',0.000,'None',0.00,0.00,0.00,0,0,0,0,0,0,NULL,0,'','',0,NULL,NULL,''),(41,'DELETED-41',NULL,'(deleted product #41)',NULL,'normal',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,0.0000,0.000,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-11 11:53:23','2026-08-11 11:53:23',0,0,0,0,0,0,0,0.000,'none','selling',0.0000,'Kg',0.000,'None',0.00,0.00,0.00,0,0,0,0,0,0,NULL,0,'','',0,NULL,NULL,''),(42,'DELETED-42',NULL,'(deleted product #42)',NULL,'normal',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,0.0000,0.000,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-11 11:53:23','2026-08-11 11:53:23',0,0,0,0,0,0,0,0.000,'none','selling',0.0000,'Kg',0.000,'None',0.00,0.00,0.00,0,0,0,0,0,0,NULL,0,'','',0,NULL,NULL,''),(43,'DELETED-43',NULL,'(deleted product #43)',NULL,'normal',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,0.0000,0.000,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-11 11:53:23','2026-08-11 11:53:23',0,0,0,0,0,0,0,0.000,'none','selling',0.0000,'Kg',0.000,'None',0.00,0.00,0.00,0,0,0,0,0,0,NULL,0,'','',0,NULL,NULL,''),(44,'DELETED-44',NULL,'(deleted product #44)',NULL,'normal',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,0.0000,0.000,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-11 11:53:23','2026-08-11 11:53:23',0,0,0,0,0,0,0,0.000,'none','selling',0.0000,'Kg',0.000,'None',0.00,0.00,0.00,0,0,0,0,0,0,NULL,0,'','',0,NULL,NULL,''),(45,'DELETED-45',NULL,'(deleted product #45)',NULL,'normal',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,0.0000,0.000,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-11 11:53:23','2026-08-11 11:53:23',0,0,0,0,0,0,0,0.000,'none','selling',0.0000,'Kg',0.000,'None',0.00,0.00,0.00,0,0,0,0,0,0,NULL,0,'','',0,NULL,NULL,''),(46,'DELETED-46',NULL,'(deleted product #46)',NULL,'normal',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,0.0000,0.000,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-11 11:53:23','2026-08-11 11:53:23',0,0,0,0,0,0,0,0.000,'none','selling',0.0000,'Kg',0.000,'None',0.00,0.00,0.00,0,0,0,0,0,0,NULL,0,'','',0,NULL,NULL,''),(47,'DELETED-47',NULL,'(deleted product #47)',NULL,'normal',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,0.0000,0.000,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-11 11:53:23','2026-08-11 11:53:23',0,0,0,0,0,0,0,0.000,'none','selling',0.0000,'Kg',0.000,'None',0.00,0.00,0.00,0,0,0,0,0,0,NULL,0,'','',0,NULL,NULL,''),(48,'DELETED-48',NULL,'(deleted product #48)',NULL,'normal',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,0.0000,0.000,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-11 11:53:23','2026-08-11 11:53:23',0,0,0,0,0,0,0,0.000,'none','selling',0.0000,'Kg',0.000,'None',0.00,0.00,0.00,0,0,0,0,0,0,NULL,0,'','',0,NULL,NULL,''),(49,'DELETED-49',NULL,'(deleted product #49)',NULL,'normal',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,0.0000,0.000,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-11 11:53:23','2026-08-11 11:53:23',0,0,0,0,0,0,0,0.000,'none','selling',0.0000,'Kg',0.000,'None',0.00,0.00,0.00,0,0,0,0,0,0,NULL,0,'','',0,NULL,NULL,''),(50,'DELETED-50',NULL,'(deleted product #50)',NULL,'normal',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,0.0000,0.000,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-11 11:53:23','2026-08-11 11:53:23',0,0,0,0,0,0,0,0.000,'none','selling',0.0000,'Kg',0.000,'None',0.00,0.00,0.00,0,0,0,0,0,0,NULL,0,'','',0,NULL,NULL,''),(51,'DELETED-51',NULL,'(deleted product #51)',NULL,'normal',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,0.0000,0.000,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-11 11:53:23','2026-08-11 11:53:23',0,0,0,0,0,0,0,0.000,'none','selling',0.0000,'Kg',0.000,'None',0.00,0.00,0.00,0,0,0,0,0,0,NULL,0,'','',0,NULL,NULL,''),(52,'DELETED-52',NULL,'(deleted product #52)',NULL,'normal',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,0.0000,0.000,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-11 11:53:23','2026-08-11 11:53:23',0,0,0,0,0,0,0,0.000,'none','selling',0.0000,'Kg',0.000,'None',0.00,0.00,0.00,0,0,0,0,0,0,NULL,0,'','',0,NULL,NULL,''),(53,'DELETED-53',NULL,'(deleted product #53)',NULL,'normal',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,0.0000,0.000,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-11 11:53:23','2026-08-11 11:53:23',0,0,0,0,0,0,0,0.000,'none','selling',0.0000,'Kg',0.000,'None',0.00,0.00,0.00,0,0,0,0,0,0,NULL,0,'','',0,NULL,NULL,''),(54,'DELETED-54',NULL,'(deleted product #54)',NULL,'normal',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,0.0000,0.000,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-11 11:53:23','2026-08-11 11:53:23',0,0,0,0,0,0,0,0.000,'none','selling',0.0000,'Kg',0.000,'None',0.00,0.00,0.00,0,0,0,0,0,0,NULL,0,'','',0,NULL,NULL,''),(55,'DELETED-55',NULL,'(deleted product #55)',NULL,'normal',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,0.0000,0.000,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-11 11:53:23','2026-08-11 11:53:23',0,0,0,0,0,0,0,0.000,'none','selling',0.0000,'Kg',0.000,'None',0.00,0.00,0.00,0,0,0,0,0,0,NULL,0,'','',0,NULL,NULL,''),(56,'DELETED-56',NULL,'(deleted product #56)',NULL,'normal',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,0.0000,0.000,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-11 11:53:23','2026-08-11 11:53:23',0,0,0,0,0,0,0,0.000,'none','selling',0.0000,'Kg',0.000,'None',0.00,0.00,0.00,0,0,0,0,0,0,NULL,0,'','',0,NULL,NULL,''),(57,'DELETED-57',NULL,'(deleted product #57)',NULL,'normal',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,0.0000,0.000,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-11 11:53:23','2026-08-11 11:53:23',0,0,0,0,0,0,0,0.000,'none','selling',0.0000,'Kg',0.000,'None',0.00,0.00,0.00,0,0,0,0,0,0,NULL,0,'','',0,NULL,NULL,''),(58,'DELETED-58',NULL,'(deleted product #58)',NULL,'normal',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,0.0000,0.000,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-11 11:53:23','2026-08-11 11:53:23',0,0,0,0,0,0,0,0.000,'none','selling',0.0000,'Kg',0.000,'None',0.00,0.00,0.00,0,0,0,0,0,0,NULL,0,'','',0,NULL,NULL,''),(59,'DELETED-59',NULL,'(deleted product #59)',NULL,'normal',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,0.0000,0.000,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-11 11:53:23','2026-08-11 11:53:23',0,0,0,0,0,0,0,0.000,'none','selling',0.0000,'Kg',0.000,'None',0.00,0.00,0.00,0,0,0,0,0,0,NULL,0,'','',0,NULL,NULL,''),(60,'DELETED-60',NULL,'(deleted product #60)',NULL,'normal',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,0.0000,0.000,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-11 11:53:23','2026-08-11 11:53:23',0,0,0,0,0,0,0,0.000,'none','selling',0.0000,'Kg',0.000,'None',0.00,0.00,0.00,0,0,0,0,0,0,NULL,0,'','',0,NULL,NULL,''),(109,'BURG001',NULL,'Classic Smash',NULL,'normal',0,11,1,NULL,NULL,NULL,3,1,26.0000,26.0000,30.000,0,NULL,'2026-08-11 13:20:53',NULL,NULL,NULL,'2026-08-26 16:47:38',NULL,'2026-08-11 13:20:53','2026-08-26 16:47:38',1,4,0,0,0,0,0,10.000,'none','selling',0.0000,'Kg',0.000,'None',0.00,0.00,0.00,8,0,0,0,0,0,NULL,0,'','',0,NULL,NULL,''),(110,'BURG002',NULL,'Double Smash',NULL,'normal',0,11,1,NULL,NULL,NULL,3,1,38.0000,38.0000,5.000,0,NULL,'2026-08-11 13:20:53',NULL,NULL,'2026-08-26 16:47:38','2026-08-26 16:47:38',NULL,'2026-08-11 13:20:53','2026-08-26 16:47:38',1,5,0,0,0,0,0,10.000,'none','selling',0.0000,'Kg',0.000,'None',0.00,0.00,0.00,9,0,0,0,0,0,NULL,0,'','',0,NULL,NULL,''),(111,'BURG003',NULL,'Triple Smash Stack',NULL,'normal',0,11,1,NULL,NULL,NULL,3,1,52.0000,52.0000,50.000,0,NULL,'2026-08-11 13:20:53',NULL,NULL,'2026-08-26 16:47:38','2026-08-26 16:47:38',NULL,'2026-08-11 13:20:53','2026-08-26 16:47:38',1,8,0,0,0,0,0,10.000,'none','selling',0.0000,'Kg',0.000,'None',0.00,0.00,0.00,11,0,0,0,0,0,NULL,0,'','',0,NULL,NULL,''),(112,'BURG004',NULL,'Bacon & Cheddar Smash',NULL,'normal',0,12,1,NULL,NULL,NULL,3,1,42.0000,42.0000,50.000,0,NULL,'2026-08-11 13:20:53',NULL,'2026-08-26 15:39:13','2026-08-26 16:47:38','2026-08-26 16:47:38',NULL,'2026-08-11 13:20:53','2026-08-26 16:47:38',1,1,0,0,0,0,0,10.000,'none','selling',0.0000,'Kg',0.000,'None',0.00,0.00,0.00,9,0,0,0,0,0,NULL,0,'','',0,NULL,NULL,''),(113,'BURG005',NULL,'Mushroom Swiss Smash',NULL,'normal',0,11,1,NULL,NULL,NULL,3,1,40.0000,40.0000,50.000,0,NULL,'2026-08-11 13:20:53',NULL,NULL,'2026-08-26 16:47:38','2026-08-26 16:47:38',NULL,'2026-08-11 13:20:53','2026-08-26 16:47:38',1,7,0,0,0,0,0,10.000,'none','selling',0.0000,'Kg',0.000,'None',0.00,0.00,0.00,10,0,0,0,0,0,NULL,0,'','',0,NULL,NULL,''),(114,'BURG006',NULL,'Jalapeno Fire Smash',NULL,'normal',0,11,1,NULL,NULL,NULL,3,1,39.0000,39.0000,550.000,0,NULL,'2026-08-11 13:20:53',NULL,NULL,'2026-08-26 16:47:38','2026-08-26 16:47:38',NULL,'2026-08-11 13:20:53','2026-08-26 16:47:38',1,6,0,0,0,0,0,10.000,'none','selling',0.0000,'Kg',0.000,'None',0.00,0.00,0.00,9,0,0,0,0,0,NULL,0,'','',0,NULL,NULL,''),(115,'BURG007',NULL,'Buttermilk Chicken Burger',NULL,'normal',0,11,1,NULL,NULL,NULL,3,1,36.0000,36.0000,50.000,0,NULL,'2026-08-11 13:20:53',NULL,NULL,'2026-08-26 16:47:38','2026-08-26 16:47:38',NULL,'2026-08-11 13:20:53','2026-08-26 16:47:38',1,3,0,0,0,0,0,10.000,'none','selling',0.0000,'Kg',0.000,'None',0.00,0.00,0.00,12,0,0,0,0,0,NULL,0,'','',0,NULL,NULL,''),(116,'BURG008',NULL,'Beyond Veggie Smash',NULL,'normal',0,11,1,NULL,NULL,NULL,3,1,44.0000,44.0000,72.000,0,NULL,'2026-08-11 13:20:53',NULL,NULL,NULL,NULL,NULL,'2026-08-11 13:20:53','2026-08-24 13:26:51',1,2,0,0,0,0,0,10.000,'none','selling',0.0000,'Kg',0.000,'None',0.00,0.00,0.00,9,0,0,0,0,0,NULL,0,'','',0,NULL,NULL,''),(117,'DOGS001',NULL,'New York Dog',NULL,'normal',0,12,1,NULL,NULL,NULL,3,1,22.0000,22.0000,30.000,0,NULL,'2026-08-11 13:20:53',NULL,NULL,NULL,NULL,NULL,'2026-08-11 13:20:53','2026-08-11 13:20:53',1,0,0,0,0,0,0,10.000,'none','selling',0.0000,'Kg',0.000,'None',0.00,0.00,0.00,6,0,0,0,0,0,NULL,0,'','',0,NULL,NULL,''),(118,'DOGS002',NULL,'Chilli Cheese Dog',NULL,'normal',0,12,1,NULL,NULL,NULL,3,1,29.0000,29.0000,36.000,0,NULL,'2026-08-11 13:20:53',NULL,NULL,NULL,NULL,NULL,'2026-08-11 13:20:53','2026-08-11 13:20:53',1,0,0,0,0,0,0,10.000,'none','selling',0.0000,'Kg',0.000,'None',0.00,0.00,0.00,7,0,0,0,0,0,NULL,0,'','',0,NULL,NULL,''),(119,'DOGS003',NULL,'Boerewors Dog',NULL,'normal',0,12,1,NULL,NULL,NULL,3,1,31.0000,31.0000,42.000,0,NULL,'2026-08-11 13:20:53',NULL,NULL,NULL,NULL,NULL,'2026-08-11 13:20:53','2026-08-11 13:20:53',1,0,0,0,0,0,0,10.000,'none','selling',0.0000,'Kg',0.000,'None',0.00,0.00,0.00,8,0,0,0,0,0,NULL,0,'','',0,NULL,NULL,''),(120,'DOGS004',NULL,'Bratwurst & Sauerkraut Dog',NULL,'normal',0,12,1,NULL,NULL,NULL,3,1,34.0000,34.0000,48.000,0,NULL,'2026-08-11 13:20:53',NULL,NULL,NULL,NULL,NULL,'2026-08-11 13:20:53','2026-08-11 13:50:30',1,0,0,0,0,0,0,10.000,'none','selling',0.0000,'Kg',0.000,'None',0.00,0.00,0.00,8,0,0,0,0,0,NULL,0,'','',0,NULL,NULL,''),(121,'DOGS005',NULL,'Mac & Cheese Dog',NULL,'normal',0,12,1,NULL,NULL,NULL,3,1,32.0000,32.0000,54.000,0,NULL,'2026-08-11 13:20:53',NULL,NULL,NULL,NULL,NULL,'2026-08-11 13:20:53','2026-08-11 13:20:53',1,0,0,0,0,0,0,10.000,'none','selling',0.0000,'Kg',0.000,'None',0.00,0.00,0.00,8,0,0,0,0,0,NULL,0,'','',0,NULL,NULL,''),(122,'DOGS006',NULL,'Corn Dog',NULL,'normal',0,12,1,NULL,NULL,NULL,3,1,17.0000,17.0000,60.000,0,NULL,'2026-08-11 13:20:53',NULL,NULL,NULL,NULL,NULL,'2026-08-11 13:20:53','2026-08-11 13:20:53',1,0,0,0,0,0,0,10.000,'none','selling',0.0000,'Kg',0.000,'None',0.00,0.00,0.00,6,0,0,0,0,0,NULL,0,'','',0,NULL,NULL,''),(123,'PIZZ001',NULL,'Margherita 30cm',NULL,'normal',0,13,1,NULL,NULL,NULL,3,1,31.0000,31.0000,30.000,0,NULL,'2026-08-11 13:20:53',NULL,NULL,NULL,NULL,NULL,'2026-08-11 13:20:53','2026-08-11 13:20:53',1,0,0,0,0,0,0,10.000,'none','selling',0.0000,'Kg',0.000,'None',0.00,0.00,0.00,12,0,0,0,0,0,NULL,0,'','',0,NULL,NULL,''),(124,'PIZZ002',NULL,'Pepperoni 30cm',NULL,'normal',0,13,1,NULL,NULL,NULL,3,1,40.0000,40.0000,36.000,0,NULL,'2026-08-11 13:20:53',NULL,NULL,NULL,NULL,NULL,'2026-08-11 13:20:53','2026-08-11 13:20:53',1,0,0,0,0,0,0,10.000,'none','selling',0.0000,'Kg',0.000,'None',0.00,0.00,0.00,12,0,0,0,0,0,NULL,0,'','',0,NULL,NULL,''),(125,'PIZZ003',NULL,'Regina 30cm',NULL,'normal',0,13,1,NULL,NULL,NULL,3,1,43.0000,43.0000,42.000,0,NULL,'2026-08-11 13:20:53',NULL,NULL,NULL,NULL,NULL,'2026-08-11 13:20:53','2026-08-11 13:20:53',1,0,0,0,0,0,0,10.000,'none','selling',0.0000,'Kg',0.000,'None',0.00,0.00,0.00,13,0,0,0,0,0,NULL,0,'','',0,NULL,NULL,''),(126,'PIZZ004',NULL,'Four Cheese 30cm',NULL,'normal',0,13,1,NULL,NULL,NULL,3,1,49.0000,49.0000,48.000,0,NULL,'2026-08-11 13:20:53',NULL,NULL,NULL,NULL,NULL,'2026-08-11 13:20:53','2026-08-11 13:20:53',1,0,0,0,0,0,0,10.000,'none','selling',0.0000,'Kg',0.000,'None',0.00,0.00,0.00,13,0,0,0,0,0,NULL,0,'','',0,NULL,NULL,''),(127,'PIZZ005',NULL,'BBQ Chicken 30cm',NULL,'normal',0,13,1,NULL,NULL,NULL,3,1,51.0000,51.0000,52.000,0,NULL,'2026-08-11 13:20:53',NULL,'2026-08-25 19:19:45',NULL,NULL,NULL,'2026-08-11 13:20:53','2026-08-25 19:19:45',1,0,0,0,0,0,0,10.000,'none','selling',0.0000,'Kg',0.000,'None',0.00,0.00,0.00,14,0,0,0,0,0,NULL,0,'','',0,NULL,NULL,''),(128,'PIZZ006',NULL,'Meat Lovers 30cm',NULL,'normal',0,13,1,NULL,NULL,NULL,3,1,62.0000,62.0000,60.000,0,NULL,'2026-08-11 13:20:53',NULL,NULL,NULL,NULL,NULL,'2026-08-11 13:20:53','2026-08-11 13:20:53',1,0,0,0,0,0,0,10.000,'none','selling',0.0000,'Kg',0.000,'None',0.00,0.00,0.00,15,0,0,0,0,0,NULL,0,'','',0,NULL,NULL,''),(129,'PIZZ007',NULL,'Vegetariana 30cm',NULL,'normal',0,13,1,NULL,NULL,NULL,3,1,38.0000,38.0000,66.000,0,NULL,'2026-08-11 13:20:53',NULL,NULL,NULL,NULL,NULL,'2026-08-11 13:20:53','2026-08-11 13:20:53',1,0,0,0,0,0,0,10.000,'none','selling',0.0000,'Kg',0.000,'None',0.00,0.00,0.00,12,0,0,0,0,0,NULL,0,'','',0,NULL,NULL,''),(130,'PIZZ008',NULL,'Build Your Own 30cm',NULL,'normal',0,13,1,NULL,NULL,NULL,3,1,22.0000,22.0000,72.000,0,NULL,'2026-08-11 13:20:53',NULL,NULL,NULL,NULL,NULL,'2026-08-11 13:20:53','2026-08-11 13:20:53',1,0,1,0,0,0,0,10.000,'none','selling',0.0000,'Kg',0.000,'None',0.00,0.00,0.00,10,0,0,0,0,0,NULL,0,'','',0,NULL,NULL,''),(131,'SIDE001',NULL,'Skin-On Fries (Regular)',NULL,'normal',0,14,1,NULL,NULL,NULL,3,1,9.0000,9.0000,30.000,0,NULL,'2026-08-11 13:20:53',NULL,NULL,NULL,NULL,NULL,'2026-08-11 13:20:53','2026-08-11 13:20:53',1,0,0,0,0,0,0,10.000,'none','selling',0.0000,'Kg',0.000,'None',0.00,0.00,0.00,5,0,0,0,0,0,NULL,0,'','',0,NULL,NULL,''),(132,'SIDE002',NULL,'Skin-On Fries (Large)',NULL,'normal',0,14,1,NULL,NULL,NULL,3,1,13.0000,13.0000,36.000,0,NULL,'2026-08-11 13:20:53',NULL,NULL,NULL,NULL,NULL,'2026-08-11 13:20:53','2026-08-11 13:20:53',1,0,0,0,0,0,0,10.000,'none','selling',0.0000,'Kg',0.000,'None',0.00,0.00,0.00,5,0,0,0,0,0,NULL,0,'','',0,NULL,NULL,''),(133,'SIDE003',NULL,'Cheese & Bacon Loaded Fries',NULL,'normal',0,14,1,NULL,NULL,NULL,3,1,24.0000,24.0000,42.000,0,NULL,'2026-08-11 13:20:53',NULL,NULL,NULL,NULL,NULL,'2026-08-11 13:20:53','2026-08-11 13:20:53',1,0,0,0,0,0,0,10.000,'none','selling',0.0000,'Kg',0.000,'None',0.00,0.00,0.00,7,0,0,0,0,0,NULL,0,'','',0,NULL,NULL,''),(134,'SIDE004',NULL,'Chilli Beef Loaded Fries',NULL,'normal',0,14,1,NULL,NULL,NULL,3,1,28.0000,28.0000,47.000,0,NULL,'2026-08-11 13:20:53',NULL,'2026-08-31 10:55:39',NULL,NULL,NULL,'2026-08-11 13:20:53','2026-08-31 10:55:39',1,0,0,0,0,0,0,10.000,'none','selling',0.0000,'Kg',0.000,'None',0.00,0.00,0.00,8,0,0,0,0,0,NULL,0,'','',0,NULL,NULL,''),(135,'SIDE005',NULL,'Onion Rings (8)',NULL,'normal',0,14,1,NULL,NULL,NULL,3,1,14.0000,14.0000,54.000,0,NULL,'2026-08-11 13:20:53',NULL,NULL,NULL,NULL,NULL,'2026-08-11 13:20:53','2026-08-11 13:20:53',1,0,0,0,0,0,0,10.000,'none','selling',0.0000,'Kg',0.000,'None',0.00,0.00,0.00,6,0,0,0,0,0,NULL,0,'','',0,NULL,NULL,''),(136,'SIDE006',NULL,'Coleslaw Tub',NULL,'normal',0,14,1,NULL,NULL,NULL,3,1,8.0000,8.0000,59.000,0,NULL,'2026-08-11 13:20:53',NULL,'2026-08-31 10:55:39',NULL,NULL,NULL,'2026-08-11 13:20:53','2026-08-31 10:55:39',1,0,0,0,0,0,0,10.000,'none','selling',0.0000,'Kg',0.000,'None',0.00,0.00,0.00,0,0,0,0,0,0,NULL,0,'','',0,NULL,NULL,''),(137,'DRNK001','6010000000294','Coca-Cola 330ml Can',NULL,'normal',0,15,2,NULL,NULL,NULL,3,1,8.5000,8.5000,60.000,0,NULL,'2026-08-11 13:20:53',NULL,NULL,NULL,NULL,NULL,'2026-08-11 13:20:53','2026-08-11 13:20:53',1,0,0,0,0,0,0,0.000,'none','selling',0.0000,'Kg',0.000,'None',0.00,0.00,0.00,0,0,0,0,0,0,NULL,0,'','',0,NULL,NULL,''),(138,'DRNK002','6010000000300','Coca-Cola Zero 330ml Can',NULL,'normal',0,15,2,NULL,NULL,NULL,3,1,8.5000,8.5000,72.000,0,NULL,'2026-08-11 13:20:53',NULL,NULL,NULL,NULL,NULL,'2026-08-11 13:20:53','2026-08-11 13:20:53',1,0,0,0,0,0,0,0.000,'none','selling',0.0000,'Kg',0.000,'None',0.00,0.00,0.00,0,0,0,0,0,0,NULL,0,'','',0,NULL,NULL,''),(139,'DRNK003','6010000000317','Fanta Orange 330ml Can',NULL,'normal',0,15,3,NULL,NULL,NULL,3,1,8.3000,8.3000,83.000,0,NULL,'2026-08-11 13:20:53',NULL,NULL,'2026-08-26 16:51:23',NULL,NULL,'2026-08-11 13:20:53','2026-08-26 16:51:23',1,0,0,0,0,0,0,0.000,'none','selling',0.0000,'Kg',0.000,'None',0.00,0.00,0.00,0,0,0,0,0,0,NULL,0,'','',0,NULL,NULL,''),(140,'DRNK004','6010000000324','Sprite 330ml Can',NULL,'normal',0,15,4,NULL,NULL,NULL,3,1,8.3000,8.3000,95.000,0,NULL,'2026-08-11 13:20:53',NULL,NULL,'2026-08-26 16:51:23',NULL,NULL,'2026-08-11 13:20:53','2026-08-26 16:51:23',1,0,0,0,0,0,0,0.000,'none','selling',0.0000,'Kg',0.000,'None',0.00,0.00,0.00,0,0,0,0,0,0,NULL,0,'','',0,NULL,NULL,''),(141,'DRNK005','6010000000331','Appletiser 330ml',NULL,'normal',0,15,5,NULL,NULL,NULL,3,1,12.0000,12.0000,103.000,0,NULL,'2026-08-11 13:20:53',NULL,'2026-08-26 15:34:12',NULL,NULL,NULL,'2026-08-11 13:20:53','2026-08-26 15:34:12',1,0,0,0,0,0,0,0.000,'none','selling',0.0000,'Kg',0.000,'None',0.00,0.00,0.00,0,0,0,0,0,0,NULL,0,'','',0,NULL,NULL,''),(142,'DRNK006','6010000000348','Red Bull 250ml',NULL,'normal',0,15,6,NULL,NULL,NULL,3,1,19.0000,19.0000,120.000,0,NULL,'2026-08-11 13:20:53',NULL,NULL,NULL,NULL,NULL,'2026-08-11 13:20:53','2026-08-11 13:20:53',1,0,0,0,0,0,0,0.000,'none','selling',0.0000,'Kg',0.000,'None',0.00,0.00,0.00,0,0,0,0,0,0,NULL,0,'','',0,NULL,NULL,''),(143,'DRNK007','6010000000355','Lipton Ice Tea Peach 300ml',NULL,'normal',0,15,7,NULL,NULL,NULL,3,1,11.0000,11.0000,132.000,0,NULL,'2026-08-11 13:20:53',NULL,NULL,NULL,NULL,NULL,'2026-08-11 13:20:53','2026-08-11 13:20:53',1,0,0,0,0,0,0,0.000,'none','selling',0.0000,'Kg',0.000,'None',0.00,0.00,0.00,0,0,0,0,0,0,NULL,0,'','',0,NULL,NULL,''),(144,'DRNK008',NULL,'Chocolate Thick Shake',NULL,'normal',0,15,1,NULL,NULL,NULL,3,1,14.0000,14.0000,72.000,0,NULL,'2026-08-11 13:20:53',NULL,NULL,NULL,NULL,NULL,'2026-08-11 13:20:53','2026-08-11 13:20:53',1,0,0,0,0,0,0,10.000,'none','selling',0.0000,'Kg',0.000,'None',0.00,0.00,0.00,4,0,0,0,0,0,NULL,0,'','',0,NULL,NULL,''),(145,'DSRT001',NULL,'Warm Chocolate Brownie',NULL,'normal',0,16,1,NULL,NULL,NULL,3,1,15.0000,15.0000,30.000,0,NULL,'2026-08-11 13:20:53',NULL,NULL,NULL,NULL,NULL,'2026-08-11 13:20:53','2026-08-11 13:20:53',1,0,0,0,0,0,0,10.000,'none','selling',0.0000,'Kg',0.000,'None',0.00,0.00,0.00,5,0,0,0,0,0,NULL,0,'','',0,NULL,NULL,''),(146,'DSRT002',NULL,'Soft-Serve Cone',NULL,'normal',0,16,1,NULL,NULL,NULL,3,1,6.5000,6.5000,36.000,0,NULL,'2026-08-11 13:20:53',NULL,NULL,NULL,NULL,NULL,'2026-08-11 13:20:53','2026-08-11 13:20:53',1,0,0,0,0,0,0,10.000,'none','selling',0.0000,'Kg',0.000,'None',0.00,0.00,0.00,2,0,0,0,0,0,NULL,0,'','',0,NULL,NULL,''),(147,'DSRT003',NULL,'Deep-Fried Ice Cream',NULL,'normal',0,16,1,NULL,NULL,NULL,3,1,21.0000,21.0000,42.000,0,NULL,'2026-08-11 13:20:53',NULL,NULL,NULL,NULL,NULL,'2026-08-11 13:20:53','2026-08-11 13:20:53',1,0,0,0,0,0,0,10.000,'none','selling',0.0000,'Kg',0.000,'None',0.00,0.00,0.00,6,0,0,0,0,0,NULL,0,'','',0,NULL,NULL,''),(148,'DSRT004',NULL,'Malva Pudding & Custard',NULL,'normal',0,16,1,NULL,NULL,NULL,3,1,18.0000,18.0000,48.000,0,NULL,'2026-08-11 13:20:53',NULL,NULL,NULL,NULL,NULL,'2026-08-11 13:20:53','2026-08-11 13:20:53',1,0,0,0,0,0,0,10.000,'none','selling',0.0000,'Kg',0.000,'None',0.00,0.00,0.00,5,0,0,0,0,0,NULL,0,'','',0,NULL,NULL,''),(149,'OP24876588',NULL,'Order test item 24876588',NULL,'normal',0,19,NULL,NULL,NULL,NULL,NULL,NULL,10.0000,10.0000,100.000,0,NULL,NULL,'2026-08-12 10:54:37',NULL,NULL,NULL,NULL,'2026-08-12 10:54:36','2026-08-24 13:26:45',1,10,0,0,0,0,0,0.000,'none','selling',0.0000,'Kg',0.000,'None',0.00,0.00,0.00,0,0,0,0,0,0,NULL,0,'','',0,NULL,NULL,''),(152,'DP24942714',NULL,'Draft test item 24942714',NULL,'normal',0,19,NULL,NULL,NULL,NULL,NULL,NULL,10.0000,10.0000,100.000,0,NULL,NULL,'2026-08-12 10:55:43',NULL,NULL,NULL,NULL,'2026-08-12 10:55:42','2026-08-24 13:26:42',1,1,0,0,0,0,0,0.000,'none','selling',0.0000,'Kg',0.000,'None',0.00,0.00,0.00,0,0,0,0,0,0,NULL,0,'','',0,NULL,NULL,''),(162,'GDA24950513',NULL,'Guard test A',NULL,'normal',0,19,NULL,NULL,NULL,NULL,NULL,NULL,10.0000,10.0000,100.000,0,NULL,NULL,'2026-08-12 10:55:50',NULL,NULL,NULL,NULL,'2026-08-12 10:55:50','2026-08-24 13:26:42',1,2,0,0,0,0,0,0.000,'none','selling',0.0000,'Kg',0.000,'None',0.00,0.00,0.00,0,0,0,0,0,0,NULL,0,'','',0,NULL,NULL,''),(163,'GDB24950513',NULL,'Guard test B',NULL,'normal',0,19,NULL,NULL,NULL,NULL,NULL,NULL,10.0000,10.0000,0.000,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-12 10:55:50','2026-08-24 13:26:42',1,3,0,0,0,0,0,0.000,'none','selling',0.0000,'Kg',0.000,'None',0.00,0.00,0.00,0,0,0,0,0,0,NULL,0,'','',0,NULL,NULL,''),(164,'GDC24950513',NULL,'Guard test C',NULL,'normal',0,19,NULL,NULL,NULL,NULL,NULL,NULL,10.0000,10.0000,99.000,0,NULL,NULL,'2026-08-12 10:55:50','2026-09-01 11:04:57',NULL,NULL,NULL,'2026-08-12 10:55:50','2026-09-01 11:04:57',1,4,0,0,0,0,0,0.000,'none','selling',0.0000,'Kg',0.000,'None',0.00,0.00,0.00,0,0,0,0,0,0,NULL,0,'','',0,NULL,NULL,''),(165,'GDD24950513',NULL,'Guard test D',NULL,'normal',0,19,NULL,NULL,NULL,NULL,NULL,NULL,10.0000,10.0000,-1.000,0,NULL,NULL,NULL,'2026-09-01 11:04:57',NULL,NULL,NULL,'2026-08-12 10:55:50','2026-09-01 11:04:57',1,5,0,0,0,0,0,0.000,'none','selling',0.0000,'Kg',0.000,'None',0.00,0.00,0.00,0,0,0,0,0,0,NULL,0,'','',0,NULL,NULL,''),(166,'GDE24950513',NULL,'Guard test E',NULL,'normal',0,19,NULL,NULL,NULL,NULL,NULL,NULL,10.0000,10.0000,101.000,0,NULL,NULL,'2026-08-12 10:55:50',NULL,NULL,NULL,NULL,'2026-08-12 10:55:50','2026-08-24 13:26:42',1,6,0,0,0,0,0,0.000,'none','selling',0.0000,'Kg',0.000,'None',0.00,0.00,0.00,0,0,0,0,0,0,NULL,0,'','',0,NULL,NULL,''),(167,'GDF24950513',NULL,'Guard test F',NULL,'normal',0,19,NULL,NULL,NULL,NULL,NULL,NULL,12.0000,12.0000,100.000,0,NULL,NULL,'2026-08-12 10:55:50',NULL,NULL,NULL,NULL,'2026-08-12 10:55:50','2026-08-24 13:26:42',1,7,0,0,0,0,0,0.000,'none','selling',0.0000,'Kg',0.000,'None',0.00,0.00,0.00,0,0,0,0,0,0,NULL,0,'','',0,NULL,NULL,''),(168,'GDG24950513',NULL,'Guard test G',NULL,'normal',0,19,NULL,NULL,NULL,NULL,NULL,NULL,10.0000,10.0000,0.000,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-12 10:55:51','2026-08-24 13:26:45',1,8,0,0,0,0,0,0.000,'none','selling',0.0000,'Kg',0.000,'None',0.00,0.00,0.00,0,0,0,0,0,0,NULL,0,'','',0,NULL,NULL,''),(169,'GDH24950513',NULL,'Guard test H',NULL,'normal',0,19,NULL,NULL,NULL,NULL,NULL,NULL,10.0000,10.0000,100.000,0,NULL,NULL,'2026-08-12 10:55:51',NULL,NULL,NULL,NULL,'2026-08-12 10:55:51','2026-08-24 13:26:45',1,9,0,0,0,0,0,0.000,'none','selling',0.0000,'Kg',0.000,'None',0.00,0.00,0.00,0,0,0,0,0,0,NULL,0,'','',0,NULL,NULL,''),(170,'PRD00001',NULL,'Paint Can Test',NULL,'batch',0,19,NULL,NULL,NULL,'tile-1',3,1,12.0000,12.0000,9.000,0,NULL,'2026-08-24 12:48:34','2026-08-24 12:49:22',NULL,NULL,NULL,NULL,'2026-08-24 12:48:34','2026-08-24 13:26:45',1,11,0,0,0,0,0,0.000,'none','selling',0.0000,'Kg',0.000,'None',0.00,0.00,0.00,0,0,0,0,0,0,NULL,0,'','',0,NULL,NULL,''),(171,'PRD00002','1234567890','Oliver Test',NULL,'normal',0,15,NULL,NULL,NULL,'pic-deep-blue',3,1,17.3900,17.3900,0.000,1,NULL,'2026-08-25 19:31:22',NULL,NULL,NULL,NULL,NULL,'2026-08-25 19:26:40','2026-08-31 10:50:21',1,0,0,0,0,0,0,0.000,'none','selling',0.0000,'Kg',0.000,'None',0.00,0.00,0.00,0,0,0,0,0,0,NULL,0,'','',0,NULL,NULL,''),(174,'PRD00005',NULL,'Oliver Test × 24',NULL,'normal',0,15,NULL,NULL,NULL,NULL,3,1,417.3600,417.3600,0.000,1,NULL,'2026-08-25 19:29:55',NULL,NULL,NULL,NULL,NULL,'2026-08-25 19:29:55','2026-08-31 10:50:21',1,0,0,0,0,0,0,0.000,'none','selling',0.0000,'Kg',24.000,'Pack',0.00,0.00,0.00,0,0,0,0,0,0,NULL,0,'','',0,NULL,NULL,''),(182,'78',NULL,'Oliver Test × 12',NULL,'normal',0,15,NULL,NULL,NULL,NULL,3,1,208.6800,208.6800,0.000,1,NULL,'2026-08-25 19:30:21',NULL,NULL,NULL,NULL,NULL,'2026-08-25 19:30:21','2026-08-31 10:50:21',1,0,0,0,0,0,0,0.000,'none','selling',0.0000,'Kg',12.000,'Pack',0.00,0.00,0.00,0,0,0,0,0,0,NULL,0,'','',0,NULL,NULL,''),(184,'PRD00012',NULL,'Oliver Test × 6',NULL,'refer',0,15,NULL,NULL,NULL,NULL,3,1,104.3400,104.3400,0.000,0,NULL,'2026-08-25 19:31:21',NULL,NULL,NULL,NULL,NULL,'2026-08-25 19:31:21','2026-08-25 19:31:21',1,0,0,0,0,0,0,0.000,'none','selling',0.0000,'Kg',6.000,'Pack',0.00,0.00,0.00,0,0,0,0,0,0,NULL,0,'','',0,NULL,NULL,''),(185,'PRD00013',NULL,'Oliver Test × 24',NULL,'refer',0,15,NULL,NULL,NULL,NULL,3,1,417.3600,417.3600,0.000,0,NULL,'2026-08-25 19:31:21',NULL,NULL,NULL,NULL,NULL,'2026-08-25 19:31:21','2026-08-25 19:31:21',1,0,0,0,0,0,0,0.000,'none','selling',0.0000,'Kg',24.000,'Pack',0.00,0.00,0.00,0,0,0,0,0,0,NULL,0,'','',0,NULL,NULL,''),(186,'PRD00014',NULL,'Gift Card',NULL,'gift_card',0,16,NULL,NULL,NULL,'pic-red',4,2,0.0000,0.0000,0.000,0,NULL,'2026-08-26 15:22:32',NULL,NULL,NULL,NULL,NULL,'2026-08-26 15:13:27','2026-08-26 15:22:32',1,0,0,1,0,0,0,0.000,'none','selling',0.0000,'Kg',0.000,'None',0.00,0.00,0.00,0,0,0,0,0,0,NULL,0,'','',0,NULL,NULL,''),(187,'PRD00015',NULL,'Refer test',NULL,'normal',0,NULL,NULL,NULL,NULL,'tile-1',3,1,100.0000,0.0000,0.000,0,NULL,'2026-08-26 16:04:33',NULL,NULL,NULL,NULL,NULL,'2026-08-26 15:47:02','2026-08-31 10:50:21',1,0,0,0,0,0,0,0.000,'none','selling',0.0000,'Kg',0.000,'None',0.00,0.00,0.00,0,0,0,0,0,0,NULL,0,'','',0,NULL,NULL,''),(188,'PRD00016',NULL,'Refer test × 6',NULL,'normal',0,NULL,NULL,NULL,NULL,NULL,3,1,60.0000,60.0000,0.000,0,NULL,'2026-08-26 15:48:42',NULL,NULL,NULL,NULL,NULL,'2026-08-26 15:48:42','2026-08-31 10:50:21',1,0,0,0,0,0,0,0.000,'none','selling',0.0000,'Kg',6.000,'Pack',0.00,0.00,0.00,0,0,0,0,0,0,NULL,0,'','',0,NULL,NULL,''),(189,'PRD00017',NULL,'Refer test × 24',NULL,'normal',0,NULL,NULL,NULL,NULL,NULL,3,1,120.0000,120.0000,10.000,0,NULL,'2026-08-26 15:48:42',NULL,NULL,'2026-08-26 16:03:10',NULL,NULL,'2026-08-26 15:48:42','2026-08-31 10:50:21',1,0,0,0,0,0,0,0.000,'none','selling',0.0000,'Kg',24.000,'Pack',0.00,0.00,0.00,0,0,0,0,0,0,NULL,0,'','',0,NULL,NULL,''),(190,'PRD00018',NULL,'Refer 2 item',NULL,'normal',0,NULL,NULL,NULL,NULL,'tile-1',3,1,60.0000,50.0000,0.000,0,NULL,'2026-08-26 16:20:13',NULL,NULL,NULL,NULL,NULL,'2026-08-26 16:01:30','2026-08-31 10:50:21',1,0,0,0,0,0,0,0.000,'none','selling',0.0000,'Kg',0.000,'None',0.00,0.00,0.00,0,0,0,0,0,0,NULL,0,'','',0,NULL,NULL,''),(191,'PRD00019',NULL,'Refer 2 item × 6',NULL,'refer',0,NULL,NULL,NULL,NULL,NULL,3,1,300.0000,300.0000,0.000,0,NULL,'2026-08-26 16:01:44',NULL,NULL,NULL,NULL,NULL,'2026-08-26 16:01:44','2026-08-26 16:01:44',1,0,0,0,0,0,0,0.000,'none','selling',0.0000,'Kg',6.000,'Pack',0.00,0.00,0.00,0,0,0,0,0,0,NULL,0,'','',0,NULL,NULL,''),(192,'PRD00020',NULL,'Refer 2 item × 12',NULL,'refer',0,NULL,NULL,NULL,NULL,NULL,3,1,600.0000,600.0000,9.000,0,NULL,'2026-08-26 16:01:44',NULL,NULL,'2026-08-26 16:51:23',NULL,NULL,'2026-08-26 16:01:44','2026-08-26 16:51:23',1,0,0,0,0,0,0,0.000,'none','selling',0.0000,'Kg',12.000,'Pack',0.00,0.00,0.00,0,0,0,0,0,0,NULL,0,'','',0,NULL,NULL,'');
/*!40000 ALTER TABLE `products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `public_holidays`
--

DROP TABLE IF EXISTS `public_holidays`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `public_holidays` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `holiday_date` date NOT NULL,
  `name` varchar(120) NOT NULL,
  `is_working_day` tinyint(1) NOT NULL DEFAULT 0,
  `note` varchar(400) DEFAULT NULL,
  `created_by_user_id` int(10) unsigned DEFAULT NULL,
  `created_by_name` varchar(120) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_holiday_date` (`holiday_date`),
  KEY `ix_holiday_date` (`holiday_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `public_holidays`
--

LOCK TABLES `public_holidays` WRITE;
/*!40000 ALTER TABLE `public_holidays` DISABLE KEYS */;
/*!40000 ALTER TABLE `public_holidays` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `purchase_document_audit`
--

DROP TABLE IF EXISTS `purchase_document_audit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `purchase_document_audit` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `document_id` int(10) unsigned NOT NULL,
  `action` varchar(40) NOT NULL,
  `detail` varchar(400) DEFAULT NULL,
  `before_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`before_json`)),
  `after_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`after_json`)),
  `user_id` int(10) unsigned DEFAULT NULL,
  `user_name` varchar(120) NOT NULL DEFAULT '',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `ix_pdocaudit_document` (`document_id`,`created_at`),
  CONSTRAINT `purchase_document_audit_ibfk_1` FOREIGN KEY (`document_id`) REFERENCES `purchase_documents` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `purchase_document_audit`
--

LOCK TABLES `purchase_document_audit` WRITE;
/*!40000 ALTER TABLE `purchase_document_audit` DISABLE KEYS */;
INSERT INTO `purchase_document_audit` VALUES (1,27,'finalised','GRV000019 · 138.00 · Draft Test Wholesalers',NULL,NULL,1,'Tiaan Smith','2026-08-24 12:49:22');
/*!40000 ALTER TABLE `purchase_document_audit` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `purchase_document_charges`
--

DROP TABLE IF EXISTS `purchase_document_charges`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `purchase_document_charges` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `document_id` int(10) unsigned NOT NULL,
  `supplier_id` int(10) unsigned DEFAULT NULL,
  `description` varchar(120) NOT NULL,
  `amount_excl` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `vat_rate_pct` decimal(6,3) NOT NULL DEFAULT 0.000,
  `their_invoice_no` varchar(60) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `ix_pcharge_document` (`document_id`),
  KEY `ix_pcharge_supplier` (`supplier_id`),
  CONSTRAINT `purchase_document_charges_ibfk_1` FOREIGN KEY (`document_id`) REFERENCES `purchase_documents` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `purchase_document_charges`
--

LOCK TABLES `purchase_document_charges` WRITE;
/*!40000 ALTER TABLE `purchase_document_charges` DISABLE KEYS */;
INSERT INTO `purchase_document_charges` VALUES (1,17,NULL,'Courier',75.0000,15.000,NULL,'2026-08-12 10:55:43'),(3,25,10,'Courier',200.0000,15.000,NULL,'2026-08-12 10:55:50');
/*!40000 ALTER TABLE `purchase_document_charges` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `purchase_document_lines`
--

DROP TABLE IF EXISTS `purchase_document_lines`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `purchase_document_lines` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `document_id` int(10) unsigned NOT NULL,
  `source_line_id` int(10) unsigned DEFAULT NULL,
  `line_number` smallint(5) unsigned NOT NULL DEFAULT 0,
  `product_id` int(10) unsigned DEFAULT NULL,
  `job_card_line_id` int(10) unsigned DEFAULT NULL,
  `location_id` int(10) unsigned DEFAULT NULL,
  `product_code` varchar(48) DEFAULT NULL,
  `supplier_code` varchar(48) DEFAULT NULL,
  `description` varchar(190) NOT NULL,
  `product_type` varchar(30) NOT NULL DEFAULT 'normal',
  `department_id` int(10) unsigned DEFAULT NULL,
  `qty_ordered` decimal(12,3) NOT NULL DEFAULT 0.000,
  `qty_received` decimal(12,3) NOT NULL DEFAULT 0.000,
  `qty_bonus` decimal(12,3) NOT NULL DEFAULT 0.000,
  `unit_cost_excl` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `discount_pct` decimal(6,3) NOT NULL DEFAULT 0.000,
  `discount_amount` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `vat_rate_pct` decimal(6,3) NOT NULL DEFAULT 0.000,
  `line_total_excl` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `line_vat` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `line_total_incl` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `charge_excl` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `landed_cost_excl` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `selling_price_incl` decimal(12,4) DEFAULT NULL COMMENT 'Buyer-set shelf price (VAT incl.); NULL = leave the price alone',
  PRIMARY KEY (`id`),
  KEY `ix_pline_document` (`document_id`,`line_number`),
  KEY `ix_pline_product` (`product_id`),
  KEY `fk_pline_location` (`location_id`),
  KEY `ix_pline_source` (`source_line_id`),
  KEY `ix_pdline_job_line` (`job_card_line_id`),
  CONSTRAINT `purchase_document_lines_ibfk_1` FOREIGN KEY (`job_card_line_id`) REFERENCES `job_card_lines` (`id`) ON DELETE SET NULL,
  CONSTRAINT `purchase_document_lines_ibfk_2` FOREIGN KEY (`document_id`) REFERENCES `purchase_documents` (`id`) ON DELETE CASCADE,
  CONSTRAINT `purchase_document_lines_ibfk_3` FOREIGN KEY (`location_id`) REFERENCES `stock_locations` (`id`),
  CONSTRAINT `purchase_document_lines_ibfk_4` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=43 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `purchase_document_lines`
--

LOCK TABLES `purchase_document_lines` WRITE;
/*!40000 ALTER TABLE `purchase_document_lines` DISABLE KEYS */;
INSERT INTO `purchase_document_lines` VALUES (1,1,NULL,1,9,NULL,1,'SB-103',NULL,'Bacon & Blue Smash','normal',11,1.000,1.000,0.000,58.0000,0.000,0.0000,15.000,58.0000,8.7000,66.7000,0.0000,0.0000,'2026-08-10 16:28:56',NULL),(2,1,NULL,2,30,NULL,1,'PZ-304',NULL,'BBQ Chicken & Bacon','normal',13,1.000,1.000,0.000,70.0000,0.000,0.0000,15.000,70.0000,10.5000,80.5000,0.0000,0.0000,'2026-08-10 16:28:56',NULL),(3,1,NULL,3,42,NULL,1,'SD-406',NULL,'Buffalo Chicken Wings','normal',14,1.000,1.000,0.000,38.0000,0.000,0.0000,15.000,38.0000,5.7000,43.7000,0.0000,0.0000,'2026-08-10 16:28:56',NULL),(13,2,NULL,1,149,NULL,NULL,'OP24876588',NULL,'Order test item','normal',NULL,100.000,100.000,0.000,10.0000,0.000,0.0000,15.000,1000.0000,150.0000,1150.0000,0.0000,0.0000,'2026-08-12 10:54:36',NULL),(14,3,NULL,1,149,NULL,1,NULL,NULL,'Order test item','normal',NULL,100.000,40.000,0.000,10.0000,0.000,0.0000,15.000,400.0000,60.0000,460.0000,0.0000,10.0000,'2026-08-12 10:54:36',NULL),(15,4,NULL,1,149,NULL,1,NULL,NULL,'Order test item','normal',NULL,100.000,60.000,0.000,10.0000,0.000,0.0000,15.000,600.0000,90.0000,690.0000,0.0000,10.0000,'2026-08-12 10:54:37',NULL),(16,5,NULL,1,149,NULL,NULL,NULL,NULL,'Order test item','normal',NULL,5.000,0.000,0.000,10.0000,0.000,0.0000,15.000,50.0000,7.5000,57.5000,0.0000,0.0000,'2026-08-12 10:54:37',NULL),(30,15,NULL,1,152,NULL,NULL,NULL,NULL,'Not counted yet','normal',NULL,0.000,0.000,0.000,0.0000,0.000,0.0000,15.000,0.0000,0.0000,0.0000,0.0000,0.0000,'2026-08-12 10:55:43',NULL),(31,17,NULL,1,152,NULL,NULL,NULL,NULL,'With extras','normal',NULL,10.000,10.000,2.000,50.0000,5.000,0.0000,15.000,475.0000,71.2500,546.2500,0.0000,0.0000,'2026-08-12 10:55:43',NULL),(32,14,NULL,1,152,NULL,1,NULL,NULL,'Draft test item','normal',NULL,100.000,100.000,0.000,10.0000,0.000,0.0000,15.000,1000.0000,150.0000,1150.0000,0.0000,10.0000,'2026-08-12 10:55:43',NULL),(34,19,NULL,1,NULL,NULL,NULL,NULL,NULL,'Reorder LOW','normal',NULL,30.000,30.000,0.000,10.0000,0.000,0.0000,15.000,300.0000,45.0000,345.0000,0.0000,0.0000,'2026-08-12 10:55:49',NULL),(35,20,NULL,1,NULL,NULL,1,NULL,NULL,'Reorder LOW','normal',NULL,30.000,30.000,0.000,10.0000,0.000,0.0000,15.000,300.0000,45.0000,345.0000,0.0000,10.0000,'2026-08-12 10:55:49',NULL),(36,21,NULL,1,162,NULL,1,NULL,NULL,'Guard test A','normal',NULL,100.000,100.000,0.000,10.0000,0.000,0.0000,15.000,1000.0000,150.0000,1150.0000,0.0000,10.0000,'2026-08-12 10:55:50',NULL),(37,22,NULL,1,164,NULL,1,NULL,NULL,'Guard test C','normal',NULL,100.000,100.000,0.000,10.0000,0.000,0.0000,15.000,1000.0000,150.0000,1150.0000,0.0000,10.0000,'2026-08-12 10:55:50',NULL),(38,23,NULL,1,166,NULL,1,NULL,NULL,'Guard test E','normal',NULL,100.000,100.000,0.000,10.0000,0.000,0.0000,15.000,1000.0000,150.0000,1150.0000,0.0000,10.0000,'2026-08-12 10:55:50',NULL),(39,24,NULL,1,166,NULL,1,NULL,NULL,'Guard test E','normal',NULL,1.000,1.000,0.000,10.0000,0.000,0.0000,15.000,10.0000,1.5000,11.5000,0.0000,10.0000,'2026-08-12 10:55:50',NULL),(40,25,NULL,1,167,NULL,1,NULL,NULL,'Guard test F','normal',NULL,100.000,100.000,0.000,10.0000,0.000,0.0000,15.000,1000.0000,150.0000,1150.0000,200.0000,12.0000,'2026-08-12 10:55:50',NULL),(41,26,NULL,1,169,NULL,1,NULL,NULL,'Guard test H','normal',NULL,100.000,100.000,0.000,10.0000,0.000,0.0000,15.000,1000.0000,150.0000,1150.0000,0.0000,10.0000,'2026-08-12 10:55:51',NULL),(42,27,NULL,1,170,NULL,1,'PRD00001',NULL,'Paint Can Test','batch',NULL,10.000,10.000,0.000,12.0000,0.000,0.0000,15.000,120.0000,18.0000,138.0000,0.0000,12.0000,'2026-08-24 12:49:22',20.0000);
/*!40000 ALTER TABLE `purchase_document_lines` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `purchase_documents`
--

DROP TABLE IF EXISTS `purchase_documents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `purchase_documents` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `doc_type` enum('purchase_order','grv','supplier_return') NOT NULL,
  `status` enum('draft','issued','finalised','cancelled') NOT NULL DEFAULT 'draft',
  `document_number` varchar(32) DEFAULT NULL,
  `document_date` date NOT NULL,
  `due_date` date DEFAULT NULL,
  `supplier_id` int(10) unsigned NOT NULL,
  `supplier_code` varchar(32) DEFAULT NULL,
  `supplier_name` varchar(160) DEFAULT NULL,
  `supplier_invoice_no` varchar(60) DEFAULT NULL,
  `user_id` int(10) unsigned DEFAULT NULL,
  `user_name` varchar(120) NOT NULL DEFAULT '',
  `subtotal_excl` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `vat_total` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `total_incl` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `charges_excl` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `discount_pct` decimal(6,3) NOT NULL DEFAULT 0.000,
  `discount_excl` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `ordered_from_id` int(10) unsigned DEFAULT NULL,
  `reverses_id` int(10) unsigned DEFAULT NULL,
  `reference` varchar(60) DEFAULT NULL,
  `notes` varchar(400) DEFAULT NULL,
  `internal_note` varchar(400) DEFAULT NULL,
  `cancel_reason` varchar(190) DEFAULT NULL,
  `cancelled_at` datetime DEFAULT NULL,
  `finalised_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_pdoc_number` (`doc_type`,`document_number`),
  KEY `ix_pdoc_supplier` (`supplier_id`,`document_date`),
  KEY `ix_pdoc_date` (`document_date`,`id`),
  KEY `ix_pdoc_status` (`doc_type`,`status`,`document_date`),
  KEY `ix_pdoc_invoice` (`supplier_invoice_no`),
  KEY `fk_pdoc_order` (`ordered_from_id`),
  KEY `fk_pdoc_reverses` (`reverses_id`),
  CONSTRAINT `purchase_documents_ibfk_1` FOREIGN KEY (`ordered_from_id`) REFERENCES `purchase_documents` (`id`) ON DELETE SET NULL,
  CONSTRAINT `purchase_documents_ibfk_2` FOREIGN KEY (`reverses_id`) REFERENCES `purchase_documents` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `purchase_documents`
--

LOCK TABLES `purchase_documents` WRITE;
/*!40000 ALTER TABLE `purchase_documents` DISABLE KEYS */;
INSERT INTO `purchase_documents` VALUES (1,'grv','draft',NULL,'2026-08-10',NULL,1,'SUPP00001','Smash burger patties',NULL,1,'Tiaan Smith',166.0000,24.9000,190.9000,0.0000,0.000,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-10 16:28:56','2026-08-10 16:28:56'),(2,'purchase_order','issued','PO000001','2026-08-12',NULL,4,'ORD24876588','Order Test Suppliers',NULL,1,'Order Test',1000.0000,150.0000,1150.0000,0.0000,0.000,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-12 10:54:36','2026-08-12 10:54:36'),(3,'grv','finalised','GRV000001','2026-08-12','2026-09-11',4,'ORD24876588','Order Test Suppliers','INV-24876588',1,'Order Test',400.0000,60.0000,460.0000,0.0000,0.000,0.0000,2,NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-12 10:54:36','2026-08-12 10:54:36','2026-08-12 10:54:36'),(4,'grv','finalised','GRV000002','2026-08-12','2026-09-11',4,'ORD24876588','Order Test Suppliers',NULL,1,'Order Test',600.0000,90.0000,690.0000,0.0000,0.000,0.0000,2,NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-12 10:54:37','2026-08-12 10:54:37','2026-08-12 10:54:37'),(5,'purchase_order','cancelled',NULL,'2026-08-12',NULL,4,'ORD24876588','Order Test Suppliers',NULL,1,'Order Test',50.0000,7.5000,57.5000,0.0000,0.000,0.0000,NULL,NULL,NULL,NULL,NULL,'Cancelled',NULL,NULL,'2026-08-12 10:54:37','2026-08-12 10:54:37'),(14,'grv','finalised','GRV000011','2026-08-12','2026-09-11',7,'DFT24942714','Draft Test Wholesalers','INV-24942714',1,'Draft Test',1000.0000,150.0000,1150.0000,0.0000,0.000,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-12 10:55:43','2026-08-12 10:55:42','2026-08-12 10:55:43'),(15,'grv','draft',NULL,'2026-08-12',NULL,7,'DFT24942714','Draft Test Wholesalers',NULL,1,'Draft Test',0.0000,0.0000,0.0000,0.0000,0.000,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-12 10:55:43','2026-08-12 10:55:43'),(16,'grv','draft',NULL,'2026-08-12',NULL,7,'DFT24942714','Draft Test Wholesalers',NULL,1,'Draft Test',0.0000,0.0000,0.0000,0.0000,0.000,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-12 10:55:43','2026-08-12 10:55:43'),(17,'grv','draft',NULL,'2026-08-12',NULL,7,'DFT24942714','Draft Test Wholesalers',NULL,1,'Draft Test',475.0000,71.2500,621.2500,75.0000,0.000,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-12 10:55:43','2026-08-12 10:55:43'),(19,'purchase_order','issued','PO000002','2026-08-12',NULL,8,'RO24949459','Reorder Test Supply',NULL,1,'Reorder Test',300.0000,45.0000,345.0000,0.0000,0.000,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-12 10:55:49','2026-08-12 10:55:49'),(20,'grv','finalised','GRV000012','2026-08-12','2026-09-11',8,'RO24949459','Reorder Test Supply',NULL,1,'Reorder Test',300.0000,45.0000,345.0000,0.0000,0.000,0.0000,19,NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-12 10:55:49','2026-08-12 10:55:49','2026-08-12 10:55:49'),(21,'grv','finalised','GRV000013','2026-08-12','2026-09-11',9,'GRD24950513','Guard Test Supply','TIE-24950513',1,'Guard Test',1000.0000,150.0000,1150.0000,0.0000,0.000,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-12 10:55:50','2026-08-12 10:55:50','2026-08-12 10:55:50'),(22,'grv','finalised','GRV000014','2026-08-12','2026-09-11',9,'GRD24950513','Guard Test Supply',NULL,1,'Guard Test',1000.0000,150.0000,1150.0000,0.0000,0.000,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-12 10:55:50','2026-08-12 10:55:50','2026-08-12 10:55:50'),(23,'grv','finalised','GRV000015','2026-08-12','2026-09-11',9,'GRD24950513','Guard Test Supply',NULL,1,'Guard Test',1000.0000,150.0000,1150.0000,0.0000,0.000,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-12 10:55:50','2026-08-12 10:55:50','2026-08-12 10:55:50'),(24,'grv','finalised','GRV000016','2026-08-12','2026-09-11',9,'GRD24950513','Guard Test Supply',NULL,1,'Guard Test',10.0000,1.5000,11.5000,0.0000,0.000,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-12 10:55:50','2026-08-12 10:55:50','2026-08-12 10:55:50'),(25,'grv','finalised','GRV000017','2026-08-12','2026-09-11',9,'GRD24950513','Guard Test Supply',NULL,1,'Guard Test',1000.0000,150.0000,1150.0000,200.0000,0.000,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-12 10:55:50','2026-08-12 10:55:50','2026-08-12 10:55:50'),(26,'grv','finalised','GRV000018','2026-08-12','2026-09-11',9,'GRD24950513','Guard Test Supply',NULL,1,'Guard Test',1000.0000,150.0000,1150.0000,0.0000,0.000,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-12 10:55:51','2026-08-12 10:55:51','2026-08-12 10:55:51'),(27,'grv','finalised','GRV000019','2026-08-24','2026-09-23',7,'DFT24942714','Draft Test Wholesalers','12312313',1,'Tiaan Smith',120.0000,18.0000,138.0000,0.0000,0.000,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-24 12:49:22','2026-08-24 12:49:22','2026-08-24 12:49:22');
/*!40000 ALTER TABLE `purchase_documents` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `purchase_order_details`
--

DROP TABLE IF EXISTS `purchase_order_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `purchase_order_details` (
  `document_id` int(10) unsigned NOT NULL,
  `expected_date` date DEFAULT NULL,
  `fulfilment_status` enum('open','part_received','received','cancelled') NOT NULL DEFAULT 'open',
  `supplier_order_no` varchar(60) DEFAULT NULL,
  PRIMARY KEY (`document_id`),
  CONSTRAINT `purchase_order_details_ibfk_1` FOREIGN KEY (`document_id`) REFERENCES `purchase_documents` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `purchase_order_details`
--

LOCK TABLES `purchase_order_details` WRITE;
/*!40000 ALTER TABLE `purchase_order_details` DISABLE KEYS */;
INSERT INTO `purchase_order_details` VALUES (2,NULL,'received',NULL),(5,NULL,'cancelled',NULL),(19,NULL,'received',NULL);
/*!40000 ALTER TABLE `purchase_order_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recurring_expense_lines`
--

DROP TABLE IF EXISTS `recurring_expense_lines`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `recurring_expense_lines` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `recurring_id` int(10) unsigned NOT NULL,
  `line_number` smallint(5) unsigned NOT NULL DEFAULT 1,
  `category_id` int(10) unsigned NOT NULL,
  `description` varchar(190) DEFAULT NULL,
  `department_id` int(10) unsigned DEFAULT NULL,
  `vat_rate_pct` decimal(6,3) NOT NULL DEFAULT 0.000,
  `line_incl` decimal(12,4) NOT NULL DEFAULT 0.0000,
  PRIMARY KEY (`id`),
  KEY `ix_recurline_parent` (`recurring_id`,`line_number`),
  KEY `fk_recurline_category` (`category_id`),
  KEY `fk_recurline_dept` (`department_id`),
  CONSTRAINT `recurring_expense_lines_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `expense_categories` (`id`),
  CONSTRAINT `recurring_expense_lines_ibfk_2` FOREIGN KEY (`department_id`) REFERENCES `departments` (`id`) ON DELETE SET NULL,
  CONSTRAINT `recurring_expense_lines_ibfk_3` FOREIGN KEY (`recurring_id`) REFERENCES `recurring_expenses` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recurring_expense_lines`
--

LOCK TABLES `recurring_expense_lines` WRITE;
/*!40000 ALTER TABLE `recurring_expense_lines` DISABLE KEYS */;
/*!40000 ALTER TABLE `recurring_expense_lines` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recurring_expenses`
--

DROP TABLE IF EXISTS `recurring_expenses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `recurring_expenses` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(120) NOT NULL,
  `frequency` enum('weekly','monthly','quarterly','annually') NOT NULL DEFAULT 'monthly',
  `day_of_month` tinyint(3) unsigned DEFAULT NULL,
  `day_of_week` tinyint(3) unsigned DEFAULT NULL,
  `payment_type` enum('on_account','direct') NOT NULL DEFAULT 'direct',
  `supplier_id` int(10) unsigned DEFAULT NULL,
  `supplier_name` varchar(160) DEFAULT NULL,
  `bank_account_id` int(10) unsigned DEFAULT NULL,
  `description` varchar(190) DEFAULT NULL,
  `reference` varchar(60) DEFAULT NULL,
  `total_incl` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `starts_on` date NOT NULL,
  `ends_on` date DEFAULT NULL,
  `last_generated_for` date DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `notes` varchar(400) DEFAULT NULL,
  `user_id` int(10) unsigned DEFAULT NULL,
  `user_name` varchar(120) NOT NULL DEFAULT '',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `ix_recur_active` (`is_active`,`starts_on`),
  KEY `fk_recur_supplier` (`supplier_id`),
  KEY `fk_recur_bank` (`bank_account_id`),
  CONSTRAINT `recurring_expenses_ibfk_1` FOREIGN KEY (`bank_account_id`) REFERENCES `bank_accounts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recurring_expenses`
--

LOCK TABLES `recurring_expenses` WRITE;
/*!40000 ALTER TABLE `recurring_expenses` DISABLE KEYS */;
/*!40000 ALTER TABLE `recurring_expenses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recurring_journal_lines`
--

DROP TABLE IF EXISTS `recurring_journal_lines`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `recurring_journal_lines` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `recurring_id` int(10) unsigned NOT NULL,
  `line_number` int(11) NOT NULL,
  `account_id` int(10) unsigned NOT NULL,
  `amount` decimal(16,4) NOT NULL,
  `description` varchar(190) DEFAULT NULL,
  `department_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_recjnl_lines` (`recurring_id`,`line_number`),
  KEY `fk_recjnl_account` (`account_id`),
  CONSTRAINT `recurring_journal_lines_ibfk_1` FOREIGN KEY (`account_id`) REFERENCES `gl_accounts` (`id`),
  CONSTRAINT `recurring_journal_lines_ibfk_2` FOREIGN KEY (`recurring_id`) REFERENCES `recurring_journals` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recurring_journal_lines`
--

LOCK TABLES `recurring_journal_lines` WRITE;
/*!40000 ALTER TABLE `recurring_journal_lines` DISABLE KEYS */;
/*!40000 ALTER TABLE `recurring_journal_lines` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recurring_journals`
--

DROP TABLE IF EXISTS `recurring_journals`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `recurring_journals` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(120) NOT NULL,
  `frequency` enum('weekly','monthly','quarterly','annually') NOT NULL DEFAULT 'monthly',
  `day_of_month` tinyint(3) unsigned DEFAULT NULL,
  `day_of_week` tinyint(3) unsigned DEFAULT NULL,
  `description` varchar(255) NOT NULL,
  `reference` varchar(60) DEFAULT NULL,
  `starts_on` date NOT NULL,
  `ends_on` date DEFAULT NULL,
  `last_generated_for` date DEFAULT NULL,
  `auto_post` tinyint(1) NOT NULL DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `notes` varchar(400) DEFAULT NULL,
  `user_id` int(10) unsigned DEFAULT NULL,
  `user_name` varchar(120) NOT NULL DEFAULT '',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `ix_recjnl_active` (`is_active`,`last_generated_for`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recurring_journals`
--

LOCK TABLES `recurring_journals` WRITE;
/*!40000 ALTER TABLE `recurring_journals` DISABLE KEYS */;
/*!40000 ALTER TABLE `recurring_journals` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `report_columns`
--

DROP TABLE IF EXISTS `report_columns`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `report_columns` (
  `report_id` varchar(64) NOT NULL,
  `columns` text DEFAULT NULL,
  `group_by` varchar(64) DEFAULT NULL,
  `updated_by` int(10) unsigned DEFAULT NULL,
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`report_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `report_columns`
--

LOCK TABLES `report_columns` WRITE;
/*!40000 ALTER TABLE `report_columns` DISABLE KEYS */;
/*!40000 ALTER TABLE `report_columns` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `report_favorites`
--

DROP TABLE IF EXISTS `report_favorites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `report_favorites` (
  `user_id` int(10) unsigned NOT NULL,
  `report_id` varchar(64) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`user_id`,`report_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `report_favorites`
--

LOCK TABLES `report_favorites` WRITE;
/*!40000 ALTER TABLE `report_favorites` DISABLE KEYS */;
/*!40000 ALTER TABLE `report_favorites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `report_schedule_runs`
--

DROP TABLE IF EXISTS `report_schedule_runs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `report_schedule_runs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `schedule_id` int(10) unsigned NOT NULL,
  `due_at` datetime NOT NULL,
  `claimed_at` datetime NOT NULL DEFAULT current_timestamp(),
  `status` enum('claimed','sent','failed','skipped') NOT NULL DEFAULT 'claimed',
  `finished_at` datetime DEFAULT NULL,
  `recipients` varchar(500) NOT NULL DEFAULT '',
  `row_count` int(10) unsigned NOT NULL DEFAULT 0,
  `attempts` smallint(5) unsigned NOT NULL DEFAULT 1,
  `error_text` varchar(500) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_schedule_due` (`schedule_id`,`due_at`),
  KEY `idx_status` (`status`,`due_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `report_schedule_runs`
--

LOCK TABLES `report_schedule_runs` WRITE;
/*!40000 ALTER TABLE `report_schedule_runs` DISABLE KEYS */;
/*!40000 ALTER TABLE `report_schedule_runs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `report_schedules`
--

DROP TABLE IF EXISTS `report_schedules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `report_schedules` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(120) NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `report_kind` enum('builtin','saved') NOT NULL DEFAULT 'builtin',
  `report_key` varchar(64) NOT NULL DEFAULT '',
  `saved_report_id` int(10) unsigned DEFAULT NULL,
  `period_key` varchar(20) NOT NULL DEFAULT 'yesterday',
  `period_from` varchar(10) NOT NULL DEFAULT '',
  `period_to` varchar(10) NOT NULL DEFAULT '',
  `frequency` enum('daily','weekly','monthly') NOT NULL DEFAULT 'daily',
  `send_time` varchar(5) NOT NULL DEFAULT '07:00',
  `days_of_week` varchar(7) NOT NULL DEFAULT '1111111',
  `day_of_month` tinyint(3) unsigned NOT NULL DEFAULT 1,
  `recipient_user_ids` varchar(500) NOT NULL DEFAULT '',
  `recipient_emails` varchar(2000) NOT NULL DEFAULT '',
  `attach_csv` tinyint(1) NOT NULL DEFAULT 1,
  `include_html` tinyint(1) NOT NULL DEFAULT 1,
  `message` varchar(500) NOT NULL DEFAULT '',
  `owner_user_id` int(10) unsigned DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT NULL,
  `created_by_name` varchar(120) NOT NULL DEFAULT '',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `last_run_at` datetime DEFAULT NULL,
  `last_run_status` varchar(20) NOT NULL DEFAULT '',
  `last_run_error` varchar(500) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `idx_active` (`is_active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `report_schedules`
--

LOCK TABLES `report_schedules` WRITE;
/*!40000 ALTER TABLE `report_schedules` DISABLE KEYS */;
/*!40000 ALTER TABLE `report_schedules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reservation_settings`
--

DROP TABLE IF EXISTS `reservation_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `reservation_settings` (
  `id` int(10) unsigned NOT NULL DEFAULT 1,
  `is_enabled` tinyint(1) NOT NULL DEFAULT 0,
  `opening_hours` text DEFAULT NULL,
  `slot_minutes` int(10) unsigned NOT NULL DEFAULT 30,
  `default_duration_minutes` int(10) unsigned NOT NULL DEFAULT 90,
  `lead_time_minutes` int(10) unsigned NOT NULL DEFAULT 120,
  `horizon_days` int(10) unsigned NOT NULL DEFAULT 60,
  `max_party_size` int(10) unsigned NOT NULL DEFAULT 12,
  `auto_confirm` tinyint(1) NOT NULL DEFAULT 0,
  `blurb` varchar(500) NOT NULL DEFAULT '',
  `max_per_phone_per_day` int(10) unsigned NOT NULL DEFAULT 3,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reservation_settings`
--

LOCK TABLES `reservation_settings` WRITE;
/*!40000 ALTER TABLE `reservation_settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `reservation_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reservations`
--

DROP TABLE IF EXISTS `reservations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `reservations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `reference` varchar(20) NOT NULL DEFAULT '',
  `status` enum('pending','confirmed','seated','completed','no_show','cancelled') NOT NULL DEFAULT 'pending',
  `source` enum('online','phone','walk_in') NOT NULL DEFAULT 'online',
  `contact_name` varchar(120) NOT NULL DEFAULT '',
  `contact_phone` varchar(50) NOT NULL DEFAULT '',
  `contact_email` varchar(190) NOT NULL DEFAULT '',
  `party_size` int(10) unsigned NOT NULL DEFAULT 0,
  `reserved_for` datetime NOT NULL,
  `duration_minutes` int(10) unsigned NOT NULL DEFAULT 90,
  `table_name` varchar(50) NOT NULL DEFAULT '',
  `customer_note` varchar(500) NOT NULL DEFAULT '',
  `cancel_reason` varchar(255) NOT NULL DEFAULT '',
  `seated_at` datetime DEFAULT NULL,
  `document_id` int(10) unsigned DEFAULT NULL,
  `submitted_ip` varchar(45) NOT NULL DEFAULT '',
  `user_id` int(10) unsigned DEFAULT NULL,
  `user_name` varchar(120) NOT NULL DEFAULT '',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_reservation_reference` (`reference`),
  KEY `ix_resv_when` (`reserved_for`,`status`),
  KEY `ix_resv_status` (`status`,`reserved_for`),
  KEY `ix_resv_phone` (`contact_phone`,`created_at`),
  KEY `ix_resv_table` (`table_name`,`reserved_for`),
  KEY `fk_resv_document` (`document_id`),
  KEY `fk_resv_user` (`user_id`),
  CONSTRAINT `reservations_ibfk_1` FOREIGN KEY (`document_id`) REFERENCES `sales_documents` (`id`) ON DELETE SET NULL,
  CONSTRAINT `reservations_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reservations`
--

LOCK TABLES `reservations` WRITE;
/*!40000 ALTER TABLE `reservations` DISABLE KEYS */;
/*!40000 ALTER TABLE `reservations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role_capabilities`
--

DROP TABLE IF EXISTS `role_capabilities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `role_capabilities` (
  `site_role` enum('owner','manager','staff') NOT NULL,
  `capability` varchar(60) NOT NULL,
  `allowed` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`site_role`,`capability`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role_capabilities`
--

LOCK TABLES `role_capabilities` WRITE;
/*!40000 ALTER TABLE `role_capabilities` DISABLE KEYS */;
INSERT INTO `role_capabilities` VALUES ('owner','sales.credit_note',1),('owner','sales.discount_override',1),('owner','sales.edit_finalised',1),('owner','sales.price_override',1),('owner','sales.void',1),('manager','sales.credit_note',1),('manager','sales.discount_override',1),('manager','sales.edit_finalised',0),('manager','sales.price_override',1),('manager','sales.void',1),('staff','sales.credit_note',0),('staff','sales.discount_override',0),('staff','sales.edit_finalised',0),('staff','sales.price_override',0),('staff','sales.void',0);
/*!40000 ALTER TABLE `role_capabilities` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role_permissions`
--

DROP TABLE IF EXISTS `role_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `role_permissions` (
  `role_id` int(10) unsigned NOT NULL,
  `capability` varchar(60) NOT NULL,
  `allowed` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`role_id`,`capability`),
  CONSTRAINT `role_permissions_ibfk_1` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role_permissions`
--

LOCK TABLES `role_permissions` WRITE;
/*!40000 ALTER TABLE `role_permissions` DISABLE KEYS */;
INSERT INTO `role_permissions` VALUES (1,'sales.credit_note',1),(1,'sales.discount_override',1),(1,'sales.edit_finalised',1),(1,'sales.price_override',1),(1,'sales.void',1),(2,'cashbook.edit',1),(2,'cashbook.view',1),(2,'customers.edit',1),(2,'customers.view',1),(2,'dashboard.view',1),(2,'online.edit',1),(2,'online.view',1),(2,'products.edit',1),(2,'products.view',1),(2,'purchasing.edit',1),(2,'purchasing.view',1),(2,'reports.view',1),(2,'sales.credit_note',1),(2,'sales.discount_override',1),(2,'sales.edit_finalised',0),(2,'sales.price_override',1),(2,'sales.till',1),(2,'sales.view',1),(2,'sales.void',1),(2,'stock.adjust',1),(2,'stock.transfer',1),(2,'stock.view',1),(2,'suppliers.edit',1),(2,'suppliers.view',1),(3,'customers.edit',1),(3,'customers.view',1),(3,'products.view',1),(3,'sales.credit_note',0),(3,'sales.discount_override',0),(3,'sales.edit_finalised',0),(3,'sales.price_override',0),(3,'sales.till',1),(3,'sales.view',1),(3,'sales.void',0);
/*!40000 ALTER TABLE `role_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `roles` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(60) NOT NULL,
  `description` varchar(200) DEFAULT NULL,
  `is_owner` tinyint(1) NOT NULL DEFAULT 0,
  `is_system` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_role_name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles`
--

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES (1,'Owner','Full access to everything, including permissions.',1,1,'2026-08-06 20:27:06','2026-08-06 20:27:06'),(2,'Manager','Runs the shop day to day.',0,1,'2026-08-06 20:27:06','2026-08-06 20:27:06'),(3,'Cashier','Till only.',0,1,'2026-08-06 20:27:06','2026-08-06 20:27:06');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sale_deposits`
--

DROP TABLE IF EXISTS `sale_deposits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sale_deposits` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `document_id` int(10) unsigned DEFAULT NULL,
  `basket_uid` varchar(64) DEFAULT NULL,
  `kind` enum('deposit','refund','applied') NOT NULL DEFAULT 'deposit',
  `amount` decimal(12,4) NOT NULL,
  `tender_type_id` int(10) unsigned DEFAULT NULL,
  `tender_name` varchar(60) NOT NULL DEFAULT '',
  `reference` varchar(120) DEFAULT NULL,
  `taken_on` date NOT NULL,
  `shift_id` int(10) unsigned DEFAULT NULL,
  `terminal_id` int(10) unsigned DEFAULT NULL,
  `user_id` int(10) unsigned DEFAULT NULL,
  `user_name` varchar(120) NOT NULL DEFAULT '',
  `note` varchar(190) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `ix_sdep_document` (`document_id`,`taken_on`),
  KEY `ix_sdep_basket` (`basket_uid`),
  KEY `ix_sdep_shift` (`shift_id`),
  CONSTRAINT `sale_deposits_ibfk_1` FOREIGN KEY (`document_id`) REFERENCES `sales_documents` (`id`),
  CONSTRAINT `CONSTRAINT_1` CHECK (`document_id` is not null or `basket_uid` is not null)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sale_deposits`
--

LOCK TABLES `sale_deposits` WRITE;
/*!40000 ALTER TABLE `sale_deposits` DISABLE KEYS */;
/*!40000 ALTER TABLE `sale_deposits` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sales_document_line_instructions`
--

DROP TABLE IF EXISTS `sales_document_line_instructions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sales_document_line_instructions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `line_id` int(10) unsigned NOT NULL,
  `document_id` int(10) unsigned NOT NULL,
  `sort_order` int(11) NOT NULL DEFAULT 0,
  `group_id` int(10) unsigned DEFAULT NULL,
  `group_name` varchar(120) NOT NULL DEFAULT '',
  `option_id` int(10) unsigned DEFAULT NULL,
  `option_name` varchar(120) NOT NULL DEFAULT '',
  `qty` decimal(12,3) NOT NULL DEFAULT 1.000,
  `price_adjust_incl` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `line_adjust_incl` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `product_id` int(10) unsigned DEFAULT NULL,
  `stock_qty_per` decimal(12,3) NOT NULL DEFAULT 0.000,
  `prints_on_kitchen` tinyint(1) NOT NULL DEFAULT 1,
  `prints_on_receipt` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `ix_sdli_line` (`line_id`,`sort_order`),
  KEY `ix_sdli_document` (`document_id`),
  KEY `ix_sdli_option` (`option_id`),
  KEY `ix_sdli_product` (`product_id`),
  KEY `fk_sdli_group` (`group_id`),
  CONSTRAINT `sales_document_line_instructions_ibfk_1` FOREIGN KEY (`document_id`) REFERENCES `sales_documents` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sales_document_line_instructions_ibfk_2` FOREIGN KEY (`group_id`) REFERENCES `instruction_groups` (`id`) ON DELETE SET NULL,
  CONSTRAINT `sales_document_line_instructions_ibfk_3` FOREIGN KEY (`line_id`) REFERENCES `sales_document_lines` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sales_document_line_instructions_ibfk_4` FOREIGN KEY (`option_id`) REFERENCES `instruction_options` (`id`) ON DELETE SET NULL,
  CONSTRAINT `sales_document_line_instructions_ibfk_5` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sales_document_line_instructions`
--

LOCK TABLES `sales_document_line_instructions` WRITE;
/*!40000 ALTER TABLE `sales_document_line_instructions` DISABLE KEYS */;
/*!40000 ALTER TABLE `sales_document_line_instructions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sales_document_lines`
--

DROP TABLE IF EXISTS `sales_document_lines`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sales_document_lines` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `document_id` int(10) unsigned NOT NULL,
  `line_number` smallint(5) unsigned NOT NULL DEFAULT 0,
  `product_id` int(10) unsigned DEFAULT NULL,
  `job_card_line_id` int(10) unsigned DEFAULT NULL,
  `product_code` varchar(48) DEFAULT NULL,
  `description` varchar(190) NOT NULL,
  `product_type` varchar(30) NOT NULL DEFAULT 'normal',
  `department_id` int(10) unsigned DEFAULT NULL,
  `sales_rep_id` int(10) unsigned DEFAULT NULL,
  `source_line_id` int(10) unsigned DEFAULT NULL,
  `sales_rep_user_id` int(10) unsigned DEFAULT NULL COMMENT 'users.id — who earns commission on this line. See 047.',
  `qty` decimal(12,3) NOT NULL DEFAULT 0.000,
  `qty_delivered` decimal(12,3) NOT NULL DEFAULT 0.000,
  `unit_price_incl` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `discount_pct` decimal(6,3) NOT NULL DEFAULT 0.000,
  `discount_incl` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `special_id` int(10) unsigned DEFAULT NULL,
  `discount_code_id` int(10) unsigned DEFAULT NULL,
  `gift_card_code` varchar(30) DEFAULT NULL,
  `batch_no` varchar(64) DEFAULT NULL,
  `serial_id` int(10) unsigned DEFAULT NULL,
  `vat_rate_pct` decimal(6,3) NOT NULL DEFAULT 0.000,
  `line_total_incl` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `line_total_excl` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `line_vat` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `unit_cost_excl` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `line_note` varchar(190) NOT NULL DEFAULT '',
  `ordered_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_line_document` (`document_id`,`line_number`),
  KEY `ix_line_product` (`product_id`),
  KEY `ix_line_department` (`department_id`),
  KEY `ix_sales_line_rep` (`sales_rep_id`),
  KEY `ix_sales_line_source` (`source_line_id`),
  KEY `ix_sales_line_rep_user` (`sales_rep_user_id`),
  KEY `idx_sales_lines_special` (`special_id`),
  KEY `ix_sales_lines_discount_code` (`discount_code_id`),
  KEY `ix_sdline_job_line` (`job_card_line_id`),
  KEY `ix_sales_line_serial` (`serial_id`),
  CONSTRAINT `sales_document_lines_ibfk_1` FOREIGN KEY (`document_id`) REFERENCES `sales_documents` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sales_document_lines_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE SET NULL,
  CONSTRAINT `sales_document_lines_ibfk_3` FOREIGN KEY (`discount_code_id`) REFERENCES `discount_codes` (`id`) ON DELETE SET NULL,
  CONSTRAINT `sales_document_lines_ibfk_4` FOREIGN KEY (`sales_rep_id`) REFERENCES `sales_reps` (`id`) ON DELETE SET NULL,
  CONSTRAINT `sales_document_lines_ibfk_5` FOREIGN KEY (`source_line_id`) REFERENCES `sales_document_lines` (`id`) ON DELETE SET NULL,
  CONSTRAINT `sales_document_lines_ibfk_6` FOREIGN KEY (`special_id`) REFERENCES `specials` (`id`) ON DELETE SET NULL,
  CONSTRAINT `sales_document_lines_ibfk_7` FOREIGN KEY (`job_card_line_id`) REFERENCES `job_card_lines` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=118 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sales_document_lines`
--

LOCK TABLES `sales_document_lines` WRITE;
/*!40000 ALTER TABLE `sales_document_lines` DISABLE KEYS */;
INSERT INTO `sales_document_lines` VALUES (5,1,1,49,NULL,'DR-505','Appletiser 330ml','normal',15,NULL,NULL,1,1.000,0.000,17.2500,0.000,0.0000,NULL,NULL,NULL,NULL,NULL,15.000,17.2500,15.0000,2.2500,13.0000,'2026-08-09 09:50:14','',NULL),(6,1,2,9,NULL,'SB-103','Bacon & Blue Smash','normal',11,NULL,NULL,1,1.000,0.000,17.2500,0.000,0.0000,NULL,NULL,NULL,NULL,NULL,15.000,17.2500,15.0000,2.2500,58.0000,'2026-08-09 09:50:14','',NULL),(7,1,3,22,NULL,'HD-204','Bacon Wrapped Dog','normal',12,NULL,NULL,1,1.000,0.000,11.5000,0.000,0.0000,NULL,NULL,NULL,NULL,NULL,15.000,11.5000,10.0000,1.5000,39.0000,'2026-08-09 09:50:14','',NULL),(8,1,4,49,NULL,'DR-505','Appletiser 330ml','normal',15,NULL,NULL,1,1.000,0.000,13.8000,0.000,0.0000,NULL,NULL,NULL,NULL,NULL,15.000,13.8000,12.0000,1.8000,13.0000,'2026-08-09 09:50:14','',NULL),(17,2,1,9,NULL,'SB-103','Bacon & Blue Smash','normal',11,NULL,NULL,1,1.000,0.000,139.1500,0.000,0.0000,NULL,NULL,NULL,NULL,NULL,15.000,139.1500,121.0000,18.1500,58.0000,'2026-08-09 10:14:30','',NULL),(18,2,2,18,NULL,'SB-112','BBQ Brisket Smash','normal',11,NULL,NULL,1,1.000,0.000,139.1500,0.000,0.0000,NULL,NULL,NULL,NULL,NULL,15.000,139.1500,121.0000,18.1500,66.0000,'2026-08-09 10:14:30','',NULL),(19,2,3,30,NULL,'PZ-304','BBQ Chicken & Bacon','normal',13,NULL,NULL,1,1.000,0.000,13.8000,0.000,0.0000,NULL,NULL,NULL,NULL,NULL,15.000,13.8000,12.0000,1.8000,70.0000,'2026-08-09 10:14:30','',NULL),(20,2,4,57,NULL,'DS-601','Belgian Chocolate Brownie','normal',16,NULL,NULL,1,1.000,0.000,25.3000,0.000,0.0000,NULL,NULL,NULL,NULL,NULL,15.000,25.3000,22.0000,3.3000,21.0000,'2026-08-09 10:14:30','',NULL),(29,7,1,54,NULL,'DR-510','Caramel Fudge Shake','normal',15,NULL,NULL,1,1.000,0.000,55.0000,0.000,0.0000,NULL,NULL,NULL,NULL,NULL,15.000,55.0000,47.8300,7.1700,20.0000,'2026-08-10 16:46:08','',NULL),(30,7,2,55,NULL,'DR-511','Cookies & Cream Shake','normal',15,NULL,NULL,1,1.000,0.000,62.0000,0.000,0.0000,NULL,NULL,NULL,NULL,NULL,15.000,62.0000,53.9100,8.0900,24.0000,'2026-08-10 16:46:08','',NULL),(31,7,3,50,NULL,'DR-506','Energy Drink 500ml','normal',15,NULL,NULL,1,1.000,0.000,38.0000,0.000,0.0000,NULL,NULL,NULL,NULL,NULL,15.000,38.0000,33.0400,4.9600,17.0000,'2026-08-10 16:46:08','',NULL),(48,9,1,141,NULL,'DRNK005','Appletiser 330ml','normal',15,NULL,NULL,1,1.000,0.000,11.5000,0.000,0.0000,NULL,NULL,NULL,NULL,NULL,15.000,11.5000,10.0000,1.5000,12.0000,'2026-08-11 13:46:45','',NULL),(49,9,2,127,NULL,'PIZZ005','BBQ Chicken 30cm','normal',13,NULL,NULL,1,1.000,0.000,11.5000,0.000,0.0000,NULL,NULL,NULL,NULL,NULL,15.000,11.5000,10.0000,1.5000,51.0000,'2026-08-11 13:46:45','',NULL),(50,9,3,116,NULL,'BURG008','Beyond Veggie Smash','normal',11,NULL,NULL,1,1.000,0.000,11.5000,0.000,0.0000,NULL,NULL,NULL,NULL,NULL,15.000,11.5000,10.0000,1.5000,44.0000,'2026-08-11 13:46:45','',NULL),(51,9,4,120,NULL,'DOGS004','Bratwurst & Sauerkraut Dog','normal',12,NULL,NULL,1,1.000,0.000,115.0000,0.000,0.0000,NULL,NULL,NULL,NULL,NULL,15.000,115.0000,100.0000,15.0000,34.0000,'2026-08-11 13:46:45','',NULL),(68,8,1,28,NULL,'PZ-302','Pepperoni Classic','normal',13,NULL,NULL,1,1.000,0.000,149.0000,0.000,0.0000,NULL,NULL,NULL,NULL,NULL,15.000,149.0000,129.5700,19.4300,58.0000,'2026-08-11 13:49:00','',NULL),(69,8,2,30,NULL,'PZ-304','BBQ Chicken & Bacon','normal',13,NULL,NULL,1,1.000,0.000,169.0000,0.000,0.0000,NULL,NULL,NULL,NULL,NULL,15.000,169.0000,146.9600,22.0400,70.0000,'2026-08-11 13:49:00','',NULL),(70,8,3,29,NULL,'PZ-303','Four Cheese','normal',13,NULL,NULL,1,1.000,0.000,159.0000,0.000,0.0000,NULL,NULL,NULL,NULL,NULL,15.000,159.0000,138.2600,20.7400,64.0000,'2026-08-11 13:49:00','',NULL),(71,8,4,36,NULL,'PZ-310','Prosciutto & Rocket','normal',13,NULL,NULL,1,1.000,0.000,185.0000,0.000,0.0000,NULL,NULL,NULL,NULL,NULL,15.000,185.0000,160.8700,24.1300,78.0000,'2026-08-11 13:49:00','',NULL),(72,8,5,141,NULL,'DRNK005','Appletiser 330ml','normal',15,NULL,NULL,1,1.000,0.000,28.0000,0.000,0.0000,NULL,NULL,NULL,NULL,NULL,15.000,28.0000,24.3500,3.6500,12.0000,'2026-08-11 13:49:00','',NULL),(73,8,6,141,NULL,'DRNK005','Appletiser 330ml','normal',15,NULL,NULL,1,1.000,0.000,28.0000,0.000,0.0000,NULL,NULL,NULL,NULL,NULL,15.000,28.0000,24.3500,3.6500,12.0000,'2026-08-11 13:49:00','',NULL),(74,8,7,141,NULL,'DRNK005','Appletiser 330ml','normal',15,NULL,NULL,1,1.000,0.000,28.0000,0.000,0.0000,NULL,NULL,NULL,NULL,NULL,15.000,28.0000,24.3500,3.6500,12.0000,'2026-08-11 13:49:00','',NULL),(75,8,8,141,NULL,'DRNK005','Appletiser 330ml','normal',15,NULL,NULL,1,1.000,0.000,28.0000,0.000,0.0000,NULL,NULL,NULL,NULL,NULL,15.000,28.0000,24.3500,3.6500,12.0000,'2026-08-11 13:49:00','',NULL),(76,10,1,170,NULL,'PRD00001','Paint Can Test','batch',NULL,NULL,NULL,1,1.000,0.000,20.0000,0.000,0.0000,NULL,NULL,NULL,NULL,NULL,15.000,20.0000,17.3900,2.6100,12.0000,'2026-08-24 12:50:09','','2026-08-24 10:50:04'),(78,12,1,127,NULL,'PIZZ005','BBQ Chicken 30cm','normal',13,NULL,NULL,1,1.000,0.000,139.0000,0.000,0.0000,NULL,NULL,NULL,NULL,NULL,15.000,139.0000,120.8700,18.1300,51.0000,'2026-08-25 19:18:39','','2026-08-25 17:18:53'),(79,11,1,127,NULL,'PIZZ005','BBQ Chicken 30cm','normal',13,NULL,NULL,1,1.000,0.000,139.0000,0.000,0.0000,NULL,NULL,NULL,NULL,NULL,15.000,139.0000,120.8700,18.1300,51.0000,'2026-08-25 19:19:45','','2026-08-25 17:13:57'),(85,13,1,152,NULL,'DP24942714','Draft test item 24942714','normal',19,NULL,NULL,1,1.000,0.000,0.0000,0.000,0.0000,NULL,NULL,NULL,NULL,NULL,0.000,0.0000,0.0000,0.0000,10.0000,'2026-08-25 19:23:49','',NULL),(86,13,2,109,NULL,'BURG001','Classic Smash','normal',11,NULL,NULL,1,1.000,0.000,0.0000,0.000,0.0000,NULL,NULL,NULL,NULL,NULL,15.000,0.0000,0.0000,0.0000,26.0000,'2026-08-25 19:23:49','',NULL),(87,13,3,165,NULL,'GDD24950513','Guard test D','normal',19,NULL,NULL,1,1.000,0.000,0.0000,0.000,0.0000,NULL,NULL,NULL,NULL,NULL,0.000,0.0000,0.0000,0.0000,10.0000,'2026-08-25 19:23:49','',NULL),(88,13,4,166,NULL,'GDE24950513','Guard test E','normal',19,NULL,NULL,1,1.000,0.000,0.0000,0.000,0.0000,NULL,NULL,NULL,NULL,NULL,0.000,0.0000,0.0000,0.0000,10.0000,'2026-08-25 19:23:49','',NULL),(89,13,5,115,NULL,'BURG007','Buttermilk Chicken Burger','normal',11,NULL,NULL,1,1.000,0.000,0.0000,0.000,0.0000,NULL,NULL,NULL,NULL,NULL,15.000,0.0000,0.0000,0.0000,36.0000,'2026-08-25 19:23:49','',NULL),(90,14,1,186,NULL,'PRD00014','Gift Card','gift_card',16,NULL,NULL,1,1.000,0.000,500.0000,0.000,0.0000,NULL,NULL,'MH7QBXHHCCX6',NULL,NULL,15.000,500.0000,434.7800,65.2200,0.0000,'2026-08-26 15:20:35','','2026-08-26 13:15:07'),(91,15,1,186,NULL,'PRD00014','Gift Card','gift_card',16,NULL,NULL,1,1.000,0.000,500.0000,0.000,0.0000,NULL,NULL,'MH7QBXHHCCX6',NULL,NULL,15.000,500.0000,434.7800,65.2200,0.0000,'2026-08-26 15:20:54','','2026-08-26 13:15:07'),(92,16,1,186,NULL,'PRD00014','Gift Card','gift_card',16,NULL,NULL,1,1.000,0.000,500.0000,0.000,0.0000,NULL,NULL,'MH7QBXHHCCX6',NULL,NULL,15.000,500.0000,434.7800,65.2200,0.0000,'2026-08-26 15:21:00','','2026-08-26 13:15:07'),(93,17,1,186,NULL,'PRD00014','Gift Card','gift_card',16,NULL,NULL,1,1.000,0.000,500.0000,0.000,0.0000,NULL,NULL,'MH7QBXHHCCX6',NULL,NULL,15.000,500.0000,434.7800,65.2200,0.0000,'2026-08-26 15:21:09','','2026-08-26 13:15:07'),(94,18,1,186,NULL,'PRD00014','Gift Card','gift_card',16,NULL,NULL,1,1.000,0.000,500.0000,0.000,0.0000,NULL,NULL,'MH7QBXHHCCX6',NULL,NULL,0.000,500.0000,500.0000,0.0000,0.0000,'2026-08-26 15:23:33','','2026-08-26 13:23:03'),(95,19,1,112,NULL,'BURG004','Bacon & Cheddar Smash','normal',12,NULL,NULL,1,1.000,0.000,119.0000,0.000,0.0000,NULL,NULL,NULL,NULL,NULL,15.000,119.0000,103.4800,15.5200,42.0000,'2026-08-26 15:33:03','','2026-08-26 13:31:56'),(96,20,1,141,NULL,'DRNK005','Appletiser 330ml','normal',15,NULL,NULL,1,1.000,0.000,28.0000,0.000,0.0000,NULL,NULL,NULL,NULL,NULL,15.000,28.0000,24.3500,3.6500,12.0000,'2026-08-26 15:34:12','','2026-08-26 13:33:29'),(97,21,1,182,NULL,'78','Oliver Test × 12','refer',15,NULL,NULL,1,1.000,0.000,0.0000,0.000,0.0000,NULL,NULL,NULL,NULL,NULL,15.000,0.0000,0.0000,0.0000,208.6800,'2026-08-26 15:38:53','','2026-08-26 13:35:02'),(98,21,2,174,NULL,'PRD00005','Oliver Test × 24','refer',15,NULL,NULL,1,1.000,0.000,0.0000,0.000,0.0000,NULL,NULL,NULL,NULL,NULL,15.000,0.0000,0.0000,0.0000,417.3600,'2026-08-26 15:38:53','','2026-08-26 13:35:03'),(99,21,3,171,NULL,'PRD00002','Oliver Test','refer',15,NULL,NULL,1,1.000,0.000,60.0000,0.000,0.0000,NULL,NULL,NULL,NULL,NULL,15.000,60.0000,52.1700,7.8300,17.3900,'2026-08-26 15:38:53','','2026-08-26 13:35:04'),(100,21,4,143,NULL,'DRNK007','Lipton Ice Tea Peach 300ml','normal',15,NULL,NULL,1,1.000,0.000,26.0000,0.000,0.0000,NULL,NULL,NULL,NULL,NULL,15.000,26.0000,22.6100,3.3900,11.0000,'2026-08-26 15:38:53','','2026-08-26 13:35:05'),(101,21,5,138,NULL,'DRNK002','Coca-Cola Zero 330ml Can','normal',15,NULL,NULL,1,1.000,0.000,22.0000,0.000,0.0000,NULL,NULL,NULL,NULL,NULL,15.000,22.0000,19.1300,2.8700,8.5000,'2026-08-26 15:38:53','','2026-08-26 13:35:34'),(102,22,1,182,NULL,'78','Oliver Test × 12','refer',15,NULL,NULL,1,1.000,0.000,0.0000,0.000,0.0000,NULL,NULL,NULL,NULL,NULL,15.000,0.0000,0.0000,0.0000,208.6800,'2026-08-26 15:38:59','','2026-08-26 13:35:02'),(103,22,2,174,NULL,'PRD00005','Oliver Test × 24','refer',15,NULL,NULL,1,1.000,0.000,0.0000,0.000,0.0000,NULL,NULL,NULL,NULL,NULL,15.000,0.0000,0.0000,0.0000,417.3600,'2026-08-26 15:38:59','','2026-08-26 13:35:03'),(104,22,3,171,NULL,'PRD00002','Oliver Test','refer',15,NULL,NULL,1,1.000,0.000,60.0000,0.000,0.0000,NULL,NULL,NULL,NULL,NULL,15.000,60.0000,52.1700,7.8300,17.3900,'2026-08-26 15:38:59','','2026-08-26 13:35:04'),(105,22,4,143,NULL,'DRNK007','Lipton Ice Tea Peach 300ml','normal',15,NULL,NULL,1,1.000,0.000,26.0000,0.000,0.0000,NULL,NULL,NULL,NULL,NULL,15.000,26.0000,22.6100,3.3900,11.0000,'2026-08-26 15:38:59','','2026-08-26 13:35:05'),(106,22,5,138,NULL,'DRNK002','Coca-Cola Zero 330ml Can','normal',15,NULL,NULL,1,1.000,0.000,22.0000,0.000,0.0000,NULL,NULL,NULL,NULL,NULL,15.000,22.0000,19.1300,2.8700,8.5000,'2026-08-26 15:38:59','','2026-08-26 13:35:34'),(107,23,1,112,NULL,'BURG004','Bacon & Cheddar Smash','normal',12,NULL,NULL,1,1.000,0.000,119.0000,0.000,0.0000,NULL,NULL,NULL,NULL,NULL,15.000,119.0000,103.4800,15.5200,42.0000,'2026-08-26 15:39:13','','2026-08-26 13:39:06'),(108,24,1,187,NULL,'PRD00015','Refer test','refer',NULL,NULL,NULL,1,1.000,0.000,250.0000,0.000,0.0000,NULL,NULL,NULL,NULL,NULL,15.000,250.0000,217.3900,32.6100,0.0000,'2026-08-26 16:04:49','','2026-08-26 14:04:39'),(109,25,1,187,NULL,'PRD00015','Refer test','refer',NULL,NULL,NULL,1,1.000,0.000,250.0000,0.000,0.0000,NULL,NULL,NULL,NULL,NULL,15.000,250.0000,217.3900,32.6100,0.0000,'2026-08-26 16:05:16','','2026-08-26 14:04:39'),(110,26,1,187,NULL,'PRD00015','Refer test','refer',NULL,NULL,NULL,1,1.000,0.000,250.0000,0.000,0.0000,NULL,NULL,NULL,NULL,NULL,15.000,250.0000,217.3900,32.6100,0.0000,'2026-08-26 16:05:28','','2026-08-26 14:04:39'),(111,27,1,187,NULL,'PRD00015','Refer test','refer',NULL,NULL,NULL,1,1.000,0.000,250.0000,0.000,0.0000,NULL,NULL,NULL,NULL,NULL,15.000,250.0000,217.3900,32.6100,0.0000,'2026-08-26 16:05:41','','2026-08-26 14:04:39'),(112,28,1,190,NULL,'PRD00018','Refer 2 item','refer',NULL,NULL,NULL,1,1.000,0.000,80.0000,0.000,0.0000,NULL,NULL,NULL,NULL,NULL,15.000,80.0000,69.5700,10.4300,50.0000,'2026-08-26 16:20:38','','2026-08-26 14:20:25'),(113,29,1,190,NULL,'PRD00018','Refer 2 item','refer',NULL,NULL,NULL,1,6.000,0.000,80.0000,0.000,0.0000,NULL,NULL,NULL,NULL,NULL,15.000,480.0000,417.3900,62.6100,50.0000,'2026-08-26 16:22:38','','2026-08-26 14:22:32'),(114,30,1,134,NULL,'SIDE004','Chilli Beef Loaded Fries','normal',14,NULL,NULL,1,1.000,0.000,75.0000,86.667,65.0000,3,NULL,NULL,NULL,NULL,15.000,10.0000,8.7000,1.3000,28.0000,'2026-08-31 10:55:39','','2026-08-31 08:54:30'),(115,30,2,136,NULL,'SIDE006','Coleslaw Tub','normal',14,NULL,NULL,1,1.000,0.000,28.0000,64.286,18.0000,3,NULL,NULL,NULL,NULL,15.000,10.0000,8.7000,1.3000,8.0000,'2026-08-31 10:55:39','','2026-08-31 08:54:31'),(116,31,1,164,NULL,'GDC24950513','Guard test C','normal',19,NULL,NULL,1,1.000,0.000,0.0000,0.000,0.0000,NULL,NULL,NULL,NULL,NULL,0.000,0.0000,0.0000,0.0000,10.0000,'2026-09-01 11:04:57','','2026-09-01 09:04:12'),(117,31,2,165,NULL,'GDD24950513','Guard test D','normal',19,NULL,NULL,1,1.000,0.000,0.0000,0.000,0.0000,NULL,NULL,NULL,NULL,NULL,0.000,0.0000,0.0000,0.0000,10.0000,'2026-09-01 11:04:57','','2026-09-01 09:04:12');
/*!40000 ALTER TABLE `sales_document_lines` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sales_documents`
--

DROP TABLE IF EXISTS `sales_documents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sales_documents` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `doc_type` enum('quote','sales_order','invoice','credit_sale') NOT NULL,
  `status` enum('draft','saved','issued','finalised','cancelled') NOT NULL DEFAULT 'draft',
  `document_number` varchar(32) DEFAULT NULL,
  `offline_sale_uid` char(36) DEFAULT NULL,
  `offline_taken_at` datetime DEFAULT NULL,
  `offline_synced_at` datetime DEFAULT NULL,
  `offline_exception` varchar(400) DEFAULT NULL,
  `document_date` date NOT NULL,
  `due_date` date DEFAULT NULL,
  `valid_until` date DEFAULT NULL,
  `quote_outcome` enum('open','accepted','declined') NOT NULL DEFAULT 'open',
  `quote_outcome_at` datetime DEFAULT NULL,
  `quote_lost_reason` varchar(190) DEFAULT NULL,
  `quote_sent_at` datetime DEFAULT NULL,
  `quote_sent_to` varchar(190) DEFAULT NULL,
  `quote_viewed_at` datetime DEFAULT NULL,
  `quote_view_count` int(10) unsigned NOT NULL DEFAULT 0,
  `quote_accept_method` enum('verbal','email','link','in_person','internal') DEFAULT NULL,
  `quote_accepted_by` varchar(160) DEFAULT NULL,
  `quote_accept_reference` varchar(190) DEFAULT NULL,
  `quote_accepted_by_user_id` int(10) unsigned DEFAULT NULL,
  `supersedes_id` int(10) unsigned DEFAULT NULL,
  `quote_revision` smallint(5) unsigned NOT NULL DEFAULT 1,
  `customer_id` int(10) unsigned DEFAULT NULL,
  `customer_code` varchar(32) DEFAULT NULL,
  `customer_name` varchar(160) DEFAULT NULL,
  `customer_vat_no` varchar(40) DEFAULT NULL,
  `customer_phone` varchar(40) DEFAULT NULL,
  `customer_address` varchar(400) DEFAULT NULL,
  `price_structure_id` int(10) unsigned DEFAULT NULL,
  `user_id` int(10) unsigned DEFAULT NULL,
  `user_name` varchar(120) NOT NULL DEFAULT '',
  `terminal_id` int(10) unsigned DEFAULT NULL,
  `terminal_code` varchar(24) DEFAULT NULL,
  `origin` enum('till','back_office') NOT NULL DEFAULT 'till' COMMENT 'where captured; back_office numbers from the shared run even with a terminal_id',
  `shift_id` int(10) unsigned DEFAULT NULL,
  `subtotal_excl` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `vat_total` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `discount_total` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `total_incl` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `rounding_adj` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `tendered_total` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `change_given` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `converted_from_id` int(10) unsigned DEFAULT NULL,
  `job_card_id` int(10) unsigned DEFAULT NULL,
  `reverses_id` int(10) unsigned DEFAULT NULL,
  `reference` varchar(60) DEFAULT NULL,
  `notes` varchar(400) DEFAULT NULL,
  `internal_note` varchar(400) DEFAULT NULL,
  `cancel_reason` varchar(190) DEFAULT NULL,
  `cancel_reason_id` int(10) unsigned DEFAULT NULL,
  `return_reason_id` int(10) unsigned DEFAULT NULL,
  `cancelled_at` datetime DEFAULT NULL,
  `cancelled_by_user_id` int(10) unsigned DEFAULT NULL,
  `finalised_at` datetime DEFAULT NULL,
  `print_count` int(10) unsigned NOT NULL DEFAULT 0,
  `last_printed_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `person_count` smallint(5) unsigned DEFAULT NULL,
  `visit_type_id` int(10) unsigned DEFAULT NULL,
  `discount_code_id` int(10) unsigned DEFAULT NULL,
  `discount_code` varchar(40) NOT NULL DEFAULT '',
  `claimed_by` int(10) unsigned DEFAULT NULL,
  `claimed_at` datetime DEFAULT NULL,
  `claimed_terminal_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_doc_number` (`doc_type`,`document_number`),
  UNIQUE KEY `uq_offline_uid` (`offline_sale_uid`),
  KEY `ix_doc_date` (`document_date`,`id`),
  KEY `ix_doc_customer` (`customer_id`,`document_date`),
  KEY `ix_doc_status` (`doc_type`,`status`,`document_date`),
  KEY `ix_doc_terminal` (`terminal_id`,`document_date`),
  KEY `ix_doc_user` (`user_id`,`document_date`),
  KEY `fk_sdoc_converted` (`converted_from_id`),
  KEY `fk_sdoc_reverses` (`reverses_id`),
  KEY `ix_sales_quote` (`doc_type`,`quote_outcome`,`valid_until`),
  KEY `ix_offline_unsynced` (`offline_synced_at`,`offline_taken_at`),
  KEY `ix_sales_cancel_reason` (`cancel_reason_id`),
  KEY `ix_sales_return_reason` (`return_reason_id`),
  KEY `ix_sdoc_job` (`job_card_id`,`doc_type`),
  KEY `ix_sdoc_quote_accept` (`job_card_id`,`doc_type`,`quote_outcome`),
  KEY `ix_sdoc_supersedes` (`supersedes_id`),
  KEY `idx_sales_documents_visit_type` (`visit_type_id`),
  KEY `ix_sales_doc_discount_code` (`discount_code_id`),
  KEY `ix_sales_documents_claim` (`claimed_at`),
  KEY `ix_sales_documents_claim_terminal` (`claimed_terminal_id`),
  KEY `ix_sales_quote_sent` (`doc_type`,`quote_outcome`,`quote_sent_at`),
  CONSTRAINT `sales_documents_ibfk_1` FOREIGN KEY (`cancel_reason_id`) REFERENCES `sales_void_reasons` (`id`) ON DELETE SET NULL,
  CONSTRAINT `sales_documents_ibfk_2` FOREIGN KEY (`discount_code_id`) REFERENCES `discount_codes` (`id`) ON DELETE SET NULL,
  CONSTRAINT `sales_documents_ibfk_3` FOREIGN KEY (`return_reason_id`) REFERENCES `sales_return_reasons` (`id`) ON DELETE SET NULL,
  CONSTRAINT `sales_documents_ibfk_4` FOREIGN KEY (`converted_from_id`) REFERENCES `sales_documents` (`id`) ON DELETE SET NULL,
  CONSTRAINT `sales_documents_ibfk_5` FOREIGN KEY (`job_card_id`) REFERENCES `job_cards` (`id`) ON DELETE SET NULL,
  CONSTRAINT `sales_documents_ibfk_6` FOREIGN KEY (`reverses_id`) REFERENCES `sales_documents` (`id`) ON DELETE SET NULL,
  CONSTRAINT `sales_documents_ibfk_7` FOREIGN KEY (`supersedes_id`) REFERENCES `sales_documents` (`id`) ON DELETE SET NULL,
  CONSTRAINT `sales_documents_ibfk_8` FOREIGN KEY (`terminal_id`) REFERENCES `terminals` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sales_documents`
--

LOCK TABLES `sales_documents` WRITE;
/*!40000 ALTER TABLE `sales_documents` DISABLE KEYS */;
INSERT INTO `sales_documents` VALUES (1,'invoice','finalised','INV000001',NULL,NULL,NULL,NULL,'2026-08-08',NULL,NULL,'open',NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'Tiaan Smith',NULL,NULL,'back_office',NULL,52.0000,7.8000,0.0000,59.8000,0.0000,59.8000,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-09 09:50:14',6,'2026-08-27 13:48:49','2026-08-08 07:47:48','2026-08-27 13:48:49',NULL,NULL,NULL,'',NULL,NULL,NULL),(2,'invoice','finalised','INV000002',NULL,NULL,NULL,NULL,'2026-08-09',NULL,NULL,'open',NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,1,1,NULL,'Tiaan Smith',NULL,NULL,NULL,NULL,1,'Tiaan Smith',NULL,NULL,'back_office',NULL,276.0000,41.4000,0.0000,317.4000,0.0000,317.4000,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-09 10:14:30',0,NULL,'2026-08-09 09:55:47','2026-08-12 08:49:30',NULL,NULL,NULL,'',NULL,NULL,NULL),(3,'invoice','draft',NULL,NULL,NULL,NULL,NULL,'2026-08-10',NULL,NULL,'open',NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'Tiaan Smith',NULL,NULL,'back_office',NULL,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,'2026-08-10 08:29:27','2026-08-12 08:49:30',NULL,NULL,NULL,'',NULL,NULL,NULL),(7,'invoice','draft',NULL,NULL,NULL,NULL,NULL,'2026-08-10',NULL,NULL,'open',NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,'Walk-in',NULL,NULL,NULL,1,1,'Tiaan Smith',NULL,NULL,'back_office',NULL,134.7800,20.2200,0.0000,155.0000,0.0000,0.0000,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,'2026-08-10 16:45:56','2026-08-12 08:49:30',NULL,NULL,NULL,'',NULL,NULL,NULL),(8,'invoice','finalised','INV000004',NULL,NULL,NULL,NULL,'2026-08-10',NULL,NULL,'open',NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,'Walk-in',NULL,NULL,NULL,1,1,'Tiaan Smith',NULL,NULL,'back_office',NULL,673.0600,100.9400,0.0000,774.0000,0.0000,774.0000,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-11 13:49:00',0,NULL,'2026-08-10 16:50:22','2026-08-12 08:49:30',NULL,NULL,NULL,'',NULL,NULL,NULL),(9,'invoice','cancelled','INV000003',NULL,NULL,NULL,NULL,'2026-08-11',NULL,NULL,'open',NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,1,1,NULL,'Tiaan Smith',NULL,NULL,NULL,NULL,1,'Tiaan Smith',NULL,NULL,'back_office',NULL,130.0000,19.5000,0.0000,149.5000,0.0000,149.5000,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,'test',NULL,NULL,'2026-08-11 13:50:30',1,'2026-08-11 13:46:45',0,NULL,'2026-08-11 13:45:57','2026-08-12 08:49:30',NULL,NULL,NULL,'',NULL,NULL,NULL),(10,'invoice','finalised','INV_01_01_000001',NULL,NULL,NULL,NULL,'2026-08-24',NULL,NULL,'open',NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,'Walk-in',NULL,NULL,NULL,1,1,'Tiaan Smith',1,'TILL01','till',1,17.3900,2.6100,0.0000,20.0000,0.0000,20.0000,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-24 12:50:09',0,NULL,'2026-08-24 12:50:09','2026-08-24 12:50:09',NULL,NULL,NULL,'',NULL,NULL,NULL),(11,'invoice','finalised','INV_01_03_000002',NULL,NULL,NULL,NULL,'2026-08-25',NULL,NULL,'open',NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,'Walk-in',NULL,NULL,NULL,1,1,'Tiaan Smith',3,'TILL03','till',2,120.8700,18.1300,0.0000,139.0000,0.0000,139.0000,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-25 19:19:45',1,'2026-08-26 14:20:07','2026-08-25 19:14:30','2026-08-26 14:20:07',NULL,NULL,NULL,'',1,'2026-08-25 17:19:40',3),(12,'invoice','finalised','INV_01_03_000001',NULL,NULL,NULL,NULL,'2026-08-25',NULL,NULL,'open',NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,'Walk-in',NULL,NULL,NULL,1,1,'Tiaan Smith',3,'TILL03','till',2,120.8700,18.1300,0.0000,139.0000,0.0000,139.0000,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-25 19:18:39',0,NULL,'2026-08-25 19:18:39','2026-08-25 19:18:39',NULL,NULL,NULL,'',NULL,NULL,NULL),(13,'invoice','draft',NULL,NULL,NULL,NULL,NULL,'2026-08-25',NULL,NULL,'open',NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,1,1,NULL,'Tiaan Smith',NULL,NULL,NULL,NULL,1,'Tiaan Smith',3,'TILL03','till',NULL,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,NULL,NULL,NULL,'1111',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,'2026-08-25 19:23:04','2026-08-25 19:23:39',NULL,NULL,NULL,'',NULL,NULL,NULL),(14,'invoice','draft',NULL,NULL,NULL,NULL,NULL,'2026-08-26',NULL,NULL,'open',NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,'Walk-in',NULL,NULL,NULL,1,1,'Tiaan Smith',4,'TILL04','till',NULL,434.7800,65.2200,0.0000,500.0000,0.0000,0.0000,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,'2026-08-26 15:20:35','2026-08-26 15:20:35',NULL,NULL,NULL,'',NULL,NULL,NULL),(15,'invoice','draft',NULL,NULL,NULL,NULL,NULL,'2026-08-26',NULL,NULL,'open',NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,'Walk-in',NULL,NULL,NULL,1,1,'Tiaan Smith',4,'TILL04','till',NULL,434.7800,65.2200,0.0000,500.0000,0.0000,0.0000,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,'2026-08-26 15:20:54','2026-08-26 15:20:54',NULL,NULL,NULL,'',NULL,NULL,NULL),(16,'invoice','draft',NULL,NULL,NULL,NULL,NULL,'2026-08-26',NULL,NULL,'open',NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,'Walk-in',NULL,NULL,NULL,1,1,'Tiaan Smith',4,'TILL04','till',NULL,434.7800,65.2200,0.0000,500.0000,0.0000,0.0000,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,'2026-08-26 15:21:00','2026-08-26 15:21:00',NULL,NULL,NULL,'',NULL,NULL,NULL),(17,'invoice','draft',NULL,NULL,NULL,NULL,NULL,'2026-08-26',NULL,NULL,'open',NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,'Walk-in',NULL,NULL,NULL,1,1,'Tiaan Smith',4,'TILL04','till',NULL,434.7800,65.2200,0.0000,500.0000,0.0000,0.0000,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,'2026-08-26 15:21:09','2026-08-26 15:21:09',NULL,NULL,NULL,'',NULL,NULL,NULL),(18,'invoice','finalised','INV_01_04_000001',NULL,NULL,NULL,NULL,'2026-08-26',NULL,NULL,'open',NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,'Walk-in',NULL,NULL,NULL,1,1,'Tiaan Smith',4,'TILL04','till',3,500.0000,0.0000,0.0000,500.0000,0.0000,500.0000,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-26 15:23:34',0,NULL,'2026-08-26 15:23:33','2026-08-26 15:23:34',NULL,NULL,NULL,'',NULL,NULL,NULL),(19,'invoice','finalised','INV_01_04_000002',NULL,NULL,NULL,NULL,'2026-08-26',NULL,NULL,'open',NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,'Walk-in',NULL,NULL,NULL,1,1,'Tiaan Smith',4,'TILL04','till',3,103.4800,15.5200,0.0000,119.0000,0.0000,119.0000,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-26 15:33:03',0,NULL,'2026-08-26 15:33:03','2026-08-26 15:33:03',NULL,NULL,NULL,'',NULL,NULL,NULL),(20,'invoice','finalised','INV_01_04_000003',NULL,NULL,NULL,NULL,'2026-08-26',NULL,NULL,'open',NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,'Walk-in',NULL,NULL,NULL,1,1,'Tiaan Smith',4,'TILL04','till',3,24.3500,3.6500,0.0000,28.0000,0.0000,28.0000,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-26 15:34:12',0,NULL,'2026-08-26 15:34:12','2026-08-26 15:34:12',NULL,NULL,NULL,'',NULL,NULL,NULL),(21,'invoice','draft',NULL,NULL,NULL,NULL,NULL,'2026-08-26',NULL,NULL,'open',NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,'Walk-in',NULL,NULL,NULL,1,1,'Tiaan Smith',4,'TILL04','till',NULL,93.9100,14.0900,0.0000,108.0000,0.0000,0.0000,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,'2026-08-26 15:38:53','2026-08-26 15:38:53',NULL,NULL,NULL,'',NULL,NULL,NULL),(22,'invoice','draft',NULL,NULL,NULL,NULL,NULL,'2026-08-26',NULL,NULL,'open',NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,'Walk-in',NULL,NULL,NULL,1,1,'Tiaan Smith',4,'TILL04','till',NULL,93.9100,14.0900,0.0000,108.0000,0.0000,0.0000,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,'2026-08-26 15:38:59','2026-08-26 15:38:59',NULL,NULL,NULL,'',NULL,NULL,NULL),(23,'invoice','finalised','INV_01_04_000004',NULL,NULL,NULL,NULL,'2026-08-26',NULL,NULL,'open',NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,'Walk-in',NULL,NULL,NULL,1,1,'Tiaan Smith',4,'TILL04','till',3,103.4800,15.5200,0.0000,119.0000,0.0000,119.0000,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-26 15:39:13',0,NULL,'2026-08-26 15:39:13','2026-08-26 15:39:13',NULL,NULL,NULL,'',NULL,NULL,NULL),(24,'invoice','draft',NULL,NULL,NULL,NULL,NULL,'2026-08-26',NULL,NULL,'open',NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,'Walk-in',NULL,NULL,NULL,1,1,'Tiaan Smith',4,'TILL04','till',NULL,217.3900,32.6100,0.0000,250.0000,0.0000,0.0000,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,'2026-08-26 16:04:49','2026-08-26 16:04:49',NULL,NULL,NULL,'',NULL,NULL,NULL),(25,'invoice','draft',NULL,NULL,NULL,NULL,NULL,'2026-08-26',NULL,NULL,'open',NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,'Walk-in',NULL,NULL,NULL,1,1,'Tiaan Smith',4,'TILL04','till',NULL,217.3900,32.6100,0.0000,250.0000,0.0000,0.0000,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,'2026-08-26 16:05:16','2026-08-26 16:05:16',NULL,NULL,NULL,'',NULL,NULL,NULL),(26,'invoice','draft',NULL,NULL,NULL,NULL,NULL,'2026-08-26',NULL,NULL,'open',NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,'Walk-in',NULL,NULL,NULL,1,1,'Tiaan Smith',4,'TILL04','till',NULL,217.3900,32.6100,0.0000,250.0000,0.0000,0.0000,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,'2026-08-26 16:05:28','2026-08-26 16:05:28',NULL,NULL,NULL,'',NULL,NULL,NULL),(27,'invoice','draft',NULL,NULL,NULL,NULL,NULL,'2026-08-26',NULL,NULL,'open',NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,'Walk-in',NULL,NULL,NULL,1,1,'Tiaan Smith',4,'TILL04','till',NULL,217.3900,32.6100,0.0000,250.0000,0.0000,0.0000,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,'2026-08-26 16:05:41','2026-08-26 16:05:41',NULL,NULL,NULL,'',NULL,NULL,NULL),(28,'invoice','draft',NULL,NULL,NULL,NULL,NULL,'2026-08-26',NULL,NULL,'open',NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,'Walk-in',NULL,NULL,NULL,1,1,'Tiaan Smith',4,'TILL04','till',NULL,69.5700,10.4300,0.0000,80.0000,0.0000,0.0000,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,'2026-08-26 16:20:38','2026-08-26 16:20:38',NULL,NULL,NULL,'',NULL,NULL,NULL),(29,'invoice','draft',NULL,NULL,NULL,NULL,NULL,'2026-08-26',NULL,NULL,'open',NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,'Walk-in',NULL,NULL,NULL,1,1,'Tiaan Smith',4,'TILL04','till',NULL,417.3900,62.6100,0.0000,480.0000,0.0000,0.0000,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,'2026-08-26 16:22:38','2026-08-26 16:22:38',NULL,NULL,NULL,'',NULL,NULL,NULL),(30,'invoice','finalised','INV_01_05_000001',NULL,NULL,NULL,NULL,'2026-08-31',NULL,NULL,'open',NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,'Walk-in',NULL,NULL,NULL,1,1,'Tiaan Smith',5,'TILL05','till',4,17.4000,2.6000,83.0000,20.0000,0.0000,20.0000,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-31 10:55:39',0,NULL,'2026-08-31 10:55:39','2026-08-31 10:55:39',NULL,NULL,NULL,'',NULL,NULL,NULL),(31,'invoice','finalised','INV_01_01_000002',NULL,NULL,NULL,NULL,'2026-09-01',NULL,NULL,'open',NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,'Walk-in',NULL,NULL,NULL,1,1,'Tiaan Smith',1,'TILL01','till',1,0.0000,0.0000,0.0000,0.0000,0.0000,20.0000,20.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-09-01 11:04:57',0,NULL,'2026-09-01 11:04:57','2026-09-01 11:04:57',NULL,NULL,NULL,'',NULL,NULL,NULL);
/*!40000 ALTER TABLE `sales_documents` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sales_order_details`
--

DROP TABLE IF EXISTS `sales_order_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sales_order_details` (
  `document_id` int(10) unsigned NOT NULL,
  `delivery_date` date DEFAULT NULL,
  `fulfilment_status` enum('open','part_delivered','delivered','cancelled') NOT NULL DEFAULT 'open',
  `reserves_stock` tinyint(1) NOT NULL DEFAULT 1,
  `reserved_at` datetime DEFAULT NULL,
  `expires_at` datetime DEFAULT NULL,
  `customer_order_no` varchar(60) DEFAULT NULL,
  PRIMARY KEY (`document_id`),
  CONSTRAINT `sales_order_details_ibfk_1` FOREIGN KEY (`document_id`) REFERENCES `sales_documents` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sales_order_details`
--

LOCK TABLES `sales_order_details` WRITE;
/*!40000 ALTER TABLE `sales_order_details` DISABLE KEYS */;
/*!40000 ALTER TABLE `sales_order_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sales_reps`
--

DROP TABLE IF EXISTS `sales_reps`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sales_reps` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(120) NOT NULL,
  `code` varchar(32) DEFAULT NULL,
  `email` varchar(190) DEFAULT NULL,
  `phone` varchar(40) DEFAULT NULL,
  `commission_pct` decimal(6,3) NOT NULL DEFAULT 0.000,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_sales_rep_name` (`name`),
  KEY `ix_sales_rep_active` (`is_active`,`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sales_reps`
--

LOCK TABLES `sales_reps` WRITE;
/*!40000 ALTER TABLE `sales_reps` DISABLE KEYS */;
/*!40000 ALTER TABLE `sales_reps` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sales_return_reasons`
--

DROP TABLE IF EXISTS `sales_return_reasons`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sales_return_reasons` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(24) NOT NULL,
  `name` varchar(120) NOT NULL,
  `allows_note` tinyint(1) NOT NULL DEFAULT 1,
  `restocks` tinyint(1) NOT NULL DEFAULT 1,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `sort_order` int(11) NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_return_reason_code` (`code`),
  KEY `ix_return_reason_active` (`is_active`,`sort_order`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sales_return_reasons`
--

LOCK TABLES `sales_return_reasons` WRITE;
/*!40000 ALTER TABLE `sales_return_reasons` DISABLE KEYS */;
INSERT INTO `sales_return_reasons` VALUES (1,'FAULTY','Faulty or damaged',1,0,1,10,'2026-08-12 08:49:31','2026-08-12 08:49:31'),(2,'NOT-AS-DESC','Not as described',1,1,1,20,'2026-08-12 08:49:31','2026-08-12 08:49:31'),(3,'WRONG-SIZE','Wrong size or colour',0,1,1,30,'2026-08-12 08:49:31','2026-08-12 08:49:31'),(4,'WRONG-ITEM','Wrong item supplied',0,1,1,40,'2026-08-12 08:49:31','2026-08-12 08:49:31'),(5,'CHANGED-MIND','Changed their mind',0,1,1,50,'2026-08-12 08:49:31','2026-08-12 08:49:31'),(6,'EXPIRED','Past its date',1,0,1,60,'2026-08-12 08:49:31','2026-08-12 08:49:31'),(7,'OTHER','Something else',1,1,1,90,'2026-08-12 08:49:31','2026-08-12 08:49:31'),(8,'CORRECTION','Invoice correction',1,1,1,999,'2026-08-12 08:49:31','2026-08-12 08:49:31');
/*!40000 ALTER TABLE `sales_return_reasons` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sales_tenders`
--

DROP TABLE IF EXISTS `sales_tenders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sales_tenders` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `document_id` int(10) unsigned NOT NULL,
  `tender_type_id` int(10) unsigned NOT NULL,
  `tender_code` varchar(24) NOT NULL,
  `tender_name` varchar(60) NOT NULL,
  `amount` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `change_given` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `surcharge` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `reference` varchar(60) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `ix_tender_document` (`document_id`),
  KEY `ix_tender_type_date` (`tender_type_id`,`created_at`),
  CONSTRAINT `sales_tenders_ibfk_1` FOREIGN KEY (`document_id`) REFERENCES `sales_documents` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sales_tenders_ibfk_2` FOREIGN KEY (`tender_type_id`) REFERENCES `tender_types` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sales_tenders`
--

LOCK TABLES `sales_tenders` WRITE;
/*!40000 ALTER TABLE `sales_tenders` DISABLE KEYS */;
INSERT INTO `sales_tenders` VALUES (1,1,1,'CASH','Cash',59.8000,0.0000,0.0000,NULL,'2026-08-09 09:50:14'),(2,2,3,'ACCOUNT','Account',317.4000,0.0000,0.0000,NULL,'2026-08-09 10:14:30'),(3,9,3,'ACCOUNT','Account',149.5000,0.0000,0.0000,NULL,'2026-08-11 13:46:45'),(4,8,1,'CASH','Cash',500.0000,0.0000,0.0000,NULL,'2026-08-11 13:49:00'),(5,8,2,'CARD','Card',274.0000,0.0000,0.0000,NULL,'2026-08-11 13:49:00'),(6,10,1,'CASH','Cash',20.0000,0.0000,0.0000,NULL,'2026-08-24 12:50:09'),(7,12,1,'CASH','Cash',139.0000,0.0000,0.0000,NULL,'2026-08-25 19:18:39'),(8,11,1,'CASH','Cash',139.0000,0.0000,0.0000,NULL,'2026-08-25 19:19:45'),(9,18,1,'CASH','Cash',500.0000,0.0000,0.0000,NULL,'2026-08-26 15:23:34'),(10,19,8,'EXCHANGE','Exchange credit',119.0000,0.0000,0.0000,'MH7Q-BXHH-CCX6','2026-08-26 15:33:03'),(11,20,8,'EXCHANGE','Exchange credit',28.0000,0.0000,0.0000,'MH7Q-BXHH-CCX6','2026-08-26 15:34:12'),(12,23,9,'GIFT_CARD','Gift card',119.0000,0.0000,0.0000,'MH7Q-BXHH-CCX6','2026-08-26 15:39:13'),(13,30,1,'CASH','Cash',20.0000,0.0000,0.0000,NULL,'2026-08-31 10:55:39'),(14,31,1,'CASH','Cash',20.0000,20.0000,0.0000,NULL,'2026-09-01 11:04:57');
/*!40000 ALTER TABLE `sales_tenders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sales_tips`
--

DROP TABLE IF EXISTS `sales_tips`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sales_tips` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `document_id` int(10) unsigned NOT NULL,
  `tender_type_id` int(10) unsigned NOT NULL,
  `shift_id` int(10) unsigned DEFAULT NULL,
  `amount` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `source` enum('over_tender','declared','service','manual') NOT NULL DEFAULT 'declared',
  `user_id` int(10) unsigned DEFAULT NULL,
  `user_name` varchar(120) NOT NULL DEFAULT '',
  `payout_id` int(10) unsigned DEFAULT NULL,
  `original_user_id` int(10) unsigned DEFAULT NULL,
  `reassigned_by` int(10) unsigned DEFAULT NULL,
  `reassigned_by_name` varchar(120) NOT NULL DEFAULT '',
  `reassigned_at` datetime DEFAULT NULL,
  `reassign_reason` varchar(200) NOT NULL DEFAULT '',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `ix_tip_document` (`document_id`),
  KEY `ix_tip_shift` (`shift_id`,`tender_type_id`),
  KEY `ix_tip_user` (`user_id`,`created_at`),
  KEY `fk_tip_tender` (`tender_type_id`),
  KEY `ix_tip_payout` (`payout_id`),
  CONSTRAINT `sales_tips_ibfk_1` FOREIGN KEY (`document_id`) REFERENCES `sales_documents` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sales_tips_ibfk_2` FOREIGN KEY (`payout_id`) REFERENCES `tip_payouts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `sales_tips_ibfk_3` FOREIGN KEY (`tender_type_id`) REFERENCES `tender_types` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sales_tips`
--

LOCK TABLES `sales_tips` WRITE;
/*!40000 ALTER TABLE `sales_tips` DISABLE KEYS */;
/*!40000 ALTER TABLE `sales_tips` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sales_void_reasons`
--

DROP TABLE IF EXISTS `sales_void_reasons`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sales_void_reasons` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(24) NOT NULL,
  `name` varchar(120) NOT NULL,
  `allows_note` tinyint(1) NOT NULL DEFAULT 1,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `sort_order` int(11) NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_void_reason_code` (`code`),
  KEY `ix_void_reason_active` (`is_active`,`sort_order`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sales_void_reasons`
--

LOCK TABLES `sales_void_reasons` WRITE;
/*!40000 ALTER TABLE `sales_void_reasons` DISABLE KEYS */;
INSERT INTO `sales_void_reasons` VALUES (1,'WRONG-ITEM','Wrong item rung up',0,1,10,'2026-08-12 08:49:31','2026-08-12 08:49:31'),(2,'WRONG-QTY','Wrong quantity or price',0,1,20,'2026-08-12 08:49:31','2026-08-12 08:49:31'),(3,'DOUBLE-RUNG','Rung up twice',0,1,30,'2026-08-12 08:49:31','2026-08-12 08:49:31'),(4,'CUST-LEFT','Customer changed mind',0,1,40,'2026-08-12 08:49:31','2026-08-12 08:49:31'),(5,'PAY-FAILED','Payment did not go through',0,1,50,'2026-08-12 08:49:31','2026-08-12 08:49:31'),(6,'TRAINING','Training or test sale',0,1,60,'2026-08-12 08:49:31','2026-08-12 08:49:31'),(7,'OTHER','Something else',1,1,90,'2026-08-12 08:49:31','2026-08-12 08:49:31');
/*!40000 ALTER TABLE `sales_void_reasons` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `saved_reports`
--

DROP TABLE IF EXISTS `saved_reports`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `saved_reports` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `kind` enum('builder','ask') NOT NULL DEFAULT 'builder',
  `name` varchar(120) NOT NULL,
  `description` varchar(255) NOT NULL DEFAULT '',
  `spec` text NOT NULL,
  `question` varchar(500) NOT NULL DEFAULT '',
  `created_by` int(10) unsigned DEFAULT NULL,
  `created_by_name` varchar(120) NOT NULL DEFAULT '',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_updated` (`updated_at`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `saved_reports`
--

LOCK TABLES `saved_reports` WRITE;
/*!40000 ALTER TABLE `saved_reports` DISABLE KEYS */;
INSERT INTO `saved_reports` VALUES (1,'builder','Invoice history (copy)','','{\"version\":1,\"name\":\"Invoice history (copy)\",\"source\":\"sales\",\"period\":{\"key\":\"thisMonth\"},\"columns\":[{\"field\":\"documentNumber\"},{\"field\":\"documentDate\"},{\"field\":\"docType\"},{\"field\":\"status\"},{\"field\":\"customerName\"},{\"field\":\"accountCode\"},{\"field\":\"userName\"},{\"field\":\"terminalCode\"},{\"field\":\"reference\"},{\"field\":\"subtotalExcl\"},{\"field\":\"vatTotal\"},{\"field\":\"discountTotal\"},{\"field\":\"roundingAdj\"},{\"field\":\"totalIncl\"},{\"field\":\"customerVatNo\"}],\"filters\":[{\"field\":\"status\",\"op\":\"eq\",\"value\":\"finalised\"}],\"groupFields\":[],\"totalFilters\":[],\"sort\":{\"key\":\"documentDate\",\"dir\":\"desc\"},\"limit\":5000}','',1,'Tiaan Smith','2026-08-24 13:19:17','2026-08-24 13:19:17');
/*!40000 ALTER TABLE `saved_reports` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `schema_migrations`
--

DROP TABLE IF EXISTS `schema_migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `schema_migrations` (
  `name` varchar(190) NOT NULL,
  `applied_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `schema_migrations`
--

LOCK TABLES `schema_migrations` WRITE;
/*!40000 ALTER TABLE `schema_migrations` DISABLE KEYS */;
INSERT INTO `schema_migrations` VALUES ('001_products.sql','2026-08-04 14:12:30'),('002_stores.sql','2026-08-04 20:45:11'),('003_drop_stores.sql','2026-08-04 21:13:29'),('004_store_sharing.sql','2026-08-04 21:13:29'),('005_product_availability.sql','2026-08-05 09:09:59'),('006_product_properties.sql','2026-08-05 09:09:59'),('007_drop_order_size.sql','2026-08-05 09:14:25'),('008_product_dimensions.sql','2026-08-05 09:20:08'),('009_product_dimension_columns.sql','2026-08-05 09:26:49'),('010_instructions.sql','2026-08-05 10:42:21'),('011_activity_log.sql','2026-08-05 11:01:48'),('012_customers.sql','2026-08-05 11:01:48'),('013_suppliers.sql','2026-08-05 11:01:48'),('014_subledger.sql','2026-08-05 12:25:11'),('015_sales_core.sql','2026-08-05 13:07:59'),('016_shifts.sql','2026-08-05 14:59:43'),('017_purchasing.sql','2026-08-05 15:14:43'),('018_statement_runs.sql','2026-08-05 15:28:37'),('019_payment_runs.sql','2026-08-05 15:44:08'),('020_recipes_refers.sql','2026-08-05 16:28:30'),('021_serials.sql','2026-08-05 16:37:14'),('022_rename_credit_and_void.sql','2026-08-05 19:50:28'),('023_customer_account_types.sql','2026-08-05 20:03:16'),('024_laybys.sql','2026-08-05 20:16:31'),('025_stock_locations.sql','2026-08-05 20:16:31'),('026_stock_transfers.sql','2026-08-05 20:50:09'),('027_serial_locations.sql','2026-08-05 20:58:38'),('028_drop_product_levels.sql','2026-08-05 21:37:54'),('029_rename_void_columns.sql','2026-08-05 21:37:55'),('030_serial_supplier_returns.sql','2026-08-05 21:58:04'),('031_party_contacts_documents_comments.sql','2026-08-05 21:37:54'),('032_rename_parked_to_saved.sql','2026-08-06 17:46:00'),('033_line_sales_rep.sql','2026-08-06 18:05:01'),('034_online_store.sql','2026-08-06 18:57:49'),('035_product_reviews.sql','2026-08-06 19:22:24'),('036_cashbook.sql','2026-08-06 19:52:59'),('037_interest_discounts_locks.sql','2026-08-06 19:52:59'),('038_payments.sql','2026-08-06 19:48:38'),('039_order_internal_note.sql','2026-08-06 19:52:59'),('040_storefront_layout.sql','2026-08-06 20:07:56'),('041_users_roles.sql','2026-08-06 20:27:06'),('042_commission.sql','2026-08-06 21:35:25'),('042_expenses.sql','2026-08-06 21:18:43'),('043_commission_attribution.sql','2026-08-06 21:39:01'),('043_expense_sequence.sql','2026-08-06 21:21:13'),('044_product_images.sql','2026-08-06 20:31:13'),('045_general_ledger.sql','2026-08-06 21:54:38'),('046_fixed_assets.sql','2026-08-06 22:26:44'),('047_commission_pays_users.sql','2026-08-06 22:29:11'),('048_quotes.sql','2026-08-06 22:51:21'),('049_credit_control.sql','2026-08-06 23:22:50'),('050_storefront_display.sql','2026-08-06 23:25:16'),('051_customer_logins.sql','2026-08-07 05:10:17'),('052_loyalty.sql','2026-08-07 05:41:55'),('052_status_notifications.sql','2026-08-07 05:41:55'),('053_staff_employment.sql','2026-08-07 05:47:02'),('054_reports.sql','2026-08-07 06:06:02'),('054_staff_time.sql','2026-08-07 05:58:00'),('055_cashup_modes.sql','2026-08-07 05:58:00'),('056_specials.sql','2026-08-07 06:22:59'),('057_specials_wallclock.sql','2026-08-07 06:31:02'),('058_specials_types.sql','2026-08-07 07:22:24'),('058_staff_leave.sql','2026-08-07 06:43:27'),('059_staff_pay_periods.sql','2026-08-07 06:55:45'),('060_storefront_images.sql','2026-08-07 09:15:30'),('061_contracts.sql','2026-08-07 09:31:40'),('061_storefront_logo.sql','2026-08-07 10:11:55'),('062_master_data_codes.sql','2026-08-07 09:42:26'),('063_staff_overtime.sql','2026-08-07 09:42:26'),('064_department_images.sql','2026-08-09 11:43:39'),('064_pos_numbering.sql','2026-08-09 11:52:32'),('065_statement_cycles.sql','2026-08-09 11:52:32'),('066_statement_run_periods.sql','2026-08-09 12:29:27'),('067_offline_operators.sql','2026-08-09 16:11:51'),('068_tile_token_width.sql','2026-08-10 08:48:46'),('069_pos_quick_keys.sql','2026-08-10 09:32:42'),('070_product_variants.sql','2026-08-10 10:11:24'),('070_storefront_pages.sql','2026-08-10 10:11:24'),('071_pos_tables.sql','2026-08-10 10:20:47'),('071_storefront_subscribers.sql','2026-08-10 11:01:57'),('072_saved_baskets.sql','2026-08-10 11:01:57'),('073_discount_codes.sql','2026-08-10 11:24:12'),('074_storefront_history.sql','2026-08-10 11:49:03'),('075_storefront_publish_at.sql','2026-08-10 11:49:03'),('076_stock_holds.sql','2026-08-10 11:49:03'),('077_storefront_presentation.sql','2026-08-10 12:03:40'),('078_purchase_line_discount_value.sql','2026-08-10 13:35:32'),('078_storefront_seo.sql','2026-08-10 12:05:55'),('079_offline_returns.sql','2026-08-10 12:09:40'),('079_storefront_product_page.sql','2026-08-10 12:25:10'),('080_drop_home_layout_columns.sql','2026-08-10 13:01:06'),('080_instruction_options_v2.sql','2026-08-10 13:35:32'),('081_instruction_reveals.sql','2026-08-10 13:35:32'),('081_price_schedules.sql','2026-08-10 13:35:32'),('081_stock_takes.sql','2026-08-10 13:35:32'),('082_sale_line_instructions.sql','2026-08-10 13:35:32'),('083_manufacturing.sql','2026-08-10 13:35:33'),('084_price_schedules.sql','2026-08-10 16:58:18'),('085_stock_take_scope_brand.sql','2026-08-10 15:15:16'),('086_pos_floor_plan.sql','2026-08-10 13:42:58'),('086_sale_line_notes.sql','2026-08-10 14:24:54'),('087_purchase_line_discount_value.sql','2026-08-10 16:58:18'),('088_purchase_charges.sql','2026-08-10 16:58:18'),('089_freight_in_mapping_fix.sql','2026-08-10 16:58:18'),('090_purchase_bonus_qty.sql','2026-08-10 16:58:18'),('091_tips.sql','2026-08-10 14:27:08'),('092_drop_stock_take_blocking.sql','2026-08-10 15:15:16'),('092_purchase_document_discount.sql','2026-08-10 16:58:18'),('093_pos_visit_types.sql','2026-08-10 20:05:29'),('093_supplier_price_lists.sql','2026-08-10 16:58:18'),('094_tip_payouts.sql','2026-08-10 16:58:19'),('095_reservations.sql','2026-08-10 17:12:15'),('096_department_page_inherit.sql','2026-08-10 18:37:26'),('097_page_slug_nullable.sql','2026-08-10 18:45:13'),('098_restore_products.sql','2026-08-11 11:53:23'),('099_sales_document_origin.sql','2026-08-12 08:49:30'),('100_stock_adjustments.sql','2026-08-12 08:49:30'),('101_store_transfers.sql','2026-08-12 08:49:31'),('102_sales_reason_codes.sql','2026-08-12 08:49:31'),('103_refer_methods.sql','2026-08-12 08:49:31'),('104_job_cards.sql','2026-08-24 09:10:34'),('105_quote_acceptance.sql','2026-08-24 09:10:34'),('106_job_appointments.sql','2026-08-24 09:10:34'),('107_job_travel.sql','2026-08-24 09:10:34'),('108_travel_return_leg.sql','2026-08-24 09:10:34'),('109_list_columns.sql','2026-08-24 09:10:34'),('110_technician_vans.sql','2026-08-24 09:10:34'),('111_report_columns.sql','2026-08-24 09:10:34'),('112_list_columns_order.sql','2026-08-24 09:10:34'),('113_job_sla.sql','2026-08-24 09:10:34'),('114_job_headlines.sql','2026-08-24 09:10:34'),('115_customer_assets.sql','2026-08-24 09:10:34'),('116_asset_status.sql','2026-08-24 09:10:34'),('117_asset_document_number.sql','2026-08-24 09:10:34'),('118_recurring_jobs.sql','2026-08-24 09:10:34'),('119_job_evidence.sql','2026-08-24 09:10:34'),('120_job_people.sql','2026-08-24 09:10:34'),('121_job_automations.sql','2026-08-24 09:10:34'),('121_product_menu_order.sql','2026-08-24 09:10:34'),('122_job_saved_views.sql','2026-08-24 09:10:34'),('123_job_status_rules.sql','2026-08-24 09:10:34'),('124_job_status_rules_fix.sql','2026-08-24 09:10:34'),('125_sale_covers.sql','2026-08-24 09:10:34'),('126_job_teams.sql','2026-08-24 09:10:34'),('127_custom_fields.sql','2026-08-24 09:10:34'),('128_job_feedback.sql','2026-08-24 09:10:35'),('129_job_intake.sql','2026-08-24 09:10:35'),('130_cashbook_categories.sql','2026-08-24 09:10:35'),('130_customer_portal.sql','2026-08-24 09:10:35'),('131_gl_budgets.sql','2026-08-24 09:10:35'),('131_portal_visibility.sql','2026-08-24 09:10:35'),('132_customer_addresses.sql','2026-08-24 09:10:35'),('133_cash_over_short.sql','2026-08-24 09:10:35'),('134_recurring_journals.sql','2026-08-24 09:10:35'),('135_customer_pricing.sql','2026-08-24 09:10:35'),('136_layby_document_number.sql','2026-08-24 09:10:35'),('137_sms_channels.sql','2026-08-24 09:10:35'),('139_purchase_document_audit.sql','2026-08-24 09:10:35'),('140_discount_code_till.sql','2026-08-24 09:10:35'),('141_exchange_tender.sql','2026-08-24 09:10:35'),('142_kitchen_send.sql','2026-08-24 09:10:35'),('143_product_barcodes.sql','2026-08-24 09:10:35'),('144_product_price_history.sql','2026-08-24 09:10:35'),('145_cycle_counts.sql','2026-08-24 09:10:35'),('146_multibuy_specials.sql','2026-08-24 09:10:35'),('147_gift_cards.sql','2026-08-24 09:10:35'),('148_product_batches.sql','2026-08-24 09:10:35'),('149_adjustment_batch.sql','2026-08-24 09:10:35'),('150_customer_password_resets.sql','2026-08-24 09:10:35'),('151_stock_notifications.sql','2026-08-24 09:10:35'),('152_online_order_voucher.sql','2026-08-24 09:10:35'),('153_online_refund_tender.sql','2026-08-24 09:10:35'),('154_activity_log_audit_index.sql','2026-08-24 09:10:35'),('155_notifications.sql','2026-08-24 09:10:35'),('156_api_keys.sql','2026-08-24 09:10:35'),('157_webhooks.sql','2026-08-24 09:10:35'),('158_api_key_expiry.sql','2026-08-24 09:10:35'),('159_job_signoff.sql','2026-08-24 09:10:36'),('160_job_expenses.sql','2026-08-24 09:10:36'),('161_job_assets.sql','2026-08-24 09:10:36'),('162_job_part_requests.sql','2026-08-24 09:10:36'),('163_purchase_line_job_link.sql','2026-08-24 09:10:36'),('164_customer_sla.sql','2026-08-24 09:10:36'),('165_tickets.sql','2026-08-24 09:10:36'),('166_ticket_sequence_fix.sql','2026-08-24 09:10:36'),('167_line_ordered_at.sql','2026-08-24 09:10:36'),('168_cashup_declaration.sql','2026-08-24 09:10:36'),('169_pos_void_events.sql','2026-08-24 09:10:36'),('169_report_group_by.sql','2026-08-24 09:10:36'),('170_training_mode.sql','2026-08-24 09:10:36'),('171_document_claim.sql','2026-08-24 09:10:36'),('172_sale_deposits.sql','2026-08-24 09:10:36'),('173_deposit_tender.sql','2026-08-24 09:10:36'),('174_table_shapes.sql','2026-08-24 09:10:36'),('175_customer_spend_limits.sql','2026-08-24 09:10:36'),('176_group_limits_and_discount.sql','2026-08-24 09:10:36'),('176_purge_retired_rooms.sql','2026-08-24 09:10:36'),('177_terminal_claim.sql','2026-08-24 09:10:36'),('178_branch_trading.sql','2026-08-24 09:10:36'),('178_licence_lease.sql','2026-08-24 09:10:36'),('179_offline_signin.sql','2026-08-24 09:10:36'),('180_terminal_pos_mode.sql','2026-08-24 09:10:36'),('181_stationery_templates.sql','2026-08-24 09:10:36'),('182_stationery_blocks.sql','2026-08-24 09:10:36'),('183_storefront_design_tokens.sql','2026-08-24 09:10:36'),('184_cashup_small_change.sql','2026-08-24 09:10:36'),('185_online_listing_presets.sql','2026-08-24 09:10:36'),('186_alerts.sql','2026-08-24 09:10:36'),('186_listing_preset_default_key.sql','2026-08-24 09:10:36'),('187_listing_badge_rules.sql','2026-08-24 09:10:36'),('188_storefront_menus.sql','2026-08-24 09:10:36'),('189_storefront_collections.sql','2026-08-24 09:10:37'),('190_storefront_currency.sql','2026-08-24 09:10:37'),('191_cart_and_thankyou_pages.sql','2026-08-24 09:10:37'),('192_checkout_wording.sql','2026-08-24 09:10:37'),('193_grv_selling_price.sql','2026-08-24 09:10:37'),('194_terminal_stock_location.sql','2026-08-24 09:10:37'),('195_stationery_images.sql','2026-08-24 09:10:37'),('196_till_sequences.sql','2026-08-24 09:10:37'),('197_shared_customer_file.sql','2026-08-24 09:10:37'),('198_origin_site.sql','2026-08-24 09:10:37'),('202_product_origin.sql','2026-08-24 09:10:37'),('203_cashbook_links_shared_customer.sql','2026-08-24 09:10:37'),('204_run_origin_site.sql','2026-08-24 09:10:37'),('205_customer_rep_name.sql','2026-08-24 09:10:37'),('206_shared_supplier_file.sql','2026-08-24 09:10:37'),('207_party_files_per_entity.sql','2026-08-24 09:10:37'),('208_drop_customer_loyalty_number.sql','2026-08-24 09:10:37'),('209_shared_gift_cards.sql','2026-08-24 09:10:37'),('210_special_shape.sql','2026-08-24 09:10:37'),('211_special_guards.sql','2026-08-24 09:10:37'),('212_special_audience.sql','2026-08-24 09:10:37'),('213_special_bonus_points.sql','2026-08-24 09:10:37'),('214_reward_per_deal.sql','2026-08-24 09:10:37'),('215_special_origin.sql','2026-08-24 09:10:37'),('216_service_charge_amount.sql','2026-08-24 09:10:37'),('217_terminal_codes.sql','2026-08-24 09:10:37'),('218_stock_take_blind_and_approval.sql','2026-08-24 09:10:37'),('219_job_notifications.sql','2026-08-24 09:10:38'),('220_job_stock_reservations.sql','2026-08-24 09:10:38'),('221_job_line_serials.sql','2026-08-24 09:10:38'),('222_job_forms.sql','2026-08-24 09:10:38'),('223_mobile_and_consent_catchup.sql','2026-08-24 09:10:38'),('224_retire_checklists.sql','2026-08-24 09:10:38'),('225_job_rules.sql','2026-08-24 09:10:38'),('226_calendar_sync.sql','2026-08-24 09:10:38'),('227_quote_sent_viewed.sql','2026-08-24 09:10:38'),('228_quoted_cost.sql','2026-08-24 09:10:38'),('229_kitchen_printing.sql','2026-08-24 09:10:38'),('230_product_kitchen_group.sql','2026-08-24 09:10:38'),('231_pos_menus.sql','2026-08-25 12:46:20'),('232_pos_menu_terminals.sql','2026-08-25 12:46:20'),('233_cashup_numbers.sql','2026-08-25 12:46:20'),('234_lot_capture.sql','2026-08-25 12:46:20'),('235_line_serial.sql','2026-08-25 12:46:20'),('236_product_last_transfer.sql','2026-08-25 12:46:20'),('237_repair_dangling_refers.sql','2026-08-31 10:50:21'),('238_site_profile.sql','2026-08-31 10:50:21'),('239_pay_links.sql','2026-08-31 10:50:21'),('240_cash_denomination_currency.sql','2026-08-31 10:50:21'),('241_list_filters.sql','2026-08-31 10:50:21'),('242_sale_custom_fields.sql','2026-08-31 10:50:21'),('243_custom_field_prints_on_slip.sql','2026-08-31 10:50:21');
/*!40000 ALTER TABLE `schema_migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `serial_movements`
--

DROP TABLE IF EXISTS `serial_movements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `serial_movements` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `serial_id` int(10) unsigned NOT NULL,
  `action` varchar(24) NOT NULL,
  `document_id` int(10) unsigned DEFAULT NULL,
  `document_line_id` int(10) unsigned DEFAULT NULL,
  `from_location_id` int(10) unsigned DEFAULT NULL,
  `to_location_id` int(10) unsigned DEFAULT NULL,
  `user_id` int(10) unsigned DEFAULT NULL,
  `user_name` varchar(120) NOT NULL DEFAULT '',
  `note` varchar(190) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `ix_smove_serial` (`serial_id`,`created_at`),
  KEY `ix_smove_doc` (`document_id`),
  KEY `fk_smove_from` (`from_location_id`),
  KEY `fk_smove_to` (`to_location_id`),
  CONSTRAINT `serial_movements_ibfk_1` FOREIGN KEY (`from_location_id`) REFERENCES `stock_locations` (`id`),
  CONSTRAINT `serial_movements_ibfk_2` FOREIGN KEY (`serial_id`) REFERENCES `product_serials` (`id`) ON DELETE CASCADE,
  CONSTRAINT `serial_movements_ibfk_3` FOREIGN KEY (`to_location_id`) REFERENCES `stock_locations` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `serial_movements`
--

LOCK TABLES `serial_movements` WRITE;
/*!40000 ALTER TABLE `serial_movements` DISABLE KEYS */;
/*!40000 ALTER TABLE `serial_movements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `service_addresses`
--

DROP TABLE IF EXISTS `service_addresses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `service_addresses` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `customer_id` int(10) unsigned NOT NULL,
  `location_id` int(10) unsigned DEFAULT NULL,
  `code` varchar(32) DEFAULT NULL,
  `name` varchar(160) NOT NULL,
  `address_line1` varchar(160) DEFAULT NULL,
  `address_line2` varchar(160) DEFAULT NULL,
  `city` varchar(120) DEFAULT NULL,
  `postal_code` varchar(20) DEFAULT NULL,
  `latitude` decimal(10,7) DEFAULT NULL,
  `longitude` decimal(10,7) DEFAULT NULL,
  `contact_id` int(10) unsigned DEFAULT NULL,
  `access_notes` varchar(1000) DEFAULT NULL,
  `note` varchar(400) DEFAULT NULL,
  `is_default` tinyint(1) NOT NULL DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `ix_saddr_customer` (`customer_id`,`is_active`),
  KEY `ix_saddr_location` (`location_id`),
  KEY `fk_saddr_contact` (`contact_id`),
  CONSTRAINT `service_addresses_ibfk_1` FOREIGN KEY (`contact_id`) REFERENCES `customer_contacts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `service_addresses_ibfk_2` FOREIGN KEY (`location_id`) REFERENCES `stock_locations` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `service_addresses`
--

LOCK TABLES `service_addresses` WRITE;
/*!40000 ALTER TABLE `service_addresses` DISABLE KEYS */;
/*!40000 ALTER TABLE `service_addresses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `service_charge_removals`
--

DROP TABLE IF EXISTS `service_charge_removals`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `service_charge_removals` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `document_id` int(10) unsigned DEFAULT NULL,
  `amount` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `user_id` int(10) unsigned DEFAULT NULL,
  `user_name` varchar(120) NOT NULL DEFAULT '',
  `reason` varchar(200) NOT NULL DEFAULT '',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `ix_removal_user` (`user_id`,`created_at`),
  KEY `fk_removal_document` (`document_id`),
  CONSTRAINT `service_charge_removals_ibfk_1` FOREIGN KEY (`document_id`) REFERENCES `sales_documents` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `service_charge_removals`
--

LOCK TABLES `service_charge_removals` WRITE;
/*!40000 ALTER TABLE `service_charge_removals` DISABLE KEYS */;
/*!40000 ALTER TABLE `service_charge_removals` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `service_charge_tiers`
--

DROP TABLE IF EXISTS `service_charge_tiers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `service_charge_tiers` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `min_total` decimal(12,2) NOT NULL DEFAULT 0.00,
  `max_total` decimal(12,2) DEFAULT NULL,
  `charge_kind` enum('percent','amount') NOT NULL DEFAULT 'percent',
  `percent` decimal(6,3) NOT NULL DEFAULT 0.000,
  `charge_amount` decimal(12,2) NOT NULL DEFAULT 0.00,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `ix_tier_range` (`is_active`,`min_total`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `service_charge_tiers`
--

LOCK TABLES `service_charge_tiers` WRITE;
/*!40000 ALTER TABLE `service_charge_tiers` DISABLE KEYS */;
/*!40000 ALTER TABLE `service_charge_tiers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `settings`
--

DROP TABLE IF EXISTS `settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `settings` (
  `setting_key` varchar(60) NOT NULL,
  `setting_value` varchar(255) DEFAULT NULL,
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`setting_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `settings`
--

LOCK TABLES `settings` WRITE;
/*!40000 ALTER TABLE `settings` DISABLE KEYS */;
INSERT INTO `settings` VALUES ('asset_auto_next_service','1','2026-08-24 09:10:34'),('asset_duplicate_action','warn','2026-08-24 09:10:34'),('autocode_customer','1','2026-08-10 15:53:06'),('autocode_product','1','2026-08-10 15:53:09'),('autocode_supplier','1','2026-08-10 15:53:08'),('autocode_terminal','1','2026-08-24 09:10:37'),('barcode_plu_length','5','2026-08-05 13:07:59'),('barcode_value_divisor','100','2026-08-05 13:07:59'),('barcode_variable_prefix','2','2026-08-05 13:07:59'),('cashup_mode','terminal','2026-08-10 16:46:47'),('cashup_variance_tolerance','5.00','2026-08-05 14:59:43'),('commission_exclude_returns','0','2026-08-06 21:35:25'),('commission_layby_on_completion','1','2026-08-06 21:35:25'),('commission_returns_original_rep','1','2026-08-06 21:35:25'),('cost_basis','average','2026-08-04 14:12:30'),('credit_control_enabled','1','2026-08-06 23:22:50'),('currency_code','ZAR','2026-08-31 10:50:21'),('currency_symbol','R','2026-08-31 10:50:21'),('deposit_allow_walkin','1','2026-08-24 09:10:36'),('deposit_min_pct','0','2026-08-24 09:10:36'),('document_logo_file','9d3fe73c-ab9a-4c96-9f74-35e4668d9736.png','2026-08-26 11:36:11'),('dunning_min_gap_days','7','2026-08-06 23:22:50'),('job_auto_escalate','1','2026-08-24 09:10:34'),('job_auto_invoice','0','2026-08-24 09:10:34'),('job_auto_visit_hours','16','2026-08-24 09:10:34'),('job_auto_visit_reminder','1','2026-08-24 09:10:34'),('job_day_ends','17:00','2026-08-24 09:10:34'),('job_day_starts','07:00','2026-08-24 09:10:34'),('job_default_priority','normal','2026-08-24 09:10:34'),('job_default_visit_minutes','60','2026-08-24 09:10:34'),('job_feedback_enabled','0','2026-08-24 09:10:35'),('job_feedback_intro','Thank you for your business. How did we do?','2026-08-24 09:10:35'),('job_headline_autoparts','0','2026-08-24 09:10:34'),('job_headline_required','0','2026-08-24 09:10:34'),('job_intake_blurb','Tell us what you need and we will come back to you.','2026-08-24 09:10:35'),('job_intake_enabled','0','2026-08-24 09:10:35'),('job_intake_max_per_phone','3','2026-08-24 09:10:35'),('job_intake_show_headlines','1','2026-08-24 09:10:35'),('job_items_block_close','1','2026-08-24 09:10:34'),('job_labour_product_id','','2026-08-24 09:10:34'),('job_notify_assignee','1','2026-08-24 09:10:34'),('job_notify_enabled','1','2026-08-24 09:10:34'),('job_notify_events','assigned,status,closed','2026-08-24 09:10:34'),('job_part_requests_enabled','1','2026-08-24 09:10:36'),('job_require_quote_acceptance','0','2026-08-24 09:10:34'),('job_series_catchup_cap','24','2026-08-24 09:10:34'),('job_signature_statement','I confirm the work described on this job card has been completed to my satisfaction.','2026-08-24 09:10:34'),('job_signature_width','600','2026-08-24 09:10:34'),('job_signoff_required','none','2026-08-24 09:10:36'),('job_sla_closes_at','17:00','2026-08-24 09:10:34'),('job_sla_escalation_enabled','0','2026-08-24 09:10:36'),('job_sla_opens_at','08:00','2026-08-24 09:10:34'),('job_sla_skip_holidays','1','2026-08-24 09:10:34'),('job_sla_trading_days','1111100','2026-08-24 09:10:34'),('job_travel_cost_per_km','','2026-08-24 09:10:34'),('job_travel_gap_minutes','30','2026-08-24 09:10:34'),('job_travel_minimum_km','','2026-08-24 09:10:34'),('job_travel_product_id','','2026-08-24 09:10:34'),('job_travel_rate_per_km','','2026-08-24 09:10:34'),('job_travel_road_factor','1.30','2026-08-24 09:10:34'),('job_travel_round_to','1','2026-08-24 09:10:34'),('job_travel_tolerance_pct','20','2026-08-24 09:10:34'),('job_van_sellable','0','2026-08-24 09:10:34'),('layby_cancellation_fee_pct','0','2026-08-05 20:16:31'),('layby_default_days','90','2026-08-05 20:16:31'),('layby_terms_text','','2026-08-05 20:16:31'),('lot_capture_mode','fefo','2026-08-25 12:46:20'),('lot_capture_strict','0','2026-08-25 12:46:20'),('loyalty_earn_on_discounted','1','2026-08-26 16:44:31'),('loyalty_earn_rate','1','2026-08-26 16:44:31'),('loyalty_enabled','0','2026-08-26 16:44:31'),('loyalty_expiry_mode','activity','2026-08-26 16:44:31'),('loyalty_expiry_months','12','2026-08-26 16:44:31'),('loyalty_min_redeem_points','0','2026-08-26 16:44:31'),('loyalty_redeem_rate','10','2026-08-26 16:44:31'),('loyalty_tier_basis','rolling','2026-08-26 16:44:31'),('loyalty_tier_grace_months','12','2026-08-26 16:44:31'),('loyalty_tier_window_months','12','2026-08-26 16:44:31'),('portal_allow_comments','1','2026-08-24 09:10:35'),('portal_allow_quote_accept','0','2026-08-24 09:10:35'),('portal_allow_uploads','1','2026-08-24 09:10:35'),('portal_enabled','0','2026-08-24 09:10:35'),('portal_max_uploads_per_job','10','2026-08-24 09:10:35'),('promise_grace_days','2','2026-08-06 23:22:50'),('purchase_invoice_tolerance','0.1','2026-08-12 10:55:51'),('quote_terms_text','','2026-08-06 22:51:21'),('quote_validity_days','30','2026-08-06 22:51:21'),('sales_allow_finalised_edit','0','2026-08-05 13:07:59'),('sales_cash_rounding','0.05','2026-08-05 13:07:59'),('sales_number_scope','terminal','2026-08-09 11:52:32'),('staff_holiday_multiplier','2','2026-08-07 09:42:26'),('staff_overtime_multiplier','1.5','2026-08-07 09:42:26'),('staff_sunday_multiplier','2','2026-08-07 09:42:26'),('staff_sunday_ordinary_multiplier','1.5','2026-08-07 09:42:26'),('store_number','01','2026-08-09 11:52:32'),('ticket_max_running_per_user','0','2026-08-24 09:10:36'),('vat_period_locked_to','','2026-08-12 10:55:01');
/*!40000 ALTER TABLE `settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shift_count_denominations`
--

DROP TABLE IF EXISTS `shift_count_denominations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shift_count_denominations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `declaration_id` int(10) unsigned NOT NULL,
  `denomination_id` int(10) unsigned NOT NULL,
  `label` varchar(24) NOT NULL,
  `value` decimal(12,4) NOT NULL,
  `qty` int(10) unsigned NOT NULL DEFAULT 0,
  `amount` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_count_denom` (`declaration_id`,`denomination_id`),
  KEY `fk_countdenom_denomination` (`denomination_id`),
  CONSTRAINT `shift_count_denominations_ibfk_1` FOREIGN KEY (`declaration_id`) REFERENCES `shift_declarations` (`id`) ON DELETE CASCADE,
  CONSTRAINT `shift_count_denominations_ibfk_2` FOREIGN KEY (`denomination_id`) REFERENCES `cash_denominations` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shift_count_denominations`
--

LOCK TABLES `shift_count_denominations` WRITE;
/*!40000 ALTER TABLE `shift_count_denominations` DISABLE KEYS */;
/*!40000 ALTER TABLE `shift_count_denominations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shift_counts`
--

DROP TABLE IF EXISTS `shift_counts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shift_counts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `shift_id` int(10) unsigned NOT NULL,
  `declaration_id` int(10) unsigned DEFAULT NULL,
  `tender_type_id` int(10) unsigned NOT NULL,
  `tender_code` varchar(24) NOT NULL,
  `tender_name` varchar(60) NOT NULL,
  `expected` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `counted` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `variance` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `transaction_count` int(10) unsigned NOT NULL DEFAULT 0,
  `float_included` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `movements_included` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_shift_tender` (`shift_id`,`tender_type_id`),
  KEY `ix_count_tender` (`tender_type_id`),
  KEY `fk_count_declaration` (`declaration_id`),
  CONSTRAINT `shift_counts_ibfk_1` FOREIGN KEY (`declaration_id`) REFERENCES `shift_declarations` (`id`) ON DELETE SET NULL,
  CONSTRAINT `shift_counts_ibfk_2` FOREIGN KEY (`shift_id`) REFERENCES `shifts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `shift_counts_ibfk_3` FOREIGN KEY (`tender_type_id`) REFERENCES `tender_types` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shift_counts`
--

LOCK TABLES `shift_counts` WRITE;
/*!40000 ALTER TABLE `shift_counts` DISABLE KEYS */;
/*!40000 ALTER TABLE `shift_counts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shift_declarations`
--

DROP TABLE IF EXISTS `shift_declarations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shift_declarations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `shift_id` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned DEFAULT NULL,
  `user_name` varchar(120) NOT NULL DEFAULT '',
  `supervisor_id` int(10) unsigned DEFAULT NULL,
  `supervisor_name` varchar(120) NOT NULL DEFAULT '',
  `declared_cash` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `small_change` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `expected_cash` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `declared_total` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `expected_total` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `variance` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `opening_float` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `payouts_total` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `payins_total` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `drops_total` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `refunds_total` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `rounding_total` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `tips_total` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `bank_declared` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `bank_expected` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `bank_reference` varchar(60) DEFAULT NULL,
  `variance_note` varchar(400) DEFAULT NULL,
  `note` varchar(400) DEFAULT NULL,
  `finalized_at` datetime DEFAULT NULL,
  `finalized_by_id` int(10) unsigned DEFAULT NULL,
  `finalized_by_name` varchar(120) DEFAULT NULL,
  `print_count` int(10) unsigned NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_declaration_shift` (`shift_id`),
  KEY `ix_declaration_finalized` (`finalized_at`),
  CONSTRAINT `shift_declarations_ibfk_1` FOREIGN KEY (`shift_id`) REFERENCES `shifts` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shift_declarations`
--

LOCK TABLES `shift_declarations` WRITE;
/*!40000 ALTER TABLE `shift_declarations` DISABLE KEYS */;
INSERT INTO `shift_declarations` VALUES (1,2,1,'Tiaan Smith',1,'Tiaan Smith',120.0000,120.0000,1278.0000,0.0000,0.0000,0.0000,1000.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,278.0000,278.0000,NULL,NULL,NULL,NULL,NULL,NULL,0,'2026-08-25 19:21:55','2026-08-25 19:22:20');
/*!40000 ALTER TABLE `shift_declarations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shift_movements`
--

DROP TABLE IF EXISTS `shift_movements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shift_movements` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `shift_id` int(10) unsigned NOT NULL,
  `terminal_id` int(10) unsigned DEFAULT NULL,
  `movement_type` enum('payout','payin','drop') NOT NULL,
  `amount` decimal(12,4) NOT NULL,
  `reason` varchar(190) NOT NULL,
  `user_id` int(10) unsigned DEFAULT NULL,
  `user_name` varchar(120) NOT NULL DEFAULT '',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `ix_smove_shift` (`shift_id`,`created_at`),
  KEY `fk_smove_terminal` (`terminal_id`),
  CONSTRAINT `shift_movements_ibfk_1` FOREIGN KEY (`shift_id`) REFERENCES `shifts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `shift_movements_ibfk_2` FOREIGN KEY (`terminal_id`) REFERENCES `terminals` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shift_movements`
--

LOCK TABLES `shift_movements` WRITE;
/*!40000 ALTER TABLE `shift_movements` DISABLE KEYS */;
/*!40000 ALTER TABLE `shift_movements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shifts`
--

DROP TABLE IF EXISTS `shifts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shifts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `document_number` varchar(40) DEFAULT NULL,
  `mode` enum('terminal','user') NOT NULL DEFAULT 'terminal',
  `terminal_id` int(10) unsigned DEFAULT NULL,
  `terminal_code` varchar(24) DEFAULT NULL,
  `user_id` int(10) unsigned DEFAULT NULL,
  `user_name` varchar(120) NOT NULL DEFAULT '',
  `opened_at` datetime NOT NULL DEFAULT current_timestamp(),
  `closed_at` datetime DEFAULT NULL,
  `status` enum('open','closed','cancelled') NOT NULL DEFAULT 'open',
  `opening_float` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `counted_total` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `expected_total` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `variance` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `variance_note` varchar(400) DEFAULT NULL,
  `closed_by_user_id` int(10) unsigned DEFAULT NULL,
  `closed_by_name` varchar(120) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `open_terminal_id` int(10) unsigned GENERATED ALWAYS AS (case when `closed_at` is null and `mode` = 'terminal' then `terminal_id` else NULL end) STORED,
  `open_user_id` int(10) unsigned GENERATED ALWAYS AS (case when `closed_at` is null and `mode` = 'user' then `user_id` else NULL end) STORED,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_shift_open_terminal` (`open_terminal_id`),
  UNIQUE KEY `uq_shift_open_user` (`open_user_id`),
  UNIQUE KEY `uq_shift_number` (`document_number`),
  KEY `ix_shift_terminal` (`terminal_id`,`opened_at`),
  KEY `ix_shift_user` (`user_id`,`opened_at`),
  KEY `ix_shift_opened` (`opened_at`),
  CONSTRAINT `shifts_ibfk_1` FOREIGN KEY (`terminal_id`) REFERENCES `terminals` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shifts`
--

LOCK TABLES `shifts` WRITE;
/*!40000 ALTER TABLE `shifts` DISABLE KEYS */;
INSERT INTO `shifts` VALUES (1,'CSH_01_000001','terminal',1,'TILL01',1,'Tiaan Smith','2026-08-24 11:13:11',NULL,'open',0.0000,0.0000,0.0000,0.0000,NULL,NULL,NULL,'2026-08-24 11:13:11','2026-08-25 12:46:20',1,NULL),(2,'CSH_01_000002','terminal',3,'TILL03',1,'Tiaan Smith','2026-08-25 19:12:30',NULL,'open',1000.0000,0.0000,0.0000,0.0000,NULL,NULL,NULL,'2026-08-25 19:12:30','2026-08-25 19:12:30',3,NULL),(3,'CSH_01_000003','terminal',4,'TILL04',1,'Tiaan Smith','2026-08-26 15:08:05',NULL,'open',1000.0000,0.0000,0.0000,0.0000,NULL,NULL,NULL,'2026-08-26 15:08:05','2026-08-26 15:08:05',4,NULL),(4,'CSH_01_000004','terminal',5,'TILL05',1,'Tiaan Smith','2026-08-31 10:53:59',NULL,'open',800.0000,0.0000,0.0000,0.0000,NULL,NULL,NULL,'2026-08-31 10:53:59','2026-08-31 10:53:59',5,NULL),(5,'CSH_01_000005','terminal',6,'TILL06',1,'Tiaan Smith','2026-09-01 10:18:01',NULL,'open',800.0000,0.0000,0.0000,0.0000,NULL,NULL,NULL,'2026-09-01 10:18:01','2026-09-01 10:18:01',6,NULL);
/*!40000 ALTER TABLE `shifts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `site_profile`
--

DROP TABLE IF EXISTS `site_profile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `site_profile` (
  `id` tinyint(3) unsigned NOT NULL DEFAULT 1,
  `site_id` int(11) NOT NULL,
  `site_code` varchar(64) NOT NULL,
  `company_name` varchar(255) NOT NULL,
  `trading_name` varchar(255) DEFAULT NULL,
  `registration_number` varchar(64) DEFAULT NULL,
  `vat_number` varchar(64) DEFAULT NULL,
  `address1` varchar(255) DEFAULT NULL,
  `address2` varchar(255) DEFAULT NULL,
  `address3` varchar(255) DEFAULT NULL,
  `postal_code` varchar(32) DEFAULT NULL,
  `phone` varchar(64) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `contact_name` varchar(255) DEFAULT NULL,
  `connection_type` varchar(16) NOT NULL DEFAULT 'cloud',
  `site_type_id` int(11) DEFAULT NULL,
  `is_paid` tinyint(1) NOT NULL DEFAULT 0,
  `status` varchar(16) NOT NULL DEFAULT 'active',
  `mirrored_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  CONSTRAINT `CONSTRAINT_1` CHECK (`id` = 1)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `site_profile`
--

LOCK TABLES `site_profile` WRITE;
/*!40000 ALTER TABLE `site_profile` DISABLE KEYS */;
/*!40000 ALTER TABLE `site_profile` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `special_items`
--

DROP TABLE IF EXISTS `special_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `special_items` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `special_id` int(10) unsigned NOT NULL,
  `role` enum('scope','trigger','reward') NOT NULL DEFAULT 'scope',
  `slot` tinyint(3) unsigned DEFAULT NULL,
  `product_id` int(10) unsigned DEFAULT NULL,
  `department_id` int(10) unsigned DEFAULT NULL,
  `qty` decimal(12,3) NOT NULL DEFAULT 1.000,
  `price_incl` decimal(12,4) NOT NULL DEFAULT 0.0000,
  PRIMARY KEY (`id`),
  KEY `idx_special_items_special` (`special_id`,`role`),
  KEY `fk_special_items_product` (`product_id`),
  KEY `fk_special_items_department` (`department_id`),
  CONSTRAINT `special_items_ibfk_1` FOREIGN KEY (`department_id`) REFERENCES `departments` (`id`) ON DELETE CASCADE,
  CONSTRAINT `special_items_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  CONSTRAINT `special_items_ibfk_3` FOREIGN KEY (`special_id`) REFERENCES `specials` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `special_items`
--

LOCK TABLES `special_items` WRITE;
/*!40000 ALTER TABLE `special_items` DISABLE KEYS */;
INSERT INTO `special_items` VALUES (5,3,'scope',NULL,NULL,11,1.000,10.0000),(6,3,'scope',NULL,NULL,13,1.000,10.0000),(7,3,'scope',NULL,NULL,14,1.000,10.0000),(8,3,'scope',NULL,NULL,15,1.000,10.0000),(9,4,'scope',NULL,NULL,17,1.000,10.0000),(10,4,'scope',NULL,NULL,18,1.000,10.0000),(11,2,'trigger',NULL,NULL,11,1.000,0.0000),(12,2,'trigger',NULL,NULL,12,1.000,0.0000),(13,1,'scope',NULL,NULL,12,1.000,0.0000);
/*!40000 ALTER TABLE `special_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `special_redemptions`
--

DROP TABLE IF EXISTS `special_redemptions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `special_redemptions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `special_id` int(10) unsigned NOT NULL,
  `document_id` int(10) unsigned DEFAULT NULL,
  `customer_id` int(10) unsigned DEFAULT NULL,
  `amount_incl` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `used_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_redemption_per_document` (`special_id`,`document_id`),
  KEY `ix_redemption_special` (`special_id`,`used_at`),
  KEY `ix_redemption_customer` (`special_id`,`customer_id`),
  CONSTRAINT `special_redemptions_ibfk_1` FOREIGN KEY (`special_id`) REFERENCES `specials` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `special_redemptions`
--

LOCK TABLES `special_redemptions` WRITE;
/*!40000 ALTER TABLE `special_redemptions` DISABLE KEYS */;
INSERT INTO `special_redemptions` VALUES (1,3,30,NULL,83.0000,'2026-08-31 10:55:39');
/*!40000 ALTER TABLE `special_redemptions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `special_tiers`
--

DROP TABLE IF EXISTS `special_tiers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `special_tiers` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `special_id` int(10) unsigned NOT NULL,
  `qty` int(10) unsigned NOT NULL,
  `price_incl` decimal(12,4) NOT NULL,
  `discount_pct` decimal(6,3) NOT NULL DEFAULT 0.000,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ux_tier_qty` (`special_id`,`qty`),
  CONSTRAINT `special_tiers_ibfk_1` FOREIGN KEY (`special_id`) REFERENCES `specials` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `special_tiers`
--

LOCK TABLES `special_tiers` WRITE;
/*!40000 ALTER TABLE `special_tiers` DISABLE KEYS */;
/*!40000 ALTER TABLE `special_tiers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `specials`
--

DROP TABLE IF EXISTS `specials`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `specials` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `shape` enum('happy_hour','special_price','cheapest_free','free_item','percent_off','bundle_price','multibuy','spend','quantity_break','second_at_pct','mix_and_match','free_delivery','bonus_points') NOT NULL DEFAULT 'happy_hour',
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `starts_at` varchar(16) NOT NULL,
  `ends_at` varchar(16) NOT NULL,
  `daily_start` varchar(5) NOT NULL DEFAULT '',
  `daily_end` varchar(5) NOT NULL DEFAULT '',
  `days_of_week` char(7) NOT NULL DEFAULT '1111111',
  `discount_pct` decimal(6,3) NOT NULL DEFAULT 0.000,
  `trigger_qty` int(10) unsigned NOT NULL DEFAULT 0,
  `bundle_price_incl` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `spend_amount_incl` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `priority` int(11) NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_by` varchar(120) NOT NULL DEFAULT '',
  `max_deals_per_sale` int(10) unsigned NOT NULL DEFAULT 0,
  `respect_max_discount` tinyint(1) NOT NULL DEFAULT 0,
  `min_margin_pct` decimal(6,3) NOT NULL DEFAULT 0.000,
  `never_below_cost` tinyint(1) NOT NULL DEFAULT 0,
  `max_redemptions` int(10) unsigned DEFAULT NULL,
  `redemptions_count` int(10) unsigned NOT NULL DEFAULT 0,
  `audience` enum('everyone','account','member','group') NOT NULL DEFAULT 'everyone',
  `audience_group_id` int(10) unsigned DEFAULT NULL,
  `runs_in_store` tinyint(1) NOT NULL DEFAULT 1,
  `runs_online` tinyint(1) NOT NULL DEFAULT 1,
  `points_multiplier` decimal(6,3) NOT NULL DEFAULT 1.000,
  `reward_per_deal` tinyint(1) NOT NULL DEFAULT 1,
  `origin_site_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_specials_live` (`is_active`,`ends_at`),
  KEY `idx_specials_priority` (`priority`,`id`),
  KEY `ix_special_audience` (`audience`,`audience_group_id`),
  KEY `fk_special_audience_group` (`audience_group_id`),
  KEY `ix_special_origin` (`origin_site_id`),
  CONSTRAINT `specials_ibfk_1` FOREIGN KEY (`audience_group_id`) REFERENCES `customer_groups` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `specials`
--

LOCK TABLES `specials` WRITE;
/*!40000 ALTER TABLE `specials` DISABLE KEYS */;
INSERT INTO `specials` VALUES (1,'20% off special','happy_hour',1,'2026-08-24T00:00','2026-08-31T23:59','','','1111111',10.000,3,0.0000,0.0000,2,'2026-08-24 13:01:08','2026-08-26 16:21:14','Tiaan Smith',0,0,0.000,0,100,0,'everyone',NULL,1,1,1.000,1,NULL),(2,'15% off special','cheapest_free',1,'2026-08-24T00:00','2026-08-31T23:59','','','1111111',10.000,3,0.0000,0.0000,1,'2026-08-24 13:02:40','2026-08-26 16:20:54','Tiaan Smith',0,0,0.000,0,NULL,0,'everyone',NULL,1,1,1.000,1,NULL),(3,'10% off specials','special_price',1,'2026-08-26T00:00','2026-09-02T23:59','','','1111111',10.000,3,0.0000,0.0000,3,'2026-08-26 15:59:22','2026-08-31 10:55:39','Tiaan Smith',0,0,0.000,0,NULL,1,'everyone',NULL,1,1,1.000,1,NULL),(4,'5% off special','special_price',1,'2026-08-26T00:00','2026-09-02T23:59','','','1111111',10.000,3,0.0000,0.0000,4,'2026-08-26 16:20:12','2026-08-26 16:20:12','Tiaan Smith',0,0,0.000,0,NULL,0,'everyone',NULL,1,1,1.000,1,NULL);
/*!40000 ALTER TABLE `specials` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `staff_pay_lines`
--

DROP TABLE IF EXISTS `staff_pay_lines`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `staff_pay_lines` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `period_id` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `user_name` varchar(120) NOT NULL DEFAULT '',
  `employee_number` varchar(32) DEFAULT NULL,
  `pay_basis` enum('hourly','salaried') NOT NULL DEFAULT 'hourly',
  `hourly_rate` decimal(10,4) NOT NULL DEFAULT 0.0000,
  `monthly_salary` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `ordinary_hours` decimal(8,2) NOT NULL DEFAULT 0.00,
  `overtime_hours` decimal(8,2) NOT NULL DEFAULT 0.00,
  `premium_hours` decimal(8,2) NOT NULL DEFAULT 0.00,
  `leave_days` decimal(8,2) NOT NULL DEFAULT 0.00,
  `ordinary_cost` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `overtime_cost` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `premium_cost` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `leave_cost` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `commission` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `total_cost` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `revenue_rung_up` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `revenue_sold` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `gross_profit` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_pay_line` (`period_id`,`user_id`),
  KEY `ix_pay_line_user` (`user_id`),
  CONSTRAINT `staff_pay_lines_ibfk_1` FOREIGN KEY (`period_id`) REFERENCES `staff_pay_periods` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `staff_pay_lines`
--

LOCK TABLES `staff_pay_lines` WRITE;
/*!40000 ALTER TABLE `staff_pay_lines` DISABLE KEYS */;
/*!40000 ALTER TABLE `staff_pay_lines` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `staff_pay_periods`
--

DROP TABLE IF EXISTS `staff_pay_periods`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `staff_pay_periods` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `period_start` date NOT NULL,
  `period_end` date NOT NULL,
  `status` enum('open','locked') NOT NULL DEFAULT 'open',
  `calculated_at` datetime DEFAULT NULL,
  `locked_at` datetime DEFAULT NULL,
  `locked_by_user_id` int(10) unsigned DEFAULT NULL,
  `locked_by_name` varchar(120) DEFAULT NULL,
  `total_cost` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `note` varchar(400) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_pay_period` (`period_start`,`period_end`),
  KEY `ix_pay_period_status` (`status`,`period_start`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `staff_pay_periods`
--

LOCK TABLES `staff_pay_periods` WRITE;
/*!40000 ALTER TABLE `staff_pay_periods` DISABLE KEYS */;
/*!40000 ALTER TABLE `staff_pay_periods` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `staff_time_entries`
--

DROP TABLE IF EXISTS `staff_time_entries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `staff_time_entries` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `user_name` varchar(120) NOT NULL DEFAULT '',
  `started_at` datetime NOT NULL,
  `ended_at` datetime DEFAULT NULL,
  `source` enum('pin','manual','import') NOT NULL DEFAULT 'pin',
  `terminal_id` int(10) unsigned DEFAULT NULL,
  `shift_id` int(10) unsigned DEFAULT NULL,
  `job_card_id` int(10) unsigned DEFAULT NULL,
  `break_minutes` int(11) NOT NULL DEFAULT 0,
  `note` varchar(400) DEFAULT NULL,
  `edited_by_user_id` int(10) unsigned DEFAULT NULL,
  `edited_by_name` varchar(120) DEFAULT NULL,
  `edited_at` datetime DEFAULT NULL,
  `edited_reason` varchar(400) DEFAULT NULL,
  `original_started_at` datetime DEFAULT NULL,
  `original_ended_at` datetime DEFAULT NULL,
  `approved_at` datetime DEFAULT NULL,
  `approved_by_user_id` int(10) unsigned DEFAULT NULL,
  `approved_by_name` varchar(120) DEFAULT NULL,
  `open_user_id` int(10) unsigned GENERATED ALWAYS AS (case when `ended_at` is null then `user_id` else NULL end) STORED,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_open_entry` (`open_user_id`),
  KEY `ix_time_user_day` (`user_id`,`started_at`),
  KEY `ix_time_started` (`started_at`),
  KEY `ix_time_shift` (`shift_id`),
  KEY `ix_time_job` (`job_card_id`,`started_at`),
  CONSTRAINT `staff_time_entries_ibfk_1` FOREIGN KEY (`job_card_id`) REFERENCES `job_cards` (`id`) ON DELETE SET NULL,
  CONSTRAINT `staff_time_entries_ibfk_2` FOREIGN KEY (`shift_id`) REFERENCES `shifts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `staff_time_entries`
--

LOCK TABLES `staff_time_entries` WRITE;
/*!40000 ALTER TABLE `staff_time_entries` DISABLE KEYS */;
INSERT INTO `staff_time_entries` VALUES (1,1,'Tiaan Smith','2026-08-10 07:56:15',NULL,'pin',NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2026-08-10 07:56:15','2026-08-10 07:56:15');
/*!40000 ALTER TABLE `staff_time_entries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stationery_images`
--

DROP TABLE IF EXISTS `stationery_images`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `stationery_images` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `stored_name` varchar(190) NOT NULL,
  `filename` varchar(255) NOT NULL,
  `label` varchar(120) NOT NULL DEFAULT '',
  `mime_type` varchar(40) NOT NULL,
  `size_bytes` bigint(20) unsigned NOT NULL DEFAULT 0,
  `created_by` int(10) unsigned DEFAULT NULL,
  `created_by_name` varchar(120) NOT NULL DEFAULT '',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_stored_name` (`stored_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stationery_images`
--

LOCK TABLES `stationery_images` WRITE;
/*!40000 ALTER TABLE `stationery_images` DISABLE KEYS */;
/*!40000 ALTER TABLE `stationery_images` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stationery_templates`
--

DROP TABLE IF EXISTS `stationery_templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `stationery_templates` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `doc_type` varchar(40) NOT NULL,
  `name` varchar(120) NOT NULL,
  `format` enum('html','slip','blocks') NOT NULL DEFAULT 'html',
  `body` mediumtext NOT NULL,
  `draft_body` mediumtext DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 0,
  `version` smallint(5) unsigned NOT NULL DEFAULT 1,
  `created_by` int(10) unsigned DEFAULT NULL,
  `created_by_name` varchar(120) NOT NULL DEFAULT '',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_type_active` (`doc_type`,`is_active`),
  KEY `idx_updated` (`updated_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stationery_templates`
--

LOCK TABLES `stationery_templates` WRITE;
/*!40000 ALTER TABLE `stationery_templates` DISABLE KEYS */;
/*!40000 ALTER TABLE `stationery_templates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stock_adjustment_lines`
--

DROP TABLE IF EXISTS `stock_adjustment_lines`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `stock_adjustment_lines` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `adjustment_id` int(10) unsigned NOT NULL,
  `line_number` smallint(5) unsigned NOT NULL DEFAULT 1,
  `product_id` int(10) unsigned NOT NULL,
  `product_code` varchar(40) DEFAULT NULL,
  `description` varchar(190) NOT NULL,
  `qty_before` decimal(12,3) NOT NULL DEFAULT 0.000,
  `qty_change` decimal(12,3) NOT NULL,
  `unit_cost_excl` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `reason_id` int(10) unsigned DEFAULT NULL,
  `serial_ids` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`serial_ids`)),
  `batch_id` int(10) unsigned DEFAULT NULL,
  `note` varchar(190) DEFAULT NULL,
  `movement_id` bigint(20) unsigned DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_aline_product` (`adjustment_id`,`product_id`),
  KEY `ix_aline_adjustment` (`adjustment_id`,`line_number`),
  KEY `ix_aline_product` (`product_id`),
  KEY `fk_aline_reason` (`reason_id`),
  KEY `fk_adj_line_batch` (`batch_id`),
  CONSTRAINT `stock_adjustment_lines_ibfk_1` FOREIGN KEY (`batch_id`) REFERENCES `product_batches` (`id`) ON DELETE SET NULL,
  CONSTRAINT `stock_adjustment_lines_ibfk_2` FOREIGN KEY (`adjustment_id`) REFERENCES `stock_adjustments` (`id`) ON DELETE CASCADE,
  CONSTRAINT `stock_adjustment_lines_ibfk_3` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`),
  CONSTRAINT `stock_adjustment_lines_ibfk_4` FOREIGN KEY (`reason_id`) REFERENCES `stock_adjustment_reasons` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stock_adjustment_lines`
--

LOCK TABLES `stock_adjustment_lines` WRITE;
/*!40000 ALTER TABLE `stock_adjustment_lines` DISABLE KEYS */;
INSERT INTO `stock_adjustment_lines` VALUES (1,1,1,115,'BURG007','Buttermilk Chicken Burger',66.000,10.000,36.0000,NULL,NULL,NULL,NULL,132,'2026-08-24 13:08:27','2026-08-24 13:08:53'),(2,2,1,189,'PRD00017','Refer test × 24',0.000,10.000,120.0000,NULL,NULL,NULL,NULL,138,'2026-08-26 16:03:10','2026-08-26 16:03:10'),(3,3,1,192,'PRD00020','Refer 2 item × 12',0.000,10.000,600.0000,NULL,NULL,NULL,NULL,139,'2026-08-26 16:19:05','2026-08-26 16:19:05'),(4,4,1,139,'DRNK003','Fanta Orange 330ml Can',84.000,-1.000,8.3000,NULL,NULL,NULL,NULL,146,'2026-08-26 16:51:23','2026-08-26 16:51:23'),(5,4,2,140,'DRNK004','Sprite 330ml Can',96.000,-1.000,8.3000,NULL,NULL,NULL,NULL,147,'2026-08-26 16:51:23','2026-08-26 16:51:23'),(6,4,3,192,'PRD00020','Refer 2 item × 12',10.000,-1.000,600.0000,NULL,NULL,NULL,NULL,148,'2026-08-26 16:51:23','2026-08-26 16:51:23');
/*!40000 ALTER TABLE `stock_adjustment_lines` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stock_adjustment_reasons`
--

DROP TABLE IF EXISTS `stock_adjustment_reasons`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `stock_adjustment_reasons` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(24) NOT NULL,
  `name` varchar(120) NOT NULL,
  `direction` enum('in','out','both') NOT NULL DEFAULT 'both',
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `sort_order` int(11) NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_adj_reason_code` (`code`),
  KEY `ix_adj_reason_active` (`is_active`,`sort_order`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stock_adjustment_reasons`
--

LOCK TABLES `stock_adjustment_reasons` WRITE;
/*!40000 ALTER TABLE `stock_adjustment_reasons` DISABLE KEYS */;
INSERT INTO `stock_adjustment_reasons` VALUES (1,'DAMAGE','Damaged','out',1,10,'2026-08-12 08:49:30','2026-08-12 08:49:30'),(2,'SHRINK','Shrinkage or theft','out',1,20,'2026-08-12 08:49:30','2026-08-12 08:49:30'),(3,'EXPIRED','Expired or spoiled','out',1,30,'2026-08-12 08:49:30','2026-08-12 08:49:30'),(4,'CONSUMED','Used in the business','out',1,40,'2026-08-12 08:49:30','2026-08-12 08:49:30'),(5,'SAMPLE','Sample or giveaway','out',1,50,'2026-08-12 08:49:30','2026-08-12 08:49:30'),(6,'FOUND','Found on the floor','in',1,60,'2026-08-12 08:49:30','2026-08-12 08:49:30'),(7,'CORRECT','Capture correction','both',1,70,'2026-08-12 08:49:30','2026-08-12 08:49:30');
/*!40000 ALTER TABLE `stock_adjustment_reasons` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stock_adjustments`
--

DROP TABLE IF EXISTS `stock_adjustments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `stock_adjustments` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `document_number` varchar(32) DEFAULT NULL,
  `document_date` date NOT NULL,
  `location_id` int(10) unsigned NOT NULL,
  `status` enum('draft','posted','cancelled') NOT NULL DEFAULT 'draft',
  `reason_id` int(10) unsigned DEFAULT NULL,
  `reference` varchar(60) DEFAULT NULL,
  `note` varchar(400) DEFAULT NULL,
  `variance_qty` decimal(14,3) NOT NULL DEFAULT 0.000,
  `variance_value` decimal(14,4) NOT NULL DEFAULT 0.0000,
  `posted_at` datetime DEFAULT NULL,
  `cancel_reason` varchar(190) DEFAULT NULL,
  `cancelled_at` datetime DEFAULT NULL,
  `user_id` int(10) unsigned DEFAULT NULL,
  `user_name` varchar(120) NOT NULL DEFAULT '',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_adjustment_number` (`document_number`),
  KEY `ix_adjustment_date` (`document_date`,`id`),
  KEY `ix_adjustment_status` (`status`,`document_date`),
  KEY `ix_adjustment_location` (`location_id`,`status`),
  KEY `fk_adjustment_reason` (`reason_id`),
  CONSTRAINT `stock_adjustments_ibfk_1` FOREIGN KEY (`location_id`) REFERENCES `stock_locations` (`id`),
  CONSTRAINT `stock_adjustments_ibfk_2` FOREIGN KEY (`reason_id`) REFERENCES `stock_adjustment_reasons` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stock_adjustments`
--

LOCK TABLES `stock_adjustments` WRITE;
/*!40000 ALTER TABLE `stock_adjustments` DISABLE KEYS */;
INSERT INTO `stock_adjustments` VALUES (1,'ADJ000001','2026-08-24',1,'posted',1,'test ref','this is a note',10.000,360.0000,'2026-08-24 13:08:53',NULL,NULL,1,'Tiaan Smith','2026-08-24 13:08:27','2026-08-24 13:08:53'),(2,'ADJ000002','2026-08-26',1,'posted',6,NULL,NULL,10.000,1200.0000,'2026-08-26 16:03:10',NULL,NULL,1,'Tiaan Smith','2026-08-26 16:03:10','2026-08-26 16:03:10'),(3,'ADJ000003','2026-08-26',1,'posted',6,NULL,NULL,10.000,6000.0000,'2026-08-26 16:19:05',NULL,NULL,1,'Tiaan Smith','2026-08-26 16:19:05','2026-08-26 16:19:05'),(4,'ADJ000004','2026-08-26',1,'posted',1,'Koos Write off',NULL,-3.000,-616.6000,'2026-08-26 16:51:23',NULL,NULL,1,'Tiaan Smith','2026-08-26 16:51:23','2026-08-26 16:51:23');
/*!40000 ALTER TABLE `stock_adjustments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stock_locations`
--

DROP TABLE IF EXISTS `stock_locations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `stock_locations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(24) NOT NULL,
  `name` varchar(120) NOT NULL,
  `is_main` tinyint(1) NOT NULL DEFAULT 0,
  `is_transit` tinyint(1) NOT NULL DEFAULT 0,
  `is_mobile` tinyint(1) NOT NULL DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `address` varchar(190) DEFAULT NULL,
  `note` varchar(190) DEFAULT NULL,
  `sort_order` int(11) NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `latitude` decimal(10,7) DEFAULT NULL,
  `longitude` decimal(10,7) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_location_code` (`code`),
  KEY `ix_location_main` (`is_main`),
  KEY `ix_location_active` (`is_active`,`sort_order`),
  KEY `ix_location_transit` (`is_transit`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stock_locations`
--

LOCK TABLES `stock_locations` WRITE;
/*!40000 ALTER TABLE `stock_locations` DISABLE KEYS */;
INSERT INTO `stock_locations` VALUES (1,'T001','Tiaan',1,0,0,1,NULL,NULL,0,'2026-08-05 20:14:43','2026-08-11 14:01:15',NULL,NULL),(2,'E001','Etienne',0,0,0,1,NULL,NULL,0,'2026-08-11 14:01:26','2026-08-11 14:01:26',NULL,NULL),(3,'TRANSIT','In transit',0,1,0,1,NULL,'Goods dispatched to another store and not yet received. Managed by the system.',9000,'2026-08-12 08:49:31','2026-08-12 08:49:31',NULL,NULL);
/*!40000 ALTER TABLE `stock_locations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stock_movements`
--

DROP TABLE IF EXISTS `stock_movements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `stock_movements` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `product_id` int(10) unsigned NOT NULL,
  `location_id` int(10) unsigned DEFAULT NULL,
  `movement_type` enum('sale','sale_return','opening','receipt','adjustment','transfer_in','transfer_out','manufacture_in','manufacture_out','unpack_in','unpack_out') NOT NULL,
  `qty_change` decimal(12,3) NOT NULL,
  `qty_after` decimal(12,3) NOT NULL DEFAULT 0.000,
  `unit_cost_excl` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `source` varchar(24) NOT NULL DEFAULT 'sale',
  `source_doc_id` int(10) unsigned DEFAULT NULL,
  `source_line_id` int(10) unsigned DEFAULT NULL,
  `terminal_id` int(10) unsigned DEFAULT NULL,
  `shift_id` int(10) unsigned DEFAULT NULL,
  `user_id` int(10) unsigned DEFAULT NULL,
  `user_name` varchar(120) NOT NULL DEFAULT '',
  `note` varchar(190) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `ix_move_product` (`product_id`,`created_at`),
  KEY `ix_move_source` (`source`,`source_doc_id`),
  KEY `ix_move_type_date` (`movement_type`,`created_at`),
  KEY `ix_move_terminal` (`terminal_id`,`created_at`),
  KEY `ix_move_location` (`location_id`,`created_at`),
  KEY `ix_move_product_location` (`product_id`,`location_id`),
  CONSTRAINT `stock_movements_ibfk_1` FOREIGN KEY (`location_id`) REFERENCES `stock_locations` (`id`),
  CONSTRAINT `stock_movements_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=153 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stock_movements`
--

LOCK TABLES `stock_movements` WRITE;
/*!40000 ALTER TABLE `stock_movements` DISABLE KEYS */;
INSERT INTO `stock_movements` VALUES (1,49,1,'sale',-1.000,39.000,13.0000,'invoice',1,5,NULL,NULL,1,'Tiaan Smith','DR-505','2026-08-09 09:50:14'),(2,9,1,'sale',-1.000,39.000,58.0000,'invoice',1,6,NULL,NULL,1,'Tiaan Smith','SB-103','2026-08-09 09:50:14'),(3,22,1,'sale',-1.000,39.000,39.0000,'invoice',1,7,NULL,NULL,1,'Tiaan Smith','HD-204','2026-08-09 09:50:14'),(4,49,1,'sale',-1.000,38.000,13.0000,'invoice',1,8,NULL,NULL,1,'Tiaan Smith','DR-505','2026-08-09 09:50:14'),(5,9,1,'sale',-1.000,39.000,58.0000,'invoice',2,17,NULL,NULL,1,'Tiaan Smith','SB-103','2026-08-09 10:14:30'),(6,18,1,'sale',-1.000,39.000,66.0000,'invoice',2,18,NULL,NULL,1,'Tiaan Smith','SB-112','2026-08-09 10:14:30'),(7,30,1,'sale',-1.000,39.000,70.0000,'invoice',2,19,NULL,NULL,1,'Tiaan Smith','PZ-304','2026-08-09 10:14:30'),(8,57,1,'sale',-1.000,39.000,21.0000,'invoice',2,20,NULL,NULL,1,'Tiaan Smith','DS-601','2026-08-09 10:14:30'),(49,109,1,'opening',30.000,30.000,26.0000,'opening',NULL,NULL,NULL,NULL,NULL,'Product created','Opening stock at capture','2026-08-11 13:20:53'),(50,110,1,'opening',36.000,36.000,38.0000,'opening',NULL,NULL,NULL,NULL,NULL,'Product created','Opening stock at capture','2026-08-11 13:20:53'),(51,111,1,'opening',42.000,42.000,52.0000,'opening',NULL,NULL,NULL,NULL,NULL,'Product created','Opening stock at capture','2026-08-11 13:20:53'),(52,112,1,'opening',48.000,48.000,42.0000,'opening',NULL,NULL,NULL,NULL,NULL,'Product created','Opening stock at capture','2026-08-11 13:20:53'),(53,113,1,'opening',54.000,54.000,40.0000,'opening',NULL,NULL,NULL,NULL,NULL,'Product created','Opening stock at capture','2026-08-11 13:20:53'),(54,114,1,'opening',60.000,60.000,39.0000,'opening',NULL,NULL,NULL,NULL,NULL,'Product created','Opening stock at capture','2026-08-11 13:20:53'),(55,115,1,'opening',66.000,66.000,36.0000,'opening',NULL,NULL,NULL,NULL,NULL,'Product created','Opening stock at capture','2026-08-11 13:20:53'),(56,116,1,'opening',72.000,72.000,44.0000,'opening',NULL,NULL,NULL,NULL,NULL,'Product created','Opening stock at capture','2026-08-11 13:20:53'),(57,117,1,'opening',30.000,30.000,22.0000,'opening',NULL,NULL,NULL,NULL,NULL,'Product created','Opening stock at capture','2026-08-11 13:20:53'),(58,118,1,'opening',36.000,36.000,29.0000,'opening',NULL,NULL,NULL,NULL,NULL,'Product created','Opening stock at capture','2026-08-11 13:20:53'),(59,119,1,'opening',42.000,42.000,31.0000,'opening',NULL,NULL,NULL,NULL,NULL,'Product created','Opening stock at capture','2026-08-11 13:20:53'),(60,120,1,'opening',48.000,48.000,34.0000,'opening',NULL,NULL,NULL,NULL,NULL,'Product created','Opening stock at capture','2026-08-11 13:20:53'),(61,121,1,'opening',54.000,54.000,32.0000,'opening',NULL,NULL,NULL,NULL,NULL,'Product created','Opening stock at capture','2026-08-11 13:20:53'),(62,122,1,'opening',60.000,60.000,17.0000,'opening',NULL,NULL,NULL,NULL,NULL,'Product created','Opening stock at capture','2026-08-11 13:20:53'),(63,123,1,'opening',30.000,30.000,31.0000,'opening',NULL,NULL,NULL,NULL,NULL,'Product created','Opening stock at capture','2026-08-11 13:20:53'),(64,124,1,'opening',36.000,36.000,40.0000,'opening',NULL,NULL,NULL,NULL,NULL,'Product created','Opening stock at capture','2026-08-11 13:20:53'),(65,125,1,'opening',42.000,42.000,43.0000,'opening',NULL,NULL,NULL,NULL,NULL,'Product created','Opening stock at capture','2026-08-11 13:20:53'),(66,126,1,'opening',48.000,48.000,49.0000,'opening',NULL,NULL,NULL,NULL,NULL,'Product created','Opening stock at capture','2026-08-11 13:20:53'),(67,127,1,'opening',54.000,54.000,51.0000,'opening',NULL,NULL,NULL,NULL,NULL,'Product created','Opening stock at capture','2026-08-11 13:20:53'),(68,128,1,'opening',60.000,60.000,62.0000,'opening',NULL,NULL,NULL,NULL,NULL,'Product created','Opening stock at capture','2026-08-11 13:20:53'),(69,129,1,'opening',66.000,66.000,38.0000,'opening',NULL,NULL,NULL,NULL,NULL,'Product created','Opening stock at capture','2026-08-11 13:20:53'),(70,130,1,'opening',72.000,72.000,22.0000,'opening',NULL,NULL,NULL,NULL,NULL,'Product created','Opening stock at capture','2026-08-11 13:20:53'),(71,131,1,'opening',30.000,30.000,9.0000,'opening',NULL,NULL,NULL,NULL,NULL,'Product created','Opening stock at capture','2026-08-11 13:20:53'),(72,132,1,'opening',36.000,36.000,13.0000,'opening',NULL,NULL,NULL,NULL,NULL,'Product created','Opening stock at capture','2026-08-11 13:20:53'),(73,133,1,'opening',42.000,42.000,24.0000,'opening',NULL,NULL,NULL,NULL,NULL,'Product created','Opening stock at capture','2026-08-11 13:20:53'),(74,134,1,'opening',48.000,48.000,28.0000,'opening',NULL,NULL,NULL,NULL,NULL,'Product created','Opening stock at capture','2026-08-11 13:20:53'),(75,135,1,'opening',54.000,54.000,14.0000,'opening',NULL,NULL,NULL,NULL,NULL,'Product created','Opening stock at capture','2026-08-11 13:20:53'),(76,136,1,'opening',60.000,60.000,8.0000,'opening',NULL,NULL,NULL,NULL,NULL,'Product created','Opening stock at capture','2026-08-11 13:20:53'),(77,137,1,'opening',60.000,60.000,8.5000,'opening',NULL,NULL,NULL,NULL,NULL,'Product created','Opening stock at capture','2026-08-11 13:20:53'),(78,138,1,'opening',72.000,72.000,8.5000,'opening',NULL,NULL,NULL,NULL,NULL,'Product created','Opening stock at capture','2026-08-11 13:20:53'),(79,139,1,'opening',84.000,84.000,8.3000,'opening',NULL,NULL,NULL,NULL,NULL,'Product created','Opening stock at capture','2026-08-11 13:20:53'),(80,140,1,'opening',96.000,96.000,8.3000,'opening',NULL,NULL,NULL,NULL,NULL,'Product created','Opening stock at capture','2026-08-11 13:20:53'),(81,141,1,'opening',108.000,108.000,12.0000,'opening',NULL,NULL,NULL,NULL,NULL,'Product created','Opening stock at capture','2026-08-11 13:20:53'),(82,142,1,'opening',120.000,120.000,19.0000,'opening',NULL,NULL,NULL,NULL,NULL,'Product created','Opening stock at capture','2026-08-11 13:20:53'),(83,143,1,'opening',132.000,132.000,11.0000,'opening',NULL,NULL,NULL,NULL,NULL,'Product created','Opening stock at capture','2026-08-11 13:20:53'),(84,144,1,'opening',72.000,72.000,14.0000,'opening',NULL,NULL,NULL,NULL,NULL,'Product created','Opening stock at capture','2026-08-11 13:20:53'),(85,145,1,'opening',30.000,30.000,15.0000,'opening',NULL,NULL,NULL,NULL,NULL,'Product created','Opening stock at capture','2026-08-11 13:20:53'),(86,146,1,'opening',36.000,36.000,6.5000,'opening',NULL,NULL,NULL,NULL,NULL,'Product created','Opening stock at capture','2026-08-11 13:20:53'),(87,147,1,'opening',42.000,42.000,21.0000,'opening',NULL,NULL,NULL,NULL,NULL,'Product created','Opening stock at capture','2026-08-11 13:20:53'),(88,148,1,'opening',48.000,48.000,18.0000,'opening',NULL,NULL,NULL,NULL,NULL,'Product created','Opening stock at capture','2026-08-11 13:20:53'),(89,141,1,'sale',-1.000,107.000,12.0000,'invoice',9,48,NULL,NULL,1,'Tiaan Smith','DRNK005','2026-08-11 13:46:45'),(90,127,1,'sale',-1.000,53.000,51.0000,'invoice',9,49,NULL,NULL,1,'Tiaan Smith','PIZZ005','2026-08-11 13:46:45'),(91,116,1,'sale',-1.000,71.000,44.0000,'invoice',9,50,NULL,NULL,1,'Tiaan Smith','BURG008','2026-08-11 13:46:45'),(92,120,1,'sale',-1.000,47.000,34.0000,'invoice',9,51,NULL,NULL,1,'Tiaan Smith','DOGS004','2026-08-11 13:46:45'),(93,28,1,'sale',-1.000,-1.000,58.0000,'invoice',8,68,NULL,NULL,1,'Tiaan Smith','PZ-302','2026-08-11 13:49:00'),(94,30,1,'sale',-1.000,-1.000,70.0000,'invoice',8,69,NULL,NULL,1,'Tiaan Smith','PZ-304','2026-08-11 13:49:00'),(95,29,1,'sale',-1.000,-1.000,64.0000,'invoice',8,70,NULL,NULL,1,'Tiaan Smith','PZ-303','2026-08-11 13:49:00'),(96,36,1,'sale',-1.000,-1.000,78.0000,'invoice',8,71,NULL,NULL,1,'Tiaan Smith','PZ-310','2026-08-11 13:49:00'),(97,141,1,'sale',-1.000,106.000,12.0000,'invoice',8,72,NULL,NULL,1,'Tiaan Smith','DRNK005','2026-08-11 13:49:00'),(98,141,1,'sale',-1.000,105.000,12.0000,'invoice',8,73,NULL,NULL,1,'Tiaan Smith','DRNK005','2026-08-11 13:49:00'),(99,141,1,'sale',-1.000,104.000,12.0000,'invoice',8,74,NULL,NULL,1,'Tiaan Smith','DRNK005','2026-08-11 13:49:00'),(100,141,1,'sale',-1.000,103.000,12.0000,'invoice',8,75,NULL,NULL,1,'Tiaan Smith','DRNK005','2026-08-11 13:49:00'),(105,149,1,'receipt',40.000,40.000,10.0000,'grv',3,NULL,NULL,NULL,1,'Order Test','Inv INV-24876588','2026-08-12 10:54:36'),(106,149,1,'receipt',60.000,100.000,10.0000,'grv',4,NULL,NULL,NULL,1,'Order Test',NULL,'2026-08-12 10:54:37'),(119,152,1,'receipt',100.000,100.000,10.0000,'grv',14,NULL,NULL,NULL,1,'Draft Test','Inv INV-24942714','2026-08-12 10:55:43'),(124,162,1,'receipt',100.000,100.000,10.0000,'grv',21,NULL,NULL,NULL,1,'Guard Test','Inv TIE-24950513','2026-08-12 10:55:50'),(125,164,1,'receipt',100.000,100.000,10.0000,'grv',22,NULL,NULL,NULL,1,'Guard Test',NULL,'2026-08-12 10:55:50'),(126,166,1,'receipt',100.000,100.000,10.0000,'grv',23,NULL,NULL,NULL,1,'Guard Test',NULL,'2026-08-12 10:55:50'),(127,166,1,'receipt',1.000,101.000,10.0000,'grv',24,NULL,NULL,NULL,1,'Guard Test',NULL,'2026-08-12 10:55:50'),(128,167,1,'receipt',100.000,100.000,12.0000,'grv',25,NULL,NULL,NULL,1,'Guard Test',NULL,'2026-08-12 10:55:50'),(129,169,1,'receipt',100.000,100.000,10.0000,'grv',26,NULL,NULL,NULL,1,'Guard Test',NULL,'2026-08-12 10:55:51'),(130,170,1,'receipt',10.000,10.000,12.0000,'grv',27,NULL,NULL,NULL,1,'Tiaan Smith','Inv 12312313','2026-08-24 12:49:22'),(131,170,1,'sale',-1.000,9.000,12.0000,'invoice',10,76,1,1,1,'Tiaan Smith','PRD00001','2026-08-24 12:50:09'),(132,115,1,'adjustment',10.000,76.000,36.0000,'stock_adjustment',1,1,NULL,NULL,1,'Tiaan Smith','Damaged','2026-08-24 13:08:53'),(133,127,1,'sale',-1.000,53.000,51.0000,'invoice',12,78,3,2,1,'Tiaan Smith','PIZZ005','2026-08-25 19:18:39'),(134,127,1,'sale',-1.000,52.000,51.0000,'invoice',11,79,3,2,1,'Tiaan Smith','PIZZ005','2026-08-25 19:19:45'),(135,112,1,'sale',-1.000,47.000,42.0000,'invoice',19,95,4,3,1,'Tiaan Smith','BURG004','2026-08-26 15:33:03'),(136,141,1,'sale',-1.000,103.000,12.0000,'invoice',20,96,4,3,1,'Tiaan Smith','DRNK005','2026-08-26 15:34:12'),(137,112,1,'sale',-1.000,46.000,42.0000,'invoice',23,107,4,3,1,'Tiaan Smith','BURG004','2026-08-26 15:39:13'),(138,189,1,'adjustment',10.000,10.000,120.0000,'stock_adjustment',2,2,NULL,NULL,1,'Tiaan Smith','Found on the floor','2026-08-26 16:03:10'),(139,192,1,'adjustment',10.000,10.000,600.0000,'stock_adjustment',3,3,NULL,NULL,1,'Tiaan Smith','Found on the floor','2026-08-26 16:19:05'),(140,110,1,'adjustment',-31.000,5.000,38.0000,'stock_take',2,14,NULL,NULL,1,'Tiaan Smith','Counted 5 against 36','2026-08-26 16:47:38'),(141,111,1,'adjustment',8.000,50.000,52.0000,'stock_take',2,15,NULL,NULL,1,'Tiaan Smith','Counted 50 against 42','2026-08-26 16:47:38'),(142,112,1,'adjustment',4.000,50.000,42.0000,'stock_take',2,16,NULL,NULL,1,'Tiaan Smith','Counted 50 against 46','2026-08-26 16:47:38'),(143,113,1,'adjustment',-4.000,50.000,40.0000,'stock_take',2,17,NULL,NULL,1,'Tiaan Smith','Counted 50 against 54','2026-08-26 16:47:38'),(144,114,1,'adjustment',490.000,550.000,39.0000,'stock_take',2,18,NULL,NULL,1,'Tiaan Smith','Counted 550 against 60','2026-08-26 16:47:38'),(145,115,1,'adjustment',-26.000,50.000,36.0000,'stock_take',2,19,NULL,NULL,1,'Tiaan Smith','Counted 50 against 76','2026-08-26 16:47:38'),(146,139,1,'adjustment',-1.000,83.000,8.3000,'stock_adjustment',4,4,NULL,NULL,1,'Tiaan Smith','Damaged','2026-08-26 16:51:23'),(147,140,1,'adjustment',-1.000,95.000,8.3000,'stock_adjustment',4,5,NULL,NULL,1,'Tiaan Smith','Damaged','2026-08-26 16:51:23'),(148,192,1,'adjustment',-1.000,9.000,600.0000,'stock_adjustment',4,6,NULL,NULL,1,'Tiaan Smith','Damaged','2026-08-26 16:51:23'),(149,134,1,'sale',-1.000,47.000,28.0000,'invoice',30,114,5,4,1,'Tiaan Smith','SIDE004','2026-08-31 10:55:39'),(150,136,1,'sale',-1.000,59.000,8.0000,'invoice',30,115,5,4,1,'Tiaan Smith','SIDE006','2026-08-31 10:55:39'),(151,164,1,'sale',-1.000,99.000,10.0000,'invoice',31,116,1,1,1,'Tiaan Smith','GDC24950513','2026-09-01 11:04:57'),(152,165,1,'sale',-1.000,-1.000,10.0000,'invoice',31,117,1,1,1,'Tiaan Smith','GDD24950513','2026-09-01 11:04:57');
/*!40000 ALTER TABLE `stock_movements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stock_notifications`
--

DROP TABLE IF EXISTS `stock_notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `stock_notifications` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `product_id` int(10) unsigned NOT NULL,
  `email` varchar(190) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `notified_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_stocknotify` (`product_id`,`email`),
  KEY `ix_stocknotify_pending` (`notified_at`,`product_id`),
  CONSTRAINT `stock_notifications_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stock_notifications`
--

LOCK TABLES `stock_notifications` WRITE;
/*!40000 ALTER TABLE `stock_notifications` DISABLE KEYS */;
/*!40000 ALTER TABLE `stock_notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stock_take_lines`
--

DROP TABLE IF EXISTS `stock_take_lines`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `stock_take_lines` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `stock_take_id` int(10) unsigned NOT NULL,
  `line_number` int(10) unsigned NOT NULL DEFAULT 1,
  `product_id` int(10) unsigned NOT NULL,
  `product_code` varchar(40) DEFAULT NULL,
  `description` varchar(190) NOT NULL,
  `line_mode` enum('count','topup','recount') NOT NULL DEFAULT 'count',
  `snapshot_qty` decimal(12,3) NOT NULL DEFAULT 0.000,
  `counted_qty` decimal(12,3) DEFAULT NULL,
  `entered_qty` decimal(12,3) DEFAULT NULL,
  `posted_qty_before` decimal(12,3) DEFAULT NULL,
  `variance_qty` decimal(12,3) DEFAULT NULL,
  `unit_cost_excl` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `serial_ids` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`serial_ids`)),
  `counted_at` datetime DEFAULT NULL,
  `counted_by` varchar(120) DEFAULT NULL,
  `approved_by_id` int(10) unsigned DEFAULT NULL,
  `approved_by` varchar(120) DEFAULT NULL,
  `approved_at` datetime DEFAULT NULL,
  `approval_reason_id` int(10) unsigned DEFAULT NULL,
  `approval_note` varchar(190) DEFAULT NULL,
  `note` varchar(190) DEFAULT NULL,
  `movement_id` bigint(20) unsigned DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_take_line_product` (`stock_take_id`,`product_id`),
  KEY `ix_takeline_sheet` (`stock_take_id`,`line_number`),
  KEY `ix_takeline_product` (`product_id`),
  KEY `ix_takeline_approval` (`stock_take_id`,`approved_at`),
  KEY `fk_takeline_approval_reason` (`approval_reason_id`),
  CONSTRAINT `stock_take_lines_ibfk_1` FOREIGN KEY (`approval_reason_id`) REFERENCES `stock_adjustment_reasons` (`id`) ON DELETE SET NULL,
  CONSTRAINT `stock_take_lines_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`),
  CONSTRAINT `stock_take_lines_ibfk_3` FOREIGN KEY (`stock_take_id`) REFERENCES `stock_takes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=75 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stock_take_lines`
--

LOCK TABLES `stock_take_lines` WRITE;
/*!40000 ALTER TABLE `stock_take_lines` DISABLE KEYS */;
INSERT INTO `stock_take_lines` VALUES (1,1,1,7,'SB-101','Classic Smash Burger','count',40.000,NULL,NULL,NULL,NULL,34.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-10 15:58:40','2026-08-10 15:58:40'),(2,1,2,8,'SB-102','Double Smash Cheeseburger','count',40.000,NULL,NULL,NULL,NULL,52.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-10 15:58:40','2026-08-10 15:58:40'),(3,1,3,9,'SB-103','Bacon & Blue Smash','count',39.000,NULL,NULL,NULL,NULL,58.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-10 15:58:40','2026-08-10 15:58:40'),(4,1,4,10,'SB-104','Mushroom Swiss Smash','count',40.000,NULL,NULL,NULL,NULL,55.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-10 15:58:40','2026-08-10 15:58:40'),(5,1,5,11,'SB-105','Jalapeño Fire Smash','count',40.000,NULL,NULL,NULL,NULL,50.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-10 15:58:40','2026-08-10 15:58:40'),(6,1,6,12,'SB-106','Crispy Chicken Deluxe','count',40.000,NULL,NULL,NULL,NULL,47.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-10 15:58:40','2026-08-10 15:58:40'),(7,1,7,13,'SB-107','Buttermilk Chicken Burger','count',40.000,NULL,NULL,NULL,NULL,45.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-10 15:58:40','2026-08-10 15:58:40'),(8,1,8,14,'SB-108','Beyond Veggie Smash','count',40.000,NULL,NULL,NULL,NULL,52.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-10 15:58:40','2026-08-10 15:58:40'),(9,1,9,15,'SB-109','Triple Stack Monster','count',40.000,NULL,NULL,NULL,NULL,74.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-10 15:58:40','2026-08-10 15:58:40'),(10,1,10,16,'SB-110','Truffle & Onion Smash','count',3.000,NULL,NULL,NULL,NULL,63.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-10 15:58:40','2026-08-10 15:58:40'),(11,1,11,17,'SB-111','Kids Mini Smash','count',40.000,NULL,NULL,NULL,NULL,24.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-10 15:58:40','2026-08-10 15:58:40'),(12,1,12,18,'SB-112','BBQ Brisket Smash','count',39.000,NULL,NULL,NULL,NULL,66.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-10 15:58:40','2026-08-10 15:58:40'),(13,2,1,109,'BURG001','Classic Smash','count',30.000,30.000,NULL,30.000,0.000,26.0000,NULL,'2026-08-26 16:46:02','Tiaan Smith',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-26 16:45:40','2026-08-26 16:47:38'),(14,2,2,110,'BURG002','Double Smash','count',36.000,5.000,NULL,36.000,-31.000,38.0000,NULL,'2026-08-26 16:46:04','Tiaan Smith',NULL,NULL,NULL,NULL,NULL,NULL,140,'2026-08-26 16:45:40','2026-08-26 16:47:38'),(15,2,3,111,'BURG003','Triple Smash Stack','count',42.000,50.000,NULL,42.000,8.000,52.0000,NULL,'2026-08-26 16:46:05','Tiaan Smith',NULL,NULL,NULL,NULL,NULL,NULL,141,'2026-08-26 16:45:40','2026-08-26 16:47:38'),(16,2,4,112,'BURG004','Bacon & Cheddar Smash','count',46.000,50.000,NULL,46.000,4.000,42.0000,NULL,'2026-08-26 16:46:06','Tiaan Smith',NULL,NULL,NULL,NULL,NULL,NULL,142,'2026-08-26 16:45:40','2026-08-26 16:47:38'),(17,2,5,113,'BURG005','Mushroom Swiss Smash','count',54.000,50.000,NULL,54.000,-4.000,40.0000,NULL,'2026-08-26 16:46:06','Tiaan Smith',NULL,NULL,NULL,NULL,NULL,NULL,143,'2026-08-26 16:45:40','2026-08-26 16:47:38'),(18,2,6,114,'BURG006','Jalapeno Fire Smash','count',60.000,550.000,NULL,60.000,490.000,39.0000,NULL,'2026-08-26 16:46:07','Tiaan Smith',NULL,NULL,NULL,NULL,NULL,NULL,144,'2026-08-26 16:45:40','2026-08-26 16:47:38'),(19,2,7,115,'BURG007','Buttermilk Chicken Burger','count',76.000,50.000,NULL,76.000,-26.000,36.0000,NULL,'2026-08-26 16:46:32','Tiaan Smith',NULL,NULL,NULL,NULL,NULL,NULL,145,'2026-08-26 16:45:40','2026-08-26 16:47:38'),(20,2,8,116,'BURG008','Beyond Veggie Smash','count',72.000,NULL,NULL,NULL,NULL,44.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-26 16:45:40','2026-08-26 16:45:40'),(21,2,9,117,'DOGS001','New York Dog','count',30.000,NULL,NULL,NULL,NULL,22.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-26 16:45:40','2026-08-26 16:45:40'),(22,2,10,118,'DOGS002','Chilli Cheese Dog','count',36.000,NULL,NULL,NULL,NULL,29.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-26 16:45:40','2026-08-26 16:45:40'),(23,2,11,119,'DOGS003','Boerewors Dog','count',42.000,NULL,NULL,NULL,NULL,31.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-26 16:45:40','2026-08-26 16:45:40'),(24,2,12,120,'DOGS004','Bratwurst & Sauerkraut Dog','count',48.000,NULL,NULL,NULL,NULL,34.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-26 16:45:40','2026-08-26 16:45:40'),(25,2,13,121,'DOGS005','Mac & Cheese Dog','count',54.000,NULL,NULL,NULL,NULL,32.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-26 16:45:40','2026-08-26 16:45:40'),(26,2,14,122,'DOGS006','Corn Dog','count',60.000,NULL,NULL,NULL,NULL,17.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-26 16:45:40','2026-08-26 16:45:40'),(27,2,15,152,'DP24942714','Draft test item 24942714','count',100.000,NULL,NULL,NULL,NULL,10.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-26 16:45:40','2026-08-26 16:45:40'),(28,2,16,137,'DRNK001','Coca-Cola 330ml Can','count',60.000,NULL,NULL,NULL,NULL,8.5000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-26 16:45:40','2026-08-26 16:45:40'),(29,2,17,138,'DRNK002','Coca-Cola Zero 330ml Can','count',72.000,NULL,NULL,NULL,NULL,8.5000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-26 16:45:40','2026-08-26 16:45:40'),(30,2,18,139,'DRNK003','Fanta Orange 330ml Can','count',84.000,NULL,NULL,NULL,NULL,8.3000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-26 16:45:40','2026-08-26 16:45:40'),(31,2,19,140,'DRNK004','Sprite 330ml Can','count',96.000,NULL,NULL,NULL,NULL,8.3000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-26 16:45:40','2026-08-26 16:45:40'),(32,2,20,141,'DRNK005','Appletiser 330ml','count',103.000,NULL,NULL,NULL,NULL,12.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-26 16:45:40','2026-08-26 16:45:40'),(33,2,21,142,'DRNK006','Red Bull 250ml','count',120.000,NULL,NULL,NULL,NULL,19.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-26 16:45:40','2026-08-26 16:45:40'),(34,2,22,143,'DRNK007','Lipton Ice Tea Peach 300ml','count',132.000,NULL,NULL,NULL,NULL,11.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-26 16:45:40','2026-08-26 16:45:40'),(35,2,23,144,'DRNK008','Chocolate Thick Shake','count',72.000,NULL,NULL,NULL,NULL,14.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-26 16:45:40','2026-08-26 16:45:40'),(36,2,24,145,'DSRT001','Warm Chocolate Brownie','count',30.000,NULL,NULL,NULL,NULL,15.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-26 16:45:40','2026-08-26 16:45:40'),(37,2,25,146,'DSRT002','Soft-Serve Cone','count',36.000,NULL,NULL,NULL,NULL,6.5000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-26 16:45:40','2026-08-26 16:45:40'),(38,2,26,147,'DSRT003','Deep-Fried Ice Cream','count',42.000,NULL,NULL,NULL,NULL,21.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-26 16:45:40','2026-08-26 16:45:40'),(39,2,27,148,'DSRT004','Malva Pudding & Custard','count',48.000,NULL,NULL,NULL,NULL,18.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-26 16:45:40','2026-08-26 16:45:40'),(40,2,28,162,'GDA24950513','Guard test A','count',100.000,NULL,NULL,NULL,NULL,10.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-26 16:45:40','2026-08-26 16:45:40'),(41,2,29,163,'GDB24950513','Guard test B','count',0.000,NULL,NULL,NULL,NULL,10.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-26 16:45:40','2026-08-26 16:45:40'),(42,2,30,164,'GDC24950513','Guard test C','count',100.000,NULL,NULL,NULL,NULL,10.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-26 16:45:40','2026-08-26 16:45:40'),(43,2,31,165,'GDD24950513','Guard test D','count',0.000,NULL,NULL,NULL,NULL,10.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-26 16:45:40','2026-08-26 16:45:40'),(44,2,32,166,'GDE24950513','Guard test E','count',101.000,NULL,NULL,NULL,NULL,10.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-26 16:45:40','2026-08-26 16:45:40'),(45,2,33,167,'GDF24950513','Guard test F','count',100.000,NULL,NULL,NULL,NULL,12.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-26 16:45:40','2026-08-26 16:45:40'),(46,2,34,168,'GDG24950513','Guard test G','count',0.000,NULL,NULL,NULL,NULL,10.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-26 16:45:40','2026-08-26 16:45:40'),(47,2,35,169,'GDH24950513','Guard test H','count',100.000,NULL,NULL,NULL,NULL,10.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-26 16:45:40','2026-08-26 16:45:40'),(48,2,36,149,'OP24876588','Order test item 24876588','count',100.000,NULL,NULL,NULL,NULL,10.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-26 16:45:40','2026-08-26 16:45:40'),(49,2,37,123,'PIZZ001','Margherita 30cm','count',30.000,NULL,NULL,NULL,NULL,31.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-26 16:45:40','2026-08-26 16:45:40'),(50,2,38,124,'PIZZ002','Pepperoni 30cm','count',36.000,NULL,NULL,NULL,NULL,40.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-26 16:45:40','2026-08-26 16:45:40'),(51,2,39,125,'PIZZ003','Regina 30cm','count',42.000,NULL,NULL,NULL,NULL,43.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-26 16:45:40','2026-08-26 16:45:40'),(52,2,40,126,'PIZZ004','Four Cheese 30cm','count',48.000,NULL,NULL,NULL,NULL,49.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-26 16:45:40','2026-08-26 16:45:40'),(53,2,41,127,'PIZZ005','BBQ Chicken 30cm','count',52.000,NULL,NULL,NULL,NULL,51.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-26 16:45:40','2026-08-26 16:45:40'),(54,2,42,128,'PIZZ006','Meat Lovers 30cm','count',60.000,NULL,NULL,NULL,NULL,62.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-26 16:45:40','2026-08-26 16:45:40'),(55,2,43,129,'PIZZ007','Vegetariana 30cm','count',66.000,NULL,NULL,NULL,NULL,38.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-26 16:45:40','2026-08-26 16:45:40'),(56,2,44,130,'PIZZ008','Build Your Own 30cm','count',72.000,NULL,NULL,NULL,NULL,22.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-26 16:45:40','2026-08-26 16:45:40'),(57,2,45,170,'PRD00001','Paint Can Test','count',9.000,NULL,NULL,NULL,NULL,12.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-26 16:45:40','2026-08-26 16:45:40'),(58,2,46,184,'PRD00012','Oliver Test × 6','count',0.000,NULL,NULL,NULL,NULL,104.3400,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-26 16:45:40','2026-08-26 16:45:40'),(59,2,47,185,'PRD00013','Oliver Test × 24','count',0.000,NULL,NULL,NULL,NULL,417.3600,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-26 16:45:40','2026-08-26 16:45:40'),(60,2,48,186,'PRD00014','Gift Card','count',0.000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-26 16:45:40','2026-08-26 16:45:40'),(61,2,49,191,'PRD00019','Refer 2 item × 6','count',0.000,NULL,NULL,NULL,NULL,300.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-26 16:45:40','2026-08-26 16:45:40'),(62,2,50,192,'PRD00020','Refer 2 item × 12','count',10.000,NULL,NULL,NULL,NULL,600.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-26 16:45:40','2026-08-26 16:45:40'),(63,2,51,131,'SIDE001','Skin-On Fries (Regular)','count',30.000,NULL,NULL,NULL,NULL,9.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-26 16:45:40','2026-08-26 16:45:40'),(64,2,52,132,'SIDE002','Skin-On Fries (Large)','count',36.000,NULL,NULL,NULL,NULL,13.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-26 16:45:40','2026-08-26 16:45:40'),(65,2,53,133,'SIDE003','Cheese & Bacon Loaded Fries','count',42.000,NULL,NULL,NULL,NULL,24.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-26 16:45:40','2026-08-26 16:45:40'),(66,2,54,134,'SIDE004','Chilli Beef Loaded Fries','count',48.000,NULL,NULL,NULL,NULL,28.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-26 16:45:40','2026-08-26 16:45:40'),(67,2,55,135,'SIDE005','Onion Rings (8)','count',54.000,NULL,NULL,NULL,NULL,14.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-26 16:45:40','2026-08-26 16:45:40'),(68,2,56,136,'SIDE006','Coleslaw Tub','count',60.000,NULL,NULL,NULL,NULL,8.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-26 16:45:40','2026-08-26 16:45:40');
/*!40000 ALTER TABLE `stock_take_lines` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stock_takes`
--

DROP TABLE IF EXISTS `stock_takes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `stock_takes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `document_number` varchar(32) DEFAULT NULL,
  `document_date` date NOT NULL,
  `location_id` int(10) unsigned NOT NULL,
  `status` enum('draft','counting','posted','cancelled') NOT NULL DEFAULT 'draft',
  `scope` enum('full','department','brand','supplier','manual') NOT NULL DEFAULT 'manual',
  `scope_ref_id` int(10) unsigned DEFAULT NULL,
  `is_blind` tinyint(1) NOT NULL DEFAULT 0,
  `programme_id` int(10) unsigned DEFAULT NULL,
  `reference` varchar(60) DEFAULT NULL,
  `note` varchar(400) DEFAULT NULL,
  `frozen_at` datetime DEFAULT NULL,
  `posted_at` datetime DEFAULT NULL,
  `cancelled_at` datetime DEFAULT NULL,
  `cancel_reason` varchar(190) DEFAULT NULL,
  `variance_qty` decimal(14,3) NOT NULL DEFAULT 0.000,
  `variance_value` decimal(14,4) NOT NULL DEFAULT 0.0000,
  `user_id` int(10) unsigned DEFAULT NULL,
  `user_name` varchar(120) NOT NULL DEFAULT '',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_take_number` (`document_number`),
  KEY `ix_take_date` (`document_date`,`id`),
  KEY `ix_take_status` (`status`,`document_date`),
  KEY `ix_take_location` (`location_id`,`status`),
  KEY `ix_take_programme` (`programme_id`),
  CONSTRAINT `stock_takes_ibfk_1` FOREIGN KEY (`location_id`) REFERENCES `stock_locations` (`id`),
  CONSTRAINT `stock_takes_ibfk_2` FOREIGN KEY (`programme_id`) REFERENCES `cycle_count_programmes` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stock_takes`
--

LOCK TABLES `stock_takes` WRITE;
/*!40000 ALTER TABLE `stock_takes` DISABLE KEYS */;
INSERT INTO `stock_takes` VALUES (1,NULL,'2026-08-10',1,'draft','department',11,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.000,0.0000,1,'Tiaan Smith','2026-08-10 15:58:40','2026-08-10 15:58:40'),(2,'STK000001','2026-08-26',1,'posted','full',NULL,0,NULL,NULL,NULL,'2026-08-26 16:47:05','2026-08-26 16:47:38',NULL,NULL,441.000,17420.0000,1,'Tiaan Smith','2026-08-26 16:45:40','2026-08-26 16:47:38');
/*!40000 ALTER TABLE `stock_takes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stock_transfer_lines`
--

DROP TABLE IF EXISTS `stock_transfer_lines`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `stock_transfer_lines` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `transfer_id` int(10) unsigned NOT NULL,
  `line_number` smallint(5) unsigned NOT NULL DEFAULT 1,
  `product_id` int(10) unsigned NOT NULL,
  `job_card_line_id` int(10) unsigned DEFAULT NULL,
  `product_code` varchar(40) DEFAULT NULL,
  `description` varchar(190) NOT NULL,
  `qty` decimal(12,3) NOT NULL,
  `qty_received` decimal(12,3) DEFAULT NULL,
  `unit_cost_excl` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `ix_tline_transfer` (`transfer_id`,`line_number`),
  KEY `ix_tline_product` (`product_id`),
  KEY `ix_stline_job_line` (`job_card_line_id`),
  CONSTRAINT `stock_transfer_lines_ibfk_1` FOREIGN KEY (`job_card_line_id`) REFERENCES `job_card_lines` (`id`) ON DELETE SET NULL,
  CONSTRAINT `stock_transfer_lines_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`),
  CONSTRAINT `stock_transfer_lines_ibfk_3` FOREIGN KEY (`transfer_id`) REFERENCES `stock_transfers` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stock_transfer_lines`
--

LOCK TABLES `stock_transfer_lines` WRITE;
/*!40000 ALTER TABLE `stock_transfer_lines` DISABLE KEYS */;
/*!40000 ALTER TABLE `stock_transfer_lines` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stock_transfers`
--

DROP TABLE IF EXISTS `stock_transfers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `stock_transfers` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `document_number` varchar(32) DEFAULT NULL,
  `document_date` date NOT NULL,
  `direction` enum('internal','out','in') NOT NULL DEFAULT 'internal',
  `peer_site_id` int(10) unsigned DEFAULT NULL,
  `peer_site_name` varchar(190) DEFAULT NULL,
  `peer_transfer_id` int(10) unsigned DEFAULT NULL,
  `peer_document_number` varchar(32) DEFAULT NULL,
  `from_location_id` int(10) unsigned DEFAULT NULL,
  `to_location_id` int(10) unsigned NOT NULL,
  `status` enum('draft','posted','in_transit','received','cancelled') NOT NULL DEFAULT 'draft',
  `reference` varchar(60) DEFAULT NULL,
  `note` varchar(400) DEFAULT NULL,
  `posted_at` datetime DEFAULT NULL,
  `dispatched_at` datetime DEFAULT NULL,
  `received_at` datetime DEFAULT NULL,
  `cancel_reason` varchar(190) DEFAULT NULL,
  `cancelled_at` datetime DEFAULT NULL,
  `user_id` int(10) unsigned DEFAULT NULL,
  `user_name` varchar(120) NOT NULL DEFAULT '',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_transfer_number` (`document_number`),
  KEY `ix_transfer_date` (`document_date`,`id`),
  KEY `ix_transfer_status` (`status`,`document_date`),
  KEY `ix_transfer_from` (`from_location_id`,`document_date`),
  KEY `ix_transfer_to` (`to_location_id`,`document_date`),
  KEY `ix_transfer_peer` (`peer_site_id`,`status`),
  KEY `ix_transfer_direction` (`direction`,`status`,`document_date`),
  CONSTRAINT `stock_transfers_ibfk_1` FOREIGN KEY (`from_location_id`) REFERENCES `stock_locations` (`id`),
  CONSTRAINT `stock_transfers_ibfk_2` FOREIGN KEY (`to_location_id`) REFERENCES `stock_locations` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stock_transfers`
--

LOCK TABLES `stock_transfers` WRITE;
/*!40000 ALTER TABLE `stock_transfers` DISABLE KEYS */;
/*!40000 ALTER TABLE `stock_transfers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `storefront_collection_products`
--

DROP TABLE IF EXISTS `storefront_collection_products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `storefront_collection_products` (
  `collection_id` int(10) unsigned NOT NULL,
  `product_id` int(10) unsigned NOT NULL,
  `sort_order` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`collection_id`,`product_id`),
  KEY `ix_collection_products_order` (`collection_id`,`sort_order`),
  KEY `fk_collection_products_product` (`product_id`),
  CONSTRAINT `storefront_collection_products_ibfk_1` FOREIGN KEY (`collection_id`) REFERENCES `storefront_collections` (`id`) ON DELETE CASCADE,
  CONSTRAINT `storefront_collection_products_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `storefront_collection_products`
--

LOCK TABLES `storefront_collection_products` WRITE;
/*!40000 ALTER TABLE `storefront_collection_products` DISABLE KEYS */;
/*!40000 ALTER TABLE `storefront_collection_products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `storefront_collections`
--

DROP TABLE IF EXISTS `storefront_collections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `storefront_collections` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `slug` varchar(60) NOT NULL,
  `title` varchar(120) NOT NULL DEFAULT '',
  `description` varchar(300) NOT NULL DEFAULT '',
  `image_id` bigint(20) unsigned DEFAULT NULL,
  `is_published` tinyint(1) NOT NULL DEFAULT 0,
  `sort_order` int(11) NOT NULL DEFAULT 0,
  `rule_kind` varchar(16) NOT NULL DEFAULT 'manual',
  `rule_value` varchar(120) NOT NULL DEFAULT '',
  `seo_title` varchar(120) NOT NULL DEFAULT '',
  `seo_description` varchar(300) NOT NULL DEFAULT '',
  `updated_at` datetime DEFAULT NULL,
  `updated_by` varchar(120) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_collection_slug` (`slug`),
  KEY `ix_collection_published` (`is_published`,`sort_order`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `storefront_collections`
--

LOCK TABLES `storefront_collections` WRITE;
/*!40000 ALTER TABLE `storefront_collections` DISABLE KEYS */;
/*!40000 ALTER TABLE `storefront_collections` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `storefront_events`
--

DROP TABLE IF EXISTS `storefront_events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `storefront_events` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `kind` enum('view','add_to_cart','begin_checkout','purchase') NOT NULL,
  `product_id` int(10) unsigned DEFAULT NULL,
  `session_key` char(32) NOT NULL,
  `value_incl` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `ix_event_kind_date` (`kind`,`created_at`),
  KEY `ix_event_session` (`session_key`,`kind`),
  KEY `ix_event_product` (`product_id`,`kind`,`created_at`),
  CONSTRAINT `storefront_events_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `storefront_events`
--

LOCK TABLES `storefront_events` WRITE;
/*!40000 ALTER TABLE `storefront_events` DISABLE KEYS */;
/*!40000 ALTER TABLE `storefront_events` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `storefront_images`
--

DROP TABLE IF EXISTS `storefront_images`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `storefront_images` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `stored_name` varchar(190) NOT NULL,
  `filename` varchar(255) NOT NULL,
  `mime_type` varchar(40) NOT NULL,
  `size_bytes` bigint(20) unsigned NOT NULL DEFAULT 0,
  `alt_text` varchar(190) NOT NULL DEFAULT '',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_sfimg_stored` (`stored_name`),
  KEY `ix_sfimg_created` (`created_at`,`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `storefront_images`
--

LOCK TABLES `storefront_images` WRITE;
/*!40000 ALTER TABLE `storefront_images` DISABLE KEYS */;
INSERT INTO `storefront_images` VALUES (1,'e8f0d073-ccc5-4120-b432-9d8b4826a4e7.jpg','hero.jpg','image/jpeg',296448,'Smash burger and fries on a board','2026-08-09 09:41:06'),(2,'e3467ddd-4bd4-4a0c-ae7e-640667ed354e.jpg','pizza.jpg','image/jpeg',452589,'Wood-fired pizza fresh from the oven','2026-08-09 09:41:06'),(3,'63f2ca22-b153-4be1-bb87-39360369a204.png','ChatGPT Image Aug 9, 2026, 09_53_25 AM.png','image/png',2031090,'','2026-08-09 10:02:23'),(4,'e68949c0-dd60-46cf-b9af-f76f6dceb8a6.png','ChatGPT Image Aug 9, 2026, 11_02_31 AM.png','image/png',2396469,'','2026-08-09 11:28:53'),(5,'a4cabd92-43eb-4a38-8aa6-aab6cdcb3fb0.png','ChatGPT Image Aug 9, 2026, 11_02_35 AM.png','image/png',2396434,'','2026-08-09 11:29:07'),(6,'f2db07ff-d275-49b4-9891-795f2c6f0dcc.png','ChatGPT Image Aug 9, 2026, 11_02_37 AM.png','image/png',2293565,'','2026-08-09 11:29:17'),(7,'f89cd83e-4ed0-4ae0-9f76-09a8a6aecaef.png','ChatGPT Image Aug 9, 2026, 12_47_26 PM (3).png','image/png',2541534,'','2026-08-09 12:49:40'),(8,'b04c2a5e-c701-427c-bb3a-ce353f5b545f.png','ChatGPT Image Aug 9, 2026, 12_47_26 PM (4).png','image/png',2424340,'','2026-08-09 12:49:47'),(9,'f24146eb-9e54-4954-b4e7-e7ffc6cedb2d.png','ChatGPT Image Aug 9, 2026, 12_47_25 PM (1).png','image/png',2433983,'','2026-08-09 12:50:01'),(10,'1eccfc16-4f70-47dd-9640-da29e023d302.png','ChatGPT Image Aug 9, 2026, 12_47_26 PM (2).png','image/png',2376126,'','2026-08-09 12:50:06'),(11,'14c4ada4-20fa-43cf-b74f-5dfb99807cc3.png','ChatGPT Image Aug 9, 2026, 12_45_08 PM (2).png','image/png',2718084,'','2026-08-10 09:28:01'),(12,'36890fa3-4a86-4126-bbdd-8bf67a3195b4.png','ChatGPT Image Aug 10, 2026, 08_05_38 AM (5).png','image/png',2416679,'','2026-08-10 09:28:25');
/*!40000 ALTER TABLE `storefront_images` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `storefront_menu_items`
--

DROP TABLE IF EXISTS `storefront_menu_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `storefront_menu_items` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `menu_id` int(10) unsigned NOT NULL,
  `parent_id` int(10) unsigned DEFAULT NULL,
  `sort_order` int(11) NOT NULL DEFAULT 0,
  `label` varchar(60) NOT NULL DEFAULT '',
  `target_kind` varchar(16) NOT NULL DEFAULT 'url',
  `target_id` int(10) unsigned DEFAULT NULL,
  `target_url` varchar(300) NOT NULL DEFAULT '',
  `image_id` bigint(20) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_menu_items_menu` (`menu_id`,`sort_order`),
  KEY `fk_menu_item_parent` (`parent_id`),
  CONSTRAINT `storefront_menu_items_ibfk_1` FOREIGN KEY (`menu_id`) REFERENCES `storefront_menus` (`id`) ON DELETE CASCADE,
  CONSTRAINT `storefront_menu_items_ibfk_2` FOREIGN KEY (`parent_id`) REFERENCES `storefront_menu_items` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `storefront_menu_items`
--

LOCK TABLES `storefront_menu_items` WRITE;
/*!40000 ALTER TABLE `storefront_menu_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `storefront_menu_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `storefront_menus`
--

DROP TABLE IF EXISTS `storefront_menus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `storefront_menus` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `slug` varchar(24) NOT NULL,
  `title` varchar(60) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_menu_slug` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `storefront_menus`
--

LOCK TABLES `storefront_menus` WRITE;
/*!40000 ALTER TABLE `storefront_menus` DISABLE KEYS */;
/*!40000 ALTER TABLE `storefront_menus` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `storefront_page_versions`
--

DROP TABLE IF EXISTS `storefront_page_versions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `storefront_page_versions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `page_id` int(10) unsigned NOT NULL,
  `layout` text DEFAULT NULL,
  `replaced_at` datetime NOT NULL DEFAULT current_timestamp(),
  `replaced_by` varchar(120) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `ix_version_page` (`page_id`,`replaced_at`),
  CONSTRAINT `storefront_page_versions_ibfk_1` FOREIGN KEY (`page_id`) REFERENCES `storefront_pages` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `storefront_page_versions`
--

LOCK TABLES `storefront_page_versions` WRITE;
/*!40000 ALTER TABLE `storefront_page_versions` DISABLE KEYS */;
/*!40000 ALTER TABLE `storefront_page_versions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `storefront_pages`
--

DROP TABLE IF EXISTS `storefront_pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `storefront_pages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `kind` enum('home','standard','department','product','collection','cart','thankyou') NOT NULL DEFAULT 'standard',
  `slug` varchar(60) DEFAULT NULL,
  `title` varchar(120) NOT NULL DEFAULT '',
  `department_id` int(10) unsigned DEFAULT NULL,
  `layout` text DEFAULT NULL,
  `layout_draft` text DEFAULT NULL,
  `is_published` tinyint(1) NOT NULL DEFAULT 0,
  `show_in_nav` tinyint(1) NOT NULL DEFAULT 0,
  `nav_order` int(11) NOT NULL DEFAULT 0,
  `seo_title` varchar(120) NOT NULL DEFAULT '',
  `seo_description` varchar(300) NOT NULL DEFAULT '',
  `seo_image_id` bigint(20) unsigned DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `publish_at` varchar(16) NOT NULL DEFAULT '',
  `applies_to_children` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'department pages: also render on descendant departments with no page of their own',
  `collection_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_page_slug` (`slug`),
  UNIQUE KEY `uq_page_department` (`kind`,`department_id`),
  UNIQUE KEY `uq_page_collection` (`kind`,`collection_id`),
  KEY `ix_page_nav` (`show_in_nav`,`nav_order`),
  KEY `fk_page_department` (`department_id`),
  KEY `fk_page_seo_image` (`seo_image_id`),
  KEY `ix_page_publish_at` (`publish_at`),
  KEY `fk_page_collection` (`collection_id`),
  CONSTRAINT `storefront_pages_ibfk_1` FOREIGN KEY (`collection_id`) REFERENCES `storefront_collections` (`id`) ON DELETE CASCADE,
  CONSTRAINT `storefront_pages_ibfk_2` FOREIGN KEY (`department_id`) REFERENCES `departments` (`id`) ON DELETE CASCADE,
  CONSTRAINT `storefront_pages_ibfk_3` FOREIGN KEY (`seo_image_id`) REFERENCES `storefront_images` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `storefront_pages`
--

LOCK TABLES `storefront_pages` WRITE;
/*!40000 ALTER TABLE `storefront_pages` DISABLE KEYS */;
INSERT INTO `storefront_pages` VALUES (1,'home','home','Front page',NULL,'[{\"id\":\"s-carousel-1-jakat\",\"kind\":\"carousel\",\"title\":\"\",\"enabled\":true,\"tone\":\"plain\",\"showFrom\":\"\",\"showUntil\":\"\",\"slides\":[{\"id\":\"sl-3-8pzqb\",\"imageId\":9,\"imageAlt\":\"\",\"heading\":\"\",\"bodyText\":\"\",\"buttonLabel\":\"\",\"linkUrl\":\"\"},{\"id\":\"sl-2-gsjkv\",\"imageId\":7,\"imageAlt\":\"\",\"heading\":\"\",\"bodyText\":\"\",\"buttonLabel\":\"\",\"linkUrl\":\"\"},{\"id\":\"sl-1-lzrn5\",\"imageId\":8,\"imageAlt\":\"\",\"heading\":\"\",\"bodyText\":\"\",\"buttonLabel\":\"\",\"linkUrl\":\"\"},{\"id\":\"sl-1-494k5\",\"imageId\":10,\"imageAlt\":\"\",\"heading\":\"\",\"bodyText\":\"\",\"buttonLabel\":\"\",\"linkUrl\":\"\"}],\"autoplaySeconds\":6},{\"id\":\"departments\",\"kind\":\"categories\",\"title\":\"Shop the menu\",\"enabled\":true,\"tone\":\"plain\",\"showFrom\":\"\",\"showUntil\":\"\",\"maxItems\":0},{\"id\":\"popular\",\"kind\":\"products\",\"title\":\"Most popular\",\"enabled\":true,\"tone\":\"plain\",\"showFrom\":\"\",\"showUntil\":\"\",\"source\":\"manual\",\"departmentId\":null,\"productIds\":[7,8,28,15,20,31,38,53],\"maxItems\":8,\"layout\":\"grid\"},{\"id\":\"cards\",\"kind\":\"cards\",\"title\":\"\",\"enabled\":true,\"tone\":\"tinted\",\"showFrom\":\"\",\"showUntil\":\"\",\"cards\":[{\"icon\":\"🔥\",\"heading\":\"Smashed to order\",\"text\":\"Never pre-cooked. Every patty hits the flat-top when you order it.\"},{\"icon\":\"⏱️\",\"heading\":\"Ready in 25 minutes\",\"text\":\"Order online and collect — we start cooking when you check out.\"},{\"icon\":\"🚚\",\"heading\":\"We deliver\",\"text\":\"Delivery across the neighbourhood, free on orders over R350.\"}]},{\"id\":\"banner-pizza\",\"kind\":\"banner\",\"title\":\"Wood-fired, properly\",\"enabled\":true,\"tone\":\"plain\",\"showFrom\":\"\",\"showUntil\":\"\",\"imageId\":2,\"imageAlt\":\"Wood-fired pizza fresh from the oven\",\"linkUrl\":\"/store\",\"bodyText\":\"90 seconds at 400°C. Leopard-spotted crust, San Marzano base.\",\"buttonLabel\":\"See the pizzas\"},{\"id\":\"about\",\"kind\":\"text\",\"title\":\"Why we smash\",\"enabled\":true,\"tone\":\"plain\",\"showFrom\":\"\",\"showUntil\":\"\",\"text\":\"Smashing a loose ball of beef onto a screaming hot flat-top does one thing nothing else can: it forces the whole surface of the patty into contact with the steel, and that is where the crust comes from. More crust, more flavour. It is a 30-second technique that we have spent years getting right.\",\"align\":\"center\"}]','[{\"id\":\"s-richtext-3-x2rjx\",\"kind\":\"richtext\",\"title\":\"\",\"enabled\":true,\"tone\":\"plain\",\"showFrom\":\"\",\"showUntil\":\"\",\"blocks\":[{\"type\":\"p\",\"spans\":[{\"text\":\"\",\"bold\":false,\"italic\":false,\"href\":\"\"}]}]},{\"id\":\"s-carousel-1-jakat\",\"kind\":\"carousel\",\"title\":\"\",\"enabled\":true,\"tone\":\"plain\",\"showFrom\":\"\",\"showUntil\":\"\",\"slides\":[{\"id\":\"sl-3-8pzqb\",\"imageId\":9,\"imageAlt\":\"\",\"heading\":\"\",\"bodyText\":\"\",\"buttonLabel\":\"\",\"linkUrl\":\"\"},{\"id\":\"sl-2-gsjkv\",\"imageId\":7,\"imageAlt\":\"\",\"heading\":\"\",\"bodyText\":\"\",\"buttonLabel\":\"\",\"linkUrl\":\"\"},{\"id\":\"sl-1-lzrn5\",\"imageId\":8,\"imageAlt\":\"\",\"heading\":\"\",\"bodyText\":\"\",\"buttonLabel\":\"\",\"linkUrl\":\"\"},{\"id\":\"sl-1-494k5\",\"imageId\":10,\"imageAlt\":\"\",\"heading\":\"\",\"bodyText\":\"\",\"buttonLabel\":\"\",\"linkUrl\":\"\"}],\"autoplaySeconds\":6},{\"id\":\"departments\",\"kind\":\"categories\",\"title\":\"Shop the menu\",\"enabled\":true,\"tone\":\"plain\",\"showFrom\":\"\",\"showUntil\":\"\",\"maxItems\":0},{\"id\":\"popular\",\"kind\":\"products\",\"title\":\"Most popular\",\"enabled\":true,\"tone\":\"plain\",\"showFrom\":\"\",\"showUntil\":\"\",\"source\":\"manual\",\"departmentId\":null,\"productIds\":[7,8,28,15,20,31,38,53],\"maxItems\":8,\"layout\":\"grid\"},{\"id\":\"cards\",\"kind\":\"cards\",\"title\":\"\",\"enabled\":true,\"tone\":\"tinted\",\"showFrom\":\"\",\"showUntil\":\"\",\"cards\":[{\"icon\":\"🔥\",\"heading\":\"Smashed to order\",\"text\":\"Never pre-cooked. Every patty hits the flat-top when you order it.\"},{\"icon\":\"⏱️\",\"heading\":\"Ready in 25 minutes\",\"text\":\"Order online and collect — we start cooking when you check out.\"},{\"icon\":\"🚚\",\"heading\":\"We deliver\",\"text\":\"Delivery across the neighbourhood, free on orders over R350.\"}]},{\"id\":\"banner-pizza\",\"kind\":\"banner\",\"title\":\"Wood-fired, properly\",\"enabled\":true,\"tone\":\"plain\",\"showFrom\":\"\",\"showUntil\":\"\",\"imageId\":2,\"imageAlt\":\"Wood-fired pizza fresh from the oven\",\"linkUrl\":\"/store\",\"bodyText\":\"90 seconds at 400°C. Leopard-spotted crust, San Marzano base.\",\"buttonLabel\":\"See the pizzas\"},{\"id\":\"about\",\"kind\":\"text\",\"title\":\"Why we smash\",\"enabled\":true,\"tone\":\"plain\",\"showFrom\":\"\",\"showUntil\":\"\",\"text\":\"Smashing a loose ball of beef onto a screaming hot flat-top does one thing nothing else can: it forces the whole surface of the patty into contact with the steel, and that is where the crust comes from. More crust, more flavour. It is a 30-second technique that we have spent years getting right.\",\"align\":\"center\"},{\"id\":\"s-richtext-1-27w6r\",\"kind\":\"richtext\",\"title\":\"\",\"enabled\":true,\"tone\":\"plain\",\"showFrom\":\"\",\"showUntil\":\"\",\"blocks\":[{\"type\":\"p\",\"spans\":[{\"text\":\"\",\"bold\":false,\"italic\":false,\"href\":\"\"}]}]},{\"id\":\"s-cards-1-n1q8d\",\"kind\":\"cards\",\"title\":\"\",\"enabled\":true,\"tone\":\"plain\",\"showFrom\":\"\",\"showUntil\":\"\",\"cards\":[{\"icon\":\"🚚\",\"heading\":\"Delivery\",\"text\":\"\"}]},{\"id\":\"s-text-2-9f0af\",\"kind\":\"text\",\"title\":\"\",\"enabled\":true,\"tone\":\"plain\",\"showFrom\":\"\",\"showUntil\":\"\",\"text\":\"\",\"align\":\"left\"}]',1,0,0,'','',NULL,'2026-08-10 10:11:24','2026-08-10 20:17:24','',0,NULL),(2,'product',NULL,'Tiaan test',NULL,'[{\"id\":\"s-richtext-1-3tprx\",\"kind\":\"richtext\",\"title\":\"test\",\"enabled\":true,\"tone\":\"plain\",\"showFrom\":\"\",\"showUntil\":\"\",\"blocks\":[{\"type\":\"h3\",\"spans\":[{\"text\":\"Welcome to Tiaans test page!\",\"bold\":false,\"italic\":false,\"href\":\"\"}]}]}]',NULL,0,0,0,'','',NULL,'2026-08-10 13:14:08','2026-08-10 18:45:12','',0,NULL);
/*!40000 ALTER TABLE `storefront_pages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `storefront_saved_sections`
--

DROP TABLE IF EXISTS `storefront_saved_sections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `storefront_saved_sections` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(80) NOT NULL,
  `kind` varchar(20) NOT NULL DEFAULT '',
  `section` text NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_saved_name` (`name`),
  KEY `ix_saved_kind` (`kind`,`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `storefront_saved_sections`
--

LOCK TABLES `storefront_saved_sections` WRITE;
/*!40000 ALTER TABLE `storefront_saved_sections` DISABLE KEYS */;
/*!40000 ALTER TABLE `storefront_saved_sections` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `storefront_subscribers`
--

DROP TABLE IF EXISTS `storefront_subscribers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `storefront_subscribers` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `email` varchar(190) NOT NULL,
  `name` varchar(120) NOT NULL DEFAULT '',
  `consented_at` datetime NOT NULL DEFAULT current_timestamp(),
  `consent_text` varchar(300) NOT NULL DEFAULT '',
  `source_page` varchar(60) NOT NULL DEFAULT '',
  `unsubscribed_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_subscriber_email` (`email`),
  KEY `ix_subscriber_live` (`unsubscribed_at`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `storefront_subscribers`
--

LOCK TABLES `storefront_subscribers` WRITE;
/*!40000 ALTER TABLE `storefront_subscribers` DISABLE KEYS */;
/*!40000 ALTER TABLE `storefront_subscribers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `supplier_allocations`
--

DROP TABLE IF EXISTS `supplier_allocations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `supplier_allocations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `debit_txn_id` int(10) unsigned NOT NULL,
  `credit_txn_id` int(10) unsigned NOT NULL,
  `amount` decimal(12,4) NOT NULL,
  `allocated_at` datetime NOT NULL DEFAULT current_timestamp(),
  `user_id` int(10) unsigned DEFAULT NULL,
  `user_name` varchar(120) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_salloc_pair` (`debit_txn_id`,`credit_txn_id`),
  KEY `ix_salloc_credit` (`credit_txn_id`),
  KEY `ix_salloc_when` (`allocated_at`),
  CONSTRAINT `supplier_allocations_ibfk_1` FOREIGN KEY (`credit_txn_id`) REFERENCES `supplier_transactions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `supplier_allocations_ibfk_2` FOREIGN KEY (`debit_txn_id`) REFERENCES `supplier_transactions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `supplier_allocations`
--

LOCK TABLES `supplier_allocations` WRITE;
/*!40000 ALTER TABLE `supplier_allocations` DISABLE KEYS */;
/*!40000 ALTER TABLE `supplier_allocations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `supplier_comments`
--

DROP TABLE IF EXISTS `supplier_comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `supplier_comments` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `entity` varchar(40) NOT NULL DEFAULT 'supplier',
  `entity_id` int(10) unsigned NOT NULL,
  `body` text NOT NULL,
  `is_pinned` tinyint(1) NOT NULL DEFAULT 0,
  `author_id` int(10) unsigned DEFAULT NULL,
  `author_name` varchar(120) NOT NULL DEFAULT '',
  `is_edited` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `ix_scomment_entity` (`entity`,`entity_id`,`is_pinned`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `supplier_comments`
--

LOCK TABLES `supplier_comments` WRITE;
/*!40000 ALTER TABLE `supplier_comments` DISABLE KEYS */;
/*!40000 ALTER TABLE `supplier_comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `supplier_contacts`
--

DROP TABLE IF EXISTS `supplier_contacts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `supplier_contacts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `supplier_id` int(10) unsigned NOT NULL,
  `name` varchar(120) NOT NULL,
  `role` varchar(60) DEFAULT NULL,
  `email` varchar(190) DEFAULT NULL,
  `phone` varchar(40) DEFAULT NULL,
  `notes` varchar(400) DEFAULT NULL,
  `is_primary` tinyint(1) NOT NULL DEFAULT 0,
  `sort_order` int(11) NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `ix_scontact_supplier` (`supplier_id`,`sort_order`,`id`),
  KEY `ix_scontact_email` (`email`),
  KEY `ix_scontact_phone` (`phone`),
  CONSTRAINT `supplier_contacts_ibfk_1` FOREIGN KEY (`supplier_id`) REFERENCES `suppliers` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `supplier_contacts`
--

LOCK TABLES `supplier_contacts` WRITE;
/*!40000 ALTER TABLE `supplier_contacts` DISABLE KEYS */;
/*!40000 ALTER TABLE `supplier_contacts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `supplier_documents`
--

DROP TABLE IF EXISTS `supplier_documents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `supplier_documents` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `entity` varchar(40) NOT NULL DEFAULT 'supplier',
  `entity_id` int(10) unsigned NOT NULL,
  `filename` varchar(255) NOT NULL,
  `stored_name` varchar(190) NOT NULL,
  `mime_type` varchar(120) DEFAULT NULL,
  `size_bytes` bigint(20) unsigned NOT NULL DEFAULT 0,
  `description` varchar(400) DEFAULT NULL,
  `uploaded_by` int(10) unsigned DEFAULT NULL,
  `uploaded_name` varchar(120) NOT NULL DEFAULT '',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_sdoc_stored` (`stored_name`),
  KEY `ix_sdoc_entity` (`entity`,`entity_id`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `supplier_documents`
--

LOCK TABLES `supplier_documents` WRITE;
/*!40000 ALTER TABLE `supplier_documents` DISABLE KEYS */;
/*!40000 ALTER TABLE `supplier_documents` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `supplier_payment_allocations`
--

DROP TABLE IF EXISTS `supplier_payment_allocations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `supplier_payment_allocations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `item_id` int(10) unsigned NOT NULL,
  `txn_id` int(10) unsigned NOT NULL,
  `doc_number` varchar(32) DEFAULT NULL,
  `doc_date` date DEFAULT NULL,
  `doc_amount` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `amount` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `discount_amount` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_palloc_item_txn` (`item_id`,`txn_id`),
  KEY `ix_palloc_txn` (`txn_id`),
  CONSTRAINT `supplier_payment_allocations_ibfk_1` FOREIGN KEY (`item_id`) REFERENCES `supplier_payment_items` (`id`) ON DELETE CASCADE,
  CONSTRAINT `supplier_payment_allocations_ibfk_2` FOREIGN KEY (`txn_id`) REFERENCES `supplier_transactions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `supplier_payment_allocations`
--

LOCK TABLES `supplier_payment_allocations` WRITE;
/*!40000 ALTER TABLE `supplier_payment_allocations` DISABLE KEYS */;
/*!40000 ALTER TABLE `supplier_payment_allocations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `supplier_payment_items`
--

DROP TABLE IF EXISTS `supplier_payment_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `supplier_payment_items` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `run_id` int(10) unsigned NOT NULL,
  `supplier_id` int(10) unsigned NOT NULL,
  `supplier_code` varchar(32) NOT NULL,
  `supplier_name` varchar(160) NOT NULL,
  `email` varchar(190) DEFAULT NULL,
  `amount` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `discount_amount` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `transaction_id` int(10) unsigned DEFAULT NULL,
  `discount_txn_id` int(10) unsigned DEFAULT NULL,
  `remittance_status` enum('none','queued','sent','failed') NOT NULL DEFAULT 'none',
  `remittance_error` varchar(400) DEFAULT NULL,
  `remittance_sent_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_pitem_run_supplier` (`run_id`,`supplier_id`),
  KEY `ix_pitem_supplier` (`supplier_id`),
  KEY `fk_spitem_disc` (`discount_txn_id`),
  CONSTRAINT `supplier_payment_items_ibfk_1` FOREIGN KEY (`run_id`) REFERENCES `supplier_payment_runs` (`id`) ON DELETE CASCADE,
  CONSTRAINT `supplier_payment_items_ibfk_2` FOREIGN KEY (`supplier_id`) REFERENCES `suppliers` (`id`),
  CONSTRAINT `supplier_payment_items_ibfk_3` FOREIGN KEY (`discount_txn_id`) REFERENCES `supplier_transactions` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `supplier_payment_items`
--

LOCK TABLES `supplier_payment_items` WRITE;
/*!40000 ALTER TABLE `supplier_payment_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `supplier_payment_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `supplier_payment_runs`
--

DROP TABLE IF EXISTS `supplier_payment_runs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `supplier_payment_runs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `payment_date` date NOT NULL,
  `reference` varchar(60) DEFAULT NULL,
  `status` enum('draft','posted','cancelled') NOT NULL DEFAULT 'draft',
  `total_amount` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `supplier_count` int(10) unsigned NOT NULL DEFAULT 0,
  `user_id` int(10) unsigned DEFAULT NULL,
  `user_name` varchar(120) NOT NULL DEFAULT '',
  `origin_site_id` int(10) unsigned DEFAULT NULL,
  `posted_at` datetime DEFAULT NULL,
  `notes` varchar(400) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `ix_prun_status` (`status`,`payment_date`),
  KEY `ix_prun_date` (`payment_date`),
  KEY `ix_sprun_origin` (`origin_site_id`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `supplier_payment_runs`
--

LOCK TABLES `supplier_payment_runs` WRITE;
/*!40000 ALTER TABLE `supplier_payment_runs` DISABLE KEYS */;
/*!40000 ALTER TABLE `supplier_payment_runs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `supplier_prices`
--

DROP TABLE IF EXISTS `supplier_prices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `supplier_prices` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `supplier_id` int(10) unsigned NOT NULL,
  `product_id` int(10) unsigned NOT NULL,
  `effective_from` date NOT NULL,
  `cost_excl` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `pack_size` decimal(12,3) NOT NULL DEFAULT 1.000,
  `list_reference` varchar(60) DEFAULT NULL,
  `note` varchar(190) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_supplier_price` (`supplier_id`,`product_id`,`effective_from`),
  KEY `ix_sprice_product` (`product_id`,`effective_from`),
  CONSTRAINT `supplier_prices_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `supplier_prices`
--

LOCK TABLES `supplier_prices` WRITE;
/*!40000 ALTER TABLE `supplier_prices` DISABLE KEYS */;
/*!40000 ALTER TABLE `supplier_prices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `supplier_transactions`
--

DROP TABLE IF EXISTS `supplier_transactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `supplier_transactions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `supplier_id` int(10) unsigned NOT NULL,
  `doc_type` enum('invoice','credit_note','payment','journal','opening','interest') NOT NULL,
  `doc_number` varchar(32) DEFAULT NULL,
  `doc_date` date NOT NULL,
  `due_date` date DEFAULT NULL,
  `reference` varchar(60) DEFAULT NULL,
  `description` varchar(190) DEFAULT NULL,
  `amount_gross` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `amount_vat` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `amount_net` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `amount_signed` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `amount_outstanding` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `source` varchar(24) NOT NULL DEFAULT 'manual',
  `source_doc_id` int(10) unsigned DEFAULT NULL,
  `origin_site_id` int(10) unsigned DEFAULT NULL,
  `reverses_id` int(10) unsigned DEFAULT NULL,
  `user_id` int(10) unsigned DEFAULT NULL,
  `user_name` varchar(120) NOT NULL DEFAULT '',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `ix_stxn_supplier_date` (`supplier_id`,`doc_date`,`id`),
  KEY `ix_stxn_outstanding` (`supplier_id`,`due_date`,`amount_outstanding`),
  KEY `ix_stxn_doc` (`doc_type`,`doc_number`),
  KEY `ix_stxn_date` (`doc_date`),
  KEY `ix_stxn_source` (`source`,`source_doc_id`),
  KEY `fk_stxn_reverses` (`reverses_id`),
  KEY `ix_stxn_origin_source` (`origin_site_id`,`source`,`source_doc_id`),
  CONSTRAINT `supplier_transactions_ibfk_1` FOREIGN KEY (`reverses_id`) REFERENCES `supplier_transactions` (`id`) ON DELETE SET NULL,
  CONSTRAINT `supplier_transactions_ibfk_2` FOREIGN KEY (`supplier_id`) REFERENCES `suppliers` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `supplier_transactions`
--

LOCK TABLES `supplier_transactions` WRITE;
/*!40000 ALTER TABLE `supplier_transactions` DISABLE KEYS */;
INSERT INTO `supplier_transactions` VALUES (1,4,'invoice','INV-24876588','2026-08-12','2026-09-11','GRV000001','Goods received GRV000001',460.0000,60.0000,400.0000,460.0000,460.0000,'purchase',3,NULL,NULL,1,'Order Test','2026-08-12 10:54:36','2026-08-12 10:54:36'),(2,4,'invoice','GRV000002','2026-08-12','2026-09-11','GRV000002','Goods received GRV000002',690.0000,90.0000,600.0000,690.0000,690.0000,'purchase',4,NULL,NULL,1,'Order Test','2026-08-12 10:54:37','2026-08-12 10:54:37'),(13,7,'invoice','INV-24942714','2026-08-12','2026-09-11','GRV000011','Goods received GRV000011',1150.0000,150.0000,1000.0000,1150.0000,1150.0000,'purchase',14,NULL,NULL,1,'Draft Test','2026-08-12 10:55:43','2026-08-12 10:55:43'),(14,8,'invoice','GRV000012','2026-08-12','2026-09-11','GRV000012','Goods received GRV000012',345.0000,45.0000,300.0000,345.0000,345.0000,'purchase',20,NULL,NULL,1,'Reorder Test','2026-08-12 10:55:49','2026-08-12 10:55:49'),(15,9,'invoice','TIE-24950513','2026-08-12','2026-09-11','GRV000013','Goods received GRV000013',1150.0000,150.0000,1000.0000,1150.0000,1150.0000,'purchase',21,NULL,NULL,1,'Guard Test','2026-08-12 10:55:50','2026-08-12 10:55:50'),(16,9,'invoice','GRV000014','2026-08-12','2026-09-11','GRV000014','Goods received GRV000014',1150.0000,150.0000,1000.0000,1150.0000,1150.0000,'purchase',22,NULL,NULL,1,'Guard Test','2026-08-12 10:55:50','2026-08-12 10:55:50'),(17,9,'invoice','GRV000015','2026-08-12','2026-09-11','GRV000015','Goods received GRV000015',1150.0000,150.0000,1000.0000,1150.0000,1150.0000,'purchase',23,NULL,NULL,1,'Guard Test','2026-08-12 10:55:50','2026-08-12 10:55:50'),(18,9,'invoice','GRV000016','2026-08-12','2026-09-11','GRV000016','Goods received GRV000016',11.5000,1.5000,10.0000,11.5000,11.5000,'purchase',24,NULL,NULL,1,'Guard Test','2026-08-12 10:55:50','2026-08-12 10:55:50'),(19,9,'invoice','GRV000017','2026-08-12','2026-09-11','GRV000017','Goods received GRV000017',1150.0000,150.0000,1000.0000,1150.0000,1150.0000,'purchase',25,NULL,NULL,1,'Guard Test','2026-08-12 10:55:50','2026-08-12 10:55:50'),(20,10,'invoice','GRV000017-F10','2026-08-12','2026-09-11','GRV000017','Courier on GRV000017',230.0000,30.0000,200.0000,230.0000,230.0000,'purchase',25,NULL,NULL,1,'Guard Test','2026-08-12 10:55:50','2026-08-12 10:55:50'),(21,9,'invoice','GRV000018','2026-08-12','2026-09-11','GRV000018','Goods received GRV000018',1150.0000,150.0000,1000.0000,1150.0000,1150.0000,'purchase',26,NULL,NULL,1,'Guard Test','2026-08-12 10:55:51','2026-08-12 10:55:51'),(22,7,'invoice','12312313','2026-08-24','2026-09-23','GRV000019','Goods received GRV000019',138.0000,18.0000,120.0000,138.0000,138.0000,'purchase',27,1,NULL,1,'Tiaan Smith','2026-08-24 12:49:22','2026-08-24 12:49:22');
/*!40000 ALTER TABLE `supplier_transactions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `suppliers`
--

DROP TABLE IF EXISTS `suppliers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `suppliers` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(32) NOT NULL,
  `name` varchar(160) NOT NULL,
  `status` enum('active','on_hold','inactive','closed') NOT NULL DEFAULT 'active',
  `status_reason` varchar(190) DEFAULT NULL,
  `contact_name` varchar(120) DEFAULT NULL,
  `email` varchar(190) DEFAULT NULL,
  `phone` varchar(40) DEFAULT NULL,
  `address_line1` varchar(190) DEFAULT NULL,
  `address_line2` varchar(190) DEFAULT NULL,
  `city` varchar(120) DEFAULT NULL,
  `postal_code` varchar(20) DEFAULT NULL,
  `vat_number` varchar(40) DEFAULT NULL,
  `account_number` varchar(60) DEFAULT NULL,
  `payment_terms_days` smallint(5) unsigned NOT NULL DEFAULT 30,
  `settlement_discount_days` smallint(5) unsigned NOT NULL DEFAULT 0,
  `settlement_discount_pct` decimal(6,4) NOT NULL DEFAULT 0.0000,
  `lead_time_days` smallint(5) unsigned NOT NULL DEFAULT 0,
  `minimum_order` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `bank_name` varchar(120) DEFAULT NULL,
  `bank_branch` varchar(60) DEFAULT NULL,
  `bank_account` varchar(60) DEFAULT NULL,
  `category` varchar(60) DEFAULT NULL,
  `balance` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `notes` text DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_supplier_code` (`code`),
  KEY `ix_supplier_name` (`name`),
  KEY `ix_supplier_status` (`status`,`name`),
  KEY `ix_supplier_category` (`category`),
  KEY `ix_supplier_balance` (`balance`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `suppliers`
--

LOCK TABLES `suppliers` WRITE;
/*!40000 ALTER TABLE `suppliers` DISABLE KEYS */;
INSERT INTO `suppliers` VALUES (1,'SUPP00001','Smash burger patties','active',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,30,0,0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,'2026-08-10 15:54:02','2026-08-10 15:54:02'),(4,'ORD24876588','Order Test Suppliers','active',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,30,0,0.0000,7,0.0000,NULL,NULL,NULL,NULL,1150.0000,NULL,'2026-08-12 10:54:36','2026-08-12 10:54:37'),(7,'DFT24942714','Draft Test Wholesalers','active',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,30,0,0.0000,0,0.0000,NULL,NULL,NULL,NULL,1288.0000,NULL,'2026-08-12 10:55:42','2026-08-24 12:49:22'),(8,'RO24949459','Reorder Test Supply','active',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,30,0,0.0000,7,500.0000,NULL,NULL,NULL,NULL,345.0000,NULL,'2026-08-12 10:55:49','2026-08-12 10:55:49'),(9,'GRD24950513','Guard Test Supply','active',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,30,0,0.0000,0,0.0000,NULL,NULL,NULL,NULL,5761.5000,NULL,'2026-08-12 10:55:50','2026-08-12 10:55:51'),(10,'GRC24950513','Guard Test Couriers','active',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,30,0,0.0000,0,0.0000,NULL,NULL,NULL,NULL,230.0000,NULL,'2026-08-12 10:55:50','2026-08-12 10:55:50');
/*!40000 ALTER TABLE `suppliers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tender_integrations`
--

DROP TABLE IF EXISTS `tender_integrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tender_integrations` (
  `integration_key` varchar(40) NOT NULL,
  `provider` varchar(40) NOT NULL,
  `display_name` varchar(80) NOT NULL,
  `config` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`config`)),
  `secrets_enc` longtext DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`integration_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tender_integrations`
--

LOCK TABLES `tender_integrations` WRITE;
/*!40000 ALTER TABLE `tender_integrations` DISABLE KEYS */;
/*!40000 ALTER TABLE `tender_integrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tender_types`
--

DROP TABLE IF EXISTS `tender_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tender_types` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(24) NOT NULL,
  `name` varchar(60) NOT NULL,
  `posts_to_debtor` tinyint(1) NOT NULL DEFAULT 0,
  `requires_customer` tinyint(1) NOT NULL DEFAULT 0,
  `counts_as_drawer_cash` tinyint(1) NOT NULL DEFAULT 0,
  `opens_cash_drawer` tinyint(1) NOT NULL DEFAULT 0,
  `allows_change` tinyint(1) NOT NULL DEFAULT 0,
  `allows_split` tinyint(1) NOT NULL DEFAULT 1,
  `allows_refund` tinyint(1) NOT NULL DEFAULT 1,
  `tip_on_over_tender` tinyint(1) NOT NULL DEFAULT 0,
  `tip_in_drawer` tinyint(1) NOT NULL DEFAULT 1,
  `requires_reference` tinyint(1) NOT NULL DEFAULT 0,
  `reference_label` varchar(40) DEFAULT NULL,
  `asks_custom_comments` tinyint(1) NOT NULL DEFAULT 0,
  `rounds_to_cash_denomination` tinyint(1) NOT NULL DEFAULT 0,
  `min_amount` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `max_amount` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `surcharge_pct` decimal(6,3) NOT NULL DEFAULT 0.000,
  `integration_key` varchar(40) DEFAULT NULL,
  `icon` varchar(40) DEFAULT NULL,
  `color` varchar(20) DEFAULT NULL,
  `position` int(11) NOT NULL DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `is_system` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_tender_code` (`code`),
  KEY `ix_tender_active` (`is_active`,`position`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tender_types`
--

LOCK TABLES `tender_types` WRITE;
/*!40000 ALTER TABLE `tender_types` DISABLE KEYS */;
INSERT INTO `tender_types` VALUES (1,'CASH','Cash',0,0,1,1,1,1,1,0,1,0,NULL,0,1,0.0000,0.0000,0.000,NULL,'Banknote','tile-2',1,1,1,'2026-08-05 13:07:59','2026-08-05 13:07:59'),(2,'CARD','Card',0,0,0,1,0,1,1,0,0,0,NULL,0,0,0.0000,0.0000,0.000,NULL,'CreditCard','tile-1',2,1,1,'2026-08-05 13:07:59','2026-08-10 14:27:08'),(3,'ACCOUNT','Account',1,1,0,0,0,1,1,0,0,0,NULL,0,0,0.0000,0.0000,0.000,NULL,'Users','tile-4',3,1,1,'2026-08-05 13:07:59','2026-08-10 14:27:50'),(4,'EFT','Direct deposit',0,0,0,0,0,1,0,0,0,1,'Deposit reference',0,0,0.0000,0.0000,0.000,NULL,'Building2','tile-5',4,1,1,'2026-08-05 13:07:59','2026-08-10 14:27:08'),(5,'ONLINE','Online payment',0,0,0,0,0,1,1,0,0,0,'Payment reference',0,0,0.0000,0.0000,0.000,NULL,NULL,NULL,8,1,1,'2026-08-06 19:48:38','2026-08-26 15:36:34'),(6,'LOYALTY_POINTS','Loyalty points',0,1,0,0,0,1,1,0,0,0,NULL,0,0,0.0000,0.0000,0.000,'loyalty','gem',NULL,5,0,0,'2026-08-07 05:41:55','2026-08-26 15:36:34'),(7,'LOYALTY_WALLET','Loyalty wallet',0,1,0,0,0,1,1,0,0,0,NULL,0,0,0.0000,0.0000,0.000,'loyalty','wallet',NULL,7,0,0,'2026-08-07 05:41:55','2026-08-26 15:36:34'),(8,'EXCHANGE','Exchange credit',0,0,0,0,0,1,1,0,1,1,'Credit note number',0,0,0.0000,0.0000,0.000,NULL,NULL,NULL,9,1,1,'2026-08-24 09:10:35','2026-08-26 15:36:34'),(9,'GIFT_CARD','Gift card',0,0,0,0,0,1,1,0,1,1,'Card number',0,0,0.0000,0.0000,0.000,'gift_card','gift','#0400ff',6,1,1,'2026-08-24 09:10:35','2026-08-26 15:38:26'),(10,'DEPOSIT','Deposit paid',0,0,0,0,0,1,1,0,1,0,NULL,0,0,0.0000,0.0000,0.000,NULL,NULL,NULL,10,1,1,'2026-08-24 09:10:36','2026-08-26 15:36:34');
/*!40000 ALTER TABLE `tender_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `terminal_kitchen_printers`
--

DROP TABLE IF EXISTS `terminal_kitchen_printers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `terminal_kitchen_printers` (
  `terminal_id` int(10) unsigned NOT NULL,
  `printer_id` int(10) unsigned NOT NULL,
  `bridge_printer` varchar(190) NOT NULL,
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`terminal_id`,`printer_id`),
  KEY `ix_tkp_printer` (`printer_id`),
  CONSTRAINT `terminal_kitchen_printers_ibfk_1` FOREIGN KEY (`printer_id`) REFERENCES `kitchen_printers` (`id`) ON DELETE CASCADE,
  CONSTRAINT `terminal_kitchen_printers_ibfk_2` FOREIGN KEY (`terminal_id`) REFERENCES `terminals` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `terminal_kitchen_printers`
--

LOCK TABLES `terminal_kitchen_printers` WRITE;
/*!40000 ALTER TABLE `terminal_kitchen_printers` DISABLE KEYS */;
/*!40000 ALTER TABLE `terminal_kitchen_printers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `terminals`
--

DROP TABLE IF EXISTS `terminals`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `terminals` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(24) NOT NULL,
  `till_number` varchar(4) DEFAULT NULL,
  `name` varchar(60) NOT NULL,
  `location` varchar(60) DEFAULT NULL,
  `pos_mode` enum('retail','hospitality','invoicing') NOT NULL DEFAULT 'retail',
  `stock_location_id` int(10) unsigned DEFAULT NULL,
  `device_id` varchar(64) DEFAULT NULL,
  `device_label` varchar(120) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `claimed_at` datetime DEFAULT NULL,
  `last_seen_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_terminal_code` (`code`),
  UNIQUE KEY `uq_terminal_device` (`device_id`),
  UNIQUE KEY `uq_terminal_till_number` (`till_number`),
  KEY `ix_terminal_stock_location` (`stock_location_id`),
  CONSTRAINT `terminals_ibfk_1` FOREIGN KEY (`stock_location_id`) REFERENCES `stock_locations` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `terminals`
--

LOCK TABLES `terminals` WRITE;
/*!40000 ALTER TABLE `terminals` DISABLE KEYS */;
INSERT INTO `terminals` VALUES (1,'TILL01','01','Chrome on Windows',NULL,'retail',NULL,'4009a9b6-79b3-4dea-87ca-b9018f480e58','Chrome on Windows',1,'2026-08-24 11:04:47','2026-09-01 11:04:57','2026-08-24 11:04:47','2026-09-01 11:04:57'),(2,'TILL02','02','Front house',NULL,'retail',NULL,'9f6239e5-e646-42bd-a8a6-ad0f38a6dc29','Chrome on Windows',1,'2026-08-24 14:57:21','2026-08-24 14:57:21','2026-08-24 14:57:06','2026-08-24 14:57:21'),(3,'TILL03','03','Till 3',NULL,'retail',NULL,'199efe4d-bb1c-406d-8e84-b5f24b3afabe','Chrome on Windows',1,'2026-08-25 19:12:07','2026-08-25 19:19:45','2026-08-25 19:12:07','2026-08-25 19:19:45'),(4,'TILL04','04','Till 4',NULL,'retail',NULL,'486ceed7-811f-4b97-aeed-56dbe9841dcb','Chrome on Windows',1,'2026-08-26 15:07:58','2026-08-26 16:22:38','2026-08-26 15:07:58','2026-08-26 16:22:38'),(5,'TILL05','05','Till 5',NULL,'retail',NULL,'c4b2043f-19ae-47d7-93c4-f48d8a48f3ce','Chrome on Linux',1,'2026-08-31 10:53:44','2026-08-31 10:55:39','2026-08-31 10:53:44','2026-08-31 10:55:39'),(6,'TILL06','06','Till 6',NULL,'retail',NULL,'7837adf6-aff0-46c7-b651-c85b7e304566','Chrome on Linux',1,'2026-09-01 10:17:47','2026-09-01 10:17:47','2026-09-01 10:17:47','2026-09-01 10:17:47');
/*!40000 ALTER TABLE `terminals` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ticket_board_statuses`
--

DROP TABLE IF EXISTS `ticket_board_statuses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ticket_board_statuses` (
  `board_id` int(10) unsigned NOT NULL,
  `status_id` int(10) unsigned NOT NULL,
  `sort_order` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`board_id`,`status_id`),
  KEY `ix_tbs_status` (`status_id`),
  CONSTRAINT `ticket_board_statuses_ibfk_1` FOREIGN KEY (`board_id`) REFERENCES `ticket_boards` (`id`) ON DELETE CASCADE,
  CONSTRAINT `ticket_board_statuses_ibfk_2` FOREIGN KEY (`status_id`) REFERENCES `ticket_statuses` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ticket_board_statuses`
--

LOCK TABLES `ticket_board_statuses` WRITE;
/*!40000 ALTER TABLE `ticket_board_statuses` DISABLE KEYS */;
INSERT INTO `ticket_board_statuses` VALUES (1,1,10),(1,2,20),(1,3,30),(1,4,40),(1,5,50),(1,6,60);
/*!40000 ALTER TABLE `ticket_board_statuses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ticket_boards`
--

DROP TABLE IF EXISTS `ticket_boards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ticket_boards` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(60) NOT NULL,
  `description` varchar(190) DEFAULT NULL,
  `sort_order` int(11) NOT NULL DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_tboard_name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ticket_boards`
--

LOCK TABLES `ticket_boards` WRITE;
/*!40000 ALTER TABLE `ticket_boards` DISABLE KEYS */;
INSERT INTO `ticket_boards` VALUES (1,'Support','Everything the desk is working on',10,1,'2026-08-24 09:10:36','2026-08-24 09:10:36');
/*!40000 ALTER TABLE `ticket_boards` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ticket_statuses`
--

DROP TABLE IF EXISTS `ticket_statuses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ticket_statuses` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(40) NOT NULL,
  `name` varchar(60) NOT NULL,
  `tone` enum('neutral','brand','success','warning','danger') NOT NULL DEFAULT 'neutral',
  `sort_order` int(11) NOT NULL DEFAULT 0,
  `clock` enum('','start','pause','end') NOT NULL DEFAULT '',
  `is_landing` tinyint(1) NOT NULL DEFAULT 0,
  `is_closed_stage` tinyint(1) NOT NULL DEFAULT 0,
  `is_cancelled_stage` tinyint(1) NOT NULL DEFAULT 0,
  `is_system` tinyint(1) NOT NULL DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_tstatus_code` (`code`),
  KEY `ix_tstatus_sort` (`sort_order`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ticket_statuses`
--

LOCK TABLES `ticket_statuses` WRITE;
/*!40000 ALTER TABLE `ticket_statuses` DISABLE KEYS */;
INSERT INTO `ticket_statuses` VALUES (1,'new','New','brand',10,'',1,0,0,1,1,'2026-08-24 09:10:36','2026-08-24 09:10:36'),(2,'in_progress','In Progress','brand',20,'start',0,0,0,1,1,'2026-08-24 09:10:36','2026-08-24 09:10:36'),(3,'on_hold','On Hold','warning',30,'pause',0,0,0,1,1,'2026-08-24 09:10:36','2026-08-24 09:10:36'),(4,'resolved','Resolved','success',40,'end',0,1,0,1,1,'2026-08-24 09:10:36','2026-08-24 09:10:36'),(5,'closed','Closed','neutral',50,'',0,1,0,1,1,'2026-08-24 09:10:36','2026-08-24 09:10:36'),(6,'cancelled','Cancelled','danger',60,'',0,1,1,1,1,'2026-08-24 09:10:36','2026-08-24 09:10:36');
/*!40000 ALTER TABLE `ticket_statuses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ticket_time_entries`
--

DROP TABLE IF EXISTS `ticket_time_entries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ticket_time_entries` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ticket_id` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned DEFAULT NULL,
  `user_name` varchar(120) NOT NULL DEFAULT '',
  `started_at` datetime NOT NULL,
  `ended_at` datetime DEFAULT NULL,
  `from_status_id` int(10) unsigned DEFAULT NULL,
  `to_status_id` int(10) unsigned DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `ix_tte_open` (`user_id`,`ended_at`),
  KEY `ix_tte_ticket` (`ticket_id`,`started_at`),
  CONSTRAINT `ticket_time_entries_ibfk_1` FOREIGN KEY (`ticket_id`) REFERENCES `tickets` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ticket_time_entries`
--

LOCK TABLES `ticket_time_entries` WRITE;
/*!40000 ALTER TABLE `ticket_time_entries` DISABLE KEYS */;
/*!40000 ALTER TABLE `ticket_time_entries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tickets`
--

DROP TABLE IF EXISTS `tickets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tickets` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `document_number` varchar(32) DEFAULT NULL,
  `customer_id` int(10) unsigned DEFAULT NULL,
  `contact_id` int(10) unsigned DEFAULT NULL,
  `subject` varchar(190) NOT NULL,
  `description` text DEFAULT NULL,
  `priority` enum('low','normal','high','urgent') NOT NULL DEFAULT 'normal',
  `status_id` int(10) unsigned NOT NULL,
  `status` enum('open','closed','cancelled') NOT NULL DEFAULT 'open',
  `assignee_user_id` int(10) unsigned DEFAULT NULL,
  `assignee_name` varchar(120) NOT NULL DEFAULT '',
  `source` enum('manual','phone','email','walk_in','internal','portal','public_form') NOT NULL DEFAULT 'manual',
  `category` varchar(60) DEFAULT NULL,
  `reported_at` datetime NOT NULL DEFAULT current_timestamp(),
  `due_at` datetime DEFAULT NULL,
  `closed_at` datetime DEFAULT NULL,
  `close_reason` varchar(400) DEFAULT NULL,
  `cancelled_at` datetime DEFAULT NULL,
  `cancel_reason` varchar(400) DEFAULT NULL,
  `job_card_id` int(10) unsigned DEFAULT NULL,
  `sla_policy_id` int(10) unsigned DEFAULT NULL,
  `respond_by` datetime DEFAULT NULL,
  `resolve_by` datetime DEFAULT NULL,
  `responded_at` datetime DEFAULT NULL,
  `responded_by_user_id` int(10) unsigned DEFAULT NULL,
  `user_id` int(10) unsigned DEFAULT NULL,
  `user_name` varchar(120) NOT NULL DEFAULT '',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_ticket_number` (`document_number`),
  KEY `ix_ticket_status` (`status_id`,`status`,`reported_at`),
  KEY `ix_ticket_customer` (`customer_id`,`status`),
  KEY `ix_ticket_assignee` (`assignee_user_id`,`status`),
  KEY `ix_ticket_job` (`job_card_id`),
  KEY `ix_ticket_respond` (`status`,`responded_at`,`respond_by`),
  CONSTRAINT `tickets_ibfk_1` FOREIGN KEY (`job_card_id`) REFERENCES `job_cards` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tickets`
--

LOCK TABLES `tickets` WRITE;
/*!40000 ALTER TABLE `tickets` DISABLE KEYS */;
/*!40000 ALTER TABLE `tickets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tip_payouts`
--

DROP TABLE IF EXISTS `tip_payouts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tip_payouts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned DEFAULT NULL,
  `user_name` varchar(120) NOT NULL DEFAULT '',
  `amount` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `method` enum('cash','wages','transfer','other') NOT NULL DEFAULT 'cash',
  `from_pool` tinyint(1) NOT NULL DEFAULT 0,
  `note` varchar(200) DEFAULT NULL,
  `paid_by` int(10) unsigned DEFAULT NULL,
  `paid_by_name` varchar(120) NOT NULL DEFAULT '',
  `paid_at` datetime NOT NULL DEFAULT current_timestamp(),
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `ix_payout_user` (`user_id`,`paid_at`),
  KEY `ix_payout_paid_at` (`paid_at`),
  KEY `fk_payout_paid_by` (`paid_by`),
  CONSTRAINT `tip_payouts_ibfk_1` FOREIGN KEY (`paid_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `tip_payouts_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tip_payouts`
--

LOCK TABLES `tip_payouts` WRITE;
/*!40000 ALTER TABLE `tip_payouts` DISABLE KEYS */;
/*!40000 ALTER TABLE `tip_payouts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `training_sessions`
--

DROP TABLE IF EXISTS `training_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `training_sessions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `marks` longtext NOT NULL,
  `removed` longtext DEFAULT NULL,
  `started_by` int(10) unsigned DEFAULT NULL,
  `started_name` varchar(120) DEFAULT NULL,
  `ended_by` int(10) unsigned DEFAULT NULL,
  `ended_name` varchar(120) DEFAULT NULL,
  `started_at` datetime NOT NULL DEFAULT current_timestamp(),
  `ended_at` datetime DEFAULT NULL,
  `is_open` tinyint(3) unsigned GENERATED ALWAYS AS (if(`ended_at` is null,1,NULL)) VIRTUAL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_training_open` (`is_open`),
  KEY `ix_training_started` (`started_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `training_sessions`
--

LOCK TABLES `training_sessions` WRITE;
/*!40000 ALTER TABLE `training_sessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `training_sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_employment`
--

DROP TABLE IF EXISTS `user_employment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_employment` (
  `user_id` int(10) unsigned NOT NULL,
  `employee_number` varchar(32) DEFAULT NULL,
  `employment_type` enum('permanent','fixed_term','casual','contractor') NOT NULL DEFAULT 'permanent',
  `pay_basis` enum('hourly','salaried') NOT NULL DEFAULT 'hourly',
  `hourly_rate` decimal(10,4) NOT NULL DEFAULT 0.0000,
  `monthly_salary` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `ordinary_hours_pw` decimal(5,2) NOT NULL DEFAULT 45.00,
  `works_sundays` tinyint(1) NOT NULL DEFAULT 0,
  `hired_on` date DEFAULT NULL,
  `terminated_on` date DEFAULT NULL,
  `leave_cycle_start` date DEFAULT NULL,
  `notes` varchar(400) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `uq_employee_number` (`employee_number`),
  KEY `ix_employment_current` (`terminated_on`,`employment_type`),
  CONSTRAINT `user_employment_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_employment`
--

LOCK TABLES `user_employment` WRITE;
/*!40000 ALTER TABLE `user_employment` DISABLE KEYS */;
INSERT INTO `user_employment` VALUES (1,'EMP1','permanent','salaried',0.0000,5000.0000,45.00,0,'2026-05-01',NULL,'2026-05-01',NULL,'2026-08-24 13:21:25','2026-08-24 13:21:25');
/*!40000 ALTER TABLE `user_employment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_offline_verifiers`
--

DROP TABLE IF EXISTS `user_offline_verifiers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_offline_verifiers` (
  `user_id` int(10) unsigned NOT NULL,
  `device_id` varchar(64) NOT NULL,
  `verifier` varchar(64) NOT NULL,
  `iterations` int(10) unsigned NOT NULL DEFAULT 2400000,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`user_id`,`device_id`),
  CONSTRAINT `user_offline_verifiers_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_offline_verifiers`
--

LOCK TABLES `user_offline_verifiers` WRITE;
/*!40000 ALTER TABLE `user_offline_verifiers` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_offline_verifiers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(120) NOT NULL,
  `control_user_id` int(10) unsigned DEFAULT NULL,
  `email` varchar(190) DEFAULT NULL,
  `mobile` varchar(40) DEFAULT NULL,
  `pin_hash` varchar(60) DEFAULT NULL,
  `user_type` enum('back_office','pos_only') NOT NULL DEFAULT 'pos_only',
  `role_id` int(10) unsigned DEFAULT NULL,
  `sales_rep_id` int(10) unsigned DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `last_login_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_user_control` (`control_user_id`),
  KEY `ix_user_active` (`is_active`,`name`),
  KEY `ix_user_role` (`role_id`),
  KEY `fk_user_rep` (`sales_rep_id`),
  CONSTRAINT `users_ibfk_1` FOREIGN KEY (`sales_rep_id`) REFERENCES `sales_reps` (`id`) ON DELETE SET NULL,
  CONSTRAINT `users_ibfk_2` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'Tiaan Smith',1,'tiaan@point-of-sale.co.za',NULL,'$2b$10$eONRC9ffqjSZy8VPEWapAOoRertSgjXcc6XXecJ.FD75bMLRoXfWC','back_office',1,NULL,1,'2026-09-01 11:05:02','2026-08-06 20:27:06','2026-09-01 11:05:02'),(5,'Etienne Smith',9,'etienne@c-pos.co.za',NULL,NULL,'back_office',1,NULL,1,NULL,'2026-09-03 14:13:12','2026-09-03 14:13:38');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vat_rates`
--

DROP TABLE IF EXISTS `vat_rates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vat_rates` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `vat_type` enum('sales','purchase') NOT NULL,
  `code` varchar(16) NOT NULL,
  `name` varchar(60) NOT NULL,
  `rate` decimal(6,3) NOT NULL DEFAULT 0.000,
  `is_default` tinyint(1) NOT NULL DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_vat_type_code` (`vat_type`,`code`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vat_rates`
--

LOCK TABLES `vat_rates` WRITE;
/*!40000 ALTER TABLE `vat_rates` DISABLE KEYS */;
INSERT INTO `vat_rates` VALUES (1,'sales','STD','Standard rate',15.000,1,1,'2026-08-04 14:12:30','2026-08-04 14:12:30'),(2,'sales','ZERO','Zero rated',0.000,0,1,'2026-08-04 14:12:30','2026-08-04 14:12:30'),(3,'purchase','STD','Standard rate',15.000,1,1,'2026-08-04 14:12:30','2026-08-04 14:12:30'),(4,'purchase','ZERO','Zero rated',0.000,0,1,'2026-08-04 14:12:30','2026-08-04 14:12:30');
/*!40000 ALTER TABLE `vat_rates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `webhook_deliveries`
--

DROP TABLE IF EXISTS `webhook_deliveries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `webhook_deliveries` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `endpoint_id` int(10) unsigned NOT NULL,
  `event` varchar(60) NOT NULL,
  `payload` mediumtext NOT NULL,
  `status` enum('pending','delivered','dead') NOT NULL DEFAULT 'pending',
  `attempts` tinyint(3) unsigned NOT NULL DEFAULT 0,
  `next_attempt_at` datetime NOT NULL,
  `last_status_code` smallint(6) DEFAULT NULL,
  `last_error` varchar(300) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `delivered_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_deliveries_due` (`status`,`next_attempt_at`),
  KEY `ix_deliveries_endpoint` (`endpoint_id`,`id`),
  CONSTRAINT `webhook_deliveries_ibfk_1` FOREIGN KEY (`endpoint_id`) REFERENCES `webhook_endpoints` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `webhook_deliveries`
--

LOCK TABLES `webhook_deliveries` WRITE;
/*!40000 ALTER TABLE `webhook_deliveries` DISABLE KEYS */;
/*!40000 ALTER TABLE `webhook_deliveries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `webhook_endpoints`
--

DROP TABLE IF EXISTS `webhook_endpoints`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `webhook_endpoints` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `url` varchar(500) NOT NULL,
  `secret` varchar(64) NOT NULL,
  `events` varchar(500) NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `last_success_at` datetime DEFAULT NULL,
  `last_failure_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `webhook_endpoints`
--

LOCK TABLES `webhook_endpoints` WRITE;
/*!40000 ALTER TABLE `webhook_endpoints` DISABLE KEYS */;
/*!40000 ALTER TABLE `webhook_endpoints` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'ody10006_master'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-09-03 14:20:55
